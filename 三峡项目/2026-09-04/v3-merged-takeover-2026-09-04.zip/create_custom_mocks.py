# -*- coding: utf-8 -*-
"""
生成测试所需的自定义 mock JSON 文件。

关键场景：
  1. 近期违规公司  — 90天内（2026-03-08 ~ 2026-06-05）有数据，验证正向计数逻辑
  2. 无数据公司    — VerifyResult=0，验证默认值分支
  3. 清算无负责人  — Leader=""，Member 有值，验证 980 fallback 逻辑
  4. 工程资质公司  — 含不同等级工程资质，验证 255 等级提取
  5. 近期招标公司  — PublishDate 在12个月内，验证 958 earlyStop
  6. 涉贷被告公司  — 882/887 企业名称匹配被告，验证贷款纠纷被告逻辑
  7. 近期欠税公司  — 近期多条记录含金额，验证 757 金额累计
  8. 近期行政处罚  — 近期多条含金额，验证 865 金额累计
  9. 近期高管系列  — 764-771 董监高接口近期数据（personName 参数）
"""

import json
import os

BASE_DIR = os.path.join(os.path.dirname(__file__), "mock-files")


def write(path_parts, data):
    """将 data 写入 mock-files/{path_parts...}.json"""
    dir_path = os.path.join(BASE_DIR, *path_parts[:-1])
    os.makedirs(dir_path, exist_ok=True)
    file_path = os.path.join(dir_path, path_parts[-1] + ".json")
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"  created: {file_path}")


def paging(total, page_size=10, page_index=1):
    return {"PageSize": page_size, "PageIndex": page_index, "TotalRecords": total}


# ============================================================
# 工具：生成各类接口的近期记录（日期在 2026-03-08 ~ 2026-06-05 范围内）
# ============================================================

RECENT_DATES = [
    "2026-05-20", "2026-05-10", "2026-04-25", "2026-04-15", "2026-03-20",
]
COURTS = ["北京市朝阳区人民法院", "上海市浦东新区人民法院", "广州市中级人民法院"]
ORG_ID = "aabbccdd11223344556677889900aabb"


# ============================================================
# 1. 通用无数据场景 (VerifyResult=0) — 适用于分页接口
# ============================================================

def make_verify0_paginated(prefix):
    return {
        "Status": "200",
        "Message": "【有效请求】查询成功",
        "OrderNumber": f"{prefix}20260606120000000000",
        "Paging": paging(0),
        "Result": {"VerifyResult": 0, "Data": []},
    }

def make_verify0_list(prefix):
    return {
        "Status": "200",
        "Message": "【有效请求】查询成功",
        "OrderNumber": f"{prefix}20260606120000000000",
        "Result": {"VerifyResult": 0, "Data": []},
    }

def make_status_error(prefix):
    return {
        "Status": "203",
        "Message": "【有效请求】参数异常",
        "OrderNumber": f"{prefix}20260606120000000001",
    }


# ============================================================
# 2. 740 失信核查 — 近期失信公司 (近期 5 条 Liandate 在 90 天内)
# ============================================================

write(["ShixinCheck", "GetList", "近期失信公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "SHIXINCHECK20260606120000000001",
    "Paging": paging(5),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"id740{i:02d}",
                "Liandate": RECENT_DATES[i],
                "Anno": f"（2026）京1001民初{1000+i}号",
                "Executegov": COURTS[i % 3],
                "Executestatus": "全部未履行",
                "Publicdate": RECENT_DATES[i],
                "Executeno": f"（2026）京1001执{2000+i}号",
                "ActionRemark": "有履行能力而拒不履行生效法律文书确定义务",
                "Amount": str(100000 * (i + 1)),
            }
            for i in range(5)
        ],
    },
})

write(["ShixinCheck", "GetList", "无数据公司"], make_verify0_paginated("SHIXINCHECK"))


# ============================================================
# 3. 741 被执行人核查 — 近期被执行公司
# ============================================================

write(["ZhixingCheck", "GetList", "近期被执行公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ZHIXINGCHECK20260606120000000001",
    "Paging": paging(4),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"id741{i:02d}",
                "Liandate": RECENT_DATES[i],
                "Anno": f"（2026）京1001执{3000+i}号",
                "ExecuteGov": COURTS[i % 3],
                "Biaodi": str(200000 * (i + 1)),
                "SuspectedApplicant": f"申请人{i+1}有限公司",
            }
            for i in range(4)
        ],
    },
})

write(["ZhixingCheck", "GetList", "无数据公司"], make_verify0_paginated("ZHIXINGCHECK"))


# ============================================================
# 4. 742 限制高消费核查 — 近期限消公司
# ============================================================

write(["SumptuaryCheck", "GetList", "近期限消公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "SUMPTUARYCHECK20260606120000000001",
    "Paging": paging(3),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"id742{i:02d}",
                "CaseNo": f"（2026）京1001执{4000+i}号",
                "PersonName": f"限消人员{i+1}",
                "PersonId": f"pid742{i:02d}",
                "JudgeDate": RECENT_DATES[i],
                "PublishDate": RECENT_DATES[i],
                "KeyNo": f"kn742{i:02d}",
                "CompanyName": "近期限消公司",
                "Applicant": f"债权人{i+1}有限公司",
                "ApplicantNo": f"an742{i:02d}",
                "Amount": str(500000 * (i + 1)),
                "ExecuteCourt": COURTS[i % 3],
            }
            for i in range(3)
        ],
    },
})

write(["SumptuaryCheck", "GetList", "无数据公司"], make_verify0_paginated("SUMPTUARYCHECK"))


# ============================================================
# 5. 744 司法拍卖核查 — 近期司法拍卖公司
#    ActionRemark 使用中文日期格式（与修复后的 ETL 正则匹配）
# ============================================================

write(["JudicialSaleCheck", "GetList", "近期司法拍卖公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "JUDICIALSALECHECK20260606120000000001",
    "Paging": paging(3),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"id744{i:02d}",
                "Name": f"近期司法拍卖公司名下的房产{i+1}",
                "CaseNo": f"（2026）京1001执{5000+i}号",
                "Executegov": COURTS[i % 3],
                "ActionRemark": f"2026年{3+i}月{10+i}日上午10时至2026年{3+i}月{11+i}日上午10时止",
                "YiWu": str(1000000 * (i + 1)),
                "EvaluationPrice": str(1100000 * (i + 1)),
            }
            for i in range(3)
        ],
    },
})

# 测试旧格式（非中文日期） — earlyStop 不触发，ActionRemark 解析失败跳过
write(["JudicialSaleCheck", "GetList", "旧格式拍卖公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "JUDICIALSALECHECK20260606120000000002",
    "Paging": paging(2),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"id744x{i:02d}",
                "Name": f"旧格式拍卖公司名下的车辆{i+1}",
                "CaseNo": f"（2020）京{i}执001号",
                "Executegov": COURTS[0],
                "ActionRemark": f"2020-01-{10+i:02d}上午10时至2020-01-{11+i:02d}上午10时止",
                "YiWu": "500000",
                "EvaluationPrice": "600000",
            }
            for i in range(2)
        ],
    },
})

write(["JudicialSaleCheck", "GetList", "无数据公司"], make_verify0_paginated("JUDICIALSALECHECK"))


# ============================================================
# 6. 746 环保处罚核查 — 近期环保处罚公司
# ============================================================

write(["EnvPunishmentCheck", "GetList", "近期环保处罚公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ENVPUNISHMENTCHECK20260606120000000001",
    "Paging": paging(2),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"id746{i:02d}",
                "CaseNo": f"环罚字〔2026〕第{100+i}号",
                "PunishDate": RECENT_DATES[i],
                "IllegalType": "",
                "PunishGov": "北京市延庆区生态环境局",
                "PunishAmt": str(50000 * (i + 1)),
            }
            for i in range(2)
        ],
    },
})

write(["EnvPunishmentCheck", "GetList", "无数据公司"], make_verify0_paginated("ENVPUNISHMENTCHECK"))


# ============================================================
# 7. 756 税收违法核查 — 近期税收违法公司
# ============================================================

write(["TaxIllegalCheck", "GetList", "近期税收违法公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "TAXILLEGALCHECK20260606120000000001",
    "Paging": paging(2),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"id756{i:02d}",
                "PublishDate": RECENT_DATES[i],
                "CaseNature": "偷税",
                "TaxGov": "国家税务总局北京市税务局",
                "IllegalContent": f"税收违法行为第{i+1}条",
                "PunishContent": f"罚款{(i+1)*10}万元",
            }
            for i in range(2)
        ],
    },
})

write(["TaxIllegalCheck", "GetList", "无数据公司"], make_verify0_paginated("TAXILLEGALCHECK"))


# ============================================================
# 8. 757 欠税公告核查 — 近期欠税公司（多条，验证金额累计）
# ============================================================

write(["TaxOweNoticeCheck", "GetList", "近期欠税公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "TAXOWENOTICECHECK20260606120000000001",
    "Paging": paging(3),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"id757{i:02d}",
                "Title": ["增值税", "企业所得税", "城市维护建设税"][i],
                "Amount": ["50000.00", "30000.00", "8000.00"][i],   # 合计 88000
                "NewAmount": ["0", "0", "0"][i],
                "PublishDate": RECENT_DATES[i],
                "IssuedBy": "北京市国家税务局",
            }
            for i in range(3)
        ],
    },
})
# 注意：期望 taxarrearsamt 累计 = 88000.00，taxarrearsflag = 3

write(["TaxOweNoticeCheck", "GetList", "无数据公司"], make_verify0_paginated("TAXOWENOTICECHECK"))


# ============================================================
# 9. 758 终本案件核查 — 近期终本案件公司
# ============================================================

write(["EndExecuteCaseCheck", "GetList", "近期终本案件公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ENDEXECUTECASECHECK20260606120000000001",
    "Paging": paging(2),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"id758{i:02d}",
                "CaseNo": f"（2026）京1001执终{6000+i}号",
                "Court": COURTS[0],
                "EndDate": RECENT_DATES[i],
                "LianDate": RECENT_DATES[i],
                "ExecuteSubject": str(1000000 * (i + 1)),
                "UnperformedAmt": str(800000 * (i + 1)),
            }
            for i in range(2)
        ],
    },
})

write(["EndExecuteCaseCheck", "GetList", "无数据公司"], make_verify0_paginated("ENDEXECUTECASECHECK"))


# ============================================================
# 10. 865 行政处罚核查 — 近期行政处罚公司（多条，验证金额累计）
# ============================================================

write(["AdminPenaltyCheck", "GetList", "近期行政处罚公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ADMINPENALTYCHECK20260606120000000001",
    "Paging": paging(3),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"id865{i:02d}",
                "DocNo": f"罚字〔2026〕第{200+i}号",
                "PunishReason": "无证经营",
                "PunishResult": f"罚款{[200000, 150000, 50000][i]}元",
                "PunishOffice": "北京市市场监督管理局",
                "PunishDate": RECENT_DATES[i],
                "Source": "市场监督管理局",
                "SourceCode": "",
                "PunishAmt": str([200000, 150000, 50000][i]),  # 合计 400000
            }
            for i in range(3)
        ],
    },
})
# 期望 adminpenaltyamt 累计 = 400000，adminpenaltycnt = 3

write(["AdminPenaltyCheck", "GetList", "无数据公司"], make_verify0_paginated("ADMINPENALTYCHECK"))


# ============================================================
# 11. 255 资质证书 — 工程资质公司（带等级，验证等级提取）
#     Result 为 JSONArray，无 VerifyResult 包装
# ============================================================

write(["ECICertification", "SearchCertification", "工程资质甲级公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ECICERTIFICATION20260606120000000001",
    "Paging": paging(4),
    "Result": [
        {
            "Id": "cert01",
            "Name": "建筑业企业资质 特级",
            "Type": "000001",
            "StartDate": "2022-01-01",
            "EndDate": "2027-12-31",   # 未过期，距今约 18+ 个月
            "No": "CERT001",
            "TypeDesc": "建筑工程资质",
            "InstitutionList": ["住房和城乡建设部"],
            "Status": "有效",
        },
        {
            "Id": "cert02",
            "Name": "建设工程监理资质 甲级",
            "Type": "000001",
            "StartDate": "2021-06-01",
            "EndDate": "2026-06-30",   # 即将到期（~24天）
            "No": "CERT002",
            "TypeDesc": "建筑工程资质",
            "InstitutionList": ["住房和城乡建设部"],
            "Status": "有效",
        },
        {
            "Id": "cert03",
            "Name": "建筑业企业资质 二级",
            "Type": "000001",
            "StartDate": "2018-01-01",
            "EndDate": "2025-12-31",   # 已过期约 157 天
            "No": "CERT003",
            "TypeDesc": "建筑工程资质",
            "InstitutionList": ["住房和城乡建设部"],
            "Status": "已过期",
        },
        {
            "Id": "cert04",
            "Name": "ISO9001质量管理体系认证",  # 非工程资质，ETL 应过滤掉
            "Type": "000002",
            "StartDate": "2023-01-01",
            "EndDate": "2026-12-31",
            "No": "CERT004",
            "TypeDesc": "管理体系认证",
            "InstitutionList": ["中国质量认证中心"],
            "Status": "有效",
        },
    ],
})
# 期望：quallevel=4（特级最高），qualexpdays=min(正值)=2026-06-30-today≈24天
#       qualstatus="正常"（有效+已过期，无吊销/撤销/注销）

write(["ECICertification", "SearchCertification", "资质吊销公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ECICERTIFICATION20260606120000000002",
    "Paging": paging(2),
    "Result": [
        {
            "Id": "cert11",
            "Name": "建筑业企业资质 一级",
            "Type": "000001",
            "StartDate": "2018-01-01",
            "EndDate": "2023-12-31",
            "No": "CERT011",
            "TypeDesc": "建筑工程资质",
            "InstitutionList": ["住房和城乡建设部"],
            "Status": "吊销",
        },
        {
            "Id": "cert12",
            "Name": "建设工程监理资质 乙级",
            "Type": "000001",
            "StartDate": "2019-01-01",
            "EndDate": "2024-06-30",
            "No": "CERT012",
            "TypeDesc": "建筑工程资质",
            "InstitutionList": ["住房和城乡建设部"],
            "Status": "撤销",
        },
    ],
})
# 期望：qualstatus="吊销/撤销"（去重后以/拼接）

write(["ECICertification", "SearchCertification", "无工程资质公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ECICERTIFICATION20260606120000000003",
    "Paging": paging(2),
    "Result": [
        {"Id": "cert21", "Name": "ISO9001质量管理体系认证", "Type": "000002",
         "StartDate": "2023-01-01", "EndDate": "2026-12-31", "No": "CERT021",
         "TypeDesc": "管理体系认证", "InstitutionList": ["中国质量认证中心"], "Status": "有效"},
        {"Id": "cert22", "Name": "CMMI 5级认证", "Type": "000002",
         "StartDate": "2024-01-01", "EndDate": "2027-01-01", "No": "CERT022",
         "TypeDesc": "能力成熟度模型", "InstitutionList": ["SEI授权机构"], "Status": "有效"},
    ],
})
# 期望：quallevel=""，qualexpdays=0，qualstatus=""


# ============================================================
# 12. 980 清算核查 — 多种清算场景
# ============================================================

write(["LiquidationCheck", "GetDetail", "清算无负责人公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "LIQUIDATIONCHECK20260606120000000001",
    "Result": {
        "VerifyResult": 1,
        "Data": {
            "Leader": "",                          # Leader 为空
            "Member": "李勇;杨建淑;张明",          # Member 有 3 人
        },
    },
})
# 期望：liquidFlag=3（fallback 统计 Member），liquidFlagDetail=[{leader:"", member:"李勇;杨建淑;张明"}]

write(["LiquidationCheck", "GetDetail", "无清算公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "LIQUIDATIONCHECK20260606120000000002",
    "Result": {"VerifyResult": 0, "Data": {}},
})
# 期望：liquidFlag=0

write(["LiquidationCheck", "GetDetail", "接口异常公司"], {
    "Status": "203",
    "Message": "【有效请求】参数异常",
    "OrderNumber": "LIQUIDATIONCHECK20260606120000000003",
})
# 期望：liquidFlag=0，statusCode980qshc=203


# ============================================================
# 13. 958 招投标信息 — 近期招标公司（PublishDate 在 12 月内）
# ============================================================

write(["TenderCheck", "GetList", "近期中标公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "TENDERCHECK20260606120000000001",
    "Paging": paging(4),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"td958{i:02d}",
                "Title": f"信息系统建设采购公告第{i+1}期",
                "ProjectNo": f"WHYX-IT-GKXJ-25-{1000+i}",
                "ChannelName": "中标公告",
                "Province": "北京市",
                "City": "北京市",
                "IndustryDesc": "信息技术",
                "BudgetAmt": str(5000000 * (i + 1)),
                "PublishDate": ["2026-05-01", "2026-03-15", "2025-12-20", "2025-08-10"][i],
                "OpenDate": "2026-04-01",
                "ObtainEndDate": "2026-03-20",
                "BidInviUnitList": [{"KeyNo": "k01", "Name": "三峡融资担保有限公司", "Contact": "张经理", "TelNo": "010-12345678"}],
                "WinBidUnitList": [{"WinBidAmt": str(4000000 * (i + 1)), "KeyNo": "k02", "Name": f"中标单位{i+1}有限公司", "Contact": "李总", "TelNo": "010-87654321"}],
                "AgentUnitList": [],
                "BidProgressList": ["招标公告", "中标公告"],
                "BidEndDate": "2026-03-25 17:00:00",
                "ContentUrl": f"https://www.example.com/tender/958{i:02d}",
                "ContractEndTime": "2027-06-30",
            }
            for i in range(4)
        ],
    },
})
# PublishDate: 2026-05-01(近期✓), 2026-03-15(近期✓), 2025-12-20(近期✓), 2025-08-10(近期✓)
# 今天2026-06-06，12个月前=2025-06-06，4条均在12个月内
# 期望：bidinfo="4"

write(["TenderCheck", "GetList", "超期招标公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "TENDERCHECK20260606120000000002",
    "Paging": paging(3),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"td958x{i:02d}",
                "Title": f"旧项目采购第{i+1}期",
                "ProjectNo": f"WHYX-IT-GKXJ-23-{2000+i}",
                "ChannelName": "中标公告",
                "Province": "北京市", "City": "北京市", "IndustryDesc": "信息技术",
                "BudgetAmt": "3000000",
                "PublishDate": ["2025-05-01", "2025-03-15", "2024-10-20"][i],  # 都在12个月前
                "OpenDate": "2025-04-01", "ObtainEndDate": "2025-03-20",
                "BidInviUnitList": [{"KeyNo": "k03", "Name": "旧招标单位", "Contact": "王经理", "TelNo": "010-11111111"}],
                "WinBidUnitList": [{"WinBidAmt": "2500000", "KeyNo": "k04", "Name": "旧中标单位", "Contact": "赵总", "TelNo": "010-22222222"}],
                "AgentUnitList": [],
                "BidProgressList": ["招标公告", "中标公告"],
                "BidEndDate": "2025-03-25 17:00:00",
                "ContentUrl": f"https://www.example.com/tender/old{i:02d}",
                "ContractEndTime": "2026-06-30",
            }
            for i in range(3)
        ],
    },
})
# 3条均在12个月前，earlyStop 在第1条即触发，bidinfo="0"

write(["TenderCheck", "GetList", "无中标公司"], make_verify0_paginated("TENDERCHECK"))


# ============================================================
# 14. 882 法院公告核查 — 涉贷被告公司（企业作为被告，近90天内借款合同纠纷）
# ============================================================

write(["CourtNoticeCheck", "GetList", "涉贷被告公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "COURTNOTICECHECK20260606120000000001",
    "Paging": paging(3),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"cn882{i:02d}",
                "CaseNo": f"（2026）京1001民初{7000+i}号",
                "CaseReason": ["借款合同纠纷", "金融借款合同纠纷", "民间借贷纠纷"][i],
                "Category": "起诉状、上诉状副本",
                "Court": COURTS[0],
                "PublishDate": RECENT_DATES[i],
                "ProsecutorList": [{"KeyNo": "p01", "Name": f"原告银行{i+1}"}],
                "DefendantList": [{"KeyNo": "d01", "Name": "涉贷被告公司"}],
                "RoleList": [
                    {"RoleType": "0", "RoleName": "原告/上诉人",
                     "RoleItemList": [{"KeyNo": "p01", "Name": f"原告银行{i+1}"}]},
                    {"RoleType": "1", "RoleName": "被告/被上诉人",
                     "RoleItemList": [{"KeyNo": "d01", "Name": "涉贷被告公司"}]},
                ],
            }
            for i in range(3)
        ],
    },
})
# searchKey="涉贷被告公司"，3条均为被告+借款纠纷+近90天内
# 期望：ent3mCourtNoticeLoanDisputeDefendantCntQcc=3

write(["CourtNoticeCheck", "GetList", "涉贷原告公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "COURTNOTICECHECK20260606120000000002",
    "Paging": paging(2),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"cn882p{i:02d}",
                "CaseNo": f"（2026）京1001民初{8000+i}号",
                "CaseReason": "借款合同纠纷",
                "Category": "起诉状、上诉状副本",
                "Court": COURTS[0],
                "PublishDate": RECENT_DATES[i],
                "ProsecutorList": [{"KeyNo": "p02", "Name": "涉贷原告公司"}],
                "DefendantList": [{"KeyNo": "d02", "Name": f"被告公司{i+1}"}],
                "RoleList": [
                    {"RoleType": "0", "RoleName": "原告/上诉人",
                     "RoleItemList": [{"KeyNo": "p02", "Name": "涉贷原告公司"}]},
                    {"RoleType": "1", "RoleName": "被告/被上诉人",
                     "RoleItemList": [{"KeyNo": "d02", "Name": f"被告公司{i+1}"}]},
                ],
            }
            for i in range(2)
        ],
    },
})
# searchKey="涉贷原告公司"，企业为原告，ETL 只统计被告，期望=0

write(["CourtNoticeCheck", "GetList", "无数据公司"], make_verify0_paginated("COURTNOTICECHECK"))


# ============================================================
# 15. 887 裁判文书核查 — 三类场景（被告借款纠纷、原告、被保全）
# ============================================================

write(["JudgmentDocCheck", "GetList", "涉贷被告公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "JUDGMENTDOCCHECK20260606120000000001",
    "Paging": paging(5),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            # 借款纠纷被告（2条）
            {
                "Id": "jd887_01", "CaseName": "某银行与涉贷被告公司借款合同纠纷一审民事判决书",
                "CaseReason": "借款合同纠纷", "CaseNo": "（2024）京01民初001号",
                "Amount": "500000", "JudgeDate": "2024-03-01",
                "PartyList": [
                    {"Name": "某银行", "RoleType": "原告", "Statement": "", "Keyno": "p1"},
                    {"Name": "涉贷被告公司", "RoleType": "被告", "Statement": "", "Keyno": "d1"},
                ],
                "CaseType": "ms",
            },
            {
                "Id": "jd887_02", "CaseName": "信用社与涉贷被告公司金融借款合同纠纷",
                "CaseReason": "金融借款合同纠纷", "CaseNo": "（2024）京01民初002号",
                "Amount": "300000", "JudgeDate": "2024-05-01",
                "PartyList": [
                    {"Name": "信用社", "RoleType": "原告", "Statement": "", "Keyno": "p2"},
                    {"Name": "涉贷被告公司", "RoleType": "被告", "Statement": "", "Keyno": "d2"},
                ],
                "CaseType": "ms",
            },
            # 原告案件（1条）
            {
                "Id": "jd887_03", "CaseName": "涉贷被告公司与某供应商合同纠纷",
                "CaseReason": "买卖合同纠纷", "CaseNo": "（2024）京01民初003号",
                "Amount": "200000", "JudgeDate": "2024-04-01",
                "PartyList": [
                    {"Name": "涉贷被告公司", "RoleType": "原告", "Statement": "胜诉", "Keyno": "p3"},
                    {"Name": "某供应商", "RoleType": "被告", "Statement": "", "Keyno": "d3"},
                ],
                "CaseType": "ms",
            },
            # 被保全案件（1条）
            {
                "Id": "jd887_04", "CaseName": "某银行申请财产保全",
                "CaseReason": "财产保全", "CaseNo": "（2024）京01民初004号",
                "Amount": "100000", "JudgeDate": "2024-06-01",
                "PartyList": [
                    {"Name": "某银行", "RoleType": "原告", "Statement": "", "Keyno": "p4"},
                    {"Name": "涉贷被告公司", "RoleType": "被告", "Statement": "", "Keyno": "d4"},
                ],
                "CaseType": "bq",  # 保全类型
            },
            # 非相关案件（1条，不应计入任何类别）
            {
                "Id": "jd887_05", "CaseName": "某公司劳动争议",
                "CaseReason": "劳动争议", "CaseNo": "（2024）京01民初005号",
                "Amount": "50000", "JudgeDate": "2024-02-01",
                "PartyList": [
                    {"Name": "员工甲", "RoleType": "原告", "Statement": "", "Keyno": "p5"},
                    {"Name": "涉贷被告公司", "RoleType": "被告", "Statement": "", "Keyno": "d5"},
                ],
                "CaseType": "ms",
            },
        ],
    },
})
# 期望：loandisputecnt=2，defendamt=500000+300000=800000
#       ent3mselfprosecutioncountqcc=1，ent3mselfprosecutionsingleamountqcc=200000
#       preservcnt=1

write(["JudgmentDocCheck", "GetList", "无数据公司"], make_verify0_paginated("JUDGMENTDOCCHECK"))


# ============================================================
# 16. 748 严重违法核查 / 739 经营异常核查 — 无数据场景
# ============================================================

write(["SeriousIllegalCheck", "GetList", "无数据公司"], make_verify0_list("SERIOUSILLEGALCHECK"))
write(["ExceptionCheck", "GetList", "无数据公司"], make_verify0_list("EXCEPTIONCHECK"))


# ============================================================
# 17. 751/752/761 — 无数据场景
# ============================================================

write(["EquityPledgedCheck", "GetList", "无数据公司"], make_verify0_paginated("EQUITYPLEDGEDCHECK"))
write(["EquityFreezeCheck", "GetList", "无数据公司"], make_verify0_paginated("EQUITYFREEZECHECK"))
write(["BankruptcyCheck", "GetList", "无数据公司"], make_verify0_paginated("BANKRUPTCYCHECK"))


# ============================================================
# 18. 761 破产重整核查 — 近期有破产记录（仅读 TotalRecords，不 earlyStop）
# ============================================================

write(["BankruptcyCheck", "GetList", "破产重整公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "BANKRUPTCYCHECK20260606120000000001",
    "Paging": paging(3),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"bk761{i:02d}",
                "CaseNo": f"（2024）京1001破申{100+i}号",
                "PublicDate": ["2024-03-01", "2024-01-15", "2023-11-20"][i],
                "ApplicantList": [{"Name": f"申请人{i+1}有限公司", "KeyNo": f"ap761{i:02d}"}],
                "RespondentList": [{"Name": "破产重整公司", "KeyNo": f"rd761{i:02d}"}],
            }
            for i in range(3)
        ],
    },
})
# 761 ETL 只读 TotalRecords=3，不逐条过滤日期，期望 bankruptflag=3


# ============================================================
# 19. 752 股权冻结核查 — 冻结中（FreezeEndDate>今天）
# ============================================================

write(["EquityFreezeCheck", "GetList", "冻结股权公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "EQUITYFREEZECHECK20260606120000000001",
    "Paging": paging(3),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"ef752{i:02d}",
                "ExecuteName": f"被冻结人{i+1}",
                "ExecuteKeyNo": f"ek752{i:02d}",
                "EquityAmount": f"{(i+1)*100}万元人民币",
                "ExecuteCourt": COURTS[0],
                "ExecutionNoticeNum": f"（2025）法执字第{300+i}号",
                "Status": ["股权冻结|冻结", "股权冻结|冻结", "股权冻结|解冻"][i],  # 前两条冻结，第三条已解冻
                "FreezeStartDate": "2025-01-01",
                "FreezeEndDate": ["2027-12-31", "2027-06-30", "2025-12-31"][i],  # 前两条未过期，第三条已过期
                "RelatedInfo": {"KeyNo": "ri752", "Name": "冻结股权公司"},
            }
            for i in range(3)
        ],
    },
})
# 期望：equityfreezeflag=2（仅前两条满足：FreezeEndDate>今天 且 Status含"冻结"不含"解除"）

# ============================================================
# 20. 751 股权出质 — 有效状态
# ============================================================

write(["EquityPledgedCheck", "GetList", "股权出质公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "EQUITYPLEDGEDCHECK20260606120000000001",
    "Paging": paging(3),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": f"ep751{i:02d}",
                "RegistNo": f"股质登记字〔2024〕第{400+i}号",
                "PledgorName": f"出质人{i+1}",
                "PledgeeName": f"质权人银行{i+1}",
                "RegDate": ["2024-01-01", "2024-06-01", "2023-01-01"][i],
                "Status": ["有效", "无效", "有效"][i],  # 第2条无效，不计入
                "RelatedCompanyName": "股权出质公司",
                "PledgedAmount": f"{(i+1)*1000}万股",
                "PledgeeList": [{"Name": f"质权人银行{i+1}", "KeyNo": f"pl751{i:02d}"}],
                "PledgorList": [{"Name": f"出质人{i+1}", "KeyNo": f"pr751{i:02d}"}],
            }
            for i in range(3)
        ],
    },
})
# 期望：equitypledgeflag=2（仅 Status=="有效" 的2条）

# ============================================================
# 21. 764-771 董监高接口 — 近期有记录的高管
# ============================================================

for api, route, prefix, records_func in [
    ("764", "PersonSXCheck/GetList", "PERSONSXCHECK",
     lambda i: {
         "Id": f"ps764{i:02d}", "Liandate": RECENT_DATES[i],
         "Anno": f"（2026）京1001执{9000+i}号", "Executegov": COURTS[0],
         "Executestatus": "全部未履行", "Publicdate": RECENT_DATES[i],
         "Executeno": f"（2026）京1001执{9100+i}号",
         "ActionRemark": "有履行能力而拒不履行", "Amount": str(300000*(i+1)),
     }),
    ("765", "PersonZXCheck/GetList", "PERSONZXCHECK",
     lambda i: {
         "Id": f"pz765{i:02d}", "Liandate": RECENT_DATES[i],
         "Anno": f"（2026）京1001执{9200+i}号", "ExecuteGov": COURTS[0],
         "Biaodi": str(400000*(i+1)), "SuspectedApplicant": f"债权方{i+1}",
     }),
    ("766", "PersonSumptuaryCheck/GetList", "PERSONSUMPTUARYCHECK",
     lambda i: {
         "Id": f"pm766{i:02d}", "CaseNo": f"（2026）京1001执{9300+i}号",
         "LimitObject": "近期违规高管供职公司", "LimitObjectKeyNo": f"lo766{i:02d}",
         "RelatedName": "近期违规高管", "RelatedKeyNo": f"rk766{i:02d}",
         "JudgeDate": RECENT_DATES[i], "PublishDate": RECENT_DATES[i],
         "Applicant": f"申请人{i+1}", "ApplicantKeyNo": f"ak766{i:02d}",
     }),
    ("771", "PersonEndExCaseCheck/GetList", "PERSONENDEXCASECHECK",
     lambda i: {
         "Id": f"pe771{i:02d}", "CaseNo": f"（2026）京1001执终{9400+i}号",
         "Court": COURTS[0], "EndDate": RECENT_DATES[i], "LianDate": RECENT_DATES[i],
         "ExecuteSubject": str(1000000*(i+1)), "UnperformedAmt": str(800000*(i+1)),
     }),
]:
    route_parts = route.split("/")
    write(route_parts + [f"近期违规高管__personName=近期违规高管"], {
        "Status": "200", "Message": "【有效请求】查询成功",
        "OrderNumber": f"{prefix}20260606120000000001",
        "Paging": paging(2),
        "Result": {
            "VerifyResult": 1,
            "Data": [records_func(i) for i in range(2)],
        },
    })
    write(route_parts + [f"无数据公司__personName=无违规高管"], make_verify0_paginated(prefix))

print("\n✅ 所有自定义 mock 文件创建完成！")
