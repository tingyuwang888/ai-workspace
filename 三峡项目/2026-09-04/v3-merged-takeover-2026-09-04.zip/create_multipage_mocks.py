# -*- coding: utf-8 -*-
"""
创建多页 earlyStop / 跨页累计 mock 文件
基准日期: 2026-06-06
90天截止: 2026-03-08
12月截止: 2025-06-06

设计思路:
  - TotalRecords=50，pageSize=10 → 5页
  - 前25条: 日期在截止线内 → 页1(0-9)、页2(10-19) 全部计入，页3(20-29) 前5条计入
  - 第26条(index=25): 日期刚好越过截止线 → earlyStop 在页3第6条触发
  - 后24条(26-49): 从未被翻到
  - 期望计数 = 25
"""

import json, os

BASE_DIR = os.path.join(os.path.dirname(__file__), "mock-files")

def write(path_parts, data):
    d = os.path.join(BASE_DIR, *path_parts[:-1])
    os.makedirs(d, exist_ok=True)
    fp = os.path.join(d, path_parts[-1] + ".json")
    with open(fp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"  created: {fp}")

COURTS = ["北京市朝阳区人民法院", "上海市浦东新区人民法院", "广州市中级人民法院"]

# 25 条近期日期(降序), 1 条恰好越界, 24 条远期
RECENT_LIANDATES = [
    "2026-06-01","2026-05-28","2026-05-25","2026-05-22","2026-05-19",
    "2026-05-16","2026-05-13","2026-05-10","2026-05-07","2026-05-04",
    "2026-05-01","2026-04-28","2026-04-25","2026-04-22","2026-04-19",
    "2026-04-16","2026-04-13","2026-04-10","2026-04-07","2026-04-04",
    "2026-04-01","2026-03-29","2026-03-26","2026-03-23","2026-03-10",
]
EARLY_STOP_DATE = "2026-03-07"   # 91天前，恰好触发 earlyStop
OLD_DATE        = "2022-08-10"   # 远期，不会被处理到

# 25 条近期 PublishDate（958 用，12个月截止=2025-06-06）
RECENT_PUBDATES_958 = [
    "2026-05-20","2026-05-10","2026-04-25","2026-04-15","2026-04-01",
    "2026-03-20","2026-03-10","2026-02-28","2026-02-15","2026-02-01",
    "2026-01-20","2026-01-10","2025-12-25","2025-12-10","2025-11-30",
    "2025-11-15","2025-11-01","2025-10-20","2025-10-01","2025-09-20",
    "2025-09-01","2025-08-20","2025-08-01","2025-07-15","2025-06-20",
]
EARLY_STOP_DATE_958 = "2025-06-05"   # 刚好越过12个月截止(2025-06-06)
OLD_DATE_958        = "2024-01-01"


# ────────────────────────────────────────────────────────────
# 740 失信核查  多页 earlyStop
# ────────────────────────────────────────────────────────────
records_740 = []
for i, d in enumerate(RECENT_LIANDATES):
    records_740.append({
        "Id": f"mp740r{i:02d}", "Liandate": d,
        "Anno": f"（2026）京100{i%3}执{10000+i}号",
        "Executegov": COURTS[i % 3], "Executestatus": "全部未履行",
        "Publicdate": d, "Executeno": f"（2026）京100{i%3}民初{20000+i}号",
        "ActionRemark": "有履行能力而拒不履行", "Amount": str(100000 * (i+1)),
    })
# index=25: earlyStop 触发点
records_740.append({
    "Id": "mp740early", "Liandate": EARLY_STOP_DATE,
    "Anno": "（2026）京1000执99999号", "Executegov": COURTS[0],
    "Executestatus": "全部未履行", "Publicdate": EARLY_STOP_DATE,
    "Executeno": "（2026）京1000民初99999号",
    "ActionRemark": "earlyStop触发点", "Amount": "1",
})
# index=26-49: 永远不会被处理到
for i in range(24):
    records_740.append({
        "Id": f"mp740old{i:02d}", "Liandate": OLD_DATE,
        "Anno": f"（2020）京100{i%3}执{30000+i}号",
        "Executegov": COURTS[0], "Executestatus": "全部未履行",
        "Publicdate": OLD_DATE, "Executeno": f"（2020）京1001民初{30000+i}号",
        "ActionRemark": "已超期，earlyStop后不再处理", "Amount": "0",
    })

write(["ShixinCheck", "GetList", "多页失信企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "SHIXINCHECK20260606500000000001",
    "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 50},
    "Result": {"VerifyResult": 1, "Data": records_740},
})
# pageSize=10 → 5页
# 页1(0-9):   10条近期 → 10条计入
# 页2(10-19): 10条近期 → 10条计入
# 页3(20-29): 前5条(20-24)近期 → 5条计入，第6条(25)=2026-03-07 earlyStop → break
# 页4/5:      永远不翻
# 期望: dishonestcnt=25


# ────────────────────────────────────────────────────────────
# 742 限制高消费  多页 earlyStop
# ────────────────────────────────────────────────────────────
records_742 = []
for i, d in enumerate(RECENT_LIANDATES):
    records_742.append({
        "Id": f"mp742r{i:02d}", "CaseNo": f"（2026）京100{i%3}执{40000+i}号",
        "PersonName": f"限消人员{i+1}", "PersonId": f"pid742mp{i:02d}",
        "JudgeDate": d, "PublishDate": d,
        "KeyNo": f"kn742mp{i:02d}", "CompanyName": "多页限消企业",
        "Applicant": f"申请人{i+1}有限公司", "ApplicantNo": f"an742mp{i:02d}",
        "Amount": str(50000 * (i+1)), "ExecuteCourt": COURTS[i % 3],
    })
records_742.append({
    "Id": "mp742early", "CaseNo": "（2026）京1000执88888号",
    "PersonName": "earlyStop人", "PersonId": "pidearlyXX",
    "JudgeDate": EARLY_STOP_DATE, "PublishDate": EARLY_STOP_DATE,
    "KeyNo": "knearly", "CompanyName": "多页限消企业",
    "Applicant": "触发earlyStop申请人", "ApplicantNo": "anearly",
    "Amount": "1", "ExecuteCourt": COURTS[0],
})
for i in range(24):
    records_742.append({
        "Id": f"mp742old{i:02d}", "CaseNo": f"（2020）京100{i%3}执{50000+i}号",
        "PersonName": f"历史人员{i+1}", "PersonId": f"pid742old{i:02d}",
        "JudgeDate": OLD_DATE, "PublishDate": OLD_DATE,
        "KeyNo": f"kn742old{i:02d}", "CompanyName": "多页限消企业",
        "Applicant": "历史申请人", "ApplicantNo": f"an742old{i:02d}",
        "Amount": "0", "ExecuteCourt": COURTS[0],
    })

write(["SumptuaryCheck", "GetList", "多页限消企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "SUMPTUARYCHECK20260606500000000001",
    "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 50},
    "Result": {"VerifyResult": 1, "Data": records_742},
})
# pageSize=10 → 5页，页3第6条(index=25)触发earlyStop
# 期望: highconsumecnt=25


# ────────────────────────────────────────────────────────────
# 958 招投标  多页 earlyStop（12个月窗口）
# ────────────────────────────────────────────────────────────
records_958 = []
COMPANY_NAMES = ["三峡工程建设公司", "长江水利开发有限公司", "大坝建设集团有限公司",
                 "峡谷投资管理有限公司", "融通担保服务有限公司"]
for i, d in enumerate(RECENT_PUBDATES_958):
    win = [{"WinBidAmt": str(5000000*(i+1)), "KeyNo": f"kw958{i:02d}",
            "Name": COMPANY_NAMES[i%5], "Contact": "张总", "TelNo": "010-12345678"}]
    records_958.append({
        "Id": f"mp958r{i:02d}",
        "Title": f"第{i+1}期工程建设信息系统采购公告",
        "ProjectNo": f"WHYX-IT-GKXJ-25-{2000+i}",
        "ChannelName": "中标公告",
        "Province": "湖北省", "City": "宜昌市",
        "IndustryDesc": "工程建筑",
        "BudgetAmt": str(6000000*(i+1)),
        "PublishDate": d,
        "OpenDate": d, "ObtainEndDate": d,
        "BidInviUnitList": [{"KeyNo": f"bi958{i:02d}", "Name": "三峡融担招标方",
                              "Contact": "李总", "TelNo": "0717-12345678"}],
        "WinBidUnitList": win,
        "AgentUnitList": [],
        "BidProgressList": ["招标公告", "中标公告"],
        "BidEndDate": f"{d} 17:00:00",
        "ContentUrl": f"https://example.com/tender/mp958{i:02d}",
        "ContractEndTime": "2027-12-31",
    })

# index=25: earlyStop 触发点（PublishDate刚好越过12个月截止）
records_958.append({
    "Id": "mp958early",
    "Title": "earlyStop触发点-12个月截止",
    "ProjectNo": "WHYX-IT-STOP-00-0000",
    "ChannelName": "中标公告",
    "Province": "湖北省", "City": "宜昌市",
    "IndustryDesc": "工程建筑",
    "BudgetAmt": "1000000",
    "PublishDate": EARLY_STOP_DATE_958,
    "OpenDate": EARLY_STOP_DATE_958, "ObtainEndDate": EARLY_STOP_DATE_958,
    "BidInviUnitList": [{"KeyNo": "biEarly", "Name": "触发earlyStop招标方",
                          "Contact": "停止", "TelNo": "000-00000000"}],
    "WinBidUnitList": [{"WinBidAmt": "999", "KeyNo": "kwEarly",
                         "Name": "earlyStop中标方", "Contact": "停止", "TelNo": "000"}],
    "AgentUnitList": [],
    "BidProgressList": ["招标公告"],
    "BidEndDate": f"{EARLY_STOP_DATE_958} 17:00:00",
    "ContentUrl": "https://example.com/tender/early",
    "ContractEndTime": "2026-06-30",
})

for i in range(24):
    records_958.append({
        "Id": f"mp958old{i:02d}",
        "Title": f"历史项目-永远不被翻到-{i+1}",
        "ProjectNo": f"WHYX-OLD-HIST-20-{3000+i}",
        "ChannelName": "中标公告",
        "Province": "湖北省", "City": "宜昌市", "IndustryDesc": "工程建筑",
        "BudgetAmt": "0",
        "PublishDate": OLD_DATE_958,
        "OpenDate": OLD_DATE_958, "ObtainEndDate": OLD_DATE_958,
        "BidInviUnitList": [], "WinBidUnitList": [], "AgentUnitList": [],
        "BidProgressList": [], "BidEndDate": f"{OLD_DATE_958} 09:00:00",
        "ContentUrl": f"https://example.com/tender/old{i:02d}",
        "ContractEndTime": "2024-12-31",
    })

write(["TenderCheck", "GetList", "多页招标企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "TENDERCHECK20260606500000000001",
    "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 50},
    "Result": {"VerifyResult": 1, "Data": records_958},
})
# pageSize=10 → 5页（keyword=多页招标企业，msgType=4）
# 页1(0-9):   10条在12月内 → 10条计入
# 页2(10-19): 10条在12月内 → 10条计入
# 页3(20-29): 前5条(20-24)在12月内 → 5条计入，第6条(25)=2025-06-05 earlyStop
# 页4/5:      永远不翻
# 期望: bidinfo='25'


# ────────────────────────────────────────────────────────────
# 255 资质证书  多页跨页累计（无earlyStop，取最高等级）
# ────────────────────────────────────────────────────────────
# 3页，pageSize=10，TotalRecords=30
# 页1(0-9): 含二级、三级、非工程资质
# 页2(10-19): 含一级(甲级)→ 更新 maxLevel=3
# 页3(20-29): 含特级 → 更新 maxLevel=4
# 期望: quallevel='4'（跨页累计取最大）
certs_255 = []
# 页1: 3条工程资质(三级、二级、三级) + 7条非工程资质
LEVEL_NAMES_P1 = [
    "建筑业企业资质 三级", "建筑业企业资质 二级", "建筑业企业资质 三级",
    "ISO9001质量管理体系认证", "CMMI 5级认证", "ISO14001环境管理体系认证",
    "高新技术企业证书", "安全生产许可证", "信息系统集成及服务资质", "软件企业认定证书",
]
for i, nm in enumerate(LEVEL_NAMES_P1):
    certs_255.append({
        "Id": f"c255p1{i:02d}", "Name": nm, "Type": "000001",
        "StartDate": "2022-01-01", "EndDate": "2027-12-31",
        "No": f"CERT_P1_{i:04d}", "TypeDesc": "建筑工程资质",
        "InstitutionList": ["住房和城乡建设部"], "Status": "有效",
    })
# 页2: 3条工程资质(甲级=3) + 7条非工程
LEVEL_NAMES_P2 = [
    "建设工程施工总承包资质 甲级", "建设工程监理资质 甲级", "工程设计资质 甲级",
    "ITSS信息技术服务标准", "CCC强制性产品认证", "计算机信息系统集成资质",
    "信息系统安全等级保护", "ISO27001信息安全管理体系认证", "软件企业认定证书", "CMMI 5级认证",
]
for i, nm in enumerate(LEVEL_NAMES_P2):
    certs_255.append({
        "Id": f"c255p2{i:02d}", "Name": nm, "Type": "000001",
        "StartDate": "2022-01-01", "EndDate": "2026-08-31",
        "No": f"CERT_P2_{i:04d}", "TypeDesc": "建筑工程资质",
        "InstitutionList": ["住房和城乡建设部"], "Status": "有效",
    })
# 页3: 1条特级(最高) + 2条一级 + 7条非工程
LEVEL_NAMES_P3 = [
    "建筑业企业资质 特级",          # maxLevel=4 在第3页才出现
    "安防工程企业资质 一级",
    "电子与智能化工程专业承包 一级",
    "高新技术企业证书", "安全生产许可证", "ISO9001质量管理体系认证",
    "ITSS信息技术服务标准", "软件企业认定证书", "信息系统集成及服务资质", "CCC强制性产品认证",
]
for i, nm in enumerate(LEVEL_NAMES_P3):
    end_date = "2027-06-30" if i == 0 else "2026-09-30"
    certs_255.append({
        "Id": f"c255p3{i:02d}", "Name": nm, "Type": "000001",
        "StartDate": "2022-01-01", "EndDate": end_date,
        "No": f"CERT_P3_{i:04d}", "TypeDesc": "建筑工程资质",
        "InstitutionList": ["住房和城乡建设部"], "Status": "有效",
    })

write(["ECICertification", "SearchCertification", "多页工程资质公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ECICERTIFICATION20260606500000000001",
    "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 30},
    "Result": certs_255,    # 255接口Result直接是JSONArray
})
# pageSize=10 → 3页，255 无 earlyStop，全部翻完
# 页1: maxLevel=2（三级/二级中最高=2）
# 页2: maxLevel=3（甲级出现，更新）
# 页3: maxLevel=4（特级出现，更新）
# 期望: quallevel='4'（跨页累计取最大等级）


print("\n✅ 多页 mock 文件全部创建完成！")
print("   - ShixinCheck/GetList/多页失信企业.json   (5页，页3earlyStop，期望count=25)")
print("   - SumptuaryCheck/GetList/多页限消企业.json (5页，页3earlyStop，期望count=25)")
print("   - TenderCheck/GetList/多页招标企业.json    (5页，页3earlyStop，期望bidinfo='25')")
print("   - ECICertification/SearchCertification/多页工程资质公司.json (3页，跨页累计，期望quallevel='4')")
