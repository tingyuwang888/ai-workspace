# -*- coding: utf-8 -*-
"""
为全量测试生成新的 mock JSON 文件。
基准日期 2026-06-06
90天截止: 2026-03-08  (daysAgo>=90 即触发earlyStop)
边界日期: 2026-03-08  (恰好90天前)
12月截止: 2025-06-06
"""
import json, os

BASE_DIR = os.path.join(os.path.dirname(__file__), "mock-files")
COURTS = ["北京市朝阳区人民法院", "上海市浦东新区人民法院", "广州市中级人民法院"]
TAX_GOVS = ["国家税务总局北京市税务局", "国家税务总局上海市税务局"]
PENALTY_OFFICES = ["北京市市场监督管理局", "上海市生态环境局"]

# 近期日期（90天内，用于各接口测试）
RECENT_5  = ["2026-05-20","2026-05-10","2026-04-25","2026-04-15","2026-04-01"]
RECENT_15 = RECENT_5 + ["2026-03-25","2026-03-22","2026-03-20","2026-03-18","2026-03-16",
                          "2026-03-14","2026-03-12","2026-03-11","2026-03-10","2026-03-09"]
BOUNDARY  = "2026-03-08"  # 恰好=90天前，daysAgo=90，触发earlyStop
OLD_5     = ["2022-08-10","2022-05-20","2023-01-15","2022-11-30","2023-03-08"]


def write(path_parts, data):
    d = os.path.join(BASE_DIR, *path_parts[:-1])
    os.makedirs(d, exist_ok=True)
    fp = os.path.join(d, path_parts[-1] + ".json")
    with open(fp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"  ✓ {fp.replace(BASE_DIR+'/', '')}")

def paginated(data_arr, order_prefix):
    n = len(data_arr)
    return {
        "Status": "200", "Message": "【有效请求】查询成功",
        "OrderNumber": f"{order_prefix}20260606",
        "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": n},
        "Result": {"VerifyResult": 1, "Data": data_arr}
    }

def verify0(order_prefix):
    return {
        "Status": "200", "Message": "【有效请求】查询成功",
        "OrderNumber": f"{order_prefix}20260606",
        "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 0},
        "Result": {"VerifyResult": 0, "Data": []}
    }

def non200(order_prefix, code="400"):
    return {"Status": code, "Message": "【有效请求】参数异常",
            "OrderNumber": f"{order_prefix}20260606"}


# ========================================================================
# 740 失信核查
# ========================================================================
print("=== 740 失信核查 ===")

# 单条记录（全字段）
write(["ShixinCheck","GetList","单条失信企业"], paginated([{
    "Id": "s740_01", "Liandate": "2026-05-20", "Anno": "（2026）京1001执10001号",
    "Executegov": COURTS[0], "Executestatus": "全部未履行",
    "Publicdate": "2026-05-20", "Executeno": "（2026）京1001民初20001号",
    "ActionRemark": "有履行能力而拒不履行生效法律文书确定义务",
    "Amount": "1500000"
}], "SHIXINCHECK"))

# 3近期+1超期（单页内中途earlyStop，count=3）
write(["ShixinCheck","GetList","混合日期失信企业"], paginated([
    {"Id": f"s740_m{i}", "Liandate": RECENT_5[i], "Anno": f"（2026）京1001执1000{i}号",
     "Executegov": COURTS[i%3], "Executestatus": "全部未履行", "Publicdate": RECENT_5[i],
     "Executeno": f"（2026）京1001民初2000{i}号", "ActionRemark": "违反财产报告制度",
     "Amount": str(100000*(i+1))} for i in range(3)
] + [
    {"Id": "s740_old", "Liandate": BOUNDARY, "Anno": "（2022）京1001执99999号",
     "Executegov": COURTS[0], "Executestatus": "全部未履行", "Publicdate": BOUNDARY,
     "Executeno": "（2022）京1001民初99999号", "ActionRemark": "earlyStop触发点",
     "Amount": "0"}
], "SHIXINCHECK"))
# count期望=3 (第4条 Liandate=2026-03-08 = 恰好90天，daysAgo>=90，break)

# 15条近期（pageSize=5时翻3页，pageSize=10时翻2页）
write(["ShixinCheck","GetList","15条失信企业"], paginated([
    {"Id": f"s740_15_{i}", "Liandate": RECENT_15[i], "Anno": f"（2026）京1001执{3000+i}号",
     "Executegov": COURTS[i%3], "Executestatus": ["全部未履行","部分未履行","全部已履行"][i%3],
     "Publicdate": RECENT_15[i], "Executeno": f"（2026）京1001民初{4000+i}号",
     "ActionRemark": "有履行能力而拒不履行", "Amount": str(200000*(i+1))}
    for i in range(15)
], "SHIXINCHECK"))

# 边界日期（Liandate=2026-03-08，daysAgo=90，触发earlyStop，count=0）
write(["ShixinCheck","GetList","边界日期失信企业"], paginated([
    {"Id": "s740_bd01", "Liandate": BOUNDARY,
     "Anno": "（2026）京1001执88001号", "Executegov": COURTS[0],
     "Executestatus": "全部未履行", "Publicdate": BOUNDARY,
     "Executeno": "（2026）京1001民初88001号",
     "ActionRemark": "边界测试", "Amount": "500000"},
    {"Id": "s740_bd02", "Liandate": "2022-01-01",
     "Anno": "（2022）京1001执88002号", "Executegov": COURTS[0],
     "Executestatus": "全部未履行", "Publicdate": "2022-01-01",
     "Executeno": "（2022）京1001民初88002号",
     "ActionRemark": "超期记录", "Amount": "100000"},
], "SHIXINCHECK"))

write(["ShixinCheck","GetList","失信非200企业"], non200("SHIXINCHECK"))


# ========================================================================
# 741 被执行人核查
# ========================================================================
print("=== 741 被执行人核查 ===")

write(["ZhixingCheck","GetList","单条被执行企业"], paginated([{
    "Id": "z741_01", "Liandate": "2026-05-20", "Anno": "（2026）京1001执50001号",
    "ExecuteGov": COURTS[0], "Biaodi": "3000000", "SuspectedApplicant": "北京某融资担保有限公司"
}], "ZHIXINGCHECK"))

write(["ZhixingCheck","GetList","混合日期被执行企业"], paginated([
    {"Id": f"z741_m{i}", "Liandate": RECENT_5[i], "Anno": f"（2026）京1001执5000{i}号",
     "ExecuteGov": COURTS[i%3], "Biaodi": str(500000*(i+1)),
     "SuspectedApplicant": f"担保申请人{i+1}有限公司"} for i in range(3)
] + [{"Id": "z741_old", "Liandate": BOUNDARY, "Anno": "（2022）京1001执59999号",
      "ExecuteGov": COURTS[0], "Biaodi": "1000", "SuspectedApplicant": "超期申请人"}
], "ZHIXINGCHECK"))

write(["ZhixingCheck","GetList","15条被执行企业"], paginated([
    {"Id": f"z741_{i}", "Liandate": RECENT_15[i], "Anno": f"（2026）京1001执{6000+i}号",
     "ExecuteGov": COURTS[i%3], "Biaodi": str(300000*(i+1)),
     "SuspectedApplicant": f"申请人{i+1}"} for i in range(15)
], "ZHIXINGCHECK"))

write(["ZhixingCheck","GetList","边界日期被执行企业"], paginated([
    {"Id": "z741_bd", "Liandate": BOUNDARY, "Anno": "（2026）京1001执79001号",
     "ExecuteGov": COURTS[0], "Biaodi": "1000000", "SuspectedApplicant": "边界申请人"}
], "ZHIXINGCHECK"))
write(["ZhixingCheck","GetList","被执行非200企业"], non200("ZHIXINGCHECK"))


# ========================================================================
# 742 限制高消费核查
# ========================================================================
print("=== 742 限制高消费核查 ===")

write(["SumptuaryCheck","GetList","单条限消企业"], paginated([{
    "Id": "sm742_01", "CaseNo": "（2026）京1001执70001号",
    "PersonName": "张三", "PersonId": "pid001",
    "JudgeDate": "2026-05-20", "PublishDate": "2026-05-20",
    "KeyNo": "kn001", "CompanyName": "单条限消企业",
    "Applicant": "北京银行股份有限公司", "ApplicantNo": "an001",
    "Amount": "2500000", "ExecuteCourt": COURTS[0]
}], "SUMPTUARYCHECK"))

write(["SumptuaryCheck","GetList","混合日期限消企业"], paginated([
    {"Id": f"sm742_m{i}", "CaseNo": f"（2026）京1001执7000{i}号",
     "PersonName": f"限消人员{i+1}", "PersonId": f"pid00{i+1}",
     "JudgeDate": RECENT_5[i], "PublishDate": RECENT_5[i],
     "KeyNo": f"kn00{i+1}", "CompanyName": "混合日期限消企业",
     "Applicant": f"债权方{i+1}", "ApplicantNo": f"an00{i+1}",
     "Amount": str(500000*(i+1)), "ExecuteCourt": COURTS[i%3]} for i in range(3)
] + [{"Id": "sm742_old", "CaseNo": "（2022）京1001执79999号",
      "PersonName": "超期人员", "PersonId": "pid999",
      "JudgeDate": BOUNDARY, "PublishDate": BOUNDARY,
      "KeyNo": "kn999", "CompanyName": "混合日期限消企业",
      "Applicant": "超期债权方", "ApplicantNo": "an999",
      "Amount": "0", "ExecuteCourt": COURTS[0]}
], "SUMPTUARYCHECK"))

write(["SumptuaryCheck","GetList","15条限消企业"], paginated([
    {"Id": f"sm742_{i}", "CaseNo": f"（2026）京1001执{8000+i}号",
     "PersonName": f"限消{i+1}", "PersonId": f"pid{100+i}",
     "JudgeDate": RECENT_15[i], "PublishDate": RECENT_15[i],
     "KeyNo": f"kn{100+i}", "CompanyName": "15条限消企业",
     "Applicant": f"债权{i+1}", "ApplicantNo": f"an{100+i}",
     "Amount": str(100000*(i+1)), "ExecuteCourt": COURTS[i%3]} for i in range(15)
], "SUMPTUARYCHECK"))

write(["SumptuaryCheck","GetList","边界日期限消企业"], paginated([
    {"Id": "sm742_bd", "CaseNo": "（2026）京1001执89001号",
     "PersonName": "边界人员", "PersonId": "pid_bd",
     "JudgeDate": BOUNDARY, "PublishDate": BOUNDARY,
     "KeyNo": "kn_bd", "CompanyName": "边界日期限消企业",
     "Applicant": "边界债权方", "ApplicantNo": "an_bd",
     "Amount": "1000000", "ExecuteCourt": COURTS[0]}
], "SUMPTUARYCHECK"))
write(["SumptuaryCheck","GetList","限消非200企业"], non200("SUMPTUARYCHECK"))


# ========================================================================
# 744 司法拍卖核查（ActionRemark用中文日期）
# ========================================================================
print("=== 744 司法拍卖核查 ===")

def cn_date(date_str):
    """2026-05-20 → 2026年5月20日"""
    y, m, d = date_str.split("-")
    return f"{y}年{int(m)}月{int(d)}日"

write(["JudicialSaleCheck","GetList","单条司法拍卖企业"], paginated([{
    "Id": "jsc744_01",
    "Name": "单条司法拍卖企业名下的办公楼",
    "CaseNo": "（2026）京1001执90001号",
    "Executegov": COURTS[0],
    "ActionRemark": f"{cn_date('2026-05-20')}上午10时至{cn_date('2026-05-21')}上午10时止",
    "YiWu": "5000000", "EvaluationPrice": "6000000"
}], "JUDICIALSALECHECK"))

write(["JudicialSaleCheck","GetList","混合日期司法拍卖企业"], paginated([
    {"Id": f"jsc744_m{i}", "Name": f"混合日期司法拍卖企业名下的资产{i+1}",
     "CaseNo": f"（2026）京1001执9000{i}号", "Executegov": COURTS[i%3],
     "ActionRemark": f"{cn_date(RECENT_5[i])}上午10时至{cn_date(RECENT_5[i])}上午10时止",
     "YiWu": str(1000000*(i+1)), "EvaluationPrice": str(1200000*(i+1))} for i in range(3)
] + [{"Id": "jsc744_old", "Name": "超期拍卖资产", "CaseNo": "（2022）京1001执99001号",
      "Executegov": COURTS[0],
      "ActionRemark": f"{cn_date(BOUNDARY)}上午10时至{cn_date(BOUNDARY)}上午10时止",
      "YiWu": "100", "EvaluationPrice": "200"}
], "JUDICIALSALECHECK"))

write(["JudicialSaleCheck","GetList","15条司法拍卖企业"], paginated([
    {"Id": f"jsc744_{i}", "Name": f"15条司法拍卖企业资产{i+1}",
     "CaseNo": f"（2026）京1001执{9100+i}号", "Executegov": COURTS[i%3],
     "ActionRemark": f"{cn_date(RECENT_15[i])}上午10时至{cn_date(RECENT_15[i])}下午14时止",
     "YiWu": str(500000*(i+1)), "EvaluationPrice": str(600000*(i+1))} for i in range(15)
], "JUDICIALSALECHECK"))

write(["JudicialSaleCheck","GetList","边界日期司法拍卖企业"], paginated([
    {"Id": "jsc744_bd", "Name": "边界日期司法拍卖企业名下资产",
     "CaseNo": "（2026）京1001执99901号", "Executegov": COURTS[0],
     "ActionRemark": f"{cn_date(BOUNDARY)}上午10时至{cn_date(BOUNDARY)}下午14时止",
     "YiWu": "2000000", "EvaluationPrice": "2500000"}
], "JUDICIALSALECHECK"))
write(["JudicialSaleCheck","GetList","司法拍卖非200企业"], non200("JUDICIALSALECHECK"))


# ========================================================================
# 746 环保处罚核查
# ========================================================================
print("=== 746 环保处罚核查 ===")

write(["EnvPunishmentCheck","GetList","单条环保处罚企业"], paginated([{
    "Id": "ep746_01", "CaseNo": "环罚字〔2026〕第0001号",
    "PunishDate": "2026-05-20", "IllegalType": "超标排放污染物",
    "PunishGov": "北京市延庆区生态环境局", "PunishAmt": "300000"
}], "ENVPUNISHMENTCHECK"))

write(["EnvPunishmentCheck","GetList","混合日期环保处罚企业"], paginated([
    {"Id": f"ep746_m{i}", "CaseNo": f"环罚字〔2026〕第{100+i}号",
     "PunishDate": RECENT_5[i], "IllegalType": "超标排放",
     "PunishGov": "北京市延庆区生态环境局", "PunishAmt": str(50000*(i+1))} for i in range(3)
] + [{"Id": "ep746_old", "CaseNo": "环罚字〔2022〕第999号",
      "PunishDate": BOUNDARY, "IllegalType": "边界测试",
      "PunishGov": "北京市延庆区生态环境局", "PunishAmt": "0"}
], "ENVPUNISHMENTCHECK"))

write(["EnvPunishmentCheck","GetList","15条环保处罚企业"], paginated([
    {"Id": f"ep746_{i}", "CaseNo": f"环罚字〔2026〕第{200+i}号",
     "PunishDate": RECENT_15[i], "IllegalType": "违法排污",
     "PunishGov": PENALTY_OFFICES[i%2], "PunishAmt": str(30000*(i+1))} for i in range(15)
], "ENVPUNISHMENTCHECK"))

write(["EnvPunishmentCheck","GetList","边界日期环保处罚企业"], paginated([
    {"Id": "ep746_bd", "CaseNo": "环罚字〔2026〕第8888号",
     "PunishDate": BOUNDARY, "IllegalType": "边界测试", "PunishGov": PENALTY_OFFICES[0], "PunishAmt": "100000"}
], "ENVPUNISHMENTCHECK"))
write(["EnvPunishmentCheck","GetList","环保处罚非200企业"], non200("ENVPUNISHMENTCHECK"))


# ========================================================================
# 756 税收违法核查
# ========================================================================
print("=== 756 税收违法核查 ===")

write(["TaxIllegalCheck","GetList","单条税收违法企业"], paginated([{
    "Id": "ti756_01", "PublishDate": "2026-05-20",
    "CaseNature": "虚开增值税专用发票",
    "TaxGov": TAX_GOVS[0],
    "IllegalContent": "该企业在2024年至2025年期间虚开增值税专用发票，涉及税款约500万元",
    "PunishContent": "追缴税款500万元，罚款100万元"
}], "TAXILLEGALCHECK"))

write(["TaxIllegalCheck","GetList","混合日期税收违法企业"], paginated([
    {"Id": f"ti756_m{i}", "PublishDate": RECENT_5[i],
     "CaseNature": ["偷税","虚开增值税专用发票","逃避追缴欠税"][i%3],
     "TaxGov": TAX_GOVS[i%2],
     "IllegalContent": f"税收违法内容{i+1}", "PunishContent": f"罚款{50*(i+1)}万元"} for i in range(3)
] + [{"Id": "ti756_old", "PublishDate": BOUNDARY, "CaseNature": "偷税",
      "TaxGov": TAX_GOVS[0], "IllegalContent": "边界记录", "PunishContent": "无"}
], "TAXILLEGALCHECK"))

write(["TaxIllegalCheck","GetList","15条税收违法企业"], paginated([
    {"Id": f"ti756_{i}", "PublishDate": RECENT_15[i],
     "CaseNature": ["偷税","虚开发票","骗取退税"][i%3],
     "TaxGov": TAX_GOVS[i%2],
     "IllegalContent": f"内容{i+1}", "PunishContent": f"罚款{20*(i+1)}万元"} for i in range(15)
], "TAXILLEGALCHECK"))

write(["TaxIllegalCheck","GetList","边界日期税收违法企业"], paginated([
    {"Id": "ti756_bd", "PublishDate": BOUNDARY, "CaseNature": "偷税",
     "TaxGov": TAX_GOVS[0], "IllegalContent": "边界测试", "PunishContent": "处罚"}
], "TAXILLEGALCHECK"))
write(["TaxIllegalCheck","GetList","税收违法非200企业"], non200("TAXILLEGALCHECK"))


# ========================================================================
# 757 欠税公告核查（含金额累积）
# ========================================================================
print("=== 757 欠税公告核查 ===")

write(["TaxOweNoticeCheck","GetList","单条欠税企业"], paginated([{
    "Id": "to757_01", "Title": "增值税",
    "Amount": "80000.00", "NewAmount": "0",
    "PublishDate": "2026-05-20", "IssuedBy": "北京市国家税务局"
}], "TAXOWENOTICECHECK"))

write(["TaxOweNoticeCheck","GetList","混合日期欠税企业"], paginated([
    {"Id": f"to757_m{i}", "Title": ["增值税","企业所得税","城建税"][i],
     "Amount": ["50000.00","30000.00","8000.00"][i],
     "NewAmount": "0", "PublishDate": RECENT_5[i], "IssuedBy": "北京市国家税务局"} for i in range(3)
] + [{"Id": "to757_old", "Title": "印花税", "Amount": "99999.00",
      "NewAmount": "0", "PublishDate": BOUNDARY, "IssuedBy": "超期机关"}
], "TAXOWENOTICECHECK"))
# count期望=3, taxarrearsamt期望=88000 (50000+30000+8000)

write(["TaxOweNoticeCheck","GetList","15条欠税企业"], paginated([
    {"Id": f"to757_{i}", "Title": ["增值税","所得税","城建税","房产税","印花税"][i%5],
     "Amount": str(10000*(i+1)),
     "NewAmount": "0", "PublishDate": RECENT_15[i], "IssuedBy": TAX_GOVS[i%2]} for i in range(15)
], "TAXOWENOTICECHECK"))
# count=15, 累积金额=sum(10000..150000)=10000*(1+2+...+15)=1200000

write(["TaxOweNoticeCheck","GetList","边界日期欠税企业"], paginated([
    {"Id": "to757_bd", "Title": "增值税", "Amount": "100000.00",
     "NewAmount": "0", "PublishDate": BOUNDARY, "IssuedBy": "边界机关"}
], "TAXOWENOTICECHECK"))
write(["TaxOweNoticeCheck","GetList","欠税非200企业"], non200("TAXOWENOTICECHECK"))


# ========================================================================
# 758 终本案件核查（注意字段 LianDate）
# ========================================================================
print("=== 758 终本案件核查 ===")

write(["EndExecuteCaseCheck","GetList","单条终本案件企业"], paginated([{
    "Id": "ec758_01", "CaseNo": "（2026）京1001执终10001号",
    "Court": COURTS[0], "EndDate": "2026-05-20", "LianDate": "2026-05-20",
    "ExecuteSubject": "5000000", "UnperformedAmt": "4500000"
}], "ENDEXECUTECASECHECK"))

write(["EndExecuteCaseCheck","GetList","混合日期终本案件企业"], paginated([
    {"Id": f"ec758_m{i}", "CaseNo": f"（2026）京1001执终1000{i}号",
     "Court": COURTS[i%3], "EndDate": RECENT_5[i], "LianDate": RECENT_5[i],
     "ExecuteSubject": str(2000000*(i+1)), "UnperformedAmt": str(1500000*(i+1))} for i in range(3)
] + [{"Id": "ec758_old", "CaseNo": "（2022）京1001执终99001号",
      "Court": COURTS[0], "EndDate": BOUNDARY, "LianDate": BOUNDARY,
      "ExecuteSubject": "100", "UnperformedAmt": "100"}
], "ENDEXECUTECASECHECK"))

write(["EndExecuteCaseCheck","GetList","15条终本案件企业"], paginated([
    {"Id": f"ec758_{i}", "CaseNo": f"（2026）京1001执终{2000+i}号",
     "Court": COURTS[i%3], "EndDate": RECENT_15[i], "LianDate": RECENT_15[i],
     "ExecuteSubject": str(1000000*(i+1)), "UnperformedAmt": str(800000*(i+1))} for i in range(15)
], "ENDEXECUTECASECHECK"))

write(["EndExecuteCaseCheck","GetList","边界日期终本案件企业"], paginated([
    {"Id": "ec758_bd", "CaseNo": "（2026）京1001执终88001号",
     "Court": COURTS[0], "EndDate": BOUNDARY, "LianDate": BOUNDARY,
     "ExecuteSubject": "1000000", "UnperformedAmt": "900000"}
], "ENDEXECUTECASECHECK"))
write(["EndExecuteCaseCheck","GetList","终本案件非200企业"], non200("ENDEXECUTECASECHECK"))


# ========================================================================
# 865 行政处罚核查（含金额累积）
# ========================================================================
print("=== 865 行政处罚核查 ===")

write(["AdminPenaltyCheck","GetList","单条行政处罚企业"], paginated([{
    "Id": "ap865_01", "DocNo": "罚字〔2026〕第00001号",
    "PunishReason": "无证经营建筑施工业务",
    "PunishResult": "罚款人民币500000元",
    "PunishOffice": PENALTY_OFFICES[0],
    "PunishDate": "2026-05-20", "Source": "市场监督管理局",
    "SourceCode": "", "PunishAmt": "500000"
}], "ADMINPENALTYCHECK"))

write(["AdminPenaltyCheck","GetList","混合日期行政处罚企业"], paginated([
    {"Id": f"ap865_m{i}", "DocNo": f"罚字〔2026〕第0000{i+1}号",
     "PunishReason": ["无证经营","虚假宣传","违反消防法规"][i],
     "PunishResult": f"罚款{[200000,150000,50000][i]}元",
     "PunishOffice": PENALTY_OFFICES[i%2], "PunishDate": RECENT_5[i],
     "Source": "市场监督管理局", "SourceCode": "",
     "PunishAmt": str([200000,150000,50000][i])} for i in range(3)
] + [{"Id": "ap865_old", "DocNo": "罚字〔2022〕第99999号", "PunishReason": "超期记录",
      "PunishResult": "罚款0元", "PunishOffice": PENALTY_OFFICES[0],
      "PunishDate": BOUNDARY, "Source": "超期", "SourceCode": "", "PunishAmt": "0"}
], "ADMINPENALTYCHECK"))
# count=3, 累积金额=400000 (200000+150000+50000)

write(["AdminPenaltyCheck","GetList","15条行政处罚企业"], paginated([
    {"Id": f"ap865_{i}", "DocNo": f"罚字〔2026〕第{1000+i}号",
     "PunishReason": "违法行为", "PunishResult": f"罚款{10000*(i+1)}元",
     "PunishOffice": PENALTY_OFFICES[i%2], "PunishDate": RECENT_15[i],
     "Source": "机关", "SourceCode": "", "PunishAmt": str(10000*(i+1))} for i in range(15)
], "ADMINPENALTYCHECK"))
# count=15, 累积金额=sum(10000..150000)=1200000

write(["AdminPenaltyCheck","GetList","边界日期行政处罚企业"], paginated([
    {"Id": "ap865_bd", "DocNo": "罚字〔2026〕第88888号", "PunishReason": "边界测试",
     "PunishResult": "罚款100000元", "PunishOffice": PENALTY_OFFICES[0],
     "PunishDate": BOUNDARY, "Source": "机关", "SourceCode": "", "PunishAmt": "100000"}
], "ADMINPENALTYCHECK"))
write(["AdminPenaltyCheck","GetList","行政处罚非200企业"], non200("ADMINPENALTYCHECK"))


# ========================================================================
# 751 股权出质核查（无earlyStop，全量翻页）
# ========================================================================
print("=== 751 股权出质核查 ===")

write(["EquityPledgedCheck","GetList","单条股权出质企业"], paginated([{
    "Id": "eq751_01", "RegistNo": "股质登记字〔2024〕第00001号",
    "PledgorName": "出质人张三", "PledgeeName": "质权人银行A",
    "RegDate": "2024-01-01", "Status": "有效",
    "RelatedCompanyName": "单条股权出质企业",
    "PledgedAmount": "500万股",
    "PledgeeList": [{"Name": "质权人银行A", "KeyNo": "kp001"}],
    "PledgorList": [{"Name": "出质人张三", "KeyNo": "kq001"}]
}], "EQUITYPLEDGEDCHECK"))

# 混合Status（有效2条，无效1条，已注销1条）→ count=2
write(["EquityPledgedCheck","GetList","混合状态股权出质企业"], paginated([
    {"Id": "eq751_v1", "RegistNo": "股质登记字〔2024〕第00010号",
     "PledgorName": "出质人A", "PledgeeName": "银行1", "RegDate": "2024-03-01",
     "Status": "有效", "RelatedCompanyName": "混合状态股权出质企业",
     "PledgedAmount": "100万股", "PledgeeList": [], "PledgorList": []},
    {"Id": "eq751_v2", "RegistNo": "股质登记字〔2024〕第00011号",
     "PledgorName": "出质人B", "PledgeeName": "银行2", "RegDate": "2024-06-01",
     "Status": "无效", "RelatedCompanyName": "混合状态股权出质企业",
     "PledgedAmount": "200万股", "PledgeeList": [], "PledgorList": []},
    {"Id": "eq751_v3", "RegistNo": "股质登记字〔2024〕第00012号",
     "PledgorName": "出质人C", "PledgeeName": "银行3", "RegDate": "2023-01-01",
     "Status": "已注销", "RelatedCompanyName": "混合状态股权出质企业",
     "PledgedAmount": "300万股", "PledgeeList": [], "PledgorList": []},
    {"Id": "eq751_v4", "RegistNo": "股质登记字〔2024〕第00013号",
     "PledgorName": "出质人D", "PledgeeName": "银行4", "RegDate": "2024-09-01",
     "Status": "有效", "RelatedCompanyName": "混合状态股权出质企业",
     "PledgedAmount": "400万股", "PledgeeList": [], "PledgorList": []},
], "EQUITYPLEDGEDCHECK"))
# count期望=2（仅"有效"的2条）

# 15条（全部有效，pageSize=5时翻3页，验证无死循环）
write(["EquityPledgedCheck","GetList","15条股权出质企业"], paginated([
    {"Id": f"eq751_{i}", "RegistNo": f"股质登记字〔2024〕第{100+i}号",
     "PledgorName": f"出质人{i+1}", "PledgeeName": f"银行{i+1}",
     "RegDate": f"2024-0{(i%9)+1}-01", "Status": "有效",
     "RelatedCompanyName": "15条股权出质企业",
     "PledgedAmount": f"{(i+1)*50}万股",
     "PledgeeList": [{"Name": f"银行{i+1}", "KeyNo": f"kp{100+i}"}],
     "PledgorList": [{"Name": f"出质人{i+1}", "KeyNo": f"kq{100+i}"}]} for i in range(15)
], "EQUITYPLEDGEDCHECK"))
write(["EquityPledgedCheck","GetList","股权出质非200企业"], non200("EQUITYPLEDGEDCHECK"))


# ========================================================================
# 752 股权冻结核查（无earlyStop，双条件过滤）
# ========================================================================
print("=== 752 股权冻结核查 ===")

write(["EquityFreezeCheck","GetList","单条股权冻结企业"], paginated([{
    "Id": "ef752_01",
    "ExecuteName": "被冻结人甲", "ExecuteKeyNo": "ek001",
    "EquityAmount": "800万元人民币", "ExecuteCourt": COURTS[0],
    "ExecutionNoticeNum": "（2025）法执字第00001号",
    "Status": "股权冻结|冻结",
    "FreezeStartDate": "2025-01-01", "FreezeEndDate": "2027-12-31",
    "RelatedInfo": {"KeyNo": "ri001", "Name": "单条股权冻结企业"}
}], "EQUITYFREEZECHECK"))

# 混合场景：4种组合（冻结+未过期√、冻结+已过期✗、解冻+未过期✗、全满足√）
write(["EquityFreezeCheck","GetList","混合条件股权冻结企业"], paginated([
    {"Id": "ef752_1", "ExecuteName": "被冻结A", "ExecuteKeyNo": "ek001",
     "EquityAmount": "100万", "ExecuteCourt": COURTS[0],
     "ExecutionNoticeNum": "001", "Status": "股权冻结|冻结",
     "FreezeStartDate": "2025-01-01", "FreezeEndDate": "2027-12-31",
     "RelatedInfo": {"KeyNo": "r1", "Name": "混合"}},  # ✓ 冻结+未过期
    {"Id": "ef752_2", "ExecuteName": "被冻结B", "ExecuteKeyNo": "ek002",
     "EquityAmount": "200万", "ExecuteCourt": COURTS[0],
     "ExecutionNoticeNum": "002", "Status": "股权冻结|冻结",
     "FreezeStartDate": "2020-01-01", "FreezeEndDate": "2025-12-31",
     "RelatedInfo": {"KeyNo": "r2", "Name": "混合"}},  # ✗ 冻结+已过期
    {"Id": "ef752_3", "ExecuteName": "被冻结C", "ExecuteKeyNo": "ek003",
     "EquityAmount": "300万", "ExecuteCourt": COURTS[0],
     "ExecutionNoticeNum": "003", "Status": "股权冻结|解冻",
     "FreezeStartDate": "2025-03-01", "FreezeEndDate": "2027-06-30",
     "RelatedInfo": {"KeyNo": "r3", "Name": "混合"}},  # ✗ 解冻+未过期
    {"Id": "ef752_4", "ExecuteName": "被冻结D", "ExecuteKeyNo": "ek004",
     "EquityAmount": "400万", "ExecuteCourt": COURTS[1],
     "ExecutionNoticeNum": "004", "Status": "股权冻结|冻结",
     "FreezeStartDate": "2025-06-01", "FreezeEndDate": "2028-06-30",
     "RelatedInfo": {"KeyNo": "r4", "Name": "混合"}},  # ✓ 冻结+未过期
], "EQUITYFREEZECHECK"))
# count期望=2（ef752_1和ef752_4）

write(["EquityFreezeCheck","GetList","15条股权冻结企业"], paginated([
    {"Id": f"ef752_{i}", "ExecuteName": f"被冻结人{i+1}", "ExecuteKeyNo": f"ek{100+i}",
     "EquityAmount": f"{(i+1)*100}万元人民币", "ExecuteCourt": COURTS[i%3],
     "ExecutionNoticeNum": f"（2025）法执字第{100+i}号",
     "Status": "股权冻结|冻结",
     "FreezeStartDate": "2025-01-01", "FreezeEndDate": "2027-12-31",
     "RelatedInfo": {"KeyNo": f"ri{100+i}", "Name": "15条股权冻结企业"}} for i in range(15)
], "EQUITYFREEZECHECK"))
# count=15（全部满足双条件），翻3页（pageSize=5）
write(["EquityFreezeCheck","GetList","股权冻结非200企业"], non200("EQUITYFREEZECHECK"))


# ========================================================================
# 761 破产重整核查（仅读TotalRecords）
# ========================================================================
print("=== 761 破产重整核查 ===")

for cnt, name in [(1,"单条破产企业"),(10,"10条破产企业"),(100,"大量破产企业")]:
    actual_cnt = min(cnt, 5)  # Data实际只存5条，TotalRecords用声明值
    data = [{"Id": f"bk761_{i:03d}", "CaseNo": f"（2024）京{cnt:04d}破申{i:03d}号",
             "PublicDate": "2024-01-01",
             "ApplicantList": [{"Name": "申请人甲", "KeyNo": f"ap{i:03d}"}],
             "RespondentList": [{"Name": f"被申请人{i}", "KeyNo": f"rd{i:03d}"}]}
            for i in range(min(actual_cnt, 5))]
    resp = {
        "Status": "200", "Message": "【有效请求】查询成功",
        "OrderNumber": f"BANKRUPTCYCHECK20260606",
        "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": cnt},
        "Result": {"VerifyResult": 1, "Data": data}
    }
    write(["BankruptcyCheck","GetList", name], resp)

write(["BankruptcyCheck","GetList","破产非200企业"], non200("BANKRUPTCYCHECK"))


# ========================================================================
# 739 经营异常核查（COMMON，RemoveDate过滤）
# ========================================================================
print("=== 739 经营异常核查 ===")

ADD_REASONS = [
    "未依照规定公示年度报告的",
    "通过登记的住所无法联系的",
    "公示企业信息隐瞒真实情况、弄虚作假的",
]

# 全部在列（count=3）
write(["ExceptionCheck","GetList","全部在列经营异常企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "EXCEPTIONCHECK20260606",
    "Result": {"VerifyResult": 1, "Data": [
        {"AddReason": ADD_REASONS[i], "AddDate": f"202{i}-01-01",
         "RomoveReason": "", "RemoveDate": "",
         "DecisionOffice": f"北京市{['海淀','朝阳','丰台'][i]}区市场监督管理局",
         "RemoveDecisionOffice": ""} for i in range(3)
    ]}
})

# 全部已移除（count=0）
write(["ExceptionCheck","GetList","全部已移出经营异常企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "EXCEPTIONCHECK20260606",
    "Result": {"VerifyResult": 1, "Data": [
        {"AddReason": ADD_REASONS[i], "AddDate": f"202{i}-01-01",
         "RomoveReason": "已补报年度报告", "RemoveDate": f"202{i+1}-06-01",
         "DecisionOffice": "北京市海淀区市场监督管理局",
         "RemoveDecisionOffice": "北京市海淀区市场监督管理局"} for i in range(3)
    ]}
})

write(["ExceptionCheck","GetList","经营异常非200企业"], {
    "Status": "400", "Message": "参数异常", "OrderNumber": "EXCEPTIONCHECK20260606"
})


# ========================================================================
# 748 严重违法核查（COMMON，RemoveDate过滤）
# ========================================================================
print("=== 748 严重违法核查 ===")

write(["SeriousIllegalCheck","GetList","全部在列严重违法企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "SERIOUSILLEGALCHECK20260606",
    "Result": {"VerifyResult": 1, "Data": [
        {"Type": "", "AddReason": "被列入经营异常名录届满3年仍未履行相关义务的",
         "AddDate": "2021-05-20", "AddOffice": "北京市工商行政管理局",
         "RemoveReason": "", "RemoveDate": "", "RemoveOffice": ""},
        {"Type": "", "AddReason": "提交虚假材料取得公司登记的",
         "AddDate": "2022-03-10", "AddOffice": "上海市市场监督管理局",
         "RemoveReason": "", "RemoveDate": "", "RemoveOffice": ""},
    ]}
})

write(["SeriousIllegalCheck","GetList","全部已移出严重违法企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "SERIOUSILLEGALCHECK20260606",
    "Result": {"VerifyResult": 1, "Data": [
        {"Type": "", "AddReason": "被列入经营异常名录届满3年仍未履行的",
         "AddDate": "2020-01-01", "AddOffice": "北京市工商行政管理局",
         "RemoveReason": "已纠正违法行为", "RemoveDate": "2023-06-01", "RemoveOffice": "北京市市场监督管理局"},
    ]}
})

write(["SeriousIllegalCheck","GetList","严重违法非200企业"], {
    "Status": "400", "Message": "参数异常", "OrderNumber": "SERIOUSILLEGALCHECK20260606"
})


# ========================================================================
# 980 清算核查
# ========================================================================
print("=== 980 清算核查 ===")

write(["LiquidationCheck","GetDetail","单负责人清算企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "LIQUIDATIONCHECK20260606",
    "Result": {"VerifyResult": 1, "Data": {"Leader": "张清算", "Member": "张清算;李成员;王成员"}}
})

write(["LiquidationCheck","GetDetail","多负责人清算企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "LIQUIDATIONCHECK20260606",
    "Result": {"VerifyResult": 1, "Data": {"Leader": "张三;李四;王五", "Member": "张三;李四;王五;赵六;孙七"}}
})
# Leader="张三;李四;王五" → liquidFlag=3

write(["LiquidationCheck","GetDetail","清算非200企业"], {
    "Status": "400", "Message": "参数异常", "OrderNumber": "LIQUIDATIONCHECK20260606"
})


# ========================================================================
# 255 资质证书（补充几个特定场景）
# ========================================================================
print("=== 255 资质证书 ===")

# 单条特级（距到期=2027-12-31）
write(["ECICertification","SearchCertification","单条特级资质企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ECICERTIFICATION20260606",
    "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 1},
    "Result": [{"Id": "c255_s01", "Name": "建筑业企业资质 特级",
                "Type": "000001", "StartDate": "2022-01-01", "EndDate": "2027-12-31",
                "No": "CERT_S001", "TypeDesc": "建筑工程资质",
                "InstitutionList": ["住房和城乡建设部"], "Status": "有效"}]
})

# 单条二级（仅一条，距到期天数=负数，已过期）
write(["ECICertification","SearchCertification","已过期资质企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ECICERTIFICATION20260606",
    "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 1},
    "Result": [{"Id": "c255_exp", "Name": "建筑业企业资质 二级",
                "Type": "000001", "StartDate": "2018-01-01", "EndDate": "2025-01-01",
                "No": "CERT_E001", "TypeDesc": "建筑工程资质",
                "InstitutionList": ["住房和城乡建设部"], "Status": "已过期"}]
})
# qualexpdays应为负数（2025-01-01 - 2026-06-06 < 0）

# 15条（页size=5时翻3页）
write(["ECICertification","SearchCertification","15条工程资质企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ECICERTIFICATION20260606",
    "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 15},
    "Result": [
        {"Id": f"c255_15_{i}", "Name": ["建筑业企业资质 一级","建设工程监理资质 甲级","工程设计资质 甲级",
                                         "建筑业企业资质 二级","安防工程企业资质 一级",
                                         "ISO9001质量管理体系认证","高新技术企业证书","安全生产许可证",
                                         "软件企业认定证书","建筑业企业资质 三级",
                                         "建筑业企业资质 特级","建设工程监理资质 乙级",
                                         "电子与智能化工程专业承包 一级","ISO14001环境管理体系认证","CMMI 5级认证"][i],
         "Type": "000001", "StartDate": "2022-01-01",
         "EndDate": ["2027-12-31","2026-08-31","2026-09-30","2025-12-31","2026-10-01",
                     "2026-12-31","2026-11-01","2026-12-31","2027-01-01","2025-06-30",
                     "2028-01-01","2026-07-31","2026-10-31","2026-12-31","2027-01-01"][i],
         "No": f"CERT_15_{i:02d}", "TypeDesc": "工程资质",
         "InstitutionList": ["住房和城乡建设部"], "Status": "有效"}
        for i in range(15)
    ]
})
# 特级在index=10，pageSize=5时需翻3页才覆盖→ quallevel=4

write(["ECICertification","SearchCertification","资质证书非200企业"], {
    "Status": "400", "Message": "参数异常", "OrderNumber": "ECICERTIFICATION20260606"
})


# ========================================================================
# 958 招投标（补充场景）
# ========================================================================
print("=== 958 招投标 ===")

RECENT_12M_5 = ["2026-05-01","2026-03-15","2025-12-20","2025-08-10","2025-07-01"]
BOUNDARY_12M = "2025-06-05"  # 刚好超过12个月截止(2025-06-06)

def make_tender(i, pub_date, keyword="招标企业"):
    return {
        "Id": f"td958_{i:03d}", "Title": f"第{i+1}期信息系统建设采购公告",
        "ProjectNo": f"WHYX-IT-GKXJ-25-{3000+i}",
        "ChannelName": "中标公告", "Province": "湖北省", "City": "宜昌市",
        "IndustryDesc": "工程建筑", "BudgetAmt": str(5000000*(i+1)),
        "PublishDate": pub_date, "OpenDate": pub_date, "ObtainEndDate": pub_date,
        "BidInviUnitList": [{"KeyNo": "bi001", "Name": "三峡融担招标方",
                              "Contact": "李总", "TelNo": "0717-12345678"}],
        "WinBidUnitList": [{"WinBidAmt": str(4000000*(i+1)), "KeyNo": "kw001",
                             "Name": f"中标单位{i+1}","Contact": "王总","TelNo": "010-12345678"}],
        "AgentUnitList": [], "BidProgressList": ["招标公告","中标公告"],
        "BidEndDate": f"{pub_date} 17:00:00", "ContentUrl": f"https://example.com/td{i}",
        "ContractEndTime": "2027-12-31"
    }

write(["TenderCheck","GetList","单条近期招标企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "TENDERCHECK20260606",
    "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 1},
    "Result": {"VerifyResult": 1, "Data": [make_tender(0, "2026-05-01")]}
})

write(["TenderCheck","GetList","混合日期招标企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "TENDERCHECK20260606",
    "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 4},
    "Result": {"VerifyResult": 1, "Data": [
        make_tender(0,"2026-05-01"), make_tender(1,"2026-03-15"), make_tender(2,"2025-12-20"),
        make_tender(3, BOUNDARY_12M)  # 第4条超过12月截止 → earlyStop
    ]}
})
# count=3 (前3条在12月内，第4条=2025-06-05触发earlyStop)

write(["TenderCheck","GetList","15条近期招标企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "TENDERCHECK20260606",
    "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 15},
    "Result": {"VerifyResult": 1, "Data": [
        make_tender(i, RECENT_12M_5[i%5]) for i in range(15)
    ]}
})
# count=15，全部在12月内，翻3页（pageSize=5）

write(["TenderCheck","GetList","招标非200企业"], {
    "Status": "400", "Message": "参数异常", "OrderNumber": "TENDERCHECK20260606"
})


# ========================================================================
# 764-771 董监高接口（单条/混合/15条 统一生成）
# ========================================================================
print("=== 764-771 董监高接口 ===")

PERSON_NAME = "近期违规高管"

# 764 失信
write(["PersonSXCheck","GetList",f"单条失信高管__personName={PERSON_NAME}"], paginated([{
    "Id": "ps764_01", "Liandate": "2026-05-20",
    "Anno": "（2026）京1001执20001号", "Executegov": COURTS[0],
    "Executestatus": "全部未履行", "Publicdate": "2026-05-20",
    "Executeno": "（2026）京1001民初30001号",
    "ActionRemark": "有履行能力而拒不履行", "Amount": "500000"
}], "PERSONSXCHECK"))

write(["PersonSXCheck","GetList",f"混合日期失信高管__personName={PERSON_NAME}"], paginated([
    {"Id": f"ps764_m{i}", "Liandate": RECENT_5[i], "Anno": f"（2026）京执{40000+i}号",
     "Executegov": COURTS[i%3], "Executestatus": "全部未履行",
     "Publicdate": RECENT_5[i], "Executeno": f"（2026）京民{50000+i}号",
     "ActionRemark": "拒不履行", "Amount": str(100000*(i+1))} for i in range(3)
] + [{"Id": "ps764_old", "Liandate": BOUNDARY, "Anno": "（2022）京执99001号",
      "Executegov": COURTS[0], "Executestatus": "部分未履行",
      "Publicdate": BOUNDARY, "Executeno": "（2022）京民99001号",
      "ActionRemark": "超期", "Amount": "0"}
], "PERSONSXCHECK"))

write(["PersonSXCheck","GetList",f"失信高管非200__personName={PERSON_NAME}"], non200("PERSONSXCHECK"))

# 765 被执行
write(["PersonZXCheck","GetList",f"单条被执行高管__personName={PERSON_NAME}"], paginated([{
    "Id": "pz765_01", "Liandate": "2026-05-20", "Anno": "（2026）京1001执60001号",
    "ExecuteGov": COURTS[0], "Biaodi": "2000000", "SuspectedApplicant": "债权银行"
}], "PERSONZXCHECK"))
write(["PersonZXCheck","GetList",f"被执行高管非200__personName={PERSON_NAME}"], non200("PERSONZXCHECK"))

# 766 限消
write(["PersonSumptuaryCheck","GetList",f"单条限消高管__personName={PERSON_NAME}"], paginated([{
    "Id": "pm766_01", "CaseNo": "（2026）京1001执70001号",
    "LimitObject": "限消高管供职公司", "LimitObjectKeyNo": "lo001",
    "RelatedName": PERSON_NAME, "RelatedKeyNo": "rk001",
    "JudgeDate": "2026-05-20", "PublishDate": "2026-05-20",
    "Applicant": "债权申请人", "ApplicantKeyNo": "ak001"
}], "PERSONSUMPTUARYCHECK"))
write(["PersonSumptuaryCheck","GetList",f"限消高管非200__personName={PERSON_NAME}"], non200("PERSONSUMPTUARYCHECK"))

# 771 终本
write(["PersonEndExCaseCheck","GetList",f"单条终本高管__personName={PERSON_NAME}"], paginated([{
    "Id": "pe771_01", "CaseNo": "（2026）京1001执终80001号",
    "Court": COURTS[0], "EndDate": "2026-05-20", "LianDate": "2026-05-20",
    "ExecuteSubject": "3000000", "UnperformedAmt": "2500000"
}], "PERSONENDEXCASECHECK"))
write(["PersonEndExCaseCheck","GetList",f"终本高管非200__personName={PERSON_NAME}"], non200("PERSONENDEXCASECHECK"))


# ========================================================================
# 2003 KYC（补充特定场景）
# ========================================================================
print("=== 2003 KYC ===")

# 90天内法代变更
write(["CustomerDueDiligence","KYC","法代变更90天内企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ENTERPRISEINFO20260606",
    "Result": {"VerifyResult": 1, "Data": {
        "KeyNo": "kyc_ldc01", "Name": "法代变更90天内企业",
        "CreditCode": "9161010001234567X", "OperName": "新法代王大明",
        "Status": "在业", "StartDate": "2015-03-15",
        "RegistCapi": "5000万元", "RegisteredCapital": "5000",
        "RegisteredCapitalUnit": "万", "RealCapi": "3000万元",
        "PaidUpCapital": "3000", "PaidUpCapitalUnit": "万",
        "ChangeList": [
            {"ProjectName": "法定代表人变更", "ChangeDate": "2026-05-01",
             "BeforeList": ["原法代李小明"], "AfterList": ["新法代王大明"], "ChangeSubject": "工商变更"},
            {"ProjectName": "经营范围变更", "ChangeDate": "2025-01-10",
             "BeforeList": ["旧经营范围"], "AfterList": ["新经营范围"], "ChangeSubject": "工商变更"},
        ],
        "RevokeInfo": {"CancelDate": "", "CancelReason": "", "RevokeDate": "", "RevokeReason": ""},
        "TaxCreditList": [
            {"TaxNo": "9161010001234567X", "Year": "2024", "Level": "A", "Org": "国家税务总局"},
            {"TaxNo": "9161010001234567X", "Year": "2023", "Level": "B", "Org": "国家税务总局"},
        ],
        "PubPartnerList": [
            {"StockName": "大股东甲", "StockPercent": "35.00%", "HoldType": "1",
             "Amount": "1750000000", "SubscribedCapital": "", "SubscribedCapitalUnit": "",
             "SubscribedCapitalCCY": "", "SubscriptionDate": "2018-01-01", "CreditCode": "91110000AAAA0001X", "Area": "北京市"},
            {"StockName": "小股东乙", "StockPercent": "15.00%", "HoldType": "0",
             "Amount": "750000000", "SubscribedCapital": "", "SubscribedCapitalUnit": "",
             "SubscribedCapitalCCY": "", "SubscriptionDate": "2018-01-01", "CreditCode": "91110000BBBB0002X", "Area": "上海市"},
        ],
        "InvestmentList": [
            {"KeyNo": "inv001", "Name": "法代变更子公司A", "StartDate": "2018-06-01",
             "Status": "存续", "FundedRatio": "51.00%", "ShouldCapi": "1000万元",
             "SubscribedCapital": "1000", "SubscribedCapitalUnit": "万", "SubscribedCapitalCCY": "CNY",
             "Industry": {"IndustryCode": "I", "Industry": "信息技术", "SubIndustryCode": "65",
                          "SubIndustry": "软件", "MiddleCategoryCode": "651", "MiddleCategory": "软件开发",
                          "SmallCategoryCode": "6511", "SmallCategory": "应用软件"},
             "Area": {"Province": "北京市", "City": "北京市", "County": "海淀区"}},
        ]
    }}
})
# 期望: chglegalrepcnt=1 (法代变更90天内), chgscopecnt=0 (超期)
# taxcreditgrade='A'，pdishonestflag=1 (大股东35%>20%)，idishonestflag=1 (子公司51%>20%)

write(["CustomerDueDiligence","KYC","增资减资企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ENTERPRISEINFO20260606",
    "Result": {"VerifyResult": 1, "Data": {
        "KeyNo": "kyc_cap01", "Name": "增资减资企业",
        "CreditCode": "9161010009999999X", "OperName": "张法代",
        "Status": "在业", "StartDate": "2010-05-01",
        "RegistCapi": "10000万元", "RegisteredCapital": "10000",
        "RegisteredCapitalUnit": "万", "RealCapi": "8000万元",
        "PaidUpCapital": "8000", "PaidUpCapitalUnit": "万",
        "ChangeList": [
            # 90天内减资：5000万→3000万
            {"ProjectName": "注册资本变更", "ChangeDate": "2026-05-15",
             "BeforeList": ["5000万元"], "AfterList": ["3000万元"], "ChangeSubject": "工商变更"},
            # 90天内增资：8000万→10000万
            {"ProjectName": "注册资本变更", "ChangeDate": "2026-04-01",
             "BeforeList": ["8000万元"], "AfterList": ["10000万元"], "ChangeSubject": "工商变更"},
        ],
        "RevokeInfo": {"CancelDate": "", "CancelReason": "", "RevokeDate": "", "RevokeReason": ""},
        "TaxCreditList": [{"TaxNo": "tax01", "Year": "2023", "Level": "M", "Org": "国家税务总局"}],
        "PubPartnerList": [], "InvestmentList": []
    }}
})
# capdeccnt=1 (减资), capinccnt=1 (增资), capdecratio=(5000-3000)/5000=40%

write(["CustomerDueDiligence","KYC","注销吊销90天内企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ENTERPRISEINFO20260606",
    "Result": {"VerifyResult": 1, "Data": {
        "KeyNo": "kyc_rev01", "Name": "注销吊销90天内企业",
        "CreditCode": "9161010099999999X", "OperName": "李法代",
        "Status": "注销", "StartDate": "2008-01-01",
        "RegistCapi": "2000万元", "RegisteredCapital": "2000", "RegisteredCapitalUnit": "万",
        "RealCapi": "2000万元", "PaidUpCapital": "2000", "PaidUpCapitalUnit": "万",
        "ChangeList": [],
        "RevokeInfo": {"CancelDate": "2026-04-20", "CancelReason": "股东会决议注销",
                       "RevokeDate": "", "RevokeReason": ""},
        "TaxCreditList": [],
        "PubPartnerList": [], "InvestmentList": []
    }}
})
# revokecnt=1 (CancelDate=2026-04-20在90天内)

write(["CustomerDueDiligence","KYC","KYC非200企业"], non200("ENTERPRISEINFO"))


print("\n✅ 所有新 mock 文件创建完成！")
