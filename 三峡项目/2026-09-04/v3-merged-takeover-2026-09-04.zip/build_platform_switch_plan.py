#!/usr/bin/env python3
"""Generate a manual Tiance datasource switch and rollback plan from parsed V27."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import re
from urllib.parse import urlparse


VERSION = "1.0.0"
MOCK_BASE_URL = "http://<MOCK_HOST>:8899"
QCC_API_CODES = {
    "2003", "255", "739", "740", "741", "742", "744", "746", "748",
    "751", "752", "756", "757", "758", "761", "764", "765", "766",
    "767", "768", "771", "865", "882", "887", "888", "958", "980",
}
PERSON_CODES = {"764", "765", "766", "767", "768", "771"}
PAGED_CODES = {
    "255", "740", "741", "742", "744", "746", "751", "752", "756",
    "757", "758", "761", "764", "765", "766", "767", "768", "771",
    "865", "882", "887", "888", "958",
}


def atomic_write_json(path: Path, payload: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def atomic_write_text(path: Path, content: str) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(content, encoding="utf-8")
    temporary.replace(path)


def extract_api_code(interface: dict) -> str:
    text = " ".join(str(interface.get(key, "")) for key in ("name", "code", "url"))
    for code in sorted(QCC_API_CODES, key=len, reverse=True):
        if re.search(rf"(?<!\d){code}(?!\d)", text):
            return code
    return interface.get("code", "")


def qcc_probe(code: str, proposed_url: str) -> dict:
    query = {
        "key": "<TEST_APP_KEY>",
        "searchKey": "BHJC_RULE_ELLS01_MISS__SWITCHCHECK__TC000",
    }
    if code == "958":
        query.pop("searchKey")
        query["keyword"] = "BHJC_RULE_ELLS01_MISS__SWITCHCHECK__TC000"
    if code in PERSON_CODES:
        query["personName"] = "测试人员"
    if code in PAGED_CODES:
        query.update({"pageIndex": "1", "pageSize": "20"})
    if code == "255":
        query["isValid"] = "1"
    return {
        "method": "GET",
        "url": proposed_url,
        "query": query,
        "headers": {
            "Token": "<由天策现有前置ETL生成>",
            "Timespan": "<当前Unix秒级时间戳>",
        },
        "expected": {
            "httpStatus": 200,
            "bodyStatus": "200",
            "orderNumberPrefix": "MOCK_",
        },
    }


def build_entry(index: int, interface: dict) -> dict:
    name = str(interface.get("name", "")).strip()
    code = extract_api_code(interface)
    original_url = str(interface.get("url", "")).strip()
    partner = str(interface.get("partner", "")).strip()
    common = {
        "sequence": index,
        "name": name,
        "code": interface.get("code"),
        "apiCode": code,
        "partner": partner,
        "protocol": interface.get("protocol"),
        "originalUrl": original_url,
        "timeoutMs": interface.get("timeout"),
    }

    if code in QCC_API_CODES and "qichacha" in original_url.lower():
        path = urlparse(original_url).path
        proposed_url = f"{MOCK_BASE_URL}{path}"
        return {
            **common,
            "classification": "ready_to_switch",
            "switchDecision": "allowed_after_probe",
            "proposedUrl": proposed_url,
            "reason": "V27 HTTP path is implemented by the isolated mock service.",
            "preSwitchChecks": [
                "Back up the complete current datasource configuration.",
                "Confirm the mock host is reachable from the Tiance test runtime.",
                "Run the endpoint probe and retain the response evidence.",
            ],
            "probe": qcc_probe(code, proposed_url),
        }

    if code == "qyzxbg" or "enterpriseCreditQueryTwoCode" in original_url:
        proposed_url = f"{MOCK_BASE_URL}/services/enterpriseCreditQueryTwoCode"
        return {
            **common,
            "classification": "safe_baseline_only",
            "switchDecision": "conditional",
            "proposedUrl": proposed_url,
            "reason": (
                "Only a zero-risk SOAP baseline is implemented. Positive credit-report "
                "rules and full V27 JSON payload semantics are not covered."
            ),
            "preSwitchChecks": [
                "Back up the complete current datasource configuration.",
                "Verify the V27 qyzxbghz ETL accepts the mock SOAP envelope and result body.",
                "Use only a green/safe baseline case; do not claim positive-rule coverage.",
            ],
            "probe": {
                "method": "POST",
                "url": proposed_url,
                "headers": {
                    "Content-Type": "text/xml; charset=utf-8",
                    "X-Mock-Token": "<TEST_SOAP_TOKEN>",
                },
                "bodyTemplate": (
                    "<request><entName>测试企业</entName>"
                    "<entCertNum>000000000000000000</entCertNum></request>"
                ),
                "expected": {"httpStatus": 200, "contains": "<retCode>1</retCode>"},
            },
        }

    return {
        **common,
        "classification": "adapter_required",
        "switchDecision": "do_not_switch",
        "proposedUrl": None,
        "reason": "No protocol adapter or verified response contract exists in this mock service.",
        "preSwitchChecks": [],
        "probe": None,
    }


def build_documents(parsed: dict, source_path: str) -> tuple[dict, dict, str]:
    interfaces = parsed.get("thirdPartyInterfaces", [])
    if not isinstance(interfaces, list) or not interfaces:
        raise ValueError("parsed strategy has no thirdPartyInterfaces")
    entries = [build_entry(index, item) for index, item in enumerate(interfaces, 1)]
    counts = {}
    for entry in entries:
        classification = entry["classification"]
        counts[classification] = counts.get(classification, 0) + 1

    generated_at = datetime.now(timezone.utc).isoformat()
    plan = {
        "schemaVersion": "1.0",
        "generatorVersion": VERSION,
        "generatedAt": generated_at,
        "sourceParsedStrategy": str(Path(source_path).resolve()),
        "operationOwner": "user",
        "agentPlatformMutationAllowed": False,
        "environmentConstraint": "Tiance isolated test environment only",
        "mockBaseUrl": MOCK_BASE_URL,
        "healthProbe": {
            "method": "GET",
            "url": f"{MOCK_BASE_URL}/health",
            "expected": {"httpStatus": 200, "status": "ok", "strictScenarioKeys": True},
        },
        "summary": {"total": len(entries), "byClassification": counts},
        "services": entries,
    }

    rollback_entries = []
    for entry in entries:
        if entry["switchDecision"] == "do_not_switch":
            continue
        rollback_entries.append({
            "sequence": entry["sequence"],
            "name": entry["name"],
            "code": entry["code"],
            "restoreUrl": entry["originalUrl"],
            "replacedMockUrl": entry["proposedUrl"],
            "verification": [
                "Confirm the saved original URL is restored exactly.",
                "Run one safe request through the restored datasource.",
                "Confirm component logs no longer reference <MOCK_HOST>:8899.",
            ],
        })
    rollback = {
        "schemaVersion": "1.0",
        "generatedAt": generated_at,
        "operationOwner": "user",
        "agentPlatformMutationAllowed": False,
        "triggerConditions": [
            "Any probe fails or returns an unexpected schema.",
            "Tiance component logs show ETL, authentication, routing, or timeout errors.",
            "The planned test window ends, regardless of test outcome.",
        ],
        "steps": [
            "Stop submitting new strategy test cases.",
            "Restore every changed URL from the pre-switch backup.",
            "Save or publish the datasource configuration using the normal test-environment process.",
            "Run the listed rollback verification for every restored service.",
            "Archive the backup, change record, probe evidence, and rollback evidence.",
        ],
        "services": rollback_entries,
    }

    lines = [
        "# 天策测试环境三方数据源手工切换清单",
        "",
        "> 平台操作人：用户。Agent 不访问、不修改天策数据源配置。仅限隔离测试环境。",
        "",
        "## 汇总",
        "",
        f"- 接口总数：{len(entries)}",
        f"- 可切换：{counts.get('ready_to_switch', 0)}",
        f"- 仅安全基线：{counts.get('safe_baseline_only', 0)}",
        f"- 需适配、禁止切换：{counts.get('adapter_required', 0)}",
        "",
        "## 切换前",
        "",
        "1. 导出并备份每个数据源的完整配置，不只记录 URL。",
        "2. 将 `<MOCK_HOST>` 替换为天策测试运行节点可访问的地址；不能使用 127.0.0.1。",
        "3. 访问 `/health`，确认 HTTP 200、`status=ok`、`strictScenarioKeys=true`。",
        "4. 按 `platform-switch-plan.json` 对每个待切换接口执行探针并保存证据。",
        "5. 确认测试机构和测试渠道隔离，生产流量无法访问 Mock。",
        "",
        "## 手工切换表",
        "",
        "|序号|接口|分类|原 URL|目标 URL|动作|",
        "|---:|---|---|---|---|---|",
    ]
    for entry in entries:
        target = entry["proposedUrl"] or "-"
        action = {
            "allowed_after_probe": "探针通过后可切换",
            "conditional": "仅安全基线，ETL验证后切换",
            "do_not_switch": "禁止切换",
        }[entry["switchDecision"]]
        lines.append(
            f"|{entry['sequence']}|{entry['name']}|{entry['classification']}|"
            f"`{entry['originalUrl']}`|`{target}`|{action}|"
        )
    lines.extend([
        "",
        "## 切换后验证",
        "",
        "1. 先执行一条代表性 SAFE/MISS 用例，检查三方节点 HTTP、状态码和字段结构。",
        "2. 再执行一个已注册 HIT 场景，核对唯一场景键、目标节点和原始响应证据。",
        "3. 未注册场景必须被严格拒绝；缺少证据的规则结果标记为 inconclusive。",
        "4. 企业征信仅允许验证零风险基线，不得据此宣称正向规则已覆盖。",
        "5. 预警通两个接口保持原配置，不能指向本 Mock。",
        "",
        "## 回滚",
        "",
        "测试结束或任一探针失败时，立即按 `platform-rollback-plan.json` 恢复原 URL，",
        "并确认组件日志不再出现 `<MOCK_HOST>:8899`。",
        "",
    ])
    return plan, rollback, "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="生成天策测试环境手工数据源切换方案")
    parser.add_argument("--parsed-strategy", required=True)
    parser.add_argument("--output-dir", default=".")
    args = parser.parse_args()

    parsed_path = Path(args.parsed_strategy)
    parsed = json.loads(parsed_path.read_text(encoding="utf-8"))
    plan, rollback, checklist = build_documents(parsed, str(parsed_path))
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json(output_dir / "platform-switch-plan.json", plan)
    atomic_write_json(output_dir / "platform-rollback-plan.json", rollback)
    atomic_write_text(output_dir / "platform-switch-checklist.md", checklist)
    print(json.dumps(plan["summary"], ensure_ascii=False))


if __name__ == "__main__":
    main()
