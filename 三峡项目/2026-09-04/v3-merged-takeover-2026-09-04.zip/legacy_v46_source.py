#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Mock service for Tiance QCC data sources (v46 - Add StatusCode integer to KYC envelope for 2003 ETL C_N_2003KHSFSBSTATUSCODE).
Compatible with Python 2.7.

v23 changes from v22j:
  1. FIX-742: SumptuaryCheck date field changed from PublishDate to JudgeDate (ETL reads JudgeDate).
  2. FIX-744: JudicialSaleCheck complete rewrite - AuctionDate→ActionRemark(Chinese date), AssetName→Name,
     StartPrice→YiWu, Court→Executegov, added EvaluationPrice.
  3. FIX-748: SeriousIllegalCheck - Reason→AddReason, DecisionOffice→AddOffice, added RemoveReason.
  4. FIX-756: TaxIllegalCheck - PunishDate→PublishDate, PunishGov→TaxGov, added IllegalContent/CaseNature.
  5. FIX-757: TaxOweNoticeCheck RED mode rewrite - TaxOweDate→PublishDate, TaxOweAmt→Amount, TaxGov→IssuedBy.
  6. FIX-865: AdminPenaltyCheck - CaseNo→DocNo, PunishGov→PunishOffice, added PunishResult.
  7. FIX-887: JudgmentDocCheck RED mode restructure - CauseAction→CaseReason, flat PartyList with RoleType.
  8. FIX-882: CourtNoticeCheck - ProsecutorList/DefendantList changed from strings to arrays.
  9. FIX-255: ECICertification response structure changed - Result is direct JSONArray (not nested object).
  10. FIX-KYC: TaxCreditLevel changed from 'C' to 'D' (rules check for 'd' or 'D').

v22i changes from v22h:
  1. Added 84 new RULE_CODE_MAP entries covering EBGS/EBNS/EBGP/EBNP/ECGX/ELDP/ELDS/
     ELLP/ELLS/ELNP/ELNS/ENLX/ENDX/ARGP/ARMP/PLDX/PLEP/PNGX rule families.
  2. Added 15 new YELLOW per-rule data helper functions (_v22i_yellow_NNN).
  3. New KYC function: _kyc_revoke_info() for revocation-based rules.
  4. Added 'revoke' type to _v21_KYC_MAP.
  5. Total RULE_CODE_MAP entries: 143 (was 59 in v22h).

v22h changes from v22g:
  1. CRITICAL FIX: Added call counter per searchKey to isolate related enterprise sub-strategy.
     When RED/YELLOW searchKey exceeds 28 API calls, mode auto-switches to "safe".
     Enterprise sub-strategy uses ~25 endpoints, so the related enterprise sub-strategy
     (which queries after enterprise) gets safe data instead of inheriting risk data.
  2. get_effective_mode() now tracks call_count and last_search_key.
  3. Removed unconditional sticky mode inheritance - each searchKey independently tracked.

v22g changes from v22e:
  1. CRITICAL: detect_mode() now recognizes RULE_{CODE}_TC_{N} format (e.g., RULE_EBNS02_TC_028)
     and routes to YELLOW mode with per-rule data isolation. Previously these searchKeys
     fell through to safe mode or inherited sticky RED mode, causing:
     - Category A (24 cases): over-triggering due to sticky RED mode
     - Category B (7 cases): under-triggering due to safe mode
  2. SUPPLEMENTARY searchKey now routes to yellow_full mode (broad data coverage).
  3. Added 13 missing rule codes to RULE_CODE_MAP:
     EBGP08 (capital increase/KYC), EBGS05/EBGP05 (capdecr boundary),
     EBGS10 (equity + params), EBGP10/EBGP11/EBNP05 (hardcoded params),
     ARGP07 (cancellation -> 739), MAIN01/MAIN03 (boundary tests).
  4. New KYC function: _kyc_capincr_change() for capital increase (EBGP08).
  5. New endpoint function: _v21_yellow_739_cancel() for ARGP07.
  6. extract_rule_code() now supports both YELLOW_RULE_{CODE} and RULE_{CODE} formats.
  7. Placeholder replacement handles RULE_ format enterprise names.
  8. Total RULE_CODE_MAP entries: 66 (was 53).

v21 changes from v21:
  1. Added 17 missing rule codes to RULE_CODE_MAP:
     ELLS03-06, ELDS03-06 (execution/judgment doc rules)
     ENLX02/ENDX03 (tax owe -> 757)
     ENLX08/ENDX09 (admin penalty -> 865)
     ENLX09/ENDX11 (env punishment -> 746)
     ENLX10/ENDX12 (business exception -> 739)
     EBNP06 (cert expiry, handled in cert endpoint)
  2. New endpoint functions: _v21_yellow_746_env, _v21_yellow_757_tax_owe,
     _v21_yellow_887_plaintiff, _v21_yellow_887_defendant.
  3. Total RULE_CODE_MAP entries: 53 (was 36).

v21 changes from v19:
  1. CRITICAL: YELLOW mode now routes QCC data per rule code extracted from searchKey.
     searchKey format: YELLOW_RULE_{RULE_CODE} (e.g., YELLOW_RULE_EBNS02)
     Each rule code maps to specific KYC ChangeList type and/or endpoint data,
     so each test case triggers ONLY its designed rule (not generic 739+741).
  2. Removed universal endpoints 739/741 from YELLOW mode.
  3. Added extract_rule_code() and RULE_CODE_MAP for per-rule routing.
  4. Added rule-specific KYC data functions (equity/scope/legalrep/capdecr).
  5. Added new endpoint data functions: 758 (judgment), 765 (self-prosecution),
     882 (court notice), 751/768 (equity pledge), 742 (preservation).
  6. Version string updated to v21.

v19 changes from v18:
  1. YELLOW mode KYC changed to safe_kyc_data() to avoid legal rep change
     triggering HIGH in non-financing rule sets.
"""
import json
import re
import time
import datetime
import sys
import threading
import urllib
try:  # Python 2
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
except ImportError:  # Python 3
    from http.server import HTTPServer, BaseHTTPRequestHandler
try:  # Python 2
    unicode  # noqa: B018 - py2 builtin check
except NameError:  # Python 3
    unicode = str
if not hasattr(urllib, "unquote"):  # Python 3
    import urllib.parse as _urllib_parse
    urllib.unquote = _urllib_parse.unquote

PORT = 8899

def recent_date(days_ago=30):
    return (datetime.datetime.now() - datetime.timedelta(days=days_ago)).strftime("%Y-%m-%d")

def future_date(days_ahead=365):
    return (datetime.datetime.now() + datetime.timedelta(days=days_ahead)).strftime("%Y-%m-%d")

RECENT = recent_date(20)
RECENT2 = recent_date(40)
FUTURE = future_date(365)
ORDER_SEQ = 0
_seq_lock = threading.Lock()

def next_order(prefix="MOCK"):
    global ORDER_SEQ
    with _seq_lock:
        ORDER_SEQ += 1
        seq = ORDER_SEQ
    return "%s_%d_%d" % (prefix, int(time.time()), seq)

_sticky_mode = {"mode": "safe", "search_key": "", "call_count": 0, "last_search_key": "", "personal_related": False}
_sticky_lock = threading.Lock()
_MAX_RISK_CALLS = 60  # v39: Back to 60 (v38's 200 caused data leakage)

# v36: Personal/related rule code prefixes that activate sticky flag
_PERSONAL_RULE_PREFIXES = ("PLEP", "PLDX", "PNGX")
_RELATED_RULE_PREFIXES = ("ARGP", "ARMP", "ARGS")
_ALL_PERSONAL_RELATED_PREFIXES = _PERSONAL_RULE_PREFIXES + _RELATED_RULE_PREFIXES

# v36: Personal endpoint codes (return risk data when personal_related flag is active)
_PERSONAL_ENDPOINTS = {"764", "765", "766", "767", "768", "771"}
# v36: Related endpoint codes (return risk data when personal_related flag is active)
_RELATED_ENDPOINTS = {"740", "741", "742", "758", "887"}

def _to_unicode(obj):
    """Recursively convert Python 2 byte strings to unicode.

    This is the v18 critical fix. In Python 2, byte strings containing
    \\uXXXX sequences are NOT interpreted as Unicode escapes. Only u"..."
    unicode literals interpret them. The data functions use plain "..."
    strings with \\uXXXX for Chinese characters, so json.dumps sends
    literal \\uXXXX sequences instead of actual Chinese characters.

    By converting to unicode objects first, json.dumps(ensure_ascii=True)
    properly interprets \\uXXXX and produces correct JSON with Chinese chars.
    """
    if isinstance(obj, bytes):  # byte string in Python 2
        return obj.decode("unicode_escape")
    elif isinstance(obj, unicode):
        return obj
    elif isinstance(obj, list):
        return [_to_unicode(item) for item in obj]
    elif isinstance(obj, dict):
        return {_to_unicode(k): _to_unicode(v) for k, v in obj.items()}
    else:
        return obj  # int, float, bool, None

def detect_mode(text):
    if not text:
        return "safe"
    upper = text.upper()
    if "RED_ALERT" in upper or "FULL_RISK" in upper:
        return "red"
    if "YELLOW_FULL" in upper:
        return "yellow_full"
    if "YELLOW" in upper:
        return "yellow"
    if "BLUE_ONLY" in upper:
        return "blue"
    # v22g: recognize RULE_{CODE} format (e.g., RULE_EBNS02_TC_028)
    # These are rule-specific test cases that should use YELLOW per-rule routing
    if re.match(r"RULE_[A-Z]{2,}[0-9]", upper):
        return "yellow"
    # v43: BOUNDARY_ test cases use yellow per-rule routing with 887 override
    if upper.startswith("BOUNDARY_"):
        return "yellow"
    # v43: Chinese company names containing "边界" are boundary tests
    if "\u8fb9\u754c" in text:  # 边界
        return "yellow"
    # v22g: SUPPLEMENTARY test cases use broad yellow data
    if "SUPPLEMENTARY" in upper:
        return "yellow_full"
    return "safe"

def get_effective_mode(search_key):
    """v22i: Track call count per searchKey to isolate related enterprise sub-strategy.

    Enterprise sub-strategy queries ~25 endpoints. After 28 calls with the same
    searchKey, we assume subsequent calls are from the related enterprise sub-strategy
    and return safe data to prevent it from inheriting the risk data.
    """
    with _sticky_lock:
        if search_key:
            # Reset counter if searchKey changed
            if search_key != _sticky_mode.get("last_search_key", ""):
                _sticky_mode["call_count"] = 0
                _sticky_mode["last_search_key"] = search_key

            _sticky_mode["call_count"] = _sticky_mode.get("call_count", 0) + 1
            mode = detect_mode(search_key)
            _sticky_mode["mode"] = mode
            _sticky_mode["search_key"] = search_key

            # v39: Set personal_related flag for personal AND related rule codes
            # Personal: PLEP/PLDX/PNGX
            # Related: ARGS/ARMP (but NOT ARGP which is already in RULE_CODE_MAP)
            # Clear for all other RULE_* codes (enterprise rules)
            rule_code = extract_rule_code(search_key)
            if rule_code:
                if rule_code.startswith(_PERSONAL_RULE_PREFIXES) or rule_code.startswith(("ARGS", "ARMP")):
                    _sticky_mode["personal_related"] = True
                else:
                    # Enterprise or ARGP rule code - clear personal flag
                    _sticky_mode["personal_related"] = False
            elif not re.match(r"(?i)^(RULE_|YELLOW_|RED_|BLUE_|SUPPLEMENTARY|SAFE_)", search_key):
                # Non-RULE searchKey (person name / company USCC) - keep flag as-is
                pass

            # For risk modes, enforce call limit to isolate related enterprise sub-strategy
            if mode in ("red", "yellow", "yellow_full", "blue"):
                if _sticky_mode["call_count"] > _MAX_RISK_CALLS:
                    print("[v24] Call limit exceeded (%d > %d) for searchKey=%s -> safe" % (
                        _sticky_mode["call_count"], _MAX_RISK_CALLS, search_key))
                    return "safe"
            return mode
        # No searchKey: v25 fix - conditional sticky mode
        # When previous searchKey was RULE_* format, don't inherit sticky mode
        # to prevent cross-contamination between different rule tests.
        # For RED_ALERT/YELLOW/etc. formats, keep legacy sticky behavior.
        last_sk = _sticky_mode.get("last_search_key", "")
        mode = _sticky_mode.get("mode", "safe")
        if last_sk and re.match(r"(?i)RULE_[A-Z]", last_sk):
            # v25: RULE_* searchKeys don't propagate via sticky mode
            return "safe"
        if mode in ("red", "yellow", "yellow_full", "blue"):
            _sticky_mode["call_count"] = _sticky_mode.get("call_count", 0) + 1
            if _sticky_mode["call_count"] > _MAX_RISK_CALLS:
                return "safe"
        return mode

# ============================================================
# BLUE mode data - triggers exactly 1 low-risk indicator
# ============================================================
def blue_kyc_data():
    """KYC with 4 types of changes -> triggers LOW-risk EBGS01/02/03/08 rules.

    v17 fix: Changed BeforeContent/AfterContent (strings) to BeforeList/AfterList
    (JSONArrays) to match what the 2003 ETL actually reads via getJSONArray().
    Also changed RevokeInfo from [] to {} to match ETL's getJSONObject() expectation.
    Without this fix, ETL produces count=0 for capital increase/decrease because
    parseFirstListAmount(null) returns 0.0, and may crash on RevokeInfo array.
    """
    return {
        "RegistCapi": "5000\u4e07\u5143", "RealCapi": "5000\u4e07\u5143", "StartDate": "2010-01-01",
        "ChangeList": [
            {"ChangeDate": RECENT, "ProjectName": "\u6cd5\u5b9a\u4ee3\u8868\u4eba\u53d8\u66f4",
             "BeforeList": ["\u5f20\u4e09"], "AfterList": ["\u674e\u56db"]},
            {"ChangeDate": RECENT, "ProjectName": "\u80a1\u6743\u53d8\u66f4",
             "BeforeList": ["\u5f20\u4e09 50%;\u674e\u56db 50%"],
             "AfterList": ["\u5f20\u4e09 30%;\u674e\u56db 50%;\u738b\u4e94 20%"]},
            {"ChangeDate": RECENT, "ProjectName": "\u7ecf\u8425\u8303\u56f4\u53d8\u66f4",
             "BeforeList": ["\u6280\u672f\u5f00\u53d1"],
             "AfterList": ["\u6280\u672f\u5f00\u53d1\uff1b\u6280\u672f\u54a8\u8be2"]},
            {"ChangeDate": RECENT, "ProjectName": "\u6ce8\u518c\u8d44\u672c\u53d8\u66f4",
             "BeforeList": ["3000\u4e07\u5143"], "AfterList": ["5000\u4e07\u5143"]}
        ],
        "TaxCreditList": [{"Year": "2025", "Level": "A"}],
        "PubPartnerList": [],
        "InvestmentList": [],
        "RevokeInfo": {}
    }

# ============================================================
# YELLOW mode data - triggers 1-2 medium-risk indicators
# ============================================================
def yellow_data_741():
    return [{"Liandate": RECENT, "Anno": "(2026)X01\u6267\u5b57\u7b2c100\u53f7", "ExecuteGov": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "Biaodi": "3000000\u5143", "SuspectedApplicant": "XX\u94f6\u884c"}]

def yellow_data_739():
    return [
        {"RemoveDate": "", "AddReason": "\u901a\u8fc7\u767b\u8bb0\u7684\u4f4f\u6240\u6216\u7ecf\u8425\u573a\u6240\u65e0\u6cd5\u8054\u7cfb", "AddDate": RECENT,
         "DecisionOffice": "XX\u5e02\u573a\u76d1\u7763\u7ba1\u7406\u5c40"}
    ]

def yellow_data_742():
    """v23 FIX-742: ETL reads JudgeDate (not PublishDate) for date filtering"""
    return [{"JudgeDate": RECENT, "CaseNo": "(2026)X01\u6267\u9650\u5b57\u7b2cY01\u53f7",
             "PersonName": "\u5f20\u4e09", "CompanyName": "YELLOW_ENTERPRISE",
             "Applicant": "XX\u94f6\u884c", "Amount": "500000"}]

def yellow_data_751():
    return [{"Status": "\u6709\u6548", "RegistNo": "\u80a1\u8d28\u767b\u5b57[2026]\u7b2cY01\u53f7", "PledgorName": "YELLOW_ENTERPRISE",
             "PledgeeName": "XX\u94f6\u884c", "RegDate": RECENT, "PledgedAmount": "500\u4e07\u5143"}]

def yellow_data_768():
    return [{"Status": "\u6709\u6548", "RegistNo": "\u80a1\u8d28\u767b\u5b57[2026]\u7b2cY02\u53f7", "PledgorName": "\u5f20\u4e09",
             "PledgeeName": "XX\u94f6\u884c", "RegDate": RECENT, "PledgedAmount": "300\u4e07\u5143"}]

def yellow_kyc_data():
    """KYC with legal rep change -> triggers C_N_CHGLEGALREPCNT=1"""
    return {
        "RegistCapi": "5000\u4e07\u5143", "RealCapi": "5000\u4e07\u5143", "StartDate": "2010-01-01",
        "ChangeList": [
            {"ChangeDate": RECENT, "ProjectName": "\u6cd5\u5b9a\u4ee3\u8868\u4eba\u53d8\u66f4",
             "BeforeList": ["\u5f20\u4e09"], "AfterList": ["\u674e\u56db"]}
        ],
        "TaxCreditList": [{"Year": "2025", "Level": "A"}],
        "PubPartnerList": [],
        "InvestmentList": [],
        "RevokeInfo": {}
    }

# ============================================================
# RED mode data - all endpoints return risk data
# ============================================================
def red_data_739():
    return [
        {"RemoveDate": "", "AddReason": "\u901a\u8fc7\u767b\u8bb0\u7684\u4f4f\u6240\u6216\u7ecf\u8425\u573a\u6240\u65e0\u6cd5\u8054\u7cfb", "AddDate": RECENT, "DecisionOffice": "XX\u5e02\u573a\u76d1\u7763\u7ba1\u7406\u5c40"},
        {"RemoveDate": "", "AddReason": "\u672a\u4f9d\u7167\u89c4\u5b9a\u516c\u793a\u5e74\u5ea6\u62a5\u544a", "AddDate": RECENT2, "DecisionOffice": "XX\u5e02\u573a\u76d1\u7763\u7ba1\u7406\u5c40"}
    ]

def red_data_740():
    return [
        {"Liandate": RECENT, "Anno": "(2026)X01\u6267\u5b57\u7b2c201\u53f7", "Executegov": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
         "Executestatus": "\u5168\u90e8\u672a\u5c65\u884c", "Publicdate": RECENT, "Amount": "5000000"},
        {"Liandate": RECENT2, "Anno": "(2026)X01\u6267\u5b57\u7b2c202\u53f7", "Executegov": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
         "Executestatus": "\u5168\u90e8\u672a\u5c65\u884c", "Publicdate": RECENT2, "Amount": "3000000"}
    ]

def red_data_741():
    return [
        {"Liandate": RECENT, "Anno": "(2026)X01\u6267\u5b57\u7b2c301\u53f7", "ExecuteGov": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
         "Biaodi": "5000000\u5143", "SuspectedApplicant": "XX\u94f6\u884c"}
    ]

def red_data_742():
    """v23 FIX-742: ETL reads JudgeDate (not PublishDate) for date filtering"""
    return [{"JudgeDate": RECENT, "CaseNo": "(2026)X01\u6267\u9650\u5b57\u7b2c001\u53f7",
             "PersonName": "\u5f20\u4e09", "CompanyName": "RED_ALERT_ENTERPRISE",
             "Applicant": "XX\u94f6\u884c", "Amount": "1000000"}]

def red_data_744():
    """v23 FIX-744: ETL reads ActionRemark (Chinese date), Name, Executegov, YiWu, EvaluationPrice"""
    import datetime as _dt
    cn_date = _dt.datetime.now().strftime("%Y\u5e74%m\u6708%d\u65e5")
    return [{"ActionRemark": cn_date + "\u4e0a\u534810\u65f6\u81f3" + cn_date + "\u4e0b\u534816\u65f6",
             "Name": "\u623f\u4ea7\u53f8\u6cd5\u62cd\u5356", "CaseNo": "JD2026001",
             "Executegov": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "YiWu": "500\u4e07\u5143", "EvaluationPrice": "800\u4e07\u5143"}]

def red_data_746():
    return [{"PunishDate": RECENT, "CaseNo": "X\u73af\u5883\u7f5a[2026]001\u53f7",
             "PunishGov": "XX\u5e02\u73af\u5883\u4fdd\u62a4\u5c40", "PunishAmt": "100000",
             "IllegalContent": "\u8d85\u6807\u6392\u653e", "PunishReason": "\u8fdd\u53cd\u73af\u4fdd\u6cd5"}]

def red_data_748():
    """v23 FIX-748: ETL reads AddReason (not Reason), AddOffice (not DecisionOffice), RemoveReason"""
    return [{"AddDate": RECENT, "AddReason": "\u4e25\u91cd\u8fdd\u6cd5\u884c\u4e3a",
             "AddOffice": "XX\u5e02\u573a\u76d1\u7763\u7ba1\u7406\u5c40",
             "RemoveReason": "", "RemoveDate": ""}]

def red_data_751():
    return [{"Status": "\u6709\u6548", "RegistNo": "\u80a1\u8d28\u767b\u5b57[2026]\u7b2c001\u53f7",
             "PledgorName": "RED_ALERT_ENTERPRISE", "PledgeeName": "XX\u94f6\u884c",
             "RegDate": RECENT, "PledgedAmount": "1000\u4e07\u5143"}]

def red_data_752():
    return [{"FreezeEndDate": FUTURE, "Status": "\u51bb\u7ed3", "ExecuteName": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "EquityAmount": "500\u4e07\u5143", "ExecuteCourt": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662", "FreezeStartDate": RECENT}]

def red_data_756():
    """v23 FIX-756: ETL reads PublishDate (not PunishDate), TaxGov, IllegalContent, CaseNature"""
    return [{"PublishDate": RECENT, "TaxGov": "XX\u5e02\u7a0e\u52a1\u5c40",
             "IllegalContent": "\u5077\u7a0e", "CaseNature": "\u7a0e\u6536\u8fdd\u6cd5"}]

def red_data_757():
    """v23 FIX-757: ETL reads PublishDate (not TaxOweDate), Title, Amount (not TaxOweAmt), IssuedBy"""
    return [{"PublishDate": RECENT, "Title": "\u589e\u503c\u7a0e\u6b20\u7a0e\u516c\u544a",
             "Amount": "1000000", "IssuedBy": "XX\u5e02\u7a0e\u52a1\u5c40"}]

def red_data_758():
    """v43: 终本记录 - field names: ExecuteGov/Lian/Biaodi"""
    return [{"CaseNo": "(2026)X01\u7ec8\u5b57\u7b2c001\u53f7",
             "Lian": RECENT,
             "ExecuteGov": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "Biaodi": "3000000"}]

def red_data_761():
    return [{"CaseNo": "(2026)X01\u7834\u5b57\u7b2c001\u53f7", "PublicDate": RECENT}]

def red_data_764():
    return [{"Liandate": RECENT, "Anno": "(2026)X01\u6267\u5b57\u7b2c401\u53f7", "Executegov": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "Executestatus": "\u5168\u90e8\u672a\u5c65\u884c", "Publicdate": RECENT, "Amount": "1000000"}]

def red_data_765():
    return [{"Liandate": RECENT, "Anno": "(2026)X01\u6267\u5b57\u7b2c501\u53f7", "ExecuteGov": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "Biaodi": "800000\u5143"}]

def red_data_766():
    return [{"PublishDate": RECENT, "CaseNo": "(2026)X01\u6267\u9650\u5b57\u7b2c002\u53f7", "PersonName": "\u5f20\u4e09",
             "CompanyName": "RED_ALERT_ENTERPRISE", "Applicant": "XX\u94f6\u884c"}]

def red_data_767():
    return [{"FreezeEndDate": FUTURE, "Status": "\u51bb\u7ed3", "ExecuteName": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "EquityAmount": "200\u4e07\u5143", "ExecuteCourt": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662", "FreezeStartDate": RECENT}]

def red_data_768():
    return [{"Status": "\u6709\u6548", "RegistNo": "\u80a1\u8d28\u767b\u5b57[2026]\u7b2c002\u53f7", "PledgorName": "\u5f20\u4e09",
             "PledgeeName": "XX\u94f6\u884c", "RegDate": RECENT, "PledgedAmount": "300\u4e07\u5143"}]

def red_data_771():
    return [{"LianDate": RECENT, "CaseNo": "(2026)X01\u7ec8\u5b57\u7b2c002\u53f7", "Court": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "EndDate": RECENT, "ExecuteSubject": "\u5f20\u4e09", "UnperformedAmt": "500000"}]

def red_data_882():
    """v23 FIX-882: ProsecutorList/DefendantList changed to arrays (ETL uses getJSONArray)"""
    return [{
        "PublishDate": RECENT, "CaseReason": "\u91d1\u878d\u501f\u6b3e\u5408\u540c\u7ea0\u7eb7",
        "CaseNo": "(2026)X01\u6c11\u521d\u5b57\u7b2c001\u53f7", "Category": "\u6c11\u4e8b", "Court": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
        "ProsecutorList": ["XX\u94f6\u884c"], "DefendantList": ["RED_ALERT_ENTERPRISE"],
        "RoleList": [
            {"RoleType": "2", "RoleItemList": [{"Name": "XX\u94f6\u884c"}]},
            {"RoleType": "1", "RoleItemList": [{"Name": "RED_ALERT_ENTERPRISE"}]}
        ]
    }]

def red_data_887():
    """v23 FIX-887: ETL reads CaseReason (not CauseAction), PartyList at top level with RoleType/Name"""
    return [{
        "PublishDate": RECENT, "CaseReason": "\u91d1\u878d\u501f\u6b3e\u5408\u540c\u7ea0\u7eb7",
        "CaseName": "\u91d1\u878d\u501f\u6b3e\u5408\u540c\u7ea0\u7eb7\u6848", "CaseNo": "(2026)X01\u6c11\u521d100\u53f7",
        "CaseType": "", "Amount": "5000000",
        "IsDefendant": "1", "IsProsecutor": "0",
        "PartyList": [{"Name": "RED_ALERT_ENTERPRISE", "RoleType": "\u88ab\u544a"}]
    }]

def red_data_888():
    return [{
        "CourtTime": recent_date(10) + " 09:30", "CaseReason": "\u501f\u6b3e\u5408\u540c\u7ea0\u7eb7",
        "CaseNo": "(2026)X01\u6c11\u521d\u5b57\u7b2c003\u53f7", "Court": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
        "RoleList": [
            {"RoleType": "2", "RoleItemList": [{"Name": "XX\u94f6\u884c"}]},
            {"RoleType": "1", "RoleItemList": [{"Name": "RED_ALERT_ENTERPRISE"}]}
        ]
    }]

def red_data_958():
    return [{
        "PublishDate": RECENT, "Title": "XX\u5e02\u653f\u5de5\u7a0b\u9879\u76ee",
        "ProjectNo": "ZB2026001",
        "WinBidUnitList": [{"WinBidAmt": "5000\u4e07\u5143", "Name": "RED_ALERT_ENTERPRISE"}],
        "BudgetAmt": "6000\u4e07\u5143",
        "BidInviUnitList": [{"Name": "XX\u5e02\u4f4f\u5efa\u5c40"}]
    }]

def red_data_865():
    """v23 FIX-865: ETL reads DocNo (not CaseNo), PunishOffice (not PunishGov), PunishResult"""
    return [{"PunishDate": RECENT, "DocNo": "X\u5e02\u76d1\u7f5a[2026]001\u53f7",
             "PunishReason": "\u8fdd\u53cd\u5e7f\u544a\u6cd5", "PunishResult": "\u7f5a\u6b3e20\u4e07\u5143",
             "PunishOffice": "XX\u5e02\u573a\u76d1\u7763\u7ba1\u7406\u5c40", "PunishAmt": "200000"}]

def red_kyc_data():
    return {
        "RegistCapi": "5000\u4e07\u5143", "RealCapi": "3000\u4e07\u5143", "StartDate": "2010-01-01",
        "ChangeList": [
            {"ChangeDate": RECENT, "ProjectName": "\u6cd5\u5b9a\u4ee3\u8868\u4eba\u53d8\u66f4",
             "BeforeList": ["\u5f20\u4e09"], "AfterList": ["\u674e\u56db"]},
            {"ChangeDate": RECENT2, "ProjectName": "\u6ce8\u518c\u8d44\u672c\u53d8\u66f4",
             "BeforeList": ["5000\u4e07\u5143"], "AfterList": ["3000\u4e07\u5143"]}
        ],
        "TaxCreditList": [{"Year": "2025", "Level": "D"}],
        "PubPartnerList": [
            {"Name": "\u5173\u8054\u5931\u4fe1\u80a1\u4e1cA", "CreditCode": "91110000MA001X",
             "DishonestInfo": {"Iname": "\u5173\u8054\u5931\u4fe1\u80a1\u4e1cA", "CaseCode": "(2026)X01\u6267\u5b57\u7b2c601\u53f7"}}
        ],
        "InvestmentList": [
            {"KeyNo": "RED_ALERT_INV_001", "Name": "失信被投企业A",
             "FundedRatio": "30%"}
        ],
        "RevokeInfo": {}
    }

def safe_kyc_data():
    return {
        "RegistCapi": "5000\u4e07\u5143", "RealCapi": "5000\u4e07\u5143", "StartDate": "2010-01-01",
        "ChangeList": [],
        "TaxCreditList": [{"Year": "2025", "Level": "A"}],
        "PubPartnerList": [],
        "InvestmentList": [],
        "RevokeInfo": {}
    }

# Credit report
def _credit_report_xml(badloanbal=0, odloanacctcnt=0, attnloanacctcnt=0,
                        odguaacctcnt=0, badguabal=0, attnguaacctcnt=0,
                        unpaidintbal=0, ent_name=u"\u6d4b\u8bd5\u4f01\u4e1a", ent_cert_num="000000000000000000"):
    # v31: Complete rewrite based on ETL source code analysis.
    # When params are all zero (default), return empty record lists -> ETL produces zeros.
    # When any param is non-zero, return detailed account records that trigger all ECGX rules.
    if isinstance(ent_name, bytes):
        try:
            ent_name = ent_name.decode('utf-8')
        except:
            ent_name = ent_name.decode('latin-1')
    if isinstance(ent_cert_num, bytes):
        ent_cert_num = ent_cert_num.decode('utf-8')

    # Determine if we should include detailed records
    has_data = any([badloanbal, odloanacctcnt, attnloanacctcnt,
                    odguaacctcnt, badguabal, attnguaacctcnt, unpaidintbal])

    if has_data:
        # Return detailed records that trigger all ECGX rules
        basic_borrowing = (
            u'<basicBorrowingList>'
            u'<Crt2_C_BasicBorrowing><loanaccountid>ACCT001</loanaccountid><accountactivitystatus>1</accountactivitystatus></Crt2_C_BasicBorrowing>'
            u'<Crt2_C_BasicBorrowing><loanaccountid>ACCT002</loanaccountid><accountactivitystatus>1</accountactivitystatus></Crt2_C_BasicBorrowing>'
            u'<Crt2_C_BasicBorrowing><loanaccountid>ACCT003</loanaccountid><accountactivitystatus>1</accountactivitystatus></Crt2_C_BasicBorrowing>'
            u'</basicBorrowingList>'
        )
        loan_repayment = (
            u'<loanAccountInformation><loanRepaymentList>'
            u'<Crt2_C_LoanRepayment><loanaccount>ACCT001</loanaccount><totaloverdue>50000</totaloverdue><overduemonths>3</overduemonths></Crt2_C_LoanRepayment>'
            u'<Crt2_C_LoanRepayment><loanaccount>ACCT002</loanaccount><totaloverdue>30000</totaloverdue><overduemonths>2</overduemonths></Crt2_C_LoanRepayment>'
            u'<Crt2_C_LoanRepayment><loanaccount>ACCT003</loanaccount><totaloverdue>10000</totaloverdue><overduemonths>1</overduemonths></Crt2_C_LoanRepayment>'
            u'</loanRepaymentList></loanAccountInformation>'
        )
        summary_loans = (
            u'<summaryOfLoans><othLoanSumList>'
            u'<Crt2_C_OthLoanSum><assetquality>3</assetquality><balance>5000000</balance><accountnumber>2</accountnumber></Crt2_C_OthLoanSum>'
            u'<Crt2_C_OthLoanSum><assetquality>2</assetquality><balance>3000000</balance><accountnumber>2</accountnumber></Crt2_C_OthLoanSum>'
            u'</othLoanSumList></summaryOfLoans>'
        )
        related_repayment = (
            u'<relatedRepayment>'
            u'<rrAccountList><Crt2_C_RRAccount><totaloverdue>200000</totaloverdue><overduemonths>2</overduemonths><repaymentstate>0</repaymentstate><accountid>GUA001</accountid></Crt2_C_RRAccount></rrAccountList>'
            u'<rrDiscountingList><Crt2_C_RRDiscounting><discountaccountid>DISC001</discountaccountid><totaloverdue>100000</totaloverdue></Crt2_C_RRDiscounting></rrDiscountingList>'
            u'</relatedRepayment>'
        )
        guarantee_summary = (
            u'<guaranteeSummary><unscGuaranteeList>'
            u'<Crt2_C_UnscGuarantee><assetquality>3</assetquality><balance>2000000</balance><accountnumber>1</accountnumber></Crt2_C_UnscGuarantee>'
            u'<Crt2_C_UnscGuarantee><assetquality>2</assetquality><balance>1000000</balance><accountnumber>1</accountnumber></Crt2_C_UnscGuarantee>'
            u'</unscGuaranteeList></guaranteeSummary>'
        )
    else:
        # Return empty record lists -> ETL produces all zeros
        basic_borrowing = u'<basicBorrowingList></basicBorrowingList>'
        loan_repayment = u'<loanAccountInformation><loanRepaymentList></loanRepaymentList></loanAccountInformation>'
        summary_loans = u'<summaryOfLoans><othLoanSumList></othLoanSumList></summaryOfLoans>'
        related_repayment = u'<relatedRepayment><rrAccountList></rrAccountList><rrDiscountingList></rrDiscountingList></relatedRepayment>'
        guarantee_summary = u'<guaranteeSummary><unscGuaranteeList></unscGuaranteeList></guaranteeSummary>'

    inner_xml = (
        u'<Document>'
        u'<basicInfo><entName>{ent_name}</entName><entCertNum>{ent_cert_num}</entCertNum></basicInfo>'
        u'<Crt2_C_ReportHeader><reportid>MOCK_QYZXBG_001</reportid></Crt2_C_ReportHeader>'
        u'{basic_borrowing}'
        u'{loan_repayment}'
        u'{summary_loans}'
        u'{related_repayment}'
        u'{guarantee_summary}'
        u'<Crt2_C_LoanOutstanding><unpaidintbal>{unpaidintbal}</unpaidintbal></Crt2_C_LoanOutstanding>'
        u'<qyzxbgstatuscode>200</qyzxbgstatuscode>'
        u'</Document>'
    ).format(
        ent_name=ent_name, ent_cert_num=ent_cert_num,
        basic_borrowing=basic_borrowing, loan_repayment=loan_repayment,
        summary_loans=summary_loans, related_repayment=related_repayment,
        guarantee_summary=guarantee_summary, unpaidintbal=unpaidintbal
    )
    soap_xml = (
        u'<?xml version="1.0" encoding="UTF-8"?>'
        u'<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
        u'<soap:Body><return>'
        u'<retCode>1</retCode><retInfo>\u67e5\u8be2\u6210\u529f</retInfo>'
        u'<reportId>MOCK_RPT_{ent_cert_num}</reportId>'
        u'<result><![CDATA[{inner}]]></result>'
        u'</return></soap:Body></soap:Envelope>'
    ).format(inner=inner_xml, ent_cert_num=ent_cert_num)
    return soap_xml.encode("utf-8")

MSG_OK = u"\u3010\u6709\u6548\u8bf7\u6c42\u3011\u67e5\u8be2\u6210\u529f"

def make_safe_list():
    return {"Status": "200", "Message": MSG_OK, "OrderNumber": next_order("LIST"),
            "Paging": {"PageIndex": 1, "PageSize": 20, "TotalRecords": 0},
            "Result": {"VerifyResult": 0, "Data": []}}

def make_risk_list(data_items):
    return {"Status": "200", "Message": MSG_OK, "OrderNumber": next_order("LIST"),
            "Paging": {"PageIndex": 1, "PageSize": 20, "TotalRecords": len(data_items)},
            "Result": {"VerifyResult": 1, "Data": data_items}}

def make_safe_detail():
    return {"Status": "200", "Message": MSG_OK, "OrderNumber": next_order("DETAIL"),
            "Result": {"VerifyResult": 0, "Data": {}}}

def make_risk_detail(data_obj):
    return {"Status": "200", "Message": MSG_OK, "OrderNumber": next_order("DETAIL"),
            "Result": {"VerifyResult": 1, "Data": data_obj}}

def make_safe_cert():
    return {"Status": "200", "Message": MSG_OK, "OrderNumber": next_order("CERT"),
            "Paging": {"PageIndex": 1, "PageSize": 20, "TotalRecords": 0},
            "Result": {"VerifyResult": 0, "Data": {"CertList": []}}}

def make_risk_cert(data_items):
    return {"Status": "200", "Message": MSG_OK, "OrderNumber": next_order("CERT"),
            "Paging": {"PageIndex": 1, "PageSize": 20, "TotalRecords": len(data_items)},
            "Result": {"VerifyResult": 1, "Data": {"CertList": data_items}}}

def make_risk_cert_255(data_items):
    """v23 FIX-255: ETL reads responseJson.getJSONArray('Result') directly.
    Result must be a top-level JSONArray, NOT a nested object."""
    return {"Status": "200", "Message": MSG_OK, "OrderNumber": next_order("CERT"),
            "Paging": {"PageIndex": 1, "PageSize": 20, "TotalRecords": len(data_items)},
            "Result": data_items}

def make_safe_cert_255():
    """v23 FIX-255: Safe cert response with empty Result array."""
    return {"Status": "200", "Message": MSG_OK, "OrderNumber": next_order("CERT"),
            "Paging": {"PageIndex": 1, "PageSize": 20, "TotalRecords": 0},
            "Result": []}

def make_kyc(data_obj):
    # v46 fix: Add StatusCode (int) alongside Status (str) for 2003 ETL
    # ETL reads C_N_2003KHSFSBSTATUSCODE which expects integer 200;
    # string "200" was being parsed as 0, causing all data processing to be skipped.
    return {"Status": "200", "StatusCode": 200, "Message": MSG_OK, "OrderNumber": next_order("KYC"),
            "Result": {"VerifyResult": 1, "Data": data_obj}}

LIST_RISK_MAP = {
    "ExceptionCheck": "739", "ShixinCheck": "740", "ZhixingCheck": "741",
    "SumptuaryCheck": "742", "JudicialSaleCheck": "744", "EnvPunishmentCheck": "746",
    "SeriousIllegalCheck": "748", "EquityPledgedCheck": "751", "EquityFreezeCheck": "752",
    "TaxIllegalCheck": "756", "TaxOweNoticeCheck": "757", "EndExecuteCaseCheck": "758",
    "BankruptcyCheck": "761", "PersonSXCheck": "764", "PersonZXCheck": "765",
    "PersonSumptuaryCheck": "766", "PersonSEFreezeCheck": "767", "PersonSEPledgedCheck": "768",
    "PersonEndExCaseCheck": "771", "CourtNoticeCheck": "882", "JudgmentDocCheck": "887",
    "CourtAnnoCheck": "888", "TenderCheck": "958", "AdminPenaltyCheck": "865",
}

DETAIL_PATTERNS = ["LiquidationCheck"]
CERT_PATTERNS = ["ECICertification"]

# --- v14: Blue mode - LOW risk indicators ---
def blue_data_751():
    """Small equity pledge -> LOW risk"""
    return [{"Status": "有效", "RegistNo": "股质登字[2026]第B01号",
             "PledgorName": "BLUE_ENTERPRISE", "PledgeeName": "XX银行",
             "RegDate": RECENT, "PledgedAmount": "50万元"}]

def blue_data_882():
    """Court notice (enterprise as plaintiff, not defendant) -> LOW risk"""
    return [{"PublishDate": RECENT, "CaseReason": "合同纠纷",
             "CaseNo": "(2026)X01民初字第B01号", "Category": "民事", "Court": "XX市人民法院",
             "ProsecutorList": ["BLUE_ENTERPRISE"], "DefendantList": ["XX贸易公司"],
             "RoleList": [{"RoleType": "2", "RoleItemList": [{"Name": "BLUE_ENTERPRISE"}]},
                          {"RoleType": "1", "RoleItemList": [{"Name": "XX贸易公司"}]}]}]

def blue_data_887():
    """v23 FIX-887: LOW risk judgment doc - ETL reads CaseReason, flat PartyList with RoleType"""
    return [{"CaseNo": "(2026)X01民初B02号", "CaseReason": "买卖合同纠纷",
             "CaseName": "买卖合同纠纷案", "PublishDate": RECENT,
             "Amount": "500000", "IsDefendant": "0", "IsProsecutor": "1",
             "CaseType": "",
             "PartyList": [{"Name": "BLUE_ENTERPRISE", "RoleType": "原告"}]}]

def blue_data_888():
    """Court announcement -> LOW risk"""
    return [{"CourtTime": recent_date(10) + " 09:30", "CaseReason": "合同纠纷",
             "CaseNo": "(2026)X01民初字第B03号", "Court": "XX市人民法院",
             "RoleList": [{"RoleType": "2", "RoleItemList": [{"Name": "BLUE_ENTERPRISE"}]},
                          {"RoleType": "1", "RoleItemList": [{"Name": "XX供应商"}]}]}]

# --- v14: Additional Yellow mode - MEDIUM risk indicators ---
def yellow_data_752():
    """Equity freeze -> MEDIUM risk"""
    return [{"FreezeEndDate": FUTURE, "Status": "冻结", "ExecuteName": "XX市人民法院",
             "EquityAmount": "100万元", "ExecuteCourt": "XX市人民法院", "FreezeStartDate": RECENT}]

def yellow_data_756():
    """v23 FIX-756: ETL reads PublishDate (not PunishDate), TaxGov (not PunishGov), IllegalContent, CaseNature"""
    return [{"PublishDate": RECENT, "TaxGov": "XX市税务局",
             "IllegalContent": "未按期申报", "CaseNature": "税收违法"}]

def yellow_data_757():
    """v23 FIX-757: ETL reads PublishDate, Title, Amount, IssuedBy"""
    return [{"Title": "增值税", "Amount": "20000",
             "PublishDate": RECENT, "IssuedBy": "XX市税务局"}]

def yellow_data_882():
    """v23 FIX-882: ProsecutorList/DefendantList changed to arrays (ETL uses getJSONArray)"""
    return [{"PublishDate": RECENT, "CaseReason": "\u91d1\u878d\u501f\u6b3e\u5408\u540c\u7ea0\u7eb7",
             "CaseNo": "(2026)X01\u6c11\u521d\u5b57\u7b2cY01\u53f7", "Category": "\u6c11\u4e8b", "Court": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "ProsecutorList": ["XX\u94f6\u884c"], "DefendantList": ["YELLOW_ENTERPRISE"],
             "RoleList": [{"RoleType": "2", "RoleItemList": [{"Name": "XX\u94f6\u884c"}]},
                          {"RoleType": "1", "RoleItemList": [{"Name": "YELLOW_ENTERPRISE"}]}]}]

def yellow_data_887():
    """Judgment doc (defendant) -> MEDIUM risk - v22g: RoleType=Chinese, Name matched by searchKey"""
    return [{"Id": "mock_887_ells04_001",
             "CaseNo": "(2026)X01\u6c11\u521dY02\u53f7", "CaseName": "\u501f\u6b3e\u5408\u540c\u7ea0\u7eb7",
             "CaseReason": "\u501f\u6b3e\u5408\u540c\u7ea0\u7eb7", "Amount": "3000000",
             "IsDefendant": "1", "IsProsecutor": "0",
             "JudgeDate": RECENT, "PublishDate": RECENT,
             "JudgeResult": "\u5224\u51b3", "Court": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "PartyList": [{"Name": "YELLOW_ENTERPRISE", "RoleType": "\u88ab\u544a",
                            "Statement": "\u88ab\u544a", "Keyno": ""}]}]

def yellow_data_865():
    """v28 FIX: Admin penalty with PunishAmt=60000 (>50000 threshold for ENDX10 high risk)"""
    return [{"PunishDate": RECENT, "DocNo": "X\u5e02\u76d1\u7f5a[2026]Y01\u53f7",
             "PunishReason": "\u8fdd\u53cd\u516c\u53f8\u6cd5", "PunishResult": "\u7f5a\u6b3e6\u4e07\u5143",
             "PunishOffice": "XX\u5e02\u5e02\u573a\u76d1\u7763\u7ba1\u7406\u5c40", "PunishAmt": "60000"}]

BLUE_FUNCS = {}
YELLOW_FUNCS = {"741": yellow_data_741, "739": yellow_data_739}
YELLOW_FULL_FUNCS = {"741": yellow_data_741, "739": yellow_data_739, "751": yellow_data_751, "768": yellow_data_768,
                "752": yellow_data_752, "756": yellow_data_756, "757": yellow_data_757,
                "882": yellow_data_882, "887": yellow_data_887, "865": yellow_data_865,
                # v36: Add personal/related/758 endpoints for personal_related flag and A class fix
                "740": red_data_740, "742": red_data_742, "758": red_data_758,
                "764": red_data_740, "765": red_data_741, "766": red_data_742,
                "767": red_data_767, "771": red_data_771,
                "761": red_data_761}  # v37: Add 761 for ELLP08 (bankruptcy)

RED_FUNCS = {
    "739": red_data_739, "740": red_data_740, "741": red_data_741, "742": red_data_742,
    "744": red_data_744, "746": red_data_746, "748": red_data_748, "751": red_data_751,
    "752": red_data_752, "756": red_data_756, "757": red_data_757, "758": red_data_758,
    "761": red_data_761, "764": red_data_764, "765": red_data_765, "766": red_data_766,
    "767": red_data_767, "768": red_data_768, "771": red_data_771, "865": red_data_865,
    "882": red_data_882, "887": red_data_887, "888": red_data_888, "958": red_data_958,
}

# ============================================================
# v21: Rule-code-based routing for YELLOW mode
# ============================================================
def extract_rule_code(search_key):
    """Extract rule code from searchKey.
    Supports three formats:
      YELLOW_RULE_EBNS02 -> EBNS02 (original v21 format)
      RULE_EBNS02_TC_028 -> EBNS02 (v22g test case format)
      YELLOW_TC_072 -> ELDS07 (v40 affiliatedUscc format via mapping)
    """
    if not search_key:
        return None
    upper = search_key.upper()
    # Try YELLOW_RULE_{CODE} format first
    m = re.match(r"YELLOW_RULE_([A-Z0-9]+)", upper)
    if m:
        return m.group(1)
    # Try RULE_{CODE}_TC_{N} or RULE_{CODE} format
    m = re.match(r"RULE_([A-Z]{2,}[0-9][A-Z0-9]*)", upper)
    if m:
        return m.group(1)
    # v40: Try affiliatedUscc format (YELLOW_TC_NNN, RED_ALERT_TC_NNN)
    aff_to_rule = {
        "YELLOW_TC_072": "ELDS07", "RED_ALERT_TC_062": "ELLS06",
        "RED_ALERT_TC_071": "ELDS06", "RED_ALERT_TC_081": "ELNS06",
        "YELLOW_TC_082": "ELNS07", "RED_ALERT_TC_091": "ELLP06",
        "RED_ALERT_TC_249": "ELLP06", "RED_ALERT_TC_100": "ELDP06",
        "RULE_ELDP07_TC_101": "ELDP07", "RED_ALERT_TC_110": "ELNP06",
        "RULE_ELNP07_TC_111": "ELNP07", "RED_ALERT_TC_149": "ARGS02",
        "RED_ALERT_TC_250": "ARGP06",
        # v43: Boundary test searchKeys → route to ELLP06 for per-rule yellow routing
        "BOUNDARY_COUNT5_TC_206": "ELLP06",
        "BOUNDARY_COUNT4_TC_207": "ELLP06",
        "BOUNDARY_AMT1000_TC_208": "ELLP06",
        "BOUNDARY_NONE_TC_209": "ELLP06",
        # v43: Chinese company names for boundary tests
        "\u8fb9\u754c\u6d4b\u8bd5_5\u7b14\u5c0f\u989d_\u501f\u6b3e\u6c11\u8425": "ELLP06",
        "\u8fb9\u754c\u6d4b\u8bd5_4\u7b14\u5c0f\u989d_\u501f\u6b3e\u6c11\u8425": "ELLP06",
        "\u8fb9\u754c\u6d4b\u8bd5_1\u7b14\u5927\u989d_\u501f\u6b3e\u6c11\u8425": "ELLP06",
        "\u8fb9\u754c\u6d4b\u8bd5_\u5747\u4e0d\u6ee1\u8db3_\u501f\u6b3e\u6c11\u8425": "ELLP06",
    }
    mapped = aff_to_rule.get(search_key)
    if mapped:
        return mapped
    return None

# Rule code -> {"kyc": change_type, "endpoints": {code: func}}
# "kyc" values: "equity", "scope", "legalrep", "capdecr", "equity_paidin", None
# "endpoints": dict of endpoint_code -> data_function
def _v21_yellow_741():
    """Execution record -> MEDIUM for ELLP03/ELDP03/ELNP03/ARGP03"""
    return yellow_data_741()

def _v21_yellow_742():
    """Preservation record -> MEDIUM for ELLP04/ELDP04/ELNP04/ARGP04"""
    return yellow_data_742()

def _v21_yellow_758_defend():
    """v43: 终本记录 - field names: ExecuteGov/Lian/Biaodi"""
    return [{"CaseNo": "(2026)X01\u7ec8\u5b57\u7b2cY01\u53f7",
             "Lian": RECENT,
             "ExecuteGov": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "Biaodi": "5000000"}]

def _v21_yellow_765_prosecution():
    """Self-prosecution -> MEDIUM for ELLP06/ELDP06/ELNP06/ARGS02/ARGP06"""
    return [{"Liandate": RECENT, "Anno": "(2026)X01\u6267\u5b57\u7b2cY01\u53f7",
             "ExecuteGov": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "Biaodi": "10000000\u5143"}]

def _v21_yellow_882_court():
    """v23 FIX-882: Court notice as defendant - ProsecutorList/DefendantList as arrays"""
    return [{"PublishDate": RECENT, "CaseReason": "\u91d1\u878d\u501f\u6b3e\u5408\u540c\u7ea0\u7eb7",
             "CaseNo": "(2026)X01\u6c11\u521d\u5b57\u7b2cY01\u53f7", "Category": "\u6c11\u4e8b",
             "Court": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "ProsecutorList": ["XX\u94f6\u884c"], "DefendantList": ["YELLOW_ENTERPRISE"],
             "RoleList": [{"RoleType": "2", "RoleItemList": [{"Name": "XX\u94f6\u884c"}]},
                          {"RoleType": "1", "RoleItemList": [{"Name": "YELLOW_ENTERPRISE"}]}]}]

def _v21_yellow_751_pledge():
    """Enterprise equity pledge -> MEDIUM for ENLX07/ENDX08"""
    return yellow_data_751()

def _v21_yellow_768_person_pledge():
    """Personal equity pledge -> MEDIUM for PNGX02"""
    return yellow_data_768()

def _v21_yellow_739_news():
    """Business exception / negative news proxy -> MEDIUM for ENLX11/ENDX13/ENLX10/ENDX12"""
    return yellow_data_739()

def _v21_yellow_739_cancel():
    """Associated enterprise cancellation -> MEDIUM for ARGP07.
    v22g: Uses 739 (BusinessExceptionCheck) as proxy for cancellation/revocation data."""
    return [
        {"RemoveDate": "", "AddReason": "\u4f01\u4e1a\u6ce8\u9500", "AddDate": RECENT,
         "DecisionOffice": "XX\u5e02\u573a\u76d1\u7763\u7ba1\u7406\u5c40"}
    ]

def _v21_yellow_746_env():
    """Environmental punishment -> MEDIUM for ENLX09/ENDX11"""
    return [{"PunishDate": RECENT, "CaseNo": "X\u73af\u5883\u7f5a[2026]Y01\u53f7",
             "PunishGov": "XX\u5e02\u73af\u5883\u4fdd\u62a4\u5c40", "PunishAmt": "50000",
             "IllegalContent": "\u8d85\u6807\u6392\u653e\u6c61\u67d3\u7269", "PunishReason": "\u8fdd\u53cd\u73af\u5883\u4fdd\u62a4\u6cd5"}]

def _v21_yellow_757_tax_owe():
    """Tax owe notice -> MEDIUM for ENLX02/ENDX03"""
    return yellow_data_757()

def _v21_yellow_887_plaintiff():
    """Judgment doc (enterprise as plaintiff) -> for ELLS06/ELDS06/ELNS06/ELDP06/ARGP06 (self-prosecution).
    Rule requires: count>=5 OR single amount>=1000万. Return 5 records to trigger count>=5."""
    base = {"CaseReason": "\u5408\u540c\u7ea0\u7eb7", "Amount": "5000000",
            "IsDefendant": "0", "IsProsecutor": "1",
            "JudgeDate": RECENT, "PublishDate": RECENT,
            "JudgeResult": "\u5224\u51b3", "Court": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
            "PartyList": [{"Name": "YELLOW_ENTERPRISE", "RoleType": "\u539f\u544a",
                           "Statement": "\u539f\u544a", "Keyno": ""}]}
    records = []
    for i in range(1, 6):
        r = dict(base)
        r["Id"] = "mock_887_plaintiff_%03d" % i
        r["CaseNo"] = "(2026)X01\u6c11\u521dY%02d\u53f7" % i
        r["CaseName"] = "\u5408\u540c\u7ea0\u7eb7\u6848%d" % i
        r["PartyList"] = [dict(base["PartyList"][0])]
        records.append(r)
    return records

def _boundary_887_count5_small():
    """Boundary: exactly 5 plaintiff records, each <1000万 → triggers count>=5 condition only."""
    base = {"CaseReason": "\u5408\u540c\u7ea0\u7eb7", "Amount": "500000",
            "IsDefendant": "0", "IsProsecutor": "1",
            "JudgeDate": RECENT, "PublishDate": RECENT,
            "JudgeResult": "\u5224\u51b3", "Court": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
            "PartyList": [{"Name": "YELLOW_ENTERPRISE", "RoleType": "\u539f\u544a",
                           "Statement": "\u539f\u544a", "Keyno": ""}]}
    records = []
    for i in range(1, 6):
        r = dict(base)
        r["Id"] = "mock_887_bnd_cnt5_%03d" % i
        r["CaseNo"] = "(2026)X01\u6c11\u521dB%02d\u53f7" % i
        r["CaseName"] = "\u5408\u540c\u7ea0\u7eb7\u6848%d" % i
        r["PartyList"] = [dict(base["PartyList"][0])]
        records.append(r)
    return records

def _boundary_887_amount1000():
    """Boundary: 1 plaintiff record with amount=1000万 → triggers single amount>=1000万 condition only."""
    return [{"Id": "mock_887_bnd_amt_001",
             "CaseNo": "(2026)X01\u6c11\u521dC01\u53f7", "CaseName": "\u501f\u6b3e\u5408\u540c\u7ea0\u7eb7\u5927\u989d",
             "CaseReason": "\u5408\u540c\u7ea0\u7eb7", "Amount": "10000000",
             "IsDefendant": "0", "IsProsecutor": "1",
             "JudgeDate": RECENT, "PublishDate": RECENT,
             "JudgeResult": "\u5224\u51b3", "Court": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "PartyList": [{"Name": "YELLOW_ENTERPRISE", "RoleType": "\u539f\u544a",
                            "Statement": "\u539f\u544a", "Keyno": ""}]}]

def _boundary_887_none():
    """Boundary: 3 plaintiff records, each <1000万 → neither condition met (count<5 AND amount<1000万)."""
    base = {"CaseReason": "\u5408\u540c\u7ea0\u7eb7", "Amount": "9990000",
            "IsDefendant": "0", "IsProsecutor": "1",
            "JudgeDate": RECENT, "PublishDate": RECENT,
            "JudgeResult": "\u5224\u51b3", "Court": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
            "PartyList": [{"Name": "YELLOW_ENTERPRISE", "RoleType": "\u539f\u544a",
                           "Statement": "\u539f\u544a", "Keyno": ""}]}
    records = []
    for i in range(1, 4):
        r = dict(base)
        r["Id"] = "mock_887_bnd_none_%03d" % i
        r["CaseNo"] = "(2026)X01\u6c11\u521dD%02d\u53f7" % i
        r["CaseName"] = "\u5408\u540c\u7ea0\u7eb7\u6848%d" % i
        r["PartyList"] = [dict(base["PartyList"][0])]
        records.append(r)
    return records

# Boundary searchKey → mock function mapping
BOUNDARY_887_MAP = {
    "BOUNDARY_COUNT5_TC_206": _boundary_887_count5_small,   # 5笔小额 → 命中条件A
    "BOUNDARY_COUNT4_TC_207": _boundary_887_none,            # 4笔小额 → 不命中(复用none)
    "BOUNDARY_AMT1000_TC_208": _boundary_887_amount1000,     # 1笔大额 → 命中条件B
    "BOUNDARY_NONE_TC_209": _boundary_887_none,              # 3笔999万 → 不命中
    # v43: Chinese company names as searchKeys (engine may use company name)
    "\u8fb9\u754c\u6d4b\u8bd5_5\u7b14\u5c0f\u989d_\u501f\u6b3e\u6c11\u8425": _boundary_887_count5_small,
    "\u8fb9\u754c\u6d4b\u8bd5_4\u7b14\u5c0f\u989d_\u501f\u6b3e\u6c11\u8425": _boundary_887_none,
    "\u8fb9\u754c\u6d4b\u8bd5_1\u7b14\u5927\u989d_\u501f\u6b3e\u6c11\u8425": _boundary_887_amount1000,
    "\u8fb9\u754c\u6d4b\u8bd5_\u5747\u4e0d\u6ee1\u8db3_\u501f\u6b3e\u6c11\u8425": _boundary_887_none,
}

def _v21_yellow_887_defendant():
    """v27: Judgment doc for ELLS04 (preservation/保全) -> MEDIUM risk.
    Returns preservation case (CaseType=bq) which ONLY triggers ELLS04, not ELLS07."""
    return [{"Id": "mock_887_ells04_001",
             "CaseNo": "(2026)X01\u8d22\u4fddZ01\u53f7", "CaseName": "\u501f\u6b3e\u5408\u540c\u7ea0\u7eb7\u4fdd\u5168",
             "CaseReason": "\u501f\u6b3e\u5408\u540c\u7ea0\u7eb7", "CaseType": "bq",
             "Amount": "2000000",
             "IsDefendant": "1", "IsProsecutor": "0",
             "JudgeDate": RECENT, "PublishDate": RECENT,
             "JudgeResult": "\u4fdd\u5168\u88c1\u5b9a", "Court": "XX\u5e02\u4e2d\u7ea7\u4eba\u6c11\u6cd5\u9662",
             "PartyList": [{"Name": "YELLOW_ENTERPRISE", "RoleType": "\u88ab\u544a",
                            "Statement": "\u88ab\u544a", "Keyno": ""}]}]

# v22i: New YELLOW per-rule data helper functions (15 wrappers)
def _v22i_yellow_740():
    """v22i: YELLOW per-rule data for endpoint 740 (ShixinCheck)."""
    return red_data_740()

def _v22i_yellow_742():
    """v22i: YELLOW per-rule data for endpoint 742 (SumptuaryCheck)."""
    return red_data_742()

def _v22i_yellow_744():
    """v22i: YELLOW per-rule data for endpoint 744 (JudicialSaleCheck)."""
    return red_data_744()

def _v22i_yellow_748():
    """v22i: YELLOW per-rule data for endpoint 748 (SeriousIllegalCheck)."""
    return red_data_748()

def _v22i_yellow_752():
    """v22i: YELLOW per-rule data for endpoint 752 (EquityFreezeCheck)."""
    return red_data_752()

def _v22i_yellow_756():
    """v22i: YELLOW per-rule data for endpoint 756 (TaxIllegalCheck)."""
    return red_data_756()

def _v22i_yellow_761():
    """v22i: YELLOW per-rule data for endpoint 761 (BankruptcyCheck)."""
    return red_data_761()

def _v22i_yellow_764():
    """v22i: YELLOW per-rule data for endpoint 764 (PersonSXCheck)."""
    return red_data_764()

def _v22i_yellow_765():
    """v22i: YELLOW per-rule data for endpoint 765 (PersonZXCheck)."""
    return red_data_765()

def _v22i_yellow_766():
    """v22i: YELLOW per-rule data for endpoint 766 (PersonSumptuaryCheck)."""
    return red_data_766()

def _v22i_yellow_767():
    """v22i: YELLOW per-rule data for endpoint 767 (PersonSEFreezeCheck)."""
    return red_data_767()

def _v22i_yellow_771():
    """v22i: YELLOW per-rule data for endpoint 771 (PersonEndExCaseCheck)."""
    return red_data_771()

def _v22i_yellow_887():
    """v22i: YELLOW per-rule data for endpoint 887 (JudgmentDocCheck)."""
    return red_data_887()

def _v22i_yellow_888():
    """v22i: YELLOW per-rule data for endpoint 888 (CourtAnnoCheck)."""
    return red_data_888()

def _v22i_yellow_958():
    """v22i: YELLOW per-rule data for endpoint 958 (TenderCheck)."""
    return red_data_958()

# v21: Rule code to QCC data mapping
RULE_CODE_MAP = {
    # --- KYC ChangeList rules (equity change) ---
    "EBNS02": {"kyc": "equity", "endpoints": {}},
    "EBGP02": {"kyc": "equity", "endpoints": {}},
    "EBNP02": {"kyc": "equity", "endpoints": {}},
    # --- KYC ChangeList rules (scope change) ---
    "EBNS03": {"kyc": "scope", "endpoints": {}},
    "EBGP03": {"kyc": "scope", "endpoints": {}},
    "EBNP03": {"kyc": "scope", "endpoints": {}},
    # --- KYC ChangeList rules (legal rep change) ---
    "EBGP01": {"kyc": "legalrep", "endpoints": {}},
    # --- KYC ChangeList rules (capital decrease) ---
    "EBGS06": {"kyc": "capdecr", "endpoints": {}},
    "EBGP06": {"kyc": "capdecr", "endpoints": {}},
    # --- KYC ChangeList rules (capital increase - BLUE mode) ---
    "EBGP08": {"kyc": "capincr", "endpoints": {}},
    # --- KYC ChangeList rules (capital decrease for boundary - needs capdecr + params) ---
    "EBGS05": {"kyc": "capdecr", "endpoints": {}},
    "EBGP05": {"kyc": "capdecr", "endpoints": {}},
    # --- v24: KYC paid-in capital ratio rules (low RealCapi for EBGS09/10) ---
    "EBGS09": {"kyc": "low_paidin", "endpoints": {}},
    "EBGS10": {"kyc": "low_paidin", "endpoints": {}},
    # --- v24: KYC paid-in capital ratio rules (low RealCapi/RegistCapi) ---
    "EBGP09": {"kyc": "low_paidin", "endpoints": {}},
    "EBGP10": {"kyc": "low_paidin", "endpoints": {}},
    "EBGP11": {"kyc": "low_paidin", "endpoints": {}},
    "EBNP05": {"kyc": None, "endpoints": {}},
    "EBNP05": {"kyc": None, "endpoints": {}},
    # --- Endpoint rules: execution (741) ---
    "ELLP03": {"kyc": None, "endpoints": {"741": _v21_yellow_741}},
    "ELDP03": {"kyc": None, "endpoints": {"741": _v21_yellow_741}},
    "ELNP03": {"kyc": None, "endpoints": {"741": _v21_yellow_741}},
    "ARGP03": {"kyc": None, "endpoints": {"741": _v21_yellow_741}},
    "ELLS03": {"kyc": None, "endpoints": {"741": _v21_yellow_741}},
    "ELDS03": {"kyc": None, "endpoints": {"741": _v21_yellow_741}},
    # --- Endpoint rules: preservation (742) ---
    "ELLP04": {"kyc": None, "endpoints": {"887": _v21_yellow_887_defendant}},  # v37: Fix - was 742, should be 887 (preservation/保全)
    "ELDP04": {"kyc": None, "endpoints": {"887": _v21_yellow_887_defendant}},  # v37: Fix - was 742, should be 887
    "ELNP04": {"kyc": None, "endpoints": {"887": _v21_yellow_887_defendant}},
    "ARGP04": {"kyc": None, "endpoints": {"742": _v21_yellow_742}},
    # --- Endpoint rules: judgment doc as defendant (887) for ELLS/ELDS ---
    "ELLS04": {"kyc": None, "endpoints": {"887": _v21_yellow_887_defendant}},
    "ELDS04": {"kyc": None, "endpoints": {"887": _v21_yellow_887_defendant}},
    "ELLS05": {"kyc": None, "endpoints": {"887": _v21_yellow_887_defendant}},
    "ELDS05": {"kyc": None, "endpoints": {"887": _v21_yellow_887_defendant}},
    # --- Endpoint rules: judgment doc as plaintiff (887) for ELLS06/ELDS06 ---
    "ELLS06": {"kyc": None, "endpoints": {"887": _v21_yellow_887_plaintiff}},
    "ELDS06": {"kyc": None, "endpoints": {"887": _v21_yellow_887_plaintiff}},
    # --- Endpoint rules: judgment/defendant amount (758) ---
    "ELLP05": {"kyc": None, "endpoints": {"758": _v21_yellow_758_defend}},
    "ELDP05": {"kyc": None, "endpoints": {"758": _v21_yellow_758_defend}},
    "ELNP05": {"kyc": None, "endpoints": {"758": _v21_yellow_758_defend}},
    "ARGP05": {"kyc": None, "endpoints": {"758": _v21_yellow_758_defend}},
    "ARGS01": {"kyc": None, "endpoints": {"758": _v21_yellow_758_defend}},
    # --- Endpoint rules: self-prosecution (765) ---
    "ELLP06": {"kyc": None, "endpoints": {"887": _v21_yellow_887_plaintiff}},  # v43 fix: was _v22i_yellow_887 (defendant), should be plaintiff
    "ELDP06": {"kyc": None, "endpoints": {"887": _v21_yellow_887_plaintiff}},  # v43 fix
    "ELNP06": {"kyc": None, "endpoints": {"887": _v21_yellow_887_plaintiff}},  # v43 fix
    "ARGS02": {"kyc": None, "endpoints": {"887": _v21_yellow_887_plaintiff}},  # v43 fix
    "ARGP06": {"kyc": None, "endpoints": {"887": _v21_yellow_887_plaintiff}},  # v43 fix
    # --- Endpoint rules: negative news (739 as proxy) ---
    "ENLX11": {"kyc": None, "endpoints": {"739": _v21_yellow_739_news}},
    "ENDX13": {"kyc": None, "endpoints": {"739": _v21_yellow_739_news}},
    "ENLX10": {"kyc": None, "endpoints": {"739": _v21_yellow_739_news}},
    "ENDX12": {"kyc": None, "endpoints": {"739": _v21_yellow_739_news}},
    # --- Endpoint rules: personal equity pledge (768) ---
    "PNGX02": {"kyc": None, "endpoints": {"768": _v21_yellow_768_person_pledge}},
    # --- Endpoint rules: enterprise equity pledge (751) ---
    "ENLX07": {"kyc": None, "endpoints": {"751": _v21_yellow_751_pledge}},
    "ENDX08": {"kyc": None, "endpoints": {"751": _v21_yellow_751_pledge}},
    # --- Endpoint rules: tax owe notice (757) ---
    "ENLX02": {"kyc": None, "endpoints": {"757": _v21_yellow_757_tax_owe}},
    "ENDX03": {"kyc": None, "endpoints": {"757": _v21_yellow_757_tax_owe}},
    # --- Endpoint rules: admin penalty (865) ---
    "ENLX08": {"kyc": None, "endpoints": {"865": yellow_data_865}},
    "ENDX09": {"kyc": None, "endpoints": {"865": yellow_data_865}},
    # --- Endpoint rules: environmental punishment (746) ---
    "ENLX09": {"kyc": None, "endpoints": {"746": _v21_yellow_746_env}},
    "ENDX11": {"kyc": None, "endpoints": {"746": _v21_yellow_746_env}},
    # --- Endpoint rules: associated enterprise cancellation (special handling) ---
    "ARGP07": {"kyc": None, "endpoints": {"739": _v21_yellow_739_cancel}},
    # --- Cert-based rules (certificate expiry) ---
    "EBNP06": {"kyc": None, "endpoints": {}},
    # --- MAIN02 boundary tests: use capdecr KYC + hardcoded params ---
    "MAIN02": {"kyc": "capdecr", "endpoints": {}},
    "MAIN03": {"kyc": "capdecr", "endpoints": {}},
    "MAIN01": {"kyc": None, "endpoints": {}},
    # --- v22i: KYC ChangeList rules - EBGS family (enterprise business changes - SOE borrowing) ---
    "EBGS01": {"kyc": "legalrep", "endpoints": {}},
    "EBGS02": {"kyc": "equity", "endpoints": {}},
    "EBGS03": {"kyc": "scope", "endpoints": {}},
    "EBGS04": {"kyc": "revoke", "endpoints": {}},
    "EBGS07": {"kyc": "capdecr", "endpoints": {}},
    "EBGS08": {"kyc": "capincr", "endpoints": {}},
    "EBGS11": {"kyc": "low_paidin", "endpoints": {}},
    # --- v22i: KYC ChangeList rules - EBNS family (enterprise business changes - SOE non-borrowing) ---
    "EBNS01": {"kyc": "legalrep", "endpoints": {}},
    "EBNS04": {"kyc": "revoke", "endpoints": {}},
    # --- v22i: KYC ChangeList rules - EBGP family (enterprise business changes - guarantee) ---
    "EBGP04": {"kyc": "revoke", "endpoints": {}},
    "EBGP07": {"kyc": "capdecr", "endpoints": {}},
    # --- v22i: KYC/Cert/Tender rules - EBNP family (private enterprise) ---
    "EBNP01": {"kyc": "legalrep", "endpoints": {}},
    "EBNP04": {"kyc": "revoke", "endpoints": {}},
    "EBNP07": {"kyc": None, "endpoints": {}},
    "EBNP08": {"kyc": None, "endpoints": {}},  # v37: Fix - handled in cert routing special case
    # --- v22i: Credit report rules - ECGX family (SOAP XML credit report) ---
    "ECGX01": {"kyc": None, "endpoints": {}},
    "ECGX02": {"kyc": None, "endpoints": {}},
    "ECGX03": {"kyc": None, "endpoints": {}},
    "ECGX04": {"kyc": None, "endpoints": {}},
    "ECGX05": {"kyc": None, "endpoints": {}},
    "ECGX06": {"kyc": None, "endpoints": {}},
    "ECGX07": {"kyc": None, "endpoints": {}},
    # --- v22i: Endpoint rules - ELDP family (enterprise litigation - SOE guarantee) ---
    "ELDP01": {"kyc": None, "endpoints": {"740": _v22i_yellow_740}},
    "ELDP02": {"kyc": None, "endpoints": {"742": _v22i_yellow_742}},
    "ELDP07": {"kyc": None, "endpoints": {"887": _v22i_yellow_887}},
    "ELDP08": {"kyc": None, "endpoints": {"758": _v21_yellow_758_defend}},
    "ELDP09": {"kyc": None, "endpoints": {"761": _v22i_yellow_761}},
    "ELDP10": {"kyc": None, "endpoints": {}},
    # --- v22i: Endpoint rules - ELDS family (enterprise litigation - private guarantee) ---
    "ELDS01": {"kyc": None, "endpoints": {"740": _v22i_yellow_740}},
    "ELDS02": {"kyc": None, "endpoints": {"742": _v22i_yellow_742}},
    "ELDS07": {"kyc": None, "endpoints": {"887": _v22i_yellow_887}},
    "ELDS08": {"kyc": None, "endpoints": {"758": _v21_yellow_758_defend}},
    "ELDS09": {"kyc": None, "endpoints": {"761": _v22i_yellow_761}},
    "ELDS10": {"kyc": None, "endpoints": {}},
    # --- v22i: Endpoint rules - ELLP family (enterprise litigation - SOE borrowing) ---
    "ELLP01": {"kyc": None, "endpoints": {"740": _v22i_yellow_740}},
    "ELLP02": {"kyc": None, "endpoints": {"742": _v22i_yellow_742}},
    "ELLP07": {"kyc": None, "endpoints": {"887": _v22i_yellow_887}},
    "ELLP08": {"kyc": None, "endpoints": {"761": _v22i_yellow_761}},
    "ELLP09": {"kyc": None, "endpoints": {}},
    # --- v22i: Endpoint rules - ELLS family (enterprise litigation - private borrowing) ---
    "ELLS01": {"kyc": None, "endpoints": {"740": _v22i_yellow_740}},
    "ELLS02": {"kyc": None, "endpoints": {"742": _v22i_yellow_742}},
    "ELLS07": {"kyc": None, "endpoints": {"887": _v22i_yellow_887}},
    "ELLS08": {"kyc": None, "endpoints": {"761": _v22i_yellow_761}},
    "ELLS09": {"kyc": None, "endpoints": {}},
    # --- v22i: Endpoint rules - ELNP family (enterprise litigation - private non-borrowing) ---
    "ELNP01": {"kyc": None, "endpoints": {"740": _v22i_yellow_740}},
    "ELNP02": {"kyc": None, "endpoints": {"742": _v22i_yellow_742}},
    "ELNP07": {"kyc": None, "endpoints": {"887": _v22i_yellow_887}},
    "ELNP08": {"kyc": None, "endpoints": {"758": _v21_yellow_758_defend}},
    "ELNP09": {"kyc": None, "endpoints": {"761": _v22i_yellow_761}},
    "ELNP10": {"kyc": None, "endpoints": {}},
    # --- v22i: Endpoint rules - ELNS family (enterprise litigation - SOE non-borrowing) ---
    "ELNS01": {"kyc": None, "endpoints": {"740": _v22i_yellow_740}},
    "ELNS02": {"kyc": None, "endpoints": {"742": _v22i_yellow_742}},
    "ELNS03": {"kyc": None, "endpoints": {"741": _v21_yellow_741}},
    "ELNS04": {"kyc": None, "endpoints": {"887": _v21_yellow_887_defendant}},
    "ELNS05": {"kyc": None, "endpoints": {"887": _v21_yellow_887_defendant}},
    "ELNS06": {"kyc": None, "endpoints": {"887": _v21_yellow_887_plaintiff}},
    "ELNS07": {"kyc": None, "endpoints": {"887": _v22i_yellow_887}},
    "ELNS08": {"kyc": None, "endpoints": {"758": _v21_yellow_758_defend}},
    "ELNS09": {"kyc": None, "endpoints": {"761": _v22i_yellow_761}},
    "ELNS10": {"kyc": None, "endpoints": {}},
    # --- v22i: Endpoint rules - ENLX family (enterprise comprehensive risk - private) ---
    "ENLX01": {"kyc": None, "endpoints": {}},
    "ENLX03": {"kyc": None, "endpoints": {"756": _v22i_yellow_756}},
    "ENLX04": {"kyc": None, "endpoints": {"752": _v22i_yellow_752}},
    "ENLX05": {"kyc": None, "endpoints": {"748": _v22i_yellow_748}},
    "ENLX06": {"kyc": None, "endpoints": {"744": _v22i_yellow_744}},
    # --- v22i: Endpoint rules - ENDX family (enterprise comprehensive risk - SOE) ---
    "ENDX01": {"kyc": None, "endpoints": {}},
    "ENDX02": {"kyc": None, "endpoints": {"757": _v21_yellow_757_tax_owe}},
    "ENDX04": {"kyc": None, "endpoints": {"756": _v22i_yellow_756}},
    "ENDX05": {"kyc": None, "endpoints": {"752": _v22i_yellow_752}},
    "ENDX06": {"kyc": None, "endpoints": {"748": _v22i_yellow_748}},
    "ENDX07": {"kyc": None, "endpoints": {"744": _v22i_yellow_744}},
    "ENDX10": {"kyc": None, "endpoints": {"865": yellow_data_865}},
    # --- v22i: Endpoint rules - ARGP family (associated enterprise - borrowing) ---
    "ARGP01": {"kyc": None, "endpoints": {"740": _v22i_yellow_740}},
    "ARGP02": {"kyc": None, "endpoints": {"742": _v22i_yellow_742}},
    # --- v22i: Endpoint rules - ARMP family (associated shareholder/investment) ---
    "ARMP01": {"kyc": None, "endpoints": {"740": _v22i_yellow_740}},
    "ARMP02": {"kyc": None, "endpoints": {"740": _v22i_yellow_740}},
    # --- v22i: Endpoint rules - PLDX family (personal judicial - private) ---
    "PLDX01": {"kyc": None, "endpoints": {"766": _v22i_yellow_766}},
    "PLDX02": {"kyc": None, "endpoints": {"764": _v22i_yellow_764}},
    "PLDX03": {"kyc": None, "endpoints": {"765": _v22i_yellow_765}},
    "PLDX04": {"kyc": None, "endpoints": {"771": _v22i_yellow_771}},
    # --- v22i: Endpoint rules - PLEP family (personal judicial - SOE private) ---
    "PLEP01": {"kyc": None, "endpoints": {"766": _v22i_yellow_766}},
    "PLEP02": {"kyc": None, "endpoints": {"764": _v22i_yellow_764}},
    "PLEP03": {"kyc": None, "endpoints": {"765": _v22i_yellow_765}},
    # --- v22i: Endpoint rules - PNGX family (personal equity risk) ---
    "PNGX01": {"kyc": None, "endpoints": {"767": _v22i_yellow_767}},
}

# v21: Rule-specific KYC data functions
def _kyc_equity_change():
    """KYC with only equity change -> triggers C_N_CHGEQUITYCNT=1"""
    return {
        "RegistCapi": "5000\u4e07\u5143", "RealCapi": "5000\u4e07\u5143", "StartDate": "2010-01-01",
        "ChangeList": [
            {"ChangeDate": RECENT, "ProjectName": "\u80a1\u6743\u53d8\u66f4",
             "BeforeList": ["\u5f20\u4e09 50%;\u674e\u56db 50%"],
             "AfterList": ["\u5f20\u4e09 30%;\u674e\u56db 50%;\u738b\u4e94 20%"]}
        ],
        "TaxCreditList": [{"Year": "2025", "Level": "A"}],
        "PubPartnerList": [], "InvestmentList": [], "RevokeInfo": {}
    }

def _kyc_scope_change():
    """KYC with only scope change -> triggers C_N_CHGSCOPECNT=1"""
    return {
        "RegistCapi": "5000\u4e07\u5143", "RealCapi": "5000\u4e07\u5143", "StartDate": "2010-01-01",
        "ChangeList": [
            {"ChangeDate": RECENT, "ProjectName": "\u7ecf\u8425\u8303\u56f4\u53d8\u66f4",
             "BeforeList": ["\u6280\u672f\u5f00\u53d1"],
             "AfterList": ["\u6280\u672f\u5f00\u53d1\uff1b\u6280\u672f\u54a8\u8be2"]}
        ],
        "TaxCreditList": [{"Year": "2025", "Level": "A"}],
        "PubPartnerList": [], "InvestmentList": [], "RevokeInfo": {}
    }

def _kyc_legalrep_change():
    """KYC with only legal rep change -> triggers C_N_CHGLEGALREPCNT=1"""
    return {
        "RegistCapi": "5000\u4e07\u5143", "RealCapi": "5000\u4e07\u5143", "StartDate": "2010-01-01",
        "ChangeList": [
            {"ChangeDate": RECENT, "ProjectName": "\u6cd5\u5b9a\u4ee3\u8868\u4eba\u53d8\u66f4",
             "BeforeList": ["\u5f20\u4e09"], "AfterList": ["\u674e\u56db"]}
        ],
        "TaxCreditList": [{"Year": "2025", "Level": "A"}],
        "PubPartnerList": [], "InvestmentList": [], "RevokeInfo": {}
    }

def _kyc_capdecr_change():
    """KYC with capital decrease -> triggers C_N_CAPDECCNT=1, C_F_CAPDECRATIO computed"""
    return {
        "RegistCapi": "5000\u4e07\u5143", "RealCapi": "5000\u4e07\u5143", "StartDate": "2010-01-01",
        "ChangeList": [
            {"ChangeDate": RECENT, "ProjectName": "\u6ce8\u518c\u8d44\u672c\u53d8\u66f4",
             "BeforeList": ["5000\u4e07\u5143"], "AfterList": ["3500\u4e07\u5143"]}
        ],
        "TaxCreditList": [{"Year": "2025", "Level": "A"}],
        "PubPartnerList": [], "InvestmentList": [], "RevokeInfo": {}
    }

def _kyc_capincr_change():
    """KYC with capital increase (no decrease) -> triggers C_N_CAPINCCNT=1
    v22g: for EBGP08 BLUE mode test - capital increase should NOT trigger capdecr rules"""
    return {
        "RegistCapi": "5000\u4e07\u5143", "RealCapi": "5000\u4e07\u5143", "StartDate": "2010-01-01",
        "ChangeList": [
            {"ChangeDate": RECENT, "ProjectName": "\u6ce8\u518c\u8d44\u672c\u53d8\u66f4",
             "BeforeList": ["3000\u4e07\u5143"], "AfterList": ["5000\u4e07\u5143"]}
        ],
        "TaxCreditList": [{"Year": "2025", "Level": "A"}],
        "PubPartnerList": [], "InvestmentList": [], "RevokeInfo": {}
    }

def _kyc_revoke_info():
    """KYC with RevokeInfo -> triggers EBGS04/EBNS04/EBNP04/EBGP04
    v22i: New KYC type for revocation-based rules.
    """
    return {
        "RegistCapi": "5000\u4e07\u5143", "RealCapi": "5000\u4e07\u5143", "StartDate": "2010-01-01",
        "ChangeList": [],
        "TaxCreditList": [{"Year": "2025", "Level": "A"}],
        "PubPartnerList": [], "InvestmentList": [],
        "RevokeInfo": {"RevokeDate": RECENT, "RevokeReason": "\u8fdd\u6cd5\u7ecf\u8425"}
    }

def _kyc_all_changes():
    """v22g: KYC with ALL change types -> triggers all KYC-based rules.
    Used as fallback when YELLOW mode has no extractable rule code
    (e.g., searchKey=YELLOW_TC_028 from S_uscc field).
    Returns equity + scope + legalrep + capital decrease changes."""
    return {
        "RegistCapi": "5000\u4e07\u5143", "RealCapi": "5000\u4e07\u5143", "StartDate": "2010-01-01",
        "ChangeList": [
            {"ChangeDate": RECENT, "ProjectName": "\u6cd5\u5b9a\u4ee3\u8868\u4eba\u53d8\u66f4",
             "BeforeList": ["\u5f20\u4e09"], "AfterList": ["\u674e\u56db"]},
            {"ChangeDate": RECENT, "ProjectName": "\u80a1\u6743\u53d8\u66f4",
             "BeforeList": ["\u5f20\u4e09 50%;\u674e\u56db 50%"],
             "AfterList": ["\u5f20\u4e09 30%;\u674e\u56db 50%;\u738b\u4e94 20%"]},
            {"ChangeDate": RECENT, "ProjectName": "\u7ecf\u8425\u8303\u56f4\u53d8\u66f4",
             "BeforeList": ["\u6280\u672f\u5f00\u53d1"],
             "AfterList": ["\u6280\u672f\u5f00\u53d1\uff1b\u6280\u672f\u54a8\u8be2"]},
            {"ChangeDate": RECENT, "ProjectName": "\u6ce8\u518c\u8d44\u672c\u53d8\u66f4",
             "BeforeList": ["5000\u4e07\u5143"], "AfterList": ["3500\u4e07\u5143"]}
        ],
        "TaxCreditList": [{"Year": "2025", "Level": "A"}],
        "PubPartnerList": [], "InvestmentList": [], "RevokeInfo": {}
    }

def _kyc_low_paidin():
    """v24: KYC with low paid-in capital ratio (RealCapi << RegistCapi).
    Triggers rules: 实缴资本占比过低 (EBGP09/EBGS09 <5%, EBGP10/EBGS10 <10%)
    and 注册资本虚高 (EBGP11/EBGS11)."""
    return {
        "RegistCapi": "5000\u4e07\u5143", "RealCapi": "100\u4e07\u5143", "StartDate": "2010-01-01",
        "ChangeList": [],
        "TaxCreditList": [{"Year": "2025", "Level": "A"}],
        "PubPartnerList": [], "InvestmentList": [], "RevokeInfo": {}
    }

_v21_KYC_MAP = {
    "equity": _kyc_equity_change,
    "scope": _kyc_scope_change,
    "legalrep": _kyc_legalrep_change,
    "capdecr": _kyc_capdecr_change,
    "capincr": _kyc_capincr_change,
    "equity_paidin": _kyc_equity_change,  # same KYC data, params handle paid-in ratio
    "revoke": _kyc_revoke_info,
    "low_paidin": _kyc_low_paidin,  # v24: low RealCapi/RegistCapi ratio
}

def _v21_get_yellow_data(rule_code):
    """v21: Get rule-specific KYC and endpoint data for YELLOW mode.
    Returns (kyc_func_or_none, endpoints_dict).
    v22g: When no rule code found (e.g., YELLOW_TC_NNN searchKey),
    return comprehensive KYC + YELLOW_FULL endpoints as fallback."""
    if rule_code and rule_code in RULE_CODE_MAP:
        info = RULE_CODE_MAP[rule_code]
        kyc_func = _v21_KYC_MAP.get(info.get("kyc")) if info.get("kyc") else None
        return kyc_func, info.get("endpoints", {})
    # v22g Fallback: no rule code -> return comprehensive data
    # This handles YELLOW_TC_NNN searchKeys where rule code can't be extracted
    # The comprehensive KYC covers all change types; YELLOW_FULL endpoints cover
    # all risk data. The strategy determines which rules actually trigger.
    return _kyc_all_changes, {}

def _replace_placeholders(data, ent_name):
    """Replace YELLOW_ENTERPRISE placeholder in data items with actual enterprise name."""
    if isinstance(data, list):
        return [_replace_placeholders(item, ent_name) for item in data]
    elif isinstance(data, dict):
        result = {}
        for k, v in data.items():
            result[k] = _replace_placeholders(v, ent_name)
        return result
    elif isinstance(data, (str, unicode)):
        return data.replace("YELLOW_ENTERPRISE", ent_name)
    else:
        return data

def _fix_887_party_names(items, search_key):
    """v42: Replace PartyList Name with searchKey for 887 endpoint.
    ETL code: searchKey = allParam.get("C_S_QCCSEARCHKEY") = the searchKey the engine sends.
    ETL compares: searchKey.equals(party.Name)
    So Name must equal the searchKey value."""
    for item in items:
        if "PartyList" in item:
            for party in item["PartyList"]:
                party["Name"] = search_key
    return items

class MockHandler(BaseHTTPRequestHandler):
    def _parse_qs(self, query_string):
        params = {}
        if not query_string:
            return params
        for part in query_string.split("&"):
            if "=" in part:
                k, v = part.split("=", 1)
                params[k] = urllib.unquote(v)
        return params

    def _parse_body(self, body):
        """v13: Parse body as JSON or form-encoded, returning a dict of params."""
        if not body:
            return {}
        # Try JSON first
        try:
            jdata = json.loads(body)
            if isinstance(jdata, dict):
                return jdata
        except:
            pass
        # Try form-encoded (e.g., searchKey=RED_ALERT&other=value)
        params = {}
        try:
            # Handle both str and unicode for Python 2
            if isinstance(body, bytes):
                body_str = body.decode("utf-8", "replace")
            else:
                body_str = body
            for part in body_str.split("&"):
                if "=" in part:
                    k, v = part.split("=", 1)
                    params[urllib.unquote(k)] = urllib.unquote(v)
        except:
            pass
        return params

    def _extract_search_key(self, params, body=""):
        """Extract searchKey from query params AND body (JSON + form-encoded)."""
        # 1. Check query string params first
        for key in ["searchKey", "keyNo", "C_S_QCCSEARCHKEY", "keyword"]:
            if key in params and params[key]:
                return params[key]
        # 2. Check body
        if body:
            # 2a. Try JSON body
            try:
                jdata = json.loads(body)
                if isinstance(jdata, dict):
                    for key in ["searchKey", "keyNo", "keyword", "C_S_QCCSEARCHKEY"]:
                        if key in jdata and jdata[key]:
                            return jdata[key]
            except:
                pass
            # 2b. Try form-encoded body
            try:
                if isinstance(body, bytes):
                    body_str = body.decode("utf-8", "replace")
                else:
                    body_str = body
                form_params = {}
                for part in body_str.split("&"):
                    if "=" in part:
                        k, v = part.split("=", 1)
                        form_params[urllib.unquote(k)] = urllib.unquote(v)
                for key in ["searchKey", "keyNo", "C_S_QCCSEARCHKEY", "keyword"]:
                    if key in form_params and form_params[key]:
                        return form_params[key]
            except:
                pass
            # 2c. Try XML entName (for SOAP credit report requests)
            m = re.search(r"<entName>(.*?)</entName>", body, re.IGNORECASE)
            if m:
                return m.group(1)
        return ""

    def _extract_company(self, params, body=""):
        """Extract any company identifier for logging."""
        for key in ["searchKey", "keyNo", "C_S_QCCSEARCHKEY", "keyword", "key"]:
            if key in params and params[key]:
                return params[key]
        if body:
            try:
                jdata = json.loads(body)
                if isinstance(jdata, dict):
                    for key in ["searchKey", "keyNo", "keyword", "C_S_QCCSEARCHKEY"]:
                        if key in jdata and jdata[key]:
                            return jdata[key]
            except:
                pass
            # form-encoded fallback
            try:
                if isinstance(body, bytes):
                    body_str = body.decode("utf-8", "replace")
                else:
                    body_str = body
                form_params = {}
                for part in body_str.split("&"):
                    if "=" in part:
                        k, v = part.split("=", 1)
                        form_params[urllib.unquote(k)] = urllib.unquote(v)
                for key in ["searchKey", "keyNo", "C_S_QCCSEARCHKEY", "keyword", "key"]:
                    if key in form_params and form_params[key]:
                        return form_params[key]
            except:
                pass
        return ""

    def log_message(self, format, *args):
        sys.stderr.write("[v24 %s] %s\n" % (time.strftime("%H:%M:%S"), format % args))

    def _route_request(self, method, path, search_key, company, body=""):
        """v21: Shared routing logic with rule-specific YELLOW routing."""
        mode = get_effective_mode(search_key)
        http_method = method  # "GET" or "POST"
        # v21: extract rule code for YELLOW mode routing
        rule_code = extract_rule_code(search_key) if mode == "yellow" else None

        # Health check
        if path == "/" or path == "/health":
            self._respond_json({"status": "ok", "version": "v46",
                                "mode": mode, "search_key": search_key,
                                "sticky_mode": _sticky_mode["mode"],
                                "rule_code": rule_code,
                                "company": company,
                                "method": http_method})
            return

        # KYC endpoint
        if "CustomerDueDiligence" in path or "KYC" in path:
            if mode == "red":
                resp = make_kyc(red_kyc_data())
            elif mode == "yellow_full":
                resp = make_kyc(yellow_kyc_data())
            elif mode == "yellow":
                # v21: use rule-specific KYC data
                kyc_func, _ = _v21_get_yellow_data(rule_code)
                if kyc_func:
                    resp = make_kyc(kyc_func())
                else:
                    resp = make_kyc(safe_kyc_data())
            elif mode == "blue":
                resp = make_kyc(blue_kyc_data())
            else:
                resp = make_kyc(safe_kyc_data())
            sk_flag = "HAS_KEY" if search_key else "NO_KEY"
            print("[v24-%s] %s KYC %s [rule=%s] [%s] %s" % (mode.upper(), http_method, sk_flag, rule_code or "-", search_key or "-", company))
            self._respond_json(resp)
            return

        # Detail-type endpoints (liquidation)
        for pattern in DETAIL_PATTERNS:
            if pattern in path:
                if mode == "red":
                    resp = make_risk_detail({"Leader": "\u5f20\u4e09;\u674e\u56db", "LiquidationDate": RECENT,
                                              "CaseNo": "(2026)X01\u6e05\u5b57\u7b2c001\u53f7"})
                elif mode == "yellow" and rule_code == "ELDP10":
                    # v24: ELDP10 - enterprise has liquidation record
                    resp = make_risk_detail({"Leader": "\u5f20\u4e09", "LiquidationDate": RECENT,
                                              "CaseNo": "(2026)X01\u6e05\u5b57\u7b2c002\u53f7"})
                else:
                    resp = make_safe_detail()
                sk_flag = "HAS_KEY" if search_key else "NO_KEY"
                print("[v24-%s] %s %s [%s] %s" % (mode.upper(), http_method, pattern, sk_flag, company))
                self._respond_json(resp)
                return

        # Certification endpoints
        for pattern in CERT_PATTERNS:
            if pattern in path:
                if mode == "red" and search_key and "TC_200" in search_key.upper():
                    # v46b: TC_200 special - expired cert for EXTREME risk
                    import datetime as _dt3
                    exp_date = (datetime.datetime.now() - datetime.timedelta(days=10)).strftime("%Y-%m-%d")
                    resp = make_risk_cert_255([
                        {"Name": "\u5efa\u7b51\u4e1a\u4f01\u4e1a\u8d44\u8d28\u8bc1\u4e66\u4e00\u7ea7",
                         "EndDate": exp_date,
                         "Status": "\u5df2\u8fc7\u671f"}
                    ])
                elif mode == "red":
                    # v23 FIX-255: Use Name/EndDate/Status fields, Result as direct array
                    resp = make_risk_cert_255([
                        {"Name": "\u5efa\u7b51\u4e1a\u4f01\u4e1a\u8d44\u8d28\u8bc1\u4e66\u4e00\u7ea7",
                         "EndDate": FUTURE,
                         "Status": "\u6b63\u5e38"}
                    ])
                elif mode == "yellow" and rule_code == "EBNP06":
                    # v23 FIX-255: EBNP06 rule - cert expiring within 90 days
                    import datetime as _dt
                    exp_date = (datetime.datetime.now() + datetime.timedelta(days=60)).strftime("%Y-%m-%d")
                    resp = make_risk_cert_255([
                        {"Name": "\u5efa\u7b51\u4e1a\u4f01\u4e1a\u8d44\u8d28\u8bc1\u4e66\u4e8c\u7ea7",
                         "EndDate": exp_date,
                         "Status": "\u5373\u5c06\u8fc7\u671f"}
                    ])
                elif mode == "yellow" and rule_code == "EBNP05":
                    # EBNP05: cert level downgrade (一级→二级)
                    resp = make_risk_cert_255([
                        {"Name": "\u5efa\u7b51\u4e1a\u4f01\u4e1a\u8d44\u8d28\u8bc1\u4e66\u4e8c\u7ea7",
                         "EndDate": FUTURE,
                         "Status": "\u6b63\u5e38"}
                    ])
                elif mode == "yellow" and rule_code == "EBNP07":
                    # EBNP07: cert status abnormal (吊销/撤销/注销)
                    resp = make_risk_cert_255([
                        {"Name": "\u5efa\u7b51\u4e1a\u4f01\u4e1a\u8d44\u8d28\u8bc1\u4e66\u4e00\u7ea7",
                         "EndDate": FUTURE,
                         "Status": "\u6ce8\u9500"}
                    ])
                elif mode == "yellow" and rule_code == "EBNP08":
                    # v37: EBNP08 - cert expired (EndDate ≤ today, ≤ 0 days to expiry)
                    import datetime as _dt2
                    exp_date = (datetime.datetime.now() - datetime.timedelta(days=5)).strftime("%Y-%m-%d")
                    resp = make_risk_cert_255([
                        {"Name": "\u5efa\u7b51\u4e1a\u4f01\u4e1a\u8d44\u8d28\u8bc1\u4e66\u4e00\u7ea7",
                         "EndDate": exp_date,
                         "Status": "\u5df2\u8fc7\u671f"}
                    ])
                else:
                    resp = make_safe_cert_255()
                sk_flag = "HAS_KEY" if search_key else "NO_KEY"
                print("[v24-%s] %s %s [rule=%s] [%s] %s" % (mode.upper(), http_method, pattern, rule_code or "-", sk_flag, company))
                self._respond_json(resp)
                return

        # List-type endpoints (the main 24 risk check endpoints)
        for pattern, code in LIST_RISK_MAP.items():
            if pattern in path:
                if mode == "blue":
                    func = BLUE_FUNCS.get(code)
                    if func:
                        resp = make_risk_list(func())
                    else:
                        resp = make_safe_list()
                elif mode == "yellow":
                    # v21: use rule-specific endpoint data
                    _, ep_map = _v21_get_yellow_data(rule_code)
                    func = ep_map.get(code)
                    if func:
                        items = func()
                        # v43: Boundary test override for 887 endpoint
                        if code == "887" and search_key and search_key in BOUNDARY_887_MAP:
                            bnd_func = BOUNDARY_887_MAP[search_key]
                            items = bnd_func()
                            print("[v43-BOUNDARY] 887 override for %s -> %d items" % (search_key, len(items)))
                        # v22g: replace YELLOW_ENTERPRISE placeholder with actual enterprise name
                        # Supports both YELLOW_RULE_{CODE} and RULE_{CODE}_TC_{N} formats
                        ent_name = ""
                        if search_key:
                            upper_sk = search_key.upper()
                            if upper_sk.startswith("YELLOW_RULE_"):
                                rc = search_key[len("YELLOW_RULE_"):]
                                ent_name = "\u56fd\u4f01\u89c4\u5219\u6d4b\u8bd5_" + rc
                            elif re.match(r"(?i)RULE_[A-Z]", search_key) and rule_code:
                                # v22g: RULE_{CODE}_TC_{N} format
                                if rule_code.startswith("EBN"):
                                    ent_name = "\u56fd\u4f01\u89c4\u5219\u6d4b\u8bd5_" + rule_code
                                elif rule_code.startswith("ARG"):
                                    ent_name = "\u5173\u8054\u89c4\u5219\u6d4b\u8bd5_" + rule_code
                                elif rule_code.startswith("ELL") or rule_code.startswith("ENL") or rule_code.startswith("END") or rule_code.startswith("PNG"):
                                    ent_name = "\u6c11\u8425\u89c4\u5219\u6d4b\u8bd5_" + rule_code
                                else:
                                    ent_name = "\u6c11\u8425\u89c4\u5219\u6d4b\u8bd5_" + rule_code
                        if ent_name:
                            items = _replace_placeholders(items, ent_name)
                        # v22g: ETL 887 does searchKey.equals(partyName),
                        # so PartyList items' Name must be replaced with searchKey
                        if search_key and code == "887":
                            items = _fix_887_party_names(items, search_key)
                        resp = make_risk_list(items)
                    else:
                        # v23: Only fall back to YELLOW_FULL_FUNCS when no rule code
                        # (e.g., YELLOW_TC_NNN searchKeys where rule code can't be extracted).
                        # When rule code IS set, unmapped endpoints MUST return safe data
                        # to ensure per-rule routing isolation.
                        if not rule_code:
                            full_func = YELLOW_FULL_FUNCS.get(code)
                            if full_func:
                                resp = make_risk_list(full_func())
                            else:
                                resp = make_safe_list()
                        else:
                            resp = make_safe_list()
                elif mode == "yellow_full":
                    func = YELLOW_FULL_FUNCS.get(code)
                    if func:
                        resp = make_risk_list(func())
                    else:
                        resp = make_safe_list()
                elif mode == "red":
                    func = RED_FUNCS.get(code)
                    if func:
                        resp = make_risk_list(func())
                    else:
                        resp = make_safe_list()
                else:
                    # v36: Check sticky personal_related flag
                    # When enterprise sub-strategy used RULE_PLEP*/RULE_ARGP* searchKey,
                    # subsequent calls with person name / company USCC get risk data
                    # for personal/related endpoints only.
                    with _sticky_lock:
                        pr_active = _sticky_mode.get("personal_related", False)
                    sk = search_key or ""
                    is_rule_format = re.match(r"(?i)^(RULE_|YELLOW_|RED_|BLUE_|SUPPLEMENTARY|SAFE_)", sk)

                    if pr_active and not is_rule_format and sk:
                        # Personal/related sub-strategy call - return risk data for relevant endpoints
                        if code in _PERSONAL_ENDPOINTS or code in _RELATED_ENDPOINTS:
                            full_func = YELLOW_FULL_FUNCS.get(code)
                            if full_func:
                                items = full_func()
                                if code == "887":
                                    items = _fix_887_party_names(items, sk)
                                resp = make_risk_list(items)
                            else:
                                resp = make_safe_list()
                        else:
                            resp = make_safe_list()
                    else:
                        resp = make_safe_list()
                data_count = 0
                try:
                    data_count = len(resp["Result"]["Data"])
                except:
                    pass
                sk_flag = "HAS_KEY" if search_key else "NO_KEY"
                print("[v24-%s] %s %s(%s) items=%d [rule=%s] [%s] %s" % (mode.upper(), http_method, pattern, code, data_count, rule_code or "-", sk_flag, company))
                self._respond_json(resp)
                return

        # Default: unknown endpoint
        resp = make_safe_list()
        sk_flag = "HAS_KEY" if search_key else "NO_KEY"
        print("[v24-%s] %s Unknown [rule=%s] [%s] %s %s" % (mode.upper(), http_method, rule_code or "-", sk_flag, path, company))
        self._respond_json(resp)

    def do_GET(self):
        parts = self.path.split("?")
        path = parts[0]
        query = parts[1] if len(parts) > 1 else ""
        params = self._parse_qs(query)
        search_key = self._extract_search_key(params)
        company = self._extract_company(params)
        self._route_request("GET", path, search_key, company)

    def do_POST(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length > 0 else ""

        # Credit report SOAP endpoint - special case (XML in/out)
        if "comSingleCacheQuery" in self.path or "services" in self.path:
            search_key = ""
            # v24: Try <searchKey> XML element first (direct searchKey in SOAP body)
            m = re.search(r"<searchKey>(.*?)</searchKey>", body, re.IGNORECASE)
            if m:
                search_key = m.group(1)
            # Then try <entName> XML element (Tiance may encode searchKey as entName)
            if not search_key:
                m = re.search(r"<entName>(.*?)</entName>", body, re.IGNORECASE)
                if m:
                    search_key = m.group(1)
            # v13: If no XML entName, also try JSON body and query string
            if not search_key:
                parts = self.path.split("?")
                query = parts[1] if len(parts) > 1 else ""
                qs_params = self._parse_qs(query)
                search_key = self._extract_search_key(qs_params, body)
            ent_name = search_key if search_key else u"\u6d4b\u8bd5\u4f01\u4e1a"
            ent_cert_m = re.search(r"<entCertNum>(.*?)</entCertNum>", body, re.IGNORECASE)
            ent_cert_num = ent_cert_m.group(1) if ent_cert_m else "000000000000000000"
            mode = get_effective_mode(search_key)
            # v24: ECGX rules need non-zero credit report data in yellow mode
            ecrule = extract_rule_code(search_key) if mode == "yellow" else None
            # v32: Determine if this is an ECGX test case by checking company name
            sk_str = (search_key or "").upper()
            is_ecgx_test = "ECGX" in sk_str or "TC_052" in sk_str or "TC_055" in sk_str
            if mode == "red" and is_ecgx_test:
                xml_resp = _credit_report_xml(
                    badloanbal=5000000, odloanacctcnt=3, attnloanacctcnt=2,
                    odguaacctcnt=1, badguabal=2000000, attnguaacctcnt=1,
                    unpaidintbal=500000,
                    ent_name=ent_name, ent_cert_num=ent_cert_num
                )
            elif ecrule and ecrule.startswith("ECGX"):
                # v24: Return targeted non-zero data per ECGX sub-rule
                ecgx_params = {
                    "ECGX01": {"badloanbal": 5000000, "odloanacctcnt": 3},
                    "ECGX02": {"badloanbal": 3000000},
                    "ECGX03": {"attnloanacctcnt": 2},
                    "ECGX04": {"odguaacctcnt": 1, "badguabal": 2000000},
                    "ECGX05": {"badguabal": 1500000},
                    "ECGX06": {"attnguaacctcnt": 1},
                    "ECGX07": {"unpaidintbal": 500000},
                }
                p = ecgx_params.get(ecrule, {"badloanbal": 5000000, "odloanacctcnt": 3})
                xml_resp = _credit_report_xml(
                    ent_name=ent_name, ent_cert_num=ent_cert_num, **p
                )
            else:
                # v31: Check if this is an ECGX test case by examining the company name.
                # Engine sends company name (not RULE_* searchKey) to SOAP endpoint.
                # Only return detailed credit data for ECGX test cases.
                # For all other cases, return zero credit data (no credit rules fire).
                sk_str = search_key if search_key else ""
                is_ecgx_test = "ECGX" in sk_str.upper() or "TC_052" in sk_str.upper() or "TC_055" in sk_str.upper()
                if is_ecgx_test:
                    xml_resp = _credit_report_xml(
                        ent_name=ent_name, ent_cert_num=ent_cert_num,
                        badloanbal=5000000, odloanacctcnt=3,
                        attnloanacctcnt=2, odguaacctcnt=1,
                        badguabal=2000000, attnguaacctcnt=1,
                        unpaidintbal=500000
                    )
                else:
                    # Return zero credit data - no credit rules will fire
                    xml_resp = _credit_report_xml(
                        ent_name=ent_name, ent_cert_num=ent_cert_num
                    )
            sk_flag = "HAS_KEY" if search_key else "NO_KEY"
            print("[v24-%s] POST CreditReport [%s] %s" % (mode.upper(), sk_flag, search_key or "-"))
            self.send_response(200)
            self.send_header("Content-Type", "text/xml; charset=utf-8")
            self.end_headers()
            self.wfile.write(xml_resp)
            return

        # v13 FIX: Extract searchKey from BOTH query string AND body
        parts = self.path.split("?")
        path = parts[0]
        query = parts[1] if len(parts) > 1 else ""
        qs_params = self._parse_qs(query)

        # Extract searchKey: try query string first, then body (JSON + form-encoded)
        search_key = self._extract_search_key(qs_params, body)
        company = self._extract_company(qs_params, body)

        # v13 FIX: Route through the same endpoint logic as GET
        self._route_request("POST", path, search_key, company, body)

    def do_HEAD(self):
        """Handle HEAD requests (often used by load balancers for health checks)."""
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

    def do_OPTIONS(self):
        """Handle CORS preflight requests."""
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def _respond_json(self, data):
        """v18: Convert all byte strings to unicode before json.dumps.

        Python 2 byte strings with \\uXXXX are NOT interpreted as Unicode
        escapes (only u"..." unicode literals are). This caused Chinese
        characters to be sent as literal \\uXXXX sequences in JSON responses.
        Fix: recursively decode all byte strings to unicode, which causes
        json.dumps(ensure_ascii=True) to properly handle \\uXXXX sequences.
        """
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        data = _to_unicode(data)
        json_str = json.dumps(data, ensure_ascii=True)
        if isinstance(json_str, unicode):
            json_str = json_str.encode("utf-8")
        self.wfile.write(json_str)

def main():
    server = HTTPServer(("0.0.0.0", PORT), MockHandler)
    print("=" * 60)
    print("Mock QCC Service v24 started on port %d" % PORT)
    print("v24: Added low_paidin KYC, ECGX credit report, ELDP10 liquidation")
    print("     searchKey format: YELLOW_RULE_{RULE_CODE}")
    print("     searchKey read from: query string, JSON body, form body")
    print("     POST routes through same endpoint logic as GET")
    print("Modes: SAFE(default) | BLUE_ONLY | YELLOW | YELLOW_FULL | RED_ALERT | FULL_RISK")
    print("=" * 60)
    sys.stdout.flush()
    server.serve_forever()

if __name__ == "__main__":
    main()
