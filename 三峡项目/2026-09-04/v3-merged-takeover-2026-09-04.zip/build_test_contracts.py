#!/usr/bin/env python3
"""Build rule/function/risk test contract inventories from parsed strategy JSON."""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import re


VERSION = "1.0.0"
API_CODES = {
    "2003", "255", "739", "740", "741", "742", "744", "746", "748",
    "751", "752", "756", "757", "758", "761", "764", "765", "766",
    "767", "768", "771", "865", "882", "887", "888", "958", "980",
}
SOURCE_KEYWORDS = {
    "客户身份": "2003",
    "变更": "2003",
    "注册资本": "2003",
    "资质": "255",
    "经营异常": "739",
    "失信": "740",
    "被执行": "741",
    "限制高消费": "742",
    "司法拍卖": "744",
    "环保处罚": "746",
    "严重违法": "748",
    "股权出质": "751",
    "股权冻结": "752",
    "税收违法": "756",
    "欠税": "757",
    "终本": "758",
    "破产": "761",
    "行政处罚": "865",
    "法院公告": "882",
    "裁判文书": "887",
    "开庭公告": "888",
    "招投标": "958",
    "中标": "958",
    "清算": "980",
    "征信": "qyzxbg",
    "预警通": "warning-service",
}


def _atomic_write(path: Path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    temporary.replace(path)


def _scenario_fragment(value):
    return re.sub(r"[^A-Za-z0-9]+", "_", str(value or "")).strip("_").upper()


def _source_codes(rule):
    text = " ".join(str(rule.get(key, "")) for key in (
        "dataSource", "name", "description", "inputParams"
    ))
    codes = {code for code in API_CODES if re.search(rf"(?<!\d){code}(?!\d)", text)}
    for keyword, code in SOURCE_KEYWORDS.items():
        if keyword in text:
            codes.add(code)
    return sorted(codes)


def _field_codes(rule):
    return [
        item.get("code") for item in rule.get("inputParamsMapped", [])
        if isinstance(item, dict) and item.get("code")
    ]


def build_contracts(parsed, strategy_code, mock_index):
    strategies = [
        item for item in parsed.get("strategies", [])
        if item.get("code") == strategy_code
    ]
    if len(strategies) != 1:
        raise ValueError(f"找不到唯一目标策略: {strategy_code}")

    rules = [
        rule for rule in parsed.get("rules", [])
        if rule.get("ruleSetCode") != "alertLevelJudgment"
    ]
    identities = Counter(
        (rule.get("ruleSetCode"), rule.get("code")) for rule in rules
    )
    available_codes = set(mock_index)
    rule_contracts = []
    for rule in rules:
        identity = (rule.get("ruleSetCode"), rule.get("code"))
        source_codes = _source_codes(rule)
        protocol_available = bool(source_codes) and all(
            code in available_codes or code == "qyzxbg" for code in source_codes
        )
        if identities[identity] > 1:
            implementation_status = "ambiguous_rule_identity"
        elif not source_codes and not rule.get("dataSource"):
            implementation_status = "direct_input_review_required"
        elif protocol_available:
            implementation_status = "scenario_payload_required"
        else:
            implementation_status = "source_adapter_required"
        prefix = "_".join((
            "BHJC",
            _scenario_fragment(rule.get("ruleSetCode")),
            _scenario_fragment(rule.get("code")),
        ))
        rule_contracts.append({
            "ruleSetCode": rule.get("ruleSetCode"),
            "ruleCode": rule.get("code"),
            "ruleName": rule.get("name"),
            "expression": rule.get("expression"),
            "hitResult": rule.get("hitResult"),
            "sourceDescription": rule.get("dataSource"),
            "sourceCodes": source_codes,
            "inputFields": _field_codes(rule),
            "identityUnique": identities[identity] == 1,
            "mockProtocolAvailable": protocol_available,
            "implementationStatus": implementation_status,
            "scenarioKeys": {
                "hit": f"{prefix}_HIT__${{RUN_ID}}__${{CASE_ID}}",
                "miss": f"{prefix}_MISS__${{RUN_ID}}__${{CASE_ID}}",
                "boundary": f"{prefix}_BOUNDARY__${{RUN_ID}}__${{CASE_ID}}",
            },
        })

    function_contracts = [{
        "name": item.get("name"),
        "type": item.get("type"),
        "inputs": item.get("inputs"),
        "outputs": item.get("outputs"),
        "logic": item.get("logic"),
        "implementationStatus": "exact_input_output_scenarios_required",
    } for item in parsed.get("functions", [])]

    risk_matrix = {
        "red": [
            {"extreme": 1, "high": 0, "medium": 0, "low": 0},
            {"extreme": 0, "high": 1, "medium": 0, "low": 0},
            {"extreme": 0, "high": 0, "medium": 3, "low": 0},
        ],
        "yellow": [
            {"extreme": 0, "high": 0, "medium": 1, "low": 0},
            {"extreme": 0, "high": 0, "medium": 2, "low": 0},
        ],
        "blue": [
            {"extreme": 0, "high": 0, "medium": 0, "low": 1},
        ],
        "green": [
            {"extreme": 0, "high": 0, "medium": 0, "low": 0},
        ],
    }

    status_counts = Counter(item["implementationStatus"] for item in rule_contracts)
    summary = {
        "strategyCode": strategy_code,
        "ruleDefinitions": len(rule_contracts),
        "uniqueRuleIdentities": len(identities),
        "duplicateRuleIdentities": sum(1 for count in identities.values() if count > 1),
        "functionCount": len(function_contracts),
        "riskLevelCount": len(risk_matrix),
        "ruleStatusCounts": dict(sorted(status_counts.items())),
    }
    return rule_contracts, function_contracts, risk_matrix, summary


def main():
    parser = argparse.ArgumentParser(description="生成保后检查可控回放测试合同")
    parser.add_argument("--parsed-strategy", required=True)
    parser.add_argument("--strategy-code", required=True)
    parser.add_argument("--mock-index", default="mock-files/index.json")
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    parsed = json.loads(Path(args.parsed_strategy).read_text(encoding="utf-8"))
    mock_index = json.loads(Path(args.mock_index).read_text(encoding="utf-8"))
    rules, functions, risk_matrix, summary = build_contracts(
        parsed, args.strategy_code, mock_index
    )
    output_dir = Path(args.output_dir)
    generated_at = datetime.now(timezone.utc).isoformat()
    common = {
        "schemaVersion": "1.0",
        "generatorVersion": VERSION,
        "strategyCode": args.strategy_code,
        "generatedAt": generated_at,
    }
    _atomic_write(output_dir / "rule-contracts.json", {**common, "rules": rules})
    _atomic_write(output_dir / "function-contracts.json", {**common, "functions": functions})
    _atomic_write(output_dir / "risk-level-matrix.json", {**common, "matrix": risk_matrix})
    _atomic_write(output_dir / "coverage-gaps.json", {**common, "summary": summary})
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
