# -*- coding: utf-8 -*-
"""生成 migration_manifest.json：147 条规则合同的迁移四态清单。

状态定义：
- native                  : V2 原生场景合同已覆盖（scenarios/registry.json 非 LG 前缀）；
- legacy                  : 经 legacy_v46_adapter 显式场景合同覆盖（BHJC_LG_*_HIT/MISS）；
- excluded_inconclusive   : 合同标记 ambiguous_rule_identity / source_adapter_required，
                            保持 inconclusive，不静默回退；
- pending                 : 以上均不覆盖，需人工决策。
"""

import json
import os
import sys
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import legacy_v46_adapter as AD  # noqa: E402

REGISTRY = os.path.join(HERE, "scenarios", "registry.json")
CONTRACTS = os.path.join(HERE, "contracts", "rule-contracts.json")
OUTPUT = os.path.join(HERE, "migration_manifest.json")

EXCLUDED_REASONS = {
    "source_adapter_required": "依赖预警通数据源适配器，保持 inconclusive",
}
AMBIGUOUS_LEGACY_REASON = "合同重复定义(ambiguous_rule_identity)，按 legacy 显式映射去重迁移"
# 伴随命中声明：日期系证书规则存在包含关系，不得按单规则隔离验收
ACCOMPANIMENT = {
    "EBNP07": ["EBNP06"],
    "EBNP08": ["EBNP06", "EBNP07"],
}


def main():
    contracts = json.load(open(CONTRACTS, encoding="utf-8"))
    registry = json.load(open(REGISTRY, encoding="utf-8"))
    scenarios = registry.get("scenarios", {})
    native_templates = {k for k in scenarios if not k.startswith("BHJC_LG_")}
    legacy_codes = AD.legacy_rule_codes()

    entries = []
    totals = {"native": 0, "legacy": 0, "excluded_inconclusive": 0, "pending": 0}
    for rule in contracts["rules"]:
        code = rule["ruleCode"]
        contract_status = rule.get("implementationStatus", "")
        templates = rule.get("scenarioKeys", {})
        native_hit = any(
            k.endswith(f"_{code}_HIT") or k.endswith(f"_{code}_MISS")
            or k.endswith(f"_{code}_BOUNDARY")
            for k in native_templates
        )
        if native_hit:
            status, provider, reason = "native", "v2_native", "V2 原生场景合同已覆盖"
        elif contract_status in EXCLUDED_REASONS:
            status, provider, reason = "excluded_inconclusive", None, EXCLUDED_REASONS[contract_status]
        elif contract_status == "scenario_payload_required" and code in legacy_codes:
            status, provider, reason = "legacy", "legacy_v46", "legacy 显式规则映射迁入 BHJC_LG_ 场景合同"
        elif contract_status == "ambiguous_rule_identity" and code in legacy_codes:
            status, provider, reason = "legacy", "legacy_v46", AMBIGUOUS_LEGACY_REASON
        elif contract_status == "ambiguous_rule_identity":
            status, provider, reason = "excluded_inconclusive", None, "规则身份歧义且无 legacy 映射，保持 inconclusive"
        else:
            status, provider, reason = "pending", None, "未覆盖，需人工决策"
        totals[status] += 1
        entries.append({
            "ruleSetCode": rule.get("ruleSetCode"),
            "ruleCode": code,
            "ruleName": rule.get("ruleName"),
            "contractStatus": contract_status,
            "status": status,
            "provider": provider,
            "reason": reason,
            "accompaniment": ACCOMPANIMENT.get(code, []),
            "scenarioTemplates": {
                "hit": f"BHJC_LG_{code}_HIT" if status == "legacy" else templates.get("hit"),
                "miss": f"BHJC_LG_{code}_MISS" if status == "legacy" else templates.get("miss"),
            },
        })

    manifest = {
        "schemaVersion": 1,
        "generatedAt": datetime.now().isoformat(timespec="seconds"),
        "source": ["contracts/rule-contracts.json", "scenarios/registry.json",
                   "legacy_v46_adapter.legacy_rule_codes()"],
        "totals": totals,
        "rules": entries,
    }
    with open(OUTPUT, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=2)
    pending = [e["ruleCode"] for e in entries if e["status"] == "pending"]
    excluded = [e["ruleCode"] for e in entries if e["status"] == "excluded_inconclusive"]
    print(f"totals={totals}")
    print(f"excluded={excluded}")
    print(f"pending={pending}")


if __name__ == "__main__":
    main()
