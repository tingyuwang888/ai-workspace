#!/bin/bash
# 企查查 Mock 服务 启动脚本

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] python3 未找到，请先安装 Python 3.8+"
    exit 1
fi

# 检查依赖；部署环境应显式安装，启动脚本不修改环境。
if ! python3 -c "import flask" 2>/dev/null; then
    echo "[ERROR] Flask 未安装，请先执行: python3 -m pip install -r requirements.txt"
    exit 1
fi

: "${QCC_MOCK_AUTH_ENABLED:=true}"
: "${QCC_MOCK_STRICT_SCENARIOS:=true}"
: "${QCC_MOCK_PORT:=8899}"
: "${QCC_MOCK_HOST:=127.0.0.1}"
export QCC_MOCK_AUTH_ENABLED QCC_MOCK_STRICT_SCENARIOS QCC_MOCK_PORT QCC_MOCK_HOST

echo "[INFO] 启动企查查 Mock 服务 v2..."
exec python3 app.py
