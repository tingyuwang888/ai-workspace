#!/usr/bin/env python3
"""v3-merged 合并版本地验证套件。

覆盖：原生场景回归、legacy provider 各接口形态、场景隔离（无 sticky 继承）、
KYC 整数 StatusCode、SOAP ECGX 显式场景、未知场景拒绝、迁移清单一致性、
legacy 模块 py3 兼容导入。
"""

import json
import os
import unittest
from unittest.mock import patch

import app as mock_app
import legacy_v46_adapter as AD
import legacy_v46_source as L

HERE = os.path.dirname(os.path.abspath(__file__))
SOAP_BODY = (
    "<soap:Envelope><soap:Body><req>"
    "<searchKey>{key}</searchKey><entName>{ent}</entName>"
    "<entCertNum>91110000MA0XXXXXX</entCertNum>"
    "</req></soap:Body></soap:Envelope>"
)


class V3MergedServiceTest(unittest.TestCase):

    def setUp(self):
        mock_app.app.config.update(TESTING=True)
        self.client = mock_app.app.test_client()
        patcher = patch.object(mock_app, "AUTH_ENABLED", False)
        patcher.start()
        self.addCleanup(patcher.stop)

    def get_json(self, path, **params):
        response = self.client.get(path, query_string=params)
        return response.get_json()

    # ---------- 基础与原生回归 ----------

    def test_health_reports_merged_version(self):
        payload = self.client.get("/health").get_json()
        self.assertEqual(payload["version"], "3.0.0-merged")
        self.assertGreater(payload["scenarioCount"], 200)

    def test_native_kyc_has_integer_status_code(self):
        payload = self.get_json(
            "/CustomerDueDiligence/KYC", searchKey="BHJC_002__RUN001__TC001")
        self.assertEqual(payload["Status"], "200")
        self.assertEqual(payload["StatusCode"], 200)
        self.assertIsInstance(payload["StatusCode"], int)
        self.assertEqual(payload["Result"]["Data"]["chglegalrepcnt"], 1)

    def test_unknown_bhjc_scenario_still_rejected(self):
        payload = self.get_json(
            "/CustomerDueDiligence/KYC", searchKey="BHJC_NOPE__RUN001__TC001")
        self.assertEqual(payload["Status"], "201")

    # ---------- legacy provider：KYC / 列表 / 证书 / 清算 ----------

    def test_legacy_kyc_hit_equity_change(self):
        payload = self.get_json(
            "/CustomerDueDiligence/KYC",
            searchKey="BHJC_LG_EBNS02_HIT__RUN001__TC001")
        data = payload["Result"]["Data"]
        self.assertEqual(payload["StatusCode"], 200)
        self.assertEqual(len(data["ChangeList"]), 1)
        self.assertEqual(data["ChangeList"][0]["ProjectName"], "股权变更")

    def test_legacy_endpoint_isolation(self):
        hit = self.get_json(
            "/ZhixingCheck/GetList",
            searchKey="BHJC_LG_ELLP03_HIT__RUN001__TC001")
        self.assertEqual(hit["Result"]["VerifyResult"], 1)
        self.assertEqual(len(hit["Result"]["Data"]), 1)
        quiet = self.get_json(
            "/ShixinCheck/GetList",
            searchKey="BHJC_LG_ELLP03_HIT__RUN001__TC001")
        self.assertEqual(quiet["Result"]["VerifyResult"], 0)

    def test_legacy_miss_scenario_returns_safe(self):
        payload = self.get_json(
            "/ZhixingCheck/GetList",
            searchKey="BHJC_LG_ELLP03_MISS__RUN001__TC001")
        self.assertEqual(payload["Result"]["VerifyResult"], 0)

    def test_legacy_cert_expired(self):
        payload = self.get_json(
            "/ECICertification/SearchCertification",
            searchKey="BHJC_LG_EBNP08_HIT__RUN001__TC001")
        self.assertIsInstance(payload["Result"], list)
        self.assertEqual(payload["Result"][0]["Status"], "已过期")

    def test_legacy_detail_liquidation(self):
        payload = self.get_json(
            "/LiquidationCheck/GetDetail",
            searchKey="BHJC_LG_ELDP10_HIT__RUN001__TC001")
        self.assertEqual(payload["Result"]["VerifyResult"], 1)

    def test_legacy_887_party_name_matches_search_key(self):
        key = "BHJC_LG_ELLP06_HIT__RUN001__TC001"
        payload = self.get_json("/JudgmentDocCheck/GetList", searchKey=key)
        records = payload["Result"]["Data"]
        self.assertEqual(len(records), 5)
        for record in records:
            self.assertEqual(record["PartyList"][0]["Name"], key)

    # ---------- 无 sticky 继承 ----------

    def test_no_sticky_inheritance_after_risk_scenario(self):
        self.get_json("/ZhixingCheck/GetList",
                      searchKey="BHJC_LG_ELLP03_HIT__RUN001__TC001")
        base = self.get_json("/ZhixingCheck/GetList",
                             searchKey="BHJC_BASE__RUN001__TC002")
        self.assertEqual(base["Result"]["VerifyResult"], 0)
        other = self.get_json("/ZhixingCheck/GetList",
                              searchKey="BHJC_LG_ELLP03_HIT__RUN002__TC009")
        self.assertEqual(len(other["Result"]["Data"]), 1)

    # ---------- RED 全量回归场景 ----------

    def test_red_full_scenario(self):
        kyc = self.get_json("/CustomerDueDiligence/KYC",
                            searchKey="BHJC_LG_RED_ALERT__RUN001__TC001")
        self.assertEqual(kyc["Result"]["VerifyResult"], 1)
        self.assertTrue(kyc["Result"]["Data"]["PubPartnerList"])
        shixin = self.get_json("/ShixinCheck/GetList",
                               searchKey="BHJC_LG_RED_ALERT__RUN001__TC001")
        self.assertGreaterEqual(len(shixin["Result"]["Data"]), 1)

    # ---------- SOAP ECGX ----------

    def test_soap_legacy_ecgx_nonzero(self):
        response = self.client.post(
            "/services/comSingleCacheQuery",
            data=SOAP_BODY.format(key="BHJC_LG_ECGX07_HIT__RUN001__TC001",
                                  ent="测试企业"),
            content_type="text/xml")
        self.assertIn(b"<unpaidintbal>500000</unpaidintbal>", response.data)
        self.assertIn(b"<Crt2_C_BasicBorrowing>", response.data)

    def test_soap_unknown_company_stays_zero(self):
        response = self.client.post(
            "/services/comSingleCacheQuery",
            data=SOAP_BODY.format(key="", ent="普通企业A"),
            content_type="text/xml")
        self.assertIn(b"<unpaidintbal>0</unpaidintbal>", response.data)
        self.assertNotIn(b"<Crt2_C_BasicBorrowing>", response.data)

    # ---------- 适配器直测 ----------

    def test_adapter_boundary_override(self):
        items = AD.build_list("887", "yellow", "ELLP06",
                              search_key="BOUNDARY_COUNT5_TC_206")
        self.assertEqual(len(items["Result"]["Data"]), 5)

    def test_legacy_module_py3_import_and_unicode_identity(self):
        self.assertTrue(callable(L.make_kyc))
        self.assertEqual(L._to_unicode("法定"), "法定")
        envelope = L.make_kyc(L.safe_kyc_data())
        self.assertEqual(envelope["StatusCode"], 200)


class MigrationManifestTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        with open(os.path.join(HERE, "migration_manifest.json"),
                  encoding="utf-8") as fh:
            cls.manifest = json.load(fh)
        with open(os.path.join(HERE, "scenarios", "registry.json"),
                  encoding="utf-8") as fh:
            cls.registry = json.load(fh)["scenarios"]

    def test_manifest_covers_all_contract_rules(self):
        rules = self.manifest["rules"]
        self.assertEqual(len(rules), 147)
        self.assertEqual(sum(self.manifest["totals"].values()), len(rules))

    def test_excluded_are_warning_channel_rules_only(self):
        excluded = {r["ruleCode"] for r in self.manifest["rules"]
                    if r["status"] == "excluded_inconclusive"}
        self.assertEqual(excluded, {"ENLX11", "ENDX13"})

    def test_legacy_entries_have_registry_scenarios(self):
        missing = []
        for rule in self.manifest["rules"]:
            if rule["status"] != "legacy":
                continue
            for key in ("hit", "miss"):
                template = rule["scenarioTemplates"].get(key)
                if template not in self.registry:
                    missing.append(template)
        self.assertEqual(missing, [])

    def test_pending_listed_explicitly(self):
        pending = {r["ruleCode"] for r in self.manifest["rules"]
                   if r["status"] == "pending"}
        self.assertEqual(pending, {"EBNP09", "EBNP10", "EBNP11"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
