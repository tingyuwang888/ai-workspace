#!/usr/bin/env python3

import unittest

from build_platform_switch_plan import build_documents


class PlatformSwitchPlanTest(unittest.TestCase):

    def test_classifies_supported_conditional_and_unsupported_services(self):
        parsed = {
            "thirdPartyInterfaces": [
                {
                    "name": "企查查758终本案件核查",
                    "code": "758zbajhc",
                    "partner": "企查查",
                    "protocol": "HTTPS GET",
                    "url": "https://api.qichacha.com/TerminatedCaseCheck/GetList",
                },
                {
                    "name": "企业征信报告",
                    "code": "qyzxbg",
                    "protocol": "SOAP",
                    "url": "http://IP:PORT/services/enterpriseCreditQueryTwoCode",
                },
                {
                    "name": "预警通新闻舆情",
                    "code": "yjtxwyq",
                    "protocol": "HTTPS",
                    "url": "预警通API-新闻舆情",
                },
            ]
        }

        plan, rollback, checklist = build_documents(parsed, "parsed.json")

        self.assertEqual(
            [item["classification"] for item in plan["services"]],
            ["ready_to_switch", "safe_baseline_only", "adapter_required"],
        )
        self.assertEqual(
            plan["services"][0]["proposedUrl"],
            "http://<MOCK_HOST>:8899/TerminatedCaseCheck/GetList",
        )
        self.assertEqual(plan["services"][2]["switchDecision"], "do_not_switch")
        self.assertEqual(len(rollback["services"]), 2)
        self.assertIn("Agent 不访问、不修改天策数据源配置", checklist)


if __name__ == "__main__":
    unittest.main()
