#!/usr/bin/env python3

from datetime import date, datetime
import unittest
from unittest.mock import patch

import app as mock_app
from build_test_contracts import build_contracts
from scenario_runtime import parse_scenario_key, rebase_dates, SERVICE_VERSION


class ScenarioRuntimeTest(unittest.TestCase):

    def test_parses_isolated_scenario_key(self):
        identity = parse_scenario_key("BHJC_002__RUN-001__TC_001")

        self.assertEqual(identity.template_key, "BHJC_002")
        self.assertEqual(identity.run_id, "RUN-001")
        self.assertEqual(identity.case_id, "TC_001")
        self.assertTrue(identity.isolated)

    def test_rebases_dates_without_changing_intervals(self):
        payload = {"recent": "2026-05-25", "older": "2026-05-01"}
        shifted = rebase_dates(payload, today=date(2026, 9, 3))

        recent = datetime.strptime(shifted["recent"], "%Y-%m-%d").date()
        older = datetime.strptime(shifted["older"], "%Y-%m-%d").date()
        self.assertEqual((date(2026, 9, 3) - recent).days, 6)
        self.assertEqual((recent - older).days, 24)


class MockServiceTest(unittest.TestCase):

    def setUp(self):
        mock_app.app.config.update(TESTING=True)
        self.client = mock_app.app.test_client()

    def test_isolated_key_uses_template_and_unique_order_number(self):
        with patch.object(mock_app, "AUTH_ENABLED", False):
            response = self.client.get(
                "/CustomerDueDiligence/KYC",
                query_string={"searchKey": "BHJC_002__RUN001__TC001"},
            )

        payload = response.get_json()
        self.assertEqual(payload["Status"], "200")
        self.assertEqual(payload["OrderNumber"], "MOCK_BHJC_002__RUN001__TC001")
        self.assertEqual(payload["Result"]["Data"]["chglegalrepcnt"], 1)
        change_date = datetime.strptime(
            payload["Result"]["Data"]["ChangeList"][0]["ChangeDate"],
            "%Y-%m-%d",
        ).date()
        self.assertLess((date.today() - change_date).days, 90)

    def test_unknown_bhjc_scenario_does_not_fall_back(self):
        with patch.object(mock_app, "AUTH_ENABLED", False):
            response = self.client.get(
                "/CustomerDueDiligence/KYC",
                query_string={"searchKey": "BHJC_UNKNOWN__RUN001__TC001"},
            )

        self.assertEqual(response.get_json()["Status"], "201")

    def test_non_target_interface_returns_safe_empty_baseline(self):
        with patch.object(mock_app, "AUTH_ENABLED", False):
            response = self.client.get(
                "/ShixinCheck/GetList",
                query_string={
                    "searchKey": "BHJC_003__RUN001__TC001",
                    "pageSize": "20",
                },
            )

        payload = response.get_json()
        self.assertEqual(payload["Status"], "200")
        self.assertEqual(payload["Result"]["VerifyResult"], 0)
        self.assertEqual(payload["Result"]["Data"], [])

    def test_registry_maps_unique_scenario_to_existing_response_file(self):
        registry = {
            "BHJC_RULE_TEST": {
                "responses": {
                    "740": {"sourceSearchKey": "近期失信公司"},
                },
            },
        }
        with patch.object(mock_app, "AUTH_ENABLED", False), patch.object(
            mock_app, "SCENARIO_REGISTRY", registry
        ):
            target = self.client.get(
                "/ShixinCheck/GetList",
                query_string={
                    "searchKey": "BHJC_RULE_TEST__RUN001__TC001",
                    "pageSize": "20",
                },
            ).get_json()
            baseline = self.client.get(
                "/ZhixingCheck/GetList",
                query_string={
                    "searchKey": "BHJC_RULE_TEST__RUN001__TC001",
                    "pageSize": "20",
                },
            ).get_json()

        self.assertEqual(target["Status"], "200")
        self.assertGreater(target["Result"]["VerifyResult"], 0)
        self.assertEqual(
            target["OrderNumber"], "MOCK_BHJC_RULE_TEST__RUN001__TC001"
        )
        self.assertEqual(baseline["Result"]["VerifyResult"], 0)

    def test_builtin_registry_has_hit_miss_and_boundary_for_ells01(self):
        with patch.object(mock_app, "AUTH_ENABLED", False):
            hit = self.client.get(
                "/ShixinCheck/GetList",
                query_string={
                    "searchKey": "BHJC_RULE_ELLS01_HIT__RUN001__TC001",
                    "pageSize": "20",
                },
            ).get_json()
            miss = self.client.get(
                "/ShixinCheck/GetList",
                query_string={
                    "searchKey": "BHJC_RULE_ELLS01_MISS__RUN001__TC002",
                    "pageSize": "20",
                },
            ).get_json()
            boundary = self.client.get(
                "/ShixinCheck/GetList",
                query_string={
                    "searchKey": "BHJC_RULE_ELLS01_BOUNDARY__RUN001__TC003",
                    "pageSize": "20",
                },
            ).get_json()

        self.assertGreater(hit["Result"]["VerifyResult"], 0)
        self.assertEqual(miss["Result"]["VerifyResult"], 0)
        boundary_date = datetime.strptime(
            boundary["Result"]["Data"][0]["Liandate"], "%Y-%m-%d"
        ).date()
        self.assertEqual((date.today() - boundary_date).days, 90)

    def test_health_exposes_contract_without_secret(self):
        payload = self.client.get("/health").get_json()

        self.assertEqual(payload["version"], SERVICE_VERSION)
        self.assertTrue(payload["strictScenarioKeys"])
        self.assertNotIn("mock_key", payload)

    def test_qcc_auth_rejects_unsigned_request_when_enabled(self):
        with patch.object(mock_app, "AUTH_ENABLED", True):
            payload = self.client.get(
                "/CustomerDueDiligence/KYC",
                query_string={"searchKey": "BHJC_BASE__RUN001__TC001"},
            ).get_json()

        self.assertEqual(payload["Status"], "401")

    def test_soap_auth_token_is_enforced_when_configured(self):
        with patch.object(mock_app, "SOAP_AUTH_TOKEN", "test-token"):
            denied = self.client.post("/services/comSingleCacheQuery", data="<x/>")
            allowed = self.client.post(
                "/services/comSingleCacheQuery",
                data="<x/>",
                headers={"X-Mock-Token": "test-token"},
            )

        self.assertEqual(denied.status_code, 401)
        self.assertEqual(allowed.status_code, 200)

    def test_v27_terminated_case_route_alias(self):
        with patch.object(mock_app, "AUTH_ENABLED", False):
            response = self.client.get(
                "/TerminatedCaseCheck/GetList",
                query_string={
                    "searchKey": "BHJC_RULE_ELLS01_MISS__RUN001__TC001",
                    "pageSize": "20",
                },
            )

        payload = response.get_json()
        self.assertEqual(payload["Status"], "200")
        self.assertEqual(payload["Result"]["VerifyResult"], 0)

    def test_v27_person_terminated_case_route_alias(self):
        with patch.object(mock_app, "AUTH_ENABLED", False):
            response = self.client.get(
                "/PersonTerminatedCaseCheck/GetList",
                query_string={
                    "searchKey": "BHJC_RULE_ELLS01_MISS__RUN001__TC001",
                    "personName": "测试人员",
                    "pageSize": "20",
                },
            )

        payload = response.get_json()
        self.assertEqual(payload["Status"], "200")
        self.assertEqual(payload["Result"]["VerifyResult"], 0)

    def test_v27_enterprise_credit_route_alias(self):
        with patch.object(mock_app, "SOAP_AUTH_TOKEN", ""):
            response = self.client.post(
                "/services/enterpriseCreditQueryTwoCode",
                data="<entName>测试企业</entName>",
            )

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"<retCode>1</retCode>", response.data)


class ContractBuilderTest(unittest.TestCase):

    def test_marks_duplicate_identity_and_available_protocol(self):
        parsed = {
            "strategies": [{"code": "bhjcpostMainBefore"}],
            "rules": [
                {
                    "ruleSetCode": "RS1", "code": "R1", "name": "失信规则A",
                    "expression": "失信数>0", "hitResult": "高风险",
                    "dataSource": "企查查740失信核查", "inputParamsMapped": [],
                },
                {
                    "ruleSetCode": "RS1", "code": "R1", "name": "失信规则B",
                    "expression": "失信数>1", "hitResult": "极高风险",
                    "dataSource": "企查查740失信核查", "inputParamsMapped": [],
                },
            ],
            "functions": [{"name": "计算函数", "inputs": "A", "outputs": "B"}],
        }

        rules, functions, matrix, summary = build_contracts(
            parsed,
            "bhjcpostMainBefore",
            {"740": {}},
        )

        self.assertEqual(len(rules), 2)
        self.assertTrue(all(not item["identityUnique"] for item in rules))
        self.assertTrue(all(item["mockProtocolAvailable"] for item in rules))
        self.assertEqual(summary["duplicateRuleIdentities"], 1)
        self.assertEqual(len(functions), 1)
        self.assertEqual(set(matrix), {"red", "yellow", "blue", "green"})


if __name__ == "__main__":
    unittest.main()
