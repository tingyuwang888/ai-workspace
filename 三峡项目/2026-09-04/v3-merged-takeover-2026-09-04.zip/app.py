# -*- coding: utf-8 -*-
"""
企查查 Mock 服务
================
基于企查查开放平台 API 文档，提供 27 个接口的本地 Mock 服务。

- 所有接口均为 GET 请求
- 支持 Token + Timespan 鉴权（可通过 ?mock_skip_auth=1 跳过）
- 分页接口支持 pageIndex / pageSize 参数，总计 50 条模拟数据
- 非分页接口返回全量 50 条数据或单条详情

启动方式：
    pip install flask
    python app.py
"""

import hashlib
import json
import os
import time
from functools import wraps

from flask import Flask, request, jsonify

from mock_data import get_mock_response, MOCK_DATA_REGISTRY, _gen_order_number
from scenario_runtime import (
    KNOWN_SCENARIO_KEYS,
    REFERENCE_DATE,
    SERVICE_VERSION,
    finalize_scenario_response,
    parse_scenario_key,
)
from scenario_registry import load_scenario_registry

app = Flask(__name__)

# ======================== 配置 ========================
# 用于 Mock 鉴权校验的 key 和 secret（可随意配置，只要匹配即可）
MOCK_APP_KEY = os.environ.get("QCC_MOCK_APP_KEY", "MOCK_APP_KEY")
MOCK_SECRET_KEY = os.environ.get("QCC_MOCK_SECRET_KEY", "MOCK_SECRET_KEY")

# 是否强制鉴权（设为 False 则跳过 Token 校验，方便调试）
AUTH_ENABLED = os.environ.get("QCC_MOCK_AUTH_ENABLED", "true").lower() in {
    "1", "true", "yes", "on"
}

# 服务端口
PORT = int(os.environ.get("QCC_MOCK_PORT", "8899"))
HOST = os.environ.get("QCC_MOCK_HOST", "127.0.0.1")
SOAP_AUTH_TOKEN = os.environ.get("QCC_MOCK_SOAP_TOKEN", "")

# BHJC 场景必须使用已声明模板；未知场景禁止回退到宽泛公共数据。
STRICT_SCENARIO_KEYS = os.environ.get(
    "QCC_MOCK_STRICT_SCENARIOS", "true"
).lower() in {"1", "true", "yes", "on"}
SCENARIO_REGISTRY_PATH = os.environ.get(
    "QCC_MOCK_SCENARIO_REGISTRY",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "scenarios", "registry.json"),
)
SCENARIO_REGISTRY = load_scenario_registry(SCENARIO_REGISTRY_PATH)

# Mock 预置文件目录
MOCK_FILES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mock-files")


# ======================== Mock 文件加载 ========================

# 每个接口的筛选参数定义
# 格式: api_code -> list of (param_name, description)
FILTER_PARAMS = {
    # 格式: (param_name, description, required)
    # required=True 表示该参数在文件匹配时不可被回退省略
    "255": [("isValid", "是否有效: 0-无效, 1-有效, 2-未披露", False)],
    "764": [("personName", "人员姓名（必填）", True)],
    "765": [("personName", "人员姓名（必填）", True)],
    "766": [("personName", "人员姓名（必填）", True)],
    "767": [("personName", "人员姓名（必填）", True)],
    "768": [("personName", "人员姓名（必填）", True)],
    "771": [("personName", "人员姓名（必填）", True)],
    "887": [
        ("pubYear", "发布年份", False),
        ("caseIdentity", "案件身份: 1-被告, 2-原告", False),
        ("caseStatus", "案件状态: 1-待结案, 2-已结案", False),
        ("keyWord", "筛选关键词", False),
    ],
    "888": [("caseIdentity", "案件身份: 1-被告, 2-原告", False)],
    "958": [
        ("msgType", "信息类型: 3-招标公告, 4-中标公告", False),
        ("areaCode", "行政区域编码", False),
    ],
}


def _build_filter_suffix(api_code):
    """
    根据当前请求的参数和接口定义的 FILTER_PARAMS，构建文件名后缀部分。
    参数按字母序排列，格式: __param1=value1__param2=value2
    """
    param_defs = FILTER_PARAMS.get(str(api_code), [])
    parts = []
    for param_name, _, *_ in sorted(param_defs, key=lambda x: x[0]):
        value = request.args.get(param_name, "")
        if value:
            parts.append(f"{param_name}={value}")
    return "__" + "__".join(parts) if parts else ""


def _build_filter_combinations(api_code):
    """
    生成所有可能的参数组合后缀（从最具体到最宽泛），用于逐级回退查找。
    必填参数（required=True）在所有回退层级中都必须保留，不可被省略。
    只有可选参数才参与逐级回退。
    """
    param_defs = FILTER_PARAMS.get(str(api_code), [])
    # 收集当前请求中有值的筛选参数，区分必填与可选
    required_params = []
    optional_params = []
    for param_name, _, required in sorted(param_defs, key=lambda x: x[0]):
        value = request.args.get(param_name, "")
        if value:
            if required:
                required_params.append((param_name, value))
            else:
                optional_params.append((param_name, value))

    if not required_params and not optional_params:
        return [""]

    # 必填参数的后缀片段（始终出现在文件名中）
    required_suffix = "__".join(f"{k}={v}" for k, v in required_params)

    if not optional_params:
        # 只有必填参数，无可选参数可回退
        return ["__" + required_suffix]

    # 有可选参数时：从全量可选 → 逐个去掉可选 → 兜底（仅保留必填）
    suffixes = []
    # 全量组合：必填 + 全部可选
    all_parts = required_suffix + "__" + "__".join(f"{k}={v}" for k, v in optional_params)
    suffixes.append("__" + all_parts)
    # 逐个去掉可选参数（从后往前）
    for i in range(len(optional_params) - 1, 0, -1):
        subset = optional_params[:i]
        parts = required_suffix + "__" + "__".join(f"{k}={v}" for k, v in subset)
        suffixes.append("__" + parts)
    # 兜底：仅保留必填参数（如果有的话），否则空
    if required_suffix:
        suffixes.append("__" + required_suffix)
    else:
        suffixes.append("")
    return suffixes


def load_mock_file(api_path, search_key, api_code=None):
    """
    从 mock-files 目录加载预置的 Mock 响应。
    支持带筛选参数的文件名匹配，逐级回退。

    Args:
        api_path: API 路径（如 CustomerDueDiligence/KYC）
        search_key: 搜索关键词（即文件名基础部分）
        api_code: API 编号，用于查找筛选参数定义

    Returns:
        dict 或 None: 加载成功返回完整响应 dict，文件不存在返回 None
    """
    base_dir = os.path.join(MOCK_FILES_DIR, api_path)
    if not os.path.isdir(base_dir):
        return None

    # 获取所有可能的后缀组合
    suffixes = _build_filter_combinations(api_code) if api_code else [""]

    for suffix in suffixes:
        file_path = os.path.join(base_dir, f"{search_key}{suffix}.json")
        if os.path.isfile(file_path):
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError) as e:
                print(f"  [WARN] 加载 Mock 文件失败: {file_path} -> {e}")
                return None

    return None


def apply_pagination(full_response, page_index, page_size):
    """
    对预置文件中的全量数据做运行时分页切片。

    预置文件存储了全部 50 条数据，这里按请求的 pageIndex/pageSize 切片。
    255 接口特殊：Result 直接是 JSONArray，而非 {"VerifyResult":1,"Data":[...]}。
    """
    if not full_response or "Result" not in full_response:
        return full_response

    result = full_response.get("Result", {})

    # 255 接口：Result 直接是 JSONArray
    if isinstance(result, list):
        data = result
        total = len(data)
        start = (page_index - 1) * page_size
        end = start + page_size
        page_data = data[start:end]
        response = dict(full_response)
        response["Paging"] = {
            "PageSize": page_size,
            "PageIndex": page_index,
            "TotalRecords": total,
        }
        response["Result"] = page_data  # 保持 JSONArray 结构
        return response

    data = result.get("Data")
    if not isinstance(data, list):
        return full_response

    total = len(data)
    start = (page_index - 1) * page_size
    end = start + page_size
    page_data = data[start:end]

    response = dict(full_response)
    response["Paging"] = {
        "PageSize": page_size,
        "PageIndex": page_index,
        "TotalRecords": total,
    }
    response["Result"] = {
        "VerifyResult": 1 if page_data else 0,
        "Data": page_data,
    }
    return response


# ======================== 鉴权中间件 ========================

def verify_token():
    """
    企查查鉴权校验：
    Token = MD5(key + Timespan + SecretKey) 取 32 位大写字符串
    """
    if not AUTH_ENABLED:
        return True
    if request.args.get("mock_skip_auth") == "1":
        return True

    token = request.headers.get("Token", "")
    timespan = request.headers.get("Timespan", "")
    key = request.args.get("key", "")

    if not token or not timespan:
        return False

    # 检查时间戳有效性（允许 5 分钟偏差）
    try:
        ts = int(timespan)
        if abs(time.time() - ts) > 300:
            return False
    except (ValueError, TypeError):
        return False

    # 验证 Token
    expected = hashlib.md5(
        (key + timespan + MOCK_SECRET_KEY).encode()
    ).hexdigest().upper()
    return token == expected


def auth_required(f):
    """鉴权装饰器"""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not verify_token():
            return jsonify({
                "Status": "401",
                "Message": "【无效请求】Token 异常",
                "OrderNumber": _gen_order_number(),
            }), 200
        return f(*args, **kwargs)
    return decorated


def parse_pagination():
    """解析分页参数，pageSize 为必填项"""
    raw_page_size = request.args.get("pageSize")
    if raw_page_size is None or raw_page_size.strip() == "":
        return None, None  # 缺少 pageSize

    try:
        page_index = int(request.args.get("pageIndex", 1))
    except (ValueError, TypeError):
        page_index = 1
    try:
        page_size = int(raw_page_size)
    except (ValueError, TypeError):
        return None, None  # pageSize 非法

    page_size = min(max(page_size, 1), 100)
    page_index = max(page_index, 1)
    return page_index, page_size


def _build_test_scenario_response(search_key, api_path, api_code=None):
    """
    测试场景动态响应：当 searchKey 以 BHJC_ 开头时，根据场景返回定制化数据。
    - KYC(2003): 返回场景对应的企业工商信息（含 ChangeList 等）
    - 其他接口: 返回空数据（VerifyResult=0），不触发任何规则
    返回 None 表示不匹配测试场景，走正常 mock 文件逻辑。
    """
    if not search_key or not search_key.startswith("BHJC_"):
        return None

    try:
        scenario_identity = parse_scenario_key(search_key)
    except ValueError as exc:
        return {
            "Status": "203",
            "Message": str(exc),
            "OrderNumber": _gen_order_number(),
        }
    registered_scenario = SCENARIO_REGISTRY.get(scenario_identity.template_key)
    if (
        STRICT_SCENARIO_KEYS
        and scenario_identity.template_key not in KNOWN_SCENARIO_KEYS
        and registered_scenario is None
    ):
        return {
            "Status": "201",
            "Message": f"未声明的BHJC场景: {scenario_identity.template_key}",
            "OrderNumber": f"MOCK_{scenario_identity.raw_key}",
        }
    scenario_key = scenario_identity.template_key
    if registered_scenario is not None:
        response_spec = registered_scenario.get("responses", {}).get(str(api_code), {})
        if response_spec:
            if response_spec.get("provider") == "legacy_v46":
                from legacy_v46_adapter import build_response
                response = build_response(
                    str(api_code),
                    response_spec.get("mode", "yellow"),
                    response_spec.get("ruleCode"),
                    search_key,
                )
                response["__mockDateOffsets"] = response_spec.get("dateOffsets", {})
                response["__mockNoRebase"] = True
                return response
            source_key = response_spec.get("sourceSearchKey")
            if not source_key:
                return {
                    "Status": "201",
                    "Message": f"场景{scenario_key}的接口{api_code}缺少sourceSearchKey",
                    "OrderNumber": f"MOCK_{search_key}",
                }
            response = load_mock_file(api_path, source_key, str(api_code))
            if response is None:
                return {
                    "Status": "201",
                    "Message": f"场景{scenario_key}未找到响应文件: {source_key}",
                    "OrderNumber": f"MOCK_{search_key}",
                }
            response["__mockDateOffsets"] = response_spec.get("dateOffsets", {})
            return response
        # 注册场景只在声明的目标接口返回风险数据，其他接口使用安全基线。
        scenario_key = "BHJC_BASE"

    # ===== 场景定义 =====
    # 基础企业信息（所有场景共用）
    base_kyc = {
        "KeyNo": f"kyc_{search_key}",
        "Name": "测试企业",
        "CreditCode": "91110000MA0XXXXXX",
        "OperName": "张三",
        "Status": "在业",
        "StartDate": "2010-01-01",
        "RegistCapi": "5000万元",
        "RegisteredCapital": "5000",
        "RegisteredCapitalUnit": "万",
        "RealCapi": "5000万元",
        "PaidUpCapital": "5000",
        "PaidUpCapitalUnit": "万",
        "RevokeInfo": {
            "CancelDate": "", "CancelReason": "",
            "RevokeDate": "", "RevokeReason": ""
        },
        "TaxCreditList": [
            {"TaxNo": "t01", "Year": "2024", "Level": "A", "Org": "国家税务总局"}
        ],
        "PubPartnerList": [],
        "InvestmentList": [],
        "ChangeList": []
    }

    # 每个场景的 ChangeList 和其他 KYC 字段覆盖
    # 包含预计算字段（chglegalrepcnt等），供天策平台数据源直接映射
    scenarios = {
        "BHJC_BASE": {  # 基准：全部正常，无变更
            "chglegalrepcnt": 0, "chgequitycnt": 0, "chgscopecnt": 0,
            "revokecnt": 0, "capdecratio": 0.0, "capdeccnt": 0, "capinccnt": 0,
            "paidcapratio": 100.0, "regcap": 5000.0, "paidcap": 5000.0,
            "estabdate": "2010-01-01", "taxcreditgrade": "A",
            "majorshareholderkeynos": "", "majorinvestedcompanykeynos": "",
            "relatedent3mcancelrevokecount": 0,
        },
        "BHJC_001": {  # 别名指向BHJC_BASE，确保KYC返回预计算字段
            "chglegalrepcnt": 0, "chgequitycnt": 0, "chgscopecnt": 0,
            "revokecnt": 0, "capdecratio": 0.0, "capdeccnt": 0, "capinccnt": 0,
            "paidcapratio": 100.0, "regcap": 5000.0, "paidcap": 5000.0,
            "estabdate": "2010-01-01", "taxcreditgrade": "A",
            "majorshareholderkeynos": "", "majorinvestedcompanykeynos": "",
            "relatedent3mcancelrevokecount": 0,
        },
        "BHJC_002": {  # 法人变更1次 → 低风险(蓝色预警)
            "ChangeList": [{
                "ProjectName": "法定代表人变更",
                "ChangeDate": "2026-05-01",
                "BeforeList": ["旧法人"],
                "AfterList": ["新法人"],
                "ChangeSubject": "工商变更"
            }],
            "chglegalrepcnt": 1,
            "chglegalrepcntdetail": "[{\"projectName\":\"法定代表人变更\",\"changeDate\":\"2026-05-01\",\"before\":\"旧法人\",\"after\":\"新法人\"}]",
            "chgequitycnt": 0, "chgscopecnt": 0,
            "revokecnt": 0, "capdecratio": 0.0, "capdeccnt": 0, "capinccnt": 0,
            "paidcapratio": 100.0, "regcap": 5000.0, "paidcap": 5000.0,
            "estabdate": "2010-01-01", "taxcreditgrade": "A",
            "majorshareholderkeynos": "", "majorinvestedcompanykeynos": "",
            "relatedent3mcancelrevokecount": 0,
        },
        "BHJC_003": {  # 法人无变更 → 不命中
            "chglegalrepcnt": 0, "chgequitycnt": 0, "chgscopecnt": 0,
            "revokecnt": 0, "capdecratio": 0.0, "capdeccnt": 0, "capinccnt": 0,
            "paidcapratio": 100.0, "regcap": 5000.0, "paidcap": 5000.0,
            "estabdate": "2010-01-01", "taxcreditgrade": "A",
            "majorshareholderkeynos": "", "majorinvestedcompanykeynos": "",
            "relatedent3mcancelrevokecount": 0,
        },
        "BHJC_004": {  # 股权变更2次 → 低风险(蓝色预警)
            "ChangeList": [
                {
                    "ProjectName": "股权转让",
                    "ChangeDate": "2026-05-01",
                    "BeforeList": ["原股东A"],
                    "AfterList": ["新股东A"],
                    "ChangeSubject": "工商变更"
                },
                {
                    "ProjectName": "股权转让",
                    "ChangeDate": "2026-04-15",
                    "BeforeList": ["原股东B"],
                    "AfterList": ["新股东B"],
                    "ChangeSubject": "工商变更"
                }
            ],
            "chgequitycnt": 2,
            "chgequitycntdetail": "[{\"projectName\":\"股权转让\",\"changeDate\":\"2026-05-01\",\"before\":\"原股东A\",\"after\":\"新股东A\"},{\"projectName\":\"股权转让\",\"changeDate\":\"2026-04-15\",\"before\":\"原股东B\",\"after\":\"新股东B\"}]",
            "chglegalrepcnt": 0, "chgscopecnt": 0,
            "revokecnt": 0, "capdecratio": 0.0, "capdeccnt": 0, "capinccnt": 0,
            "paidcapratio": 100.0, "regcap": 5000.0, "paidcap": 5000.0,
            "estabdate": "2010-01-01", "taxcreditgrade": "A",
            "majorshareholderkeynos": "", "majorinvestedcompanykeynos": "",
            "relatedent3mcancelrevokecount": 0,
        },
        "BHJC_005": {  # 经营范围变更1次 → 低风险(蓝色预警)
            "ChangeList": [{
                "ProjectName": "经营范围变更",
                "ChangeDate": "2026-05-01",
                "BeforeList": ["旧经营范围"],
                "AfterList": ["新经营范围"],
                "ChangeSubject": "工商变更"
            }],
            "chgscopecnt": 1,
            "chgscopecntdetail": "[{\"projectName\":\"经营范围变更\",\"changeDate\":\"2026-05-01\",\"before\":\"旧经营范围\",\"after\":\"新经营范围\"}]",
            "chglegalrepcnt": 0, "chgequitycnt": 0,
            "revokecnt": 0, "capdecratio": 0.0, "capdeccnt": 0, "capinccnt": 0,
            "paidcapratio": 100.0, "regcap": 5000.0, "paidcap": 5000.0,
            "estabdate": "2010-01-01", "taxcreditgrade": "A",
            "majorshareholderkeynos": "", "majorinvestedcompanykeynos": "",
            "relatedent3mcancelrevokecount": 0,
        },
        "BHJC_006": {  # 注销记录 → 高风险(红色预警)
            "Status": "注销",
            "RevokeInfo": {
                "CancelDate": "2026-04-25",
                "CancelReason": "股东会决议注销",
                "RevokeDate": "",
                "RevokeReason": ""
            },
            "revokecnt": 1,
            "revokecntdetail": "[{\"cancelDate\":\"2026-04-25\",\"cancelReason\":\"股东会决议注销\"}]",
            "chglegalrepcnt": 0, "chgequitycnt": 0, "chgscopecnt": 0,
            "capdecratio": 0.0, "capdeccnt": 0, "capinccnt": 0,
            "paidcapratio": 100.0, "regcap": 5000.0, "paidcap": 5000.0,
            "estabdate": "2010-01-01", "taxcreditgrade": "A",
            "majorshareholderkeynos": "", "majorinvestedcompanykeynos": "",
            "relatedent3mcancelrevokecount": 0,
        },
        "BHJC_007": {  # 减资60% → 高风险(红色预警)
            "RegistCapi": "2000万元",
            "RegisteredCapital": "2000",
            "ChangeList": [{
                "ProjectName": "注册资本变更",
                "ChangeDate": "2026-05-01",
                "BeforeList": ["5000万元"],
                "AfterList": ["2000万元"],
                "ChangeSubject": "工商变更"
            }],
            "capdecratio": 0.6, "capdeccnt": 1, "capinccnt": 0,
            "chglegalrepcnt": 0, "chgequitycnt": 0, "chgscopecnt": 0,
            "revokecnt": 0,
            "paidcapratio": 100.0, "regcap": 2000.0, "paidcap": 5000.0,
            "estabdate": "2010-01-01", "taxcreditgrade": "A",
            "majorshareholderkeynos": "", "majorinvestedcompanykeynos": "",
            "relatedent3mcancelrevokecount": 0,
        },
        "BHJC_008": {  # 减资50% → 高风险(红色预警)
            "RegistCapi": "2500万元",
            "RegisteredCapital": "2500",
            "ChangeList": [{
                "ProjectName": "注册资本变更",
                "ChangeDate": "2026-05-01",
                "BeforeList": ["5000万元"],
                "AfterList": ["2500万元"],
                "ChangeSubject": "工商变更"
            }],
            "capdecratio": 0.5, "capdeccnt": 1, "capinccnt": 0,
            "chglegalrepcnt": 0, "chgequitycnt": 0, "chgscopecnt": 0,
            "revokecnt": 0,
            "paidcapratio": 100.0, "regcap": 2500.0, "paidcap": 5000.0,
            "estabdate": "2010-01-01", "taxcreditgrade": "A",
            "majorshareholderkeynos": "", "majorinvestedcompanykeynos": "",
            "relatedent3mcancelrevokecount": 0,
        },
        "BHJC_009": {  # 减资35% → 中风险(蓝色预警)
            "RegistCapi": "3250万元",
            "RegisteredCapital": "3250",
            "ChangeList": [{
                "ProjectName": "注册资本变更",
                "ChangeDate": "2026-05-01",
                "BeforeList": ["5000万元"],
                "AfterList": ["3250万元"],
                "ChangeSubject": "工商变更"
            }],
            "capdecratio": 0.35, "capdeccnt": 1, "capinccnt": 0,
            "chglegalrepcnt": 0, "chgequitycnt": 0, "chgscopecnt": 0,
            "revokecnt": 0,
            "paidcapratio": 100.0, "regcap": 3250.0, "paidcap": 5000.0,
            "estabdate": "2010-01-01", "taxcreditgrade": "A",
            "majorshareholderkeynos": "", "majorinvestedcompanykeynos": "",
            "relatedent3mcancelrevokecount": 0,
        },
        "BHJC_010": {  # 减资30% → 中风险(蓝色预警)
            "RegistCapi": "3500万元",
            "RegisteredCapital": "3500",
            "ChangeList": [{
                "ProjectName": "注册资本变更",
                "ChangeDate": "2026-05-01",
                "BeforeList": ["5000万元"],
                "AfterList": ["3500万元"],
                "ChangeSubject": "工商变更"
            }],
            "capdecratio": 0.3, "capdeccnt": 1, "capinccnt": 0,
            "chglegalrepcnt": 0, "chgequitycnt": 0, "chgscopecnt": 0,
            "revokecnt": 0,
            "paidcapratio": 100.0, "regcap": 3500.0, "paidcap": 5000.0,
            "estabdate": "2010-01-01", "taxcreditgrade": "A",
            "majorshareholderkeynos": "", "majorinvestedcompanykeynos": "",
            "relatedent3mcancelrevokecount": 0,
        },
    }

    # 获取场景配置（未定义的用 BASE）
    scenario_overrides = scenarios.get(scenario_key, {})

    # ===== KYC (2003) 接口 =====
    if "CustomerDueDiligence" in api_path or "KYC" in api_path:
        import copy
        kyc_data = copy.deepcopy(base_kyc)
        kyc_data["KeyNo"] = f"kyc_{search_key}"
        kyc_data["Name"] = f"测试企业_{search_key}"
        # 应用场景覆盖
        for k, v in scenario_overrides.items():
            if k in ("ChangeList",):
                kyc_data[k] = v  # 直接替换列表
            else:
                kyc_data[k] = v
        return {
            "Status": "200",
            "StatusCode": 200,
            "Message": "OK",
            "OrderNumber": f"MOCK_{search_key}",
            "Result": {
                "VerifyResult": 1,
                "Data": kyc_data
            }
        }

    # ===== 255 资质证书 =====
    if "ECICertification" in api_path:
        return {
            "Status": "200",
            "OrderNumber": f"MOCK_{search_key}",
            "Paging": {"PageSize": 20, "PageIndex": 1, "TotalRecords": 0},
            "Result": []
        }

    # ===== 980 清算核查（非分页，GetDetail） =====
    if "LiquidationCheck" in api_path:
        return {
            "Status": "200",
            "Message": "OK",
            "OrderNumber": f"MOCK_{search_key}",
            "Result": {
                "VerifyResult": 0,
                "Data": {}
            }
        }

    # ===== 958 招投标（keyword 而非 searchKey） =====
    if "TenderCheck" in api_path:
        return {
            "Status": "200",
            "Message": "OK",
            "OrderNumber": f"MOCK_{search_key}",
            "Paging": {"PageSize": 20, "PageIndex": 1, "TotalRecords": 0},
            "Result": {
                "VerifyResult": 0,
                "Data": []
            }
        }

    # ===== 场景级测试数据（非KYC接口）=====
    # 每个场景为不同接口提供数据，基准场景(BHJC_BASE)全部为空
    scenario_extra = {
        "BHJC_002": {  # 法人变更场景 → 综合风险数据
            "ShixinCheck": [
                {"Id":"sx001","Liandate":"2026-05-20","Anno":"（2026）京1001执5001号","Executegov":"北京市朝阳区人民法院","Executestatus":"全部未履行","Publicdate":"2026-05-20","Executeno":"（2026）京1001民初10001号","ActionRemark":"有履行能力而拒不履行","Amount":"500000"},
                {"Id":"sx002","Liandate":"2026-05-10","Anno":"（2026）京1002执5002号","Executegov":"上海市浦东新区人民法院","Executestatus":"部分未履行","Publicdate":"2026-05-10","Executeno":"（2026）京1002民初10002号","ActionRemark":"有履行能力而拒不履行","Amount":"300000"},
                {"Id":"sx003","Liandate":"2026-04-28","Anno":"（2026）粤0101执5003号","Executegov":"广州市中级人民法院","Executestatus":"全部未履行","Publicdate":"2026-04-28","Executeno":"（2026）粤0101民初10003号","ActionRemark":"有履行能力而拒不履行","Amount":"800000"},
            ],
            "ZhixingCheck": [
                {"Id":"zx001","Liandate":"2026-05-18","Anno":"（2026）京1001执7001号","ExecuteGov":"北京市朝阳区人民法院","Biaodi":"450000","SuspectedApplicant":"供应商甲"},
                {"Id":"zx002","Liandate":"2026-05-08","Anno":"（2026）沪0101执7002号","ExecuteGov":"上海市浦东新区人民法院","Biaodi":"280000","SuspectedApplicant":"供应商乙"},
            ],
            "SumptuaryCheck": [
                {"Id":"sm001","CaseNo":"（2026）京1001执限1号","PersonName":"张三","PersonId":"110101199001011234","JudgeDate":"2026-05-22","PublishDate":"2026-05-22","KeyNo":"kyc_BHJC_002","CompanyName":"测试企业_BHJC_002","Applicant":"债权人甲","ApplicantNo":"an001","Amount":"500000","ExecuteCourt":"北京市朝阳区人民法院"},
            ],
            "EndExecuteCaseCheck": [
                {"Id":"ec001","CaseNo":"（2026）京1001执终3001号","Court":"北京市朝阳区人民法院","EndDate":"2026-05-15","LianDate":"2026-04-01","ExecuteSubject":"1200000","UnperformedAmt":"900000"},
            ],
            "JudgmentDocCheck": [
                {"Id":"jd001","CaseName":"借款合同纠纷","CaseReason":"借款合同纠纷","CaseNo":"（2026）京1001民初8001号","Amount":"800000","JudgeDate":"2026-05-25","PublishDate":"2026-05-25","PartyList":[{"Name":"原告银行A","RoleType":"原告","Statement":"","Keyno":"p01"},{"Name":"测试企业_BHJC_002","RoleType":"被告","Statement":"","Keyno":"d01"}],"CaseType":"ms"},
                {"Id":"jd002","CaseName":"民间借贷纠纷","CaseReason":"民间借贷纠纷","CaseNo":"（2026）沪0101民初8002号","Amount":"350000","JudgeDate":"2026-05-12","PublishDate":"2026-05-12","PartyList":[{"Name":"原告B","RoleType":"原告","Statement":"","Keyno":"p02"},{"Name":"测试企业_BHJC_002","RoleType":"被告","Statement":"","Keyno":"d02"}],"CaseType":"ms"},
            ],
            "AdminPenaltyCheck": [
                {"Id":"ap001","DocNo":"京市监罚〔2026〕第501号","PunishReason":"虚假宣传","PunishResult":"罚款50000元","PunishOffice":"北京市市场监督管理局","PunishDate":"2026-05-20","Source":"机关","SourceCode":"","PunishAmt":"50000"},
            ],
        },
        "BHJC_004": {  # 股权变更场景
            "ShixinCheck": [
                {"Id":"sx004","Liandate":"2026-05-15","Anno":"（2026）京1001执6001号","Executegov":"北京市海淀区人民法院","Executestatus":"全部未履行","Publicdate":"2026-05-15","Executeno":"（2026）京1001民初11001号","ActionRemark":"有履行能力而拒不履行","Amount":"400000"},
                {"Id":"sx005","Liandate":"2026-05-05","Anno":"（2026）沪0101执6002号","Executegov":"上海市黄浦区人民法院","Executestatus":"全部未履行","Publicdate":"2026-05-05","Executeno":"（2026）沪0101民初11002号","ActionRemark":"有履行能力而拒不履行","Amount":"600000"},
            ],
            "EquityPledgedCheck": [
                {"Id":"eq001","RegistNo":"股质登记字〔2026〕第201号","PledgorName":"原股东A","PledgeeName":"某银行","RegDate":"2026-05-10","Status":"有效","RelatedCompanyName":"测试企业_BHJC_004","PledgedAmount":"200万股","PledgeeList":[{"Name":"某银行","KeyNo":"kp01"}],"PledgorList":[{"Name":"原股东A","KeyNo":"kq01"}]},
            ],
            "EquityFreezeCheck": [
                {"Id":"ef001","ExecuteName":"原股东B","ExecuteKeyNo":"ek01","EquityAmount":"150万元人民币","ExecuteCourt":"北京市海淀区人民法院","ExecutionNoticeNum":"（2026）海法执字第201号","Status":"股权冻结|冻结","FreezeStartDate":"2026-05-01","FreezeEndDate":"2028-04-30","RelatedInfo":{"KeyNo":"ri01","Name":"测试企业_BHJC_004"}},
            ],
            "ZhixingCheck": [
                {"Id":"zx003","Liandate":"2026-05-12","Anno":"（2026）京1002执7003号","ExecuteGov":"北京市西城区人民法院","Biaodi":"350000","SuspectedApplicant":"供应商丙"},
            ],
        },
        "BHJC_006": {  # 注销场景 → 多项高风险数据
            "ShixinCheck": [
                {"Id":"sx006","Liandate":"2026-04-20","Anno":"（2026）京1001执9001号","Executegov":"北京市朝阳区人民法院","Executestatus":"全部未履行","Publicdate":"2026-04-20","Executeno":"（2026）京1001民初20001号","ActionRemark":"有履行能力而拒不履行","Amount":"1200000"},
            ],
            "ZhixingCheck": [
                {"Id":"zx004","Liandate":"2026-04-18","Anno":"（2026）京1001执9002号","ExecuteGov":"北京市朝阳区人民法院","Biaodi":"950000","SuspectedApplicant":"债权人丁"},
            ],
            "BankruptcyCheck": [
                {"Id":"bk001","CaseNo":"（2026）京01破申1号","PublicDate":"2026-04-10","ApplicantList":[{"Name":"债权人甲","KeyNo":"ap01"}],"RespondentList":[{"Name":"测试企业_BHJC_006","KeyNo":"rd01"}]},
            ],
            "EndExecuteCaseCheck": [
                {"Id":"ec002","CaseNo":"（2026）京1001执终9001号","Court":"北京市朝阳区人民法院","EndDate":"2026-04-15","LianDate":"2026-03-01","ExecuteSubject":"2000000","UnperformedAmt":"1800000"},
                {"Id":"ec003","CaseNo":"（2026）沪0101执终9002号","Court":"上海市浦东新区人民法院","EndDate":"2026-04-20","LianDate":"2026-03-15","ExecuteSubject":"1500000","UnperformedAmt":"1200000"},
            ],
        },
        "BHJC_007": {  # 减资60%场景
            "EquityPledgedCheck": [
                {"Id":"eq002","RegistNo":"股质登记字〔2026〕第301号","PledgorName":"股东A","PledgeeName":"某信托公司","RegDate":"2026-05-08","Status":"有效","RelatedCompanyName":"测试企业_BHJC_007","PledgedAmount":"500万股","PledgeeList":[{"Name":"某信托公司","KeyNo":"kp02"}],"PledgorList":[{"Name":"股东A","KeyNo":"kq02"}]},
            ],
            "TaxOweNoticeCheck": [
                {"Id":"to001","TaxNo":"tax001","TaxPayerName":"测试企业_BHJC_007","Amount":"250000","TaxType":"增值税","PublishDate":"2026-05-15","TaxOrg":"北京市朝阳区税务局"},
            ],
        },
        "BHJC_008": {  # 减资50%场景
            "AdminPenaltyCheck": [
                {"Id":"ap002","DocNo":"京市监罚〔2026〕第601号","PunishReason":"未按规定公示信息","PunishResult":"罚款30000元","PunishOffice":"北京市市场监督管理局","PunishDate":"2026-05-10","Source":"机关","SourceCode":"","PunishAmt":"30000"},
                {"Id":"ap003","DocNo":"京环保罚〔2026〕第602号","PunishReason":"超标排放","PunishResult":"罚款80000元","PunishOffice":"北京市生态环境局","PunishDate":"2026-05-18","Source":"机关","SourceCode":"","PunishAmt":"80000"},
            ],
            "ExceptionCheck": [
                {"AddReason":"通过登记的住所或经营场所无法联系","AddDate":"2026-05-01","RomoveReason":"","RemoveDate":"","DecisionOffice":"北京市海淀区市场监督管理局","RemoveDecisionOffice":""},
            ],
        },
    }

    # 查找当前场景 + 接口的数据
    scene_data = scenario_extra.get(scenario_key, {})
    for api_key, records in scene_data.items():
        if api_key in api_path:
            return {
                "Status": "200",
                "Message": "OK",
                "OrderNumber": f"MOCK_{search_key}",
                "Paging": {"PageSize": 20, "PageIndex": 1, "TotalRecords": len(records)},
                "Result": {
                    "VerifyResult": 1 if records else 0,
                    "Data": records
                }
            }

    # ===== 所有其他分页接口：返回空数据 =====
    return {
        "Status": "200",
        "Message": "OK",
        "OrderNumber": f"MOCK_{search_key}",
        "Paging": {"PageSize": 20, "PageIndex": 1, "TotalRecords": 0},
        "Result": {
            "VerifyResult": 0,
            "Data": []
        }
    }


def _get_test_scenario_response(search_key, api_path, api_code=None):
    response = _build_test_scenario_response(search_key, api_path, api_code=api_code)
    if response is None or response.get("Status") != "200":
        return response
    identity = parse_scenario_key(search_key)
    return finalize_scenario_response(response, identity)


def mock_handler(api_code, extra_params=None):
    """
    通用 Mock 响应处理器
    优先检查测试场景，然后从 mock-files 目录读取预置文件，未命中则返回错误提示。
    """
    search_key = request.args.get("searchKey", request.args.get("keyword", "")).strip()
    if not search_key:
        return jsonify({
            "Status": "203",
            "Message": "【有效请求】参数异常：缺少 searchKey 参数",
            "OrderNumber": _gen_order_number(),
        })

    # 从 request.path 获取 API 路径（去掉开头的 /）
    api_path = request.path.lstrip("/")

    # 优先检查测试场景
    scenario_resp = _get_test_scenario_response(search_key, api_path, api_code=api_code)
    if scenario_resp is not None:
        print(f"  [测试场景] searchKey={search_key}, api={api_path} -> 场景数据")
        return jsonify(scenario_resp)

    # 从预置文件加载
    full_response = load_mock_file(api_path, search_key, api_code)

    if full_response is None:
        # 未命中预置文件，返回错误提示
        return jsonify({
            "Status": "201",
            "Message": f"【有效请求】未找到 searchKey=\"{search_key}\" 的预置 Mock 数据。请在 mock-files/{api_path}/ 下添加 {search_key}.json 文件，或运行 generate_mock_files.py 重新生成。",
            "OrderNumber": _gen_order_number(),
        })

    # 分页接口做运行时切片
    config = MOCK_DATA_REGISTRY.get(str(api_code))
    if config and config["paginated"]:
        page_index, page_size = parse_pagination()
        if page_size is None:
            return jsonify({
                "Status": "203",
                "Message": "【有效请求】参数异常：缺少 pageSize 参数",
                "OrderNumber": _gen_order_number(),
            })
        result = apply_pagination(full_response, page_index, page_size)
    else:
        result = full_response

    return jsonify(result)


# ======================== API 路由 ========================

# --- API 2003: 客户身份识别 (KYC) ---
@app.route("/CustomerDueDiligence/KYC", methods=["GET"])
@auth_required
def kyc():
    """客户身份识别"""
    search_key = request.args.get("searchKey", "").strip()
    if not search_key:
        return jsonify({
            "Status": "203",
            "Message": "【有效请求】参数异常：缺少 searchKey 参数",
            "OrderNumber": _gen_order_number("ENTERPRISEINFO"),
        })

    # 优先检查测试场景
    api_path = "CustomerDueDiligence/KYC"
    scenario_resp = _get_test_scenario_response(search_key, api_path, api_code="2003")
    if scenario_resp is not None:
        print(f"  [测试场景] searchKey={search_key}, api=KYC -> 场景数据")
        return jsonify(scenario_resp)

    result = load_mock_file("CustomerDueDiligence/KYC", search_key, "2003")
    if result is None:
        return jsonify({
            "Status": "201",
            "Message": f"【有效请求】未找到 searchKey=\"{search_key}\" 的预置 Mock 数据。请在 mock-files/CustomerDueDiligence/KYC/ 下添加 {search_key}.json 文件。",
            "OrderNumber": _gen_order_number("ENTERPRISEINFO"),
        })
    if isinstance(result, dict) and "StatusCode" not in result:
        result["StatusCode"] = 200
    return jsonify(result)


# --- API 255: 资质证书 ---
@app.route("/ECICertification/SearchCertification", methods=["GET"])
@auth_required
def certification():
    """资质证书"""
    return mock_handler("255")


# --- API 739: 经营异常核查 ---
@app.route("/ExceptionCheck/GetList", methods=["GET"])
@auth_required
def exception_check():
    """经营异常核查"""
    return mock_handler("739")


# --- API 740: 失信核查 ---
@app.route("/ShixinCheck/GetList", methods=["GET"])
@auth_required
def shixin_check():
    """失信核查"""
    return mock_handler("740")


# --- API 741: 被执行人核查 ---
@app.route("/ZhixingCheck/GetList", methods=["GET"])
@auth_required
def zhixing_check():
    """被执行人核查"""
    return mock_handler("741")


# --- API 742: 限制高消费核查 ---
@app.route("/SumptuaryCheck/GetList", methods=["GET"])
@auth_required
def sumptuary_check():
    """限制高消费核查"""
    return mock_handler("742")


# --- API 744: 司法拍卖核查 ---
@app.route("/JudicialSaleCheck/GetList", methods=["GET"])
@auth_required
def judicial_sale_check():
    """司法拍卖核查"""
    return mock_handler("744")


# --- API 746: 环保处罚核查 ---
@app.route("/EnvPunishmentCheck/GetList", methods=["GET"])
@auth_required
def env_punishment_check():
    """环保处罚核查"""
    return mock_handler("746")


# --- API 748: 严重违法核查 ---
@app.route("/SeriousIllegalCheck/GetList", methods=["GET"])
@auth_required
def serious_illegal_check():
    """严重违法核查"""
    return mock_handler("748")


# --- API 751: 股权出质核查 ---
@app.route("/EquityPledgedCheck/GetList", methods=["GET"])
@auth_required
def equity_pledged_check():
    """股权出质核查"""
    return mock_handler("751")


# --- API 752: 股权冻结核查 ---
@app.route("/EquityFreezeCheck/GetList", methods=["GET"])
@auth_required
def equity_freeze_check():
    """股权冻结核查"""
    return mock_handler("752")


# --- API 756: 税收违法核查 ---
@app.route("/TaxIllegalCheck/GetList", methods=["GET"])
@auth_required
def tax_illegal_check():
    """税收违法核查"""
    return mock_handler("756")


# --- API 757: 欠税公告核查 ---
@app.route("/TaxOweNoticeCheck/GetList", methods=["GET"])
@auth_required
def tax_owe_notice_check():
    """欠税公告核查"""
    return mock_handler("757")


# --- API 758: 终本案件核查 ---
@app.route("/EndExecuteCaseCheck/GetList", methods=["GET"])
@app.route("/TerminatedCaseCheck/GetList", methods=["GET"])
@auth_required
def end_execute_case_check():
    """终本案件核查"""
    return mock_handler("758")


# --- API 761: 破产重整核查 ---
@app.route("/BankruptcyCheck/GetList", methods=["GET"])
@auth_required
def bankruptcy_check():
    """破产重整核查"""
    return mock_handler("761")


# --- API 764: 失信被执行核查【董监高】 ---
@app.route("/PersonSXCheck/GetList", methods=["GET"])
@auth_required
def person_sx_check():
    """失信被执行核查【董监高】"""
    person_name = request.args.get("personName", "")
    if not person_name:
        return jsonify({
            "Status": "203",
            "Message": "【有效请求】参数异常：缺少 personName 参数",
            "OrderNumber": _gen_order_number("PERSONSXCHECK"),
        })
    return mock_handler("764")


# --- API 765: 被执行人核查【董监高】 ---
@app.route("/PersonZXCheck/GetList", methods=["GET"])
@auth_required
def person_zx_check():
    """被执行人核查【董监高】"""
    person_name = request.args.get("personName", "")
    if not person_name:
        return jsonify({
            "Status": "203",
            "Message": "【有效请求】参数异常：缺少 personName 参数",
            "OrderNumber": _gen_order_number("PERSONZXCHECK"),
        })
    return mock_handler("765")


# --- API 766: 限制高消费核查【董监高】 ---
@app.route("/PersonSumptuaryCheck/GetList", methods=["GET"])
@auth_required
def person_sumptuary_check():
    """限制高消费核查【董监高】"""
    person_name = request.args.get("personName", "")
    if not person_name:
        return jsonify({
            "Status": "203",
            "Message": "【有效请求】参数异常：缺少 personName 参数",
            "OrderNumber": _gen_order_number("PERSONSUMPTUARYCHECK"),
        })
    return mock_handler("766")


# --- API 767: 股权冻结核查【董监高】 ---
@app.route("/PersonSEFreezeCheck/GetList", methods=["GET"])
@auth_required
def person_freeze_check():
    """股权冻结核查【董监高】"""
    person_name = request.args.get("personName", "")
    if not person_name:
        return jsonify({
            "Status": "203",
            "Message": "【有效请求】参数异常：缺少 personName 参数",
            "OrderNumber": _gen_order_number("PERSONSEFREEZECHECK"),
        })
    return mock_handler("767")


# --- API 768: 股权出质核查【董监高】 ---
@app.route("/PersonSEPledgedCheck/GetList", methods=["GET"])
@auth_required
def person_pledged_check():
    """股权出质核查【董监高】"""
    person_name = request.args.get("personName", "")
    if not person_name:
        return jsonify({
            "Status": "203",
            "Message": "【有效请求】参数异常：缺少 personName 参数",
            "OrderNumber": _gen_order_number("PERSONSEPLEDGEDCHECK"),
        })
    return mock_handler("768")


# --- API 771: 终本案件核查【董监高】 ---
@app.route("/PersonEndExCaseCheck/GetList", methods=["GET"])
@app.route("/PersonTerminatedCaseCheck/GetList", methods=["GET"])
@auth_required
def person_end_ex_check():
    """终本案件核查【董监高】"""
    person_name = request.args.get("personName", "")
    if not person_name:
        return jsonify({
            "Status": "203",
            "Message": "【有效请求】参数异常：缺少 personName 参数",
            "OrderNumber": _gen_order_number("PERSONENDEXCASECHECK"),
        })
    return mock_handler("771")


# --- API 865: 行政处罚核查 ---
@app.route("/AdminPenaltyCheck/GetList", methods=["GET"])
@auth_required
def admin_penalty_check():
    """行政处罚核查"""
    return mock_handler("865")


# --- API 882: 法院公告核查 ---
@app.route("/CourtNoticeCheck/GetList", methods=["GET"])
@auth_required
def court_notice_check():
    """法院公告核查"""
    return mock_handler("882")


# --- API 887: 裁判文书核查 ---
@app.route("/JudgmentDocCheck/GetList", methods=["GET"])
@auth_required
def judgment_doc_check():
    """裁判文书核查"""
    return mock_handler("887")


# --- API 888: 开庭公告核查 ---
@app.route("/CourtAnnoCheck/GetList", methods=["GET"])
@auth_required
def court_anno_check():
    """开庭公告核查"""
    return mock_handler("888")


# --- API 958: 招投标信息 ---
@app.route("/TenderCheck/GetList", methods=["GET"])
@auth_required
def tender_check():
    """招投标信息"""
    keyword = request.args.get("keyword", "").strip()
    if not keyword:
        return jsonify({
            "Status": "203",
            "Message": "【有效请求】参数异常：缺少 keyword 参数",
            "OrderNumber": _gen_order_number("TENDERCHECK"),
        })

    # 优先检查测试场景
    api_path = "TenderCheck/GetList"
    scenario_resp = _get_test_scenario_response(keyword, api_path, api_code="958")
    if scenario_resp is not None:
        print(f"  [测试场景] keyword={keyword}, api=958招投标 -> 场景数据")
        return jsonify(scenario_resp)

    return mock_handler("958")


# --- API 980: 清算核查 ---
@app.route("/LiquidationCheck/GetDetail", methods=["GET"])
@auth_required
def liquidation_check():
    """清算核查"""
    search_key = request.args.get("searchKey", "").strip()
    if not search_key:
        return jsonify({
            "Status": "203",
            "Message": "【有效请求】参数异常：缺少 searchKey 参数",
            "OrderNumber": _gen_order_number("LIQUIDATIONCHECK"),
        })

    # 优先检查测试场景
    api_path = "LiquidationCheck/GetDetail"
    scenario_resp = _get_test_scenario_response(search_key, api_path, api_code="980")
    if scenario_resp is not None:
        print(f"  [测试场景] searchKey={search_key}, api=980清算 -> 场景数据")
        return jsonify(scenario_resp)

    result = load_mock_file("LiquidationCheck/GetDetail", search_key, "980")
    if result is None:
        return jsonify({
            "Status": "201",
            "Message": f"【有效请求】未找到 searchKey=\"{search_key}\" 的预置 Mock 数据。请在 mock-files/LiquidationCheck/GetDetail/ 下添加 {search_key}.json 文件。",
            "OrderNumber": _gen_order_number("LIQUIDATIONCHECK"),
        })
    return jsonify(result)


# ======================== 管理端点 ========================

@app.route("/", methods=["GET"])
def index():
    """Mock 服务首页 - 接口列表"""
    api_list = []
    routes = {
        "2003": ("/CustomerDueDiligence/KYC", "客户身份识别", "GET", "searchKey"),
        "255": ("/ECICertification/SearchCertification", "资质证书", "GET", "searchKey, pageIndex, pageSize, isValid"),
        "739": ("/ExceptionCheck/GetList", "经营异常核查", "GET", "searchKey"),
        "740": ("/ShixinCheck/GetList", "失信核查", "GET", "searchKey, pageIndex, pageSize"),
        "741": ("/ZhixingCheck/GetList", "被执行人核查", "GET", "searchKey, pageIndex, pageSize"),
        "742": ("/SumptuaryCheck/GetList", "限制高消费核查", "GET", "searchKey, pageIndex, pageSize"),
        "744": ("/JudicialSaleCheck/GetList", "司法拍卖核查", "GET", "searchKey, pageIndex, pageSize"),
        "746": ("/EnvPunishmentCheck/GetList", "环保处罚核查", "GET", "searchKey, pageIndex, pageSize"),
        "748": ("/SeriousIllegalCheck/GetList", "严重违法核查", "GET", "searchKey"),
        "751": ("/EquityPledgedCheck/GetList", "股权出质核查", "GET", "searchKey, pageIndex, pageSize"),
        "752": ("/EquityFreezeCheck/GetList", "股权冻结核查", "GET", "searchKey, pageIndex, pageSize"),
        "756": ("/TaxIllegalCheck/GetList", "税收违法核查", "GET", "searchKey, pageIndex, pageSize"),
        "757": ("/TaxOweNoticeCheck/GetList", "欠税公告核查", "GET", "searchKey, pageIndex, pageSize"),
        "758": ("/TerminatedCaseCheck/GetList", "终本案件核查", "GET", "searchKey, pageIndex, pageSize"),
        "761": ("/BankruptcyCheck/GetList", "破产重整核查", "GET", "searchKey, pageIndex, pageSize"),
        "764": ("/PersonSXCheck/GetList", "失信被执行核查【董监高】", "GET", "searchKey, personName, pageIndex, pageSize"),
        "765": ("/PersonZXCheck/GetList", "被执行人核查【董监高】", "GET", "searchKey, personName, pageIndex, pageSize"),
        "766": ("/PersonSumptuaryCheck/GetList", "限制高消费核查【董监高】", "GET", "searchKey, personName, pageIndex, pageSize"),
        "767": ("/PersonSEFreezeCheck/GetList", "股权冻结核查【董监高】", "GET", "searchKey, personName, pageIndex, pageSize"),
        "768": ("/PersonSEPledgedCheck/GetList", "股权出质核查【董监高】", "GET", "searchKey, personName, pageIndex, pageSize"),
        "771": ("/PersonTerminatedCaseCheck/GetList", "终本案件核查【董监高】", "GET", "searchKey, personName, pageIndex, pageSize"),
        "865": ("/AdminPenaltyCheck/GetList", "行政处罚核查", "GET", "searchKey, pageIndex, pageSize"),
        "882": ("/CourtNoticeCheck/GetList", "法院公告核查", "GET", "searchKey, pageIndex, pageSize"),
        "887": ("/JudgmentDocCheck/GetList", "裁判文书核查", "GET", "searchKey, pubYear, caseIdentity, caseStatus, keyWord, pageIndex, pageSize"),
        "888": ("/CourtAnnoCheck/GetList", "开庭公告核查", "GET", "searchKey, caseIdentity, pageIndex, pageSize"),
        "958": ("/TenderCheck/GetList", "招投标信息", "GET", "keyword, areaCode, msgType, pubDateStart, pubDateEnd, pageIndex, pageSize"),
        "980": ("/LiquidationCheck/GetDetail", "清算核查", "GET", "searchKey"),
    }
    for code, (path, name, method, params) in routes.items():
        # 扫描 mock-files 下该接口的可用 searchKey
        api_mock_dir = os.path.join(MOCK_FILES_DIR, path.lstrip("/"))
        available_keys = []
        if os.path.isdir(api_mock_dir):
            available_keys = sorted(
                f.replace(".json", "")
                for f in os.listdir(api_mock_dir)
                if f.endswith(".json")
            )

        first_key = available_keys[0] if available_keys else "测试公司A"
        # 招投标接口用 keyword 而非 searchKey
        key_param = "keyword" if code == "958" else "searchKey"
        example = f"http://localhost:{PORT}{path}?key=MOCK_APP_KEY&{key_param}={first_key}"

        api_list.append({
            "code": code,
            "name": name,
            "path": path,
            "method": method,
            "params": params,
            "paginated": MOCK_DATA_REGISTRY.get(code, {}).get("paginated", False),
            "available_search_keys": available_keys,
            "example": example,
        })
    return jsonify({
        "service": "企查查 Mock 服务",
        "version": SERVICE_VERSION,
        "total_apis": len(api_list),
        "auth_enabled": AUTH_ENABLED,
        "strict_scenario_keys": STRICT_SCENARIO_KEYS,
        "scenario_key_format": "BHJC_<SCENARIO>__<runId>__<caseId>",
        "apis": api_list,
    })


@app.route("/health", methods=["GET"])
def health():
    """健康检查"""
    return jsonify({
        "status": "ok",
        "version": SERVICE_VERSION,
        "timestamp": int(time.time()),
        "authEnabled": AUTH_ENABLED,
        "soapAuthEnabled": bool(SOAP_AUTH_TOKEN),
        "strictScenarioKeys": STRICT_SCENARIO_KEYS,
        "referenceDate": REFERENCE_DATE.isoformat(),
        "scenarioCount": len(KNOWN_SCENARIO_KEYS) + len(SCENARIO_REGISTRY),
        "scenarioRegistryPath": SCENARIO_REGISTRY_PATH,
    })


# ======================== 请求日志 ========================

@app.before_request
def log_request():
    """打印每个请求的日志"""
    params = dict(request.args)
    print(f"[{time.strftime('%H:%M:%S')}] {request.method} {request.path} | params: {json.dumps(params, ensure_ascii=False)}")


@app.after_request
def log_response(response):
    """打印响应状态"""
    if request.path != "/health":
        print(f"  -> {response.status_code} ({len(response.data)} bytes)")
    return response


# ======================== 征信报告 SOAP XML Mock ========================

# 企业征信报告 Mock SOAP XML 响应
# 字段名必须与 bridge 模块 ETL 处理器 (qyzxbghz) 的 outputConfig 完全匹配:
#   odloanacctcnt, badloanbal, attnloanacctcnt, odguaacctcnt,
#   badguabal, attnguaacctcnt, unpaidintbal, qyzxbgstatuscode
# 所有征信字段返回 0 值（无逾期、无不良、无欠息）
CREDIT_REPORT_SOAP_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <return>
      <retCode>1</retCode>
      <retInfo>查询成功</retInfo>
      <result>&lt;![CDATA[<Document>
  <basicInfo>
    <entName>{ent_name}</entName>
    <entCertNum>{ent_cert_num}</entCertNum>
  </basicInfo>
  <summaryInformation>
    <Crt2_C_CreaditPrompts>
      <badloanbal>0</badloanbal>
      <odloanacctcnt>0</odloanacctcnt>
      <attnloanacctcnt>0</attnloanacctcnt>
      <badguabal>0</badguabal>
      <odguaacctcnt>0</odguaacctcnt>
      <attnguaacctcnt>0</attnguaacctcnt>
    </Crt2_C_CreaditPrompts>
  </summaryInformation>
  <basicBorrowingList>
  </basicBorrowingList>
  <loanAccountInformation>
    <loanRepaymentList>
    </loanRepaymentList>
    <guaAccountInfo>
      <guaranteeList>
      </guaranteeList>
    </guaAccountInfo>
  </loanAccountInformation>
  <Crt2_C_LoanOutstanding>
    <unpaidintbal>0</unpaidintbal>
  </Crt2_C_LoanOutstanding>
  <qyzxbgstatuscode>0</qyzxbgstatuscode>
</Document>]]&gt;</result>
    </return>
  </soap:Body>
</soap:Envelope>"""


@app.route("/services/comSingleCacheQuery", methods=["POST"])
@app.route("/services/enterpriseCreditQueryTwoCode", methods=["POST"])
def credit_report_mock():
    """企业征信报告 Mock - 返回全 0 值的 SOAP XML 响应
    字段名已与 bridge 模块 qyzxbghz ETL 出参映射对齐:
    odloanacctcnt, badloanbal, attnloanacctcnt, odguaacctcnt,
    badguabal, attnguaacctcnt, unpaidintbal, qyzxbgstatuscode
    """
    if SOAP_AUTH_TOKEN and request.headers.get("X-Mock-Token") != SOAP_AUTH_TOKEN:
        from flask import Response
        return Response("unauthorized", mimetype="text/plain", status=401)

    # 尝试从请求体中提取企业名称和信用代码
    body = request.data.decode("utf-8", errors="replace")
    ent_name = "测试企业"
    ent_cert_num = "000000000000000000"

    # 简单的 XML 参数提取（兼容多种 SOAP 包装格式）
    import re
    for tag in ["entName", "EntName", "ENTNAME"]:
        m = re.search(rf"<{tag}>(.*?)</{tag}>", body, re.IGNORECASE)
        if m:
            ent_name = m.group(1)
            break
    for tag in ["entCertNum", "EntCertNum", "ENTCERTNUM"]:
        m = re.search(rf"<{tag}>(.*?)</{tag}>", body, re.IGNORECASE)
        if m:
            ent_cert_num = m.group(1)
            break

    # v3-merged: legacy ECGX 场景由 SOAP 体内显式 BHJC 键驱动（无 sticky 状态）
    soap_search_key = ""
    m_sk = re.search(r"<searchKey>(.*?)</searchKey>", body, re.IGNORECASE)
    if m_sk:
        soap_search_key = m_sk.group(1)
    candidate = soap_search_key or ent_name
    if str(candidate).startswith("BHJC_"):
        try:
            identity = parse_scenario_key(candidate)
        except ValueError:
            identity = None
        if identity is not None:
            soap_spec = (SCENARIO_REGISTRY.get(identity.template_key) or {}) \
                .get("responses", {}).get("SOAP", {})
            if soap_spec.get("provider") == "legacy_v46":
                from flask import Response
                from legacy_v46_adapter import build_credit_xml
                xml_response = build_credit_xml(
                    soap_spec.get("mode", "yellow"),
                    soap_spec.get("ruleCode"),
                    ent_name, ent_cert_num,
                )
                print(f"  [征信Mock] legacy ECGX 场景 {identity.template_key} -> 非零明细")
                return Response(xml_response, mimetype="text/xml", status=200)

    xml_response = CREDIT_REPORT_SOAP_TEMPLATE.format(
        ent_name=ent_name, ent_cert_num=ent_cert_num
    )

    # 打印请求体前 200 字符用于排查 SOAP 格式问题
    body_preview = body[:200].replace("\n", " ").replace("\r", "")
    print(f"  [征信Mock] entName={ent_name}, entCertNum={ent_cert_num} -> 全0值")
    print(f"  [征信Mock] 请求体预览: {body_preview}")

    from flask import Response
    return Response(xml_response, mimetype="text/xml", status=200)


# ======================== 启动 ========================

if __name__ == "__main__":
    print(f"""
╔══════════════════════════════════════════════════════════╗
║              企查查 Mock 服务 v2.0.0                     ║
╠══════════════════════════════════════════════════════════╣
║  端口:    {PORT:<45} ║
║  鉴权:    {'已开启' if AUTH_ENABLED else '已关闭（调试模式）':<45} ║
║  接口数:  27 个 API                                      ║
║  数据量:  每个分页接口 50 条 Mock 数据                     ║
╠══════════════════════════════════════════════════════════╣
║  首页:    http://localhost:{PORT}/                         ║
║  健康检查: http://localhost:{PORT}/health                   ║
╚══════════════════════════════════════════════════════════╝
""")
    debug_enabled = os.environ.get("QCC_MOCK_DEBUG", "false").lower() in {
        "1", "true", "yes", "on"
    }
    app.run(host=HOST, port=PORT, debug=debug_enabled)
