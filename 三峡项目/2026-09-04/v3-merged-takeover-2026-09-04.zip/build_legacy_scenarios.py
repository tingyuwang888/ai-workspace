# -*- coding: utf-8 -*-
"""生成 legacy_v46 场景合同并合并进 scenarios/registry.json。

规则：
- 仅对 contracts/rule-contracts.json 中 implementationStatus=scenario_payload_required
  且规则码存在于 legacy 显式映射的规则生成 HIT/MISS 场景；
- HIT 场景显式声明 mode=yellow + ruleCode，MISS 场景 mode=safe；
- ECGX 规则只声明 SOAP 响应；证书规则声明 255；ELDP10 声明 980；
- 不生成任何依赖 sticky/调用次数的场景；
- 保留 registry 中已有原生场景，重复运行幂等（先剔除 BHJC_LG_ 前缀旧条目）。
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import legacy_v46_adapter as AD  # noqa: E402

REGISTRY = os.path.join(HERE, "scenarios", "registry.json")
CONTRACTS = os.path.join(HERE, "contracts", "rule-contracts.json")

LIST_CODES = ["739", "740", "741", "742", "744", "746", "748", "751", "752",
              "756", "757", "758", "761", "764", "765", "766", "767", "768",
              "771", "865", "882", "887", "888", "958"]


def _spec(mode, rule_code):
    return {"provider": "legacy_v46", "mode": mode, "ruleCode": rule_code}


def build_scenario_responses(rule_code, mode):
    import legacy_v46_source as L
    responses = {"2003": _spec(mode, rule_code)}
    if rule_code.startswith("ECGX"):
        return {"SOAP": _spec(mode, rule_code)}
    if rule_code in AD.DISPLAY_RULE_CODES:
        return {AD.DISPLAY_RULE_CODES[rule_code]: _spec(mode, rule_code)}
    if rule_code in AD.CERT_RULE_CODES:
        responses["255"] = _spec(mode, rule_code)
        return responses
    if rule_code in AD.DETAIL_RULE_CODES:
        responses["980"] = _spec(mode, rule_code)
        return responses
    info = L.RULE_CODE_MAP.get(rule_code, {})
    for endpoint in sorted(info.get("endpoints", {})):
        responses[endpoint] = _spec(mode, rule_code)
    if mode == "yellow" and not info.get("endpoints") and not info.get("kyc"):
        # 映射存在但无 KYC/端点动作的规则：仅 KYC 安全基线，保持显式声明
        pass
    return responses


def main():
    contracts = json.load(open(CONTRACTS, encoding="utf-8"))
    registry = json.load(open(REGISTRY, encoding="utf-8"))
    scenarios = registry.get("scenarios", {})
    scenarios = {k: v for k, v in scenarios.items() if not k.startswith("BHJC_LG_")}

    legacy_codes = AD.legacy_rule_codes()
    native_templates = {k for k in scenarios if not k.startswith("BHJC_LG_")}
    generated = 0
    skipped = []
    for rule in contracts["rules"]:
        code = rule["ruleCode"]
        status = rule.get("implementationStatus")
        eligible = status == "scenario_payload_required" or (
            status == "ambiguous_rule_identity" and code in legacy_codes)
        has_native = any(
            k.endswith(f"_{code}_HIT") or k.endswith(f"_{code}_MISS")
            or k.endswith(f"_{code}_BOUNDARY")
            for k in native_templates
        )
        if not eligible or code not in legacy_codes or has_native:
            skipped.append(code)
            continue
        hit = f"BHJC_LG_{code}_HIT"
        miss = f"BHJC_LG_{code}_MISS"
        scenarios[hit] = {
            "description": f"legacy V46 兼容场景：{rule.get('ruleName', code)} 命中",
            "responses": build_scenario_responses(code, "yellow"),
        }
        scenarios[miss] = {
            "description": f"legacy V46 兼容场景：{rule.get('ruleName', code)} 未命中",
            "responses": build_scenario_responses(code, "safe"),
        }
        generated += 2

    # RED 全量回归场景（显式声明，不依赖 sticky）
    red_responses = {"2003": _spec("red", None), "255": _spec("red", None),
                     "980": _spec("red", None), "SOAP": _spec("red", None)}
    for code in LIST_CODES:
        red_responses[code] = _spec("red", None)
    scenarios["BHJC_LG_RED_ALERT"] = {
        "description": "legacy V46 RED 全量风险回归场景（显式声明）",
        "responses": red_responses,
    }

    registry["scenarios"] = scenarios
    with open(REGISTRY, "w", encoding="utf-8") as fh:
        json.dump(registry, fh, ensure_ascii=False, indent=2, sort_keys=True)
    print(f"registry scenarios: {len(scenarios)} (generated {generated}, "
          f"red_full 1, skipped rules {len(skipped)})")


if __name__ == "__main__":
    main()
