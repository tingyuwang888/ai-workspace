# -*- coding: utf-8 -*-
"""
补充跨页累积测试所需的 15 条 mock 文件。
缺失的 8 个接口：882/887/888（名称匹配）+ 764/765/766/771/767/768（董监高）
"""
import json, os

BASE_DIR = os.path.join(os.path.dirname(__file__), "mock-files")
COURTS = ["北京市朝阳区人民法院", "上海市浦东新区人民法院", "广州市中级人民法院"]

# 15 条近期日期（全部在90天内，降序排列，用于 earlyStop 接口）
RECENT_15 = [
    "2026-06-01","2026-05-28","2026-05-25","2026-05-22","2026-05-19",
    "2026-05-16","2026-05-13","2026-05-10","2026-05-07","2026-05-04",
    "2026-05-01","2026-04-28","2026-04-25","2026-04-22","2026-04-19",
]

def write(path_parts, data):
    d = os.path.join(BASE_DIR, *path_parts[:-1])
    os.makedirs(d, exist_ok=True)
    fp = os.path.join(d, path_parts[-1] + ".json")
    with open(fp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"  ✓ {'/'.join(path_parts)}")

def p15(data_arr, prefix, has_paging=True):
    base = {
        "Status": "200", "Message": "【有效请求】查询成功",
        "OrderNumber": f"{prefix}20260606",
    }
    if has_paging:
        base["Paging"] = {"PageSize": 10, "PageIndex": 1, "TotalRecords": len(data_arr)}
        base["Result"] = {"VerifyResult": 1, "Data": data_arr}
    else:
        base["Result"] = {"VerifyResult": 1, "Data": data_arr}
    return base


# ────────────────────────────────────────────────────────────────
# 882 法院公告核查 — 15条，公司作为借款纠纷被告，90天内
# 跨页场景：pageSize=5 → 3页，每页 5 条，累积 count=15
# ────────────────────────────────────────────────────────────────
LOAN_REASONS = ["借款合同纠纷","金融借款合同纠纷","民间借贷纠纷",
                "借款合同纠纷","融资租赁合同纠纷"]

cn882_15 = []
for i in range(15):
    cn882_15.append({
        "Id": f"cn882x{i:02d}",
        "CaseNo": f"（2026）京{1001+i%3}民初{70000+i}号",
        "CaseReason": LOAN_REASONS[i % 5],
        "Category": "起诉状、上诉状副本",
        "Court": COURTS[i % 3],
        "PublishDate": RECENT_15[i],
        "ProsecutorList": [{"KeyNo": f"px882{i:02d}", "Name": f"原告银行{i+1}"}],
        "DefendantList": [{"KeyNo": f"dx882{i:02d}", "Name": "15条涉贷被告公司"}],
        "RoleList": [
            {"RoleType": "0", "RoleName": "原告/上诉人",
             "RoleItemList": [{"KeyNo": f"px882{i:02d}", "Name": f"原告银行{i+1}"}]},
            {"RoleType": "1", "RoleName": "被告/被上诉人",
             "RoleItemList": [{"KeyNo": f"dx882{i:02d}", "Name": "15条涉贷被告公司"}]},
        ],
    })

write(["CourtNoticeCheck","GetList","15条涉贷被告公司"], p15(cn882_15, "COURTNOTICECHECK"))
# searchKey="15条涉贷被告公司"
# pageSize=5 → totalPage=3，每页5条均满足（借款案由+被告角色匹配+90天内）
# 期望：ent3mCourtNoticeLoanDisputeDefendantCntQcc=15（跨3页累积）


# ────────────────────────────────────────────────────────────────
# 887 裁判文书核查 — 15条，三类案件混合，跨页累积
# 分布：每组5条 = 借款被告2+原告1+保全1+无关1，共3组跨3页
# pageSize=5 → 3页，各页累积各类计数
# ────────────────────────────────────────────────────────────────
def make_887_batch(offset, sk):
    """生成一批5条: 2借款被告 + 1原告 + 1保全 + 1无关"""
    return [
        # 借款被告
        {"Id": f"jd887x{offset+0:02d}", "CaseName": f"某银行{offset}期借款纠纷",
         "CaseReason": "借款合同纠纷", "CaseNo": f"（2026）京01民初{90000+offset:05d}号",
         "Amount": "500000", "JudgeDate": RECENT_15[offset % 15],
         "PublishDate": RECENT_15[offset % 15],
         "PartyList": [
             {"Name": f"原告银行{offset}", "RoleType": "原告", "Statement": "", "Keyno": f"p{offset}1"},
             {"Name": sk, "RoleType": "被告", "Statement": "", "Keyno": f"d{offset}1"},
         ], "CaseType": "ms"},
        # 借款被告（第2条）
        {"Id": f"jd887x{offset+1:02d}", "CaseName": f"信用社{offset}期金融借款",
         "CaseReason": "金融借款合同纠纷", "CaseNo": f"（2026）京01民初{90001+offset:05d}号",
         "Amount": "300000", "JudgeDate": RECENT_15[(offset+1) % 15],
         "PublishDate": RECENT_15[(offset+1) % 15],
         "PartyList": [
             {"Name": f"信用社{offset}", "RoleType": "原告", "Statement": "", "Keyno": f"p{offset}2"},
             {"Name": sk, "RoleType": "被告", "Statement": "", "Keyno": f"d{offset}2"},
         ], "CaseType": "ms"},
        # 原告（自诉）
        {"Id": f"jd887x{offset+2:02d}", "CaseName": f"{sk}诉某供应商{offset}",
         "CaseReason": "买卖合同纠纷", "CaseNo": f"（2026）京01民初{90002+offset:05d}号",
         "Amount": "200000", "JudgeDate": RECENT_15[(offset+2) % 15],
         "PublishDate": RECENT_15[(offset+2) % 15],
         "PartyList": [
             {"Name": sk, "RoleType": "原告", "Statement": "胜诉", "Keyno": f"p{offset}3"},
             {"Name": f"某供应商{offset}", "RoleType": "被告", "Statement": "", "Keyno": f"d{offset}3"},
         ], "CaseType": "ms"},
        # 被保全
        {"Id": f"jd887x{offset+3:02d}", "CaseName": f"某银行{offset}申请财产保全",
         "CaseReason": "财产保全", "CaseNo": f"（2026）京01民初{90003+offset:05d}号",
         "Amount": "100000", "JudgeDate": RECENT_15[(offset+3) % 15],
         "PublishDate": RECENT_15[(offset+3) % 15],
         "PartyList": [
             {"Name": f"某银行{offset}", "RoleType": "原告", "Statement": "", "Keyno": f"p{offset}4"},
             {"Name": sk, "RoleType": "被告", "Statement": "", "Keyno": f"d{offset}4"},
         ], "CaseType": "bq"},
        # 无关（不计入任何类别）
        {"Id": f"jd887x{offset+4:02d}", "CaseName": f"劳动争议{offset}",
         "CaseReason": "劳动争议", "CaseNo": f"（2026）京01民初{90004+offset:05d}号",
         "Amount": "50000", "JudgeDate": RECENT_15[(offset+4) % 15],
         "PublishDate": RECENT_15[(offset+4) % 15],
         "PartyList": [
             {"Name": f"员工{offset}", "RoleType": "原告", "Statement": "", "Keyno": f"p{offset}5"},
             {"Name": sk, "RoleType": "被告", "Statement": "", "Keyno": f"d{offset}5"},
         ], "CaseType": "ms"},
    ]

jd887_15 = make_887_batch(0, "15条涉贷被告公司") + \
           make_887_batch(10, "15条涉贷被告公司") + \
           make_887_batch(20, "15条涉贷被告公司")

write(["JudgmentDocCheck","GetList","15条涉贷被告公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "JUDGMENTDOCCHECK20260606",
    "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 15},
    "Result": {"VerifyResult": 1, "Data": jd887_15}
})
# searchKey="15条涉贷被告公司"，pageSize=5 → 3页
# 每页5条：2借款被告+1原告+1保全+1无关
# 期望：loandisputecnt=6（每页2条×3页）/ defendamt=累积 / selfcnt=3 / preservcnt=3


# ────────────────────────────────────────────────────────────────
# 888 开庭公告核查 — 15条，借款被告+近期CourtTime
# pageSize=5 → 3页，累积 count
# ────────────────────────────────────────────────────────────────
ca888_15 = []
LOAN_REASONS_888 = ["借款合同纠纷","金融借款合同纠纷","民间借贷纠纷",
                    "借款合同纠纷","票据纠纷"]
for i in range(15):
    ca888_15.append({
        "Id": f"ca888x{i:02d}",
        "CaseNo": f"（2026）京{1001+i%3}民初{80000+i}号",
        "CaseReason": LOAN_REASONS_888[i % 5],
        "Court": COURTS[i % 3],
        "CourtTime": f"{RECENT_15[i]} 09:00:00",
        "PartyList": [
            {"Name": f"原告方{i+1}", "RoleType": "2", "Keyno": f"p888{i:02d}"},
            {"Name": "15条开庭被告公司", "RoleType": "1", "Keyno": f"d888{i:02d}"},
        ],
        "RoleList": [
            {"RoleType": "0", "RoleName": "原告",
             "RoleItemList": [{"KeyNo": f"p888{i:02d}", "Name": f"原告方{i+1}"}]},
            {"RoleType": "1", "RoleName": "被告",
             "RoleItemList": [{"KeyNo": f"d888{i:02d}", "Name": "15条开庭被告公司"}]},
        ],
    })

write(["CourtAnnoCheck","GetList","15条开庭被告公司"], p15(ca888_15, "COURTANNOCHECK"))
# searchKey="15条开庭被告公司"，pageSize=5 → 3页
# 期望：ent3mcourtannoloandisputedefendantcntqcc=15（跨3页累积）


# ────────────────────────────────────────────────────────────────
# 764 失信【董监高】 — 15条，Liandate 90天内
# ────────────────────────────────────────────────────────────────
ps764_15 = [
    {"Id": f"ps764x{i:02d}", "Liandate": RECENT_15[i],
     "Anno": f"（2026）京{1001+i%3}执{20000+i}号",
     "Executegov": COURTS[i % 3], "Executestatus": ["全部未履行","部分未履行"][i % 2],
     "Publicdate": RECENT_15[i], "Executeno": f"（2026）京{1001+i%3}民初{30000+i}号",
     "ActionRemark": "有履行能力而拒不履行", "Amount": str(100000*(i+1))}
    for i in range(15)
]
write(["PersonSXCheck","GetList","15条失信高管__personName=近期违规高管"], p15(ps764_15, "PERSONSXCHECK"))
# pageSize=5 → 3页，pdishonestcnt=15（跨3页累积）


# ────────────────────────────────────────────────────────────────
# 765 被执行人【董监高】 — 15条
# ────────────────────────────────────────────────────────────────
pz765_15 = [
    {"Id": f"pz765x{i:02d}", "Liandate": RECENT_15[i],
     "Anno": f"（2026）京{1001+i%3}执{40000+i}号",
     "ExecuteGov": COURTS[i % 3], "Biaodi": str(200000*(i+1)),
     "SuspectedApplicant": f"债权人{i+1}有限公司"}
    for i in range(15)
]
write(["PersonZXCheck","GetList","15条被执行高管__personName=近期违规高管"], p15(pz765_15, "PERSONZXCHECK"))
# pageSize=5 → 3页，pexecutedcnt=15


# ────────────────────────────────────────────────────────────────
# 766 限消【董监高】 — 15条，PublishDate 90天内
# ────────────────────────────────────────────────────────────────
pm766_15 = [
    {"Id": f"pm766x{i:02d}",
     "CaseNo": f"（2026）京{1001+i%3}执{50000+i}号",
     "LimitObject": "限消高管供职公司", "LimitObjectKeyNo": f"lo766{i:02d}",
     "RelatedName": "近期违规高管", "RelatedKeyNo": f"rk766{i:02d}",
     "JudgeDate": RECENT_15[i], "PublishDate": RECENT_15[i],
     "Applicant": f"申请方{i+1}", "ApplicantKeyNo": f"ak766{i:02d}"}
    for i in range(15)
]
write(["PersonSumptuaryCheck","GetList","15条限消高管__personName=近期违规高管"], p15(pm766_15, "PERSONSUMPTUARYCHECK"))
# pageSize=5 → 3页，phighconsumecnt=15


# ────────────────────────────────────────────────────────────────
# 771 终本案件【董监高】 — 15条，LianDate 90天内
# ────────────────────────────────────────────────────────────────
pe771_15 = [
    {"Id": f"pe771x{i:02d}",
     "CaseNo": f"（2026）京{1001+i%3}执终{60000+i}号",
     "Court": COURTS[i % 3], "EndDate": RECENT_15[i], "LianDate": RECENT_15[i],
     "ExecuteSubject": str(1000000*(i+1)), "UnperformedAmt": str(800000*(i+1))}
    for i in range(15)
]
write(["PersonEndExCaseCheck","GetList","15条终本高管__personName=近期违规高管"], p15(pe771_15, "PERSONENDEXCASECHECK"))
# pageSize=5 → 3页，pterminatedcnt=15


# ────────────────────────────────────────────────────────────────
# 767 股权冻结【董监高】 — 15条，全部冻结+未过期（无earlyStop）
# ────────────────────────────────────────────────────────────────
pef767_15 = [
    {"Id": f"pef767x{i:02d}", "ExecuteName": "高管甲", "ExecuteKeyNo": f"ek767{i:02d}",
     "EquityAmount": f"{(i+1)*50}万元人民币", "ExecuteCourt": COURTS[i % 3],
     "ExecutionNoticeNum": f"（2025）法执字第{700+i}号",
     "Status": "股权冻结|冻结",
     "FreezeStartDate": "2025-01-01", "FreezeEndDate": "2027-12-31",
     "RelatedInfo": {"KeyNo": f"ri767{i:02d}", "Name": "15条冻结高管企业"}}
    for i in range(15)
]
write(["PersonSEFreezeCheck","GetList","15条冻结高管企业__personName=高管甲"], p15(pef767_15, "PERSONSEFREEZECHECK"))
# pageSize=5 → 3页，pequityfreezeflag=15（全部满足双条件，无earlyStop全翻）


# ────────────────────────────────────────────────────────────────
# 768 股权出质【董监高】 — 15条，全部"有效"（无earlyStop）
# ────────────────────────────────────────────────────────────────
pep768_15 = [
    {"Id": f"pep768x{i:02d}",
     "RegistNo": f"股质登记字〔2024〕第{800+i}号",
     "PledgorName": "高管乙", "PledgeeName": f"质权银行{i+1}",
     "PledgedAmount": f"{(i+1)*100}万股", "RegDate": f"2024-0{(i%9)+1:02d}-01",
     "Status": "有效",
     "RelatedCompanyName": "15条出质高管企业"}
    for i in range(15)
]
write(["PersonSEPledgedCheck","GetList","15条出质高管企业__personName=高管乙"], p15(pep768_15, "PERSONSEPLEDGEDCHECK"))
# pageSize=5 → 3页，pequitypledgeflag=15（全部有效，无earlyStop全翻）


print("\n✅ 所有缺失的跨页 mock 文件创建完成！")
print("\n=== 汇总 ===")
print("882 法院公告: 15条涉贷被告公司.json → count=15（pageSize=5，3页）")
print("887 裁判文书: 15条涉贷被告公司.json → loan=6,self=3,preserv=3（每页2+1+1+1）")
print("888 开庭公告: 15条开庭被告公司.json → count=15")
print("764 失信【董监高】: 15条失信高管 → count=15")
print("765 被执行【董监高】: 15条被执行高管 → count=15")
print("766 限消【董监高】: 15条限消高管 → count=15")
print("771 终本【董监高】: 15条终本高管 → count=15")
print("767 股权冻结【董监高】: 15条冻结高管 → count=15（无earlyStop，全翻）")
print("768 股权出质【董监高】: 15条出质高管 → count=15（无earlyStop，全翻）")
