# -*- coding: utf-8 -*-
"""Legacy V46 兼容数据源适配器（v3-merged）。

设计边界（与合并方案一致）：
- 只迁移 V46 的"显式规则映射 + 响应构造函数"；
- 不迁移全局 sticky_mode、调用次数判断、未知接口安全回退；
- 所有请求由 V2 场景注册表显式声明 mode/ruleCode 驱动，无跨用例状态；
- 739 冒充预警通的两条规则（ENLX11/ENDX13）不经过本适配器，保持 inconclusive。
"""

from __future__ import annotations

import datetime as _dt

import legacy_v46_source as L

KYC_CODE = "2003"
CERT_CODE = "255"
DETAIL_CODE = "980"
SOAP_KEY = "SOAP"

# 与 legacy do_POST 中 ECGX 子规则参数保持一致
ECGX_PARAMS = {
    "ECGX01": {"badloanbal": 5000000, "odloanacctcnt": 3},
    "ECGX02": {"badloanbal": 3000000},
    "ECGX03": {"attnloanacctcnt": 2},
    "ECGX04": {"odguaacctcnt": 1, "badguabal": 2000000},
    "ECGX05": {"badguabal": 1500000},
    "ECGX06": {"attnguaacctcnt": 1},
    "ECGX07": {"unpaidintbal": 500000},
}

# 证书类规则（255 接口）
CERT_RULE_CODES = {"EBNP05", "EBNP06", "EBNP07", "EBNP08", "EBNP09", "EBNP10"}
# 清算类规则（980 接口）
DETAIL_RULE_CODES = {"ELDP10"}
# 展示类规则（命中=通过，仅抓取展示）：规则码 → 接口码
DISPLAY_RULE_CODES = {"EBNP11": "958"}


def legacy_rule_codes():
    """V46 显式规则映射的全部规则码（不含 ECGX/证书/清算补充）。"""
    codes = set(L.RULE_CODE_MAP.keys())
    codes |= set(ECGX_PARAMS.keys())
    codes |= CERT_RULE_CODES
    codes |= DETAIL_RULE_CODES
    codes |= set(DISPLAY_RULE_CODES.keys())
    return codes


def _endpoint_funcs(mode, rule_code):
    if mode == "red":
        return L.RED_FUNCS
    if mode == "blue":
        return L.BLUE_FUNCS
    if mode == "yellow_full":
        return L.YELLOW_FULL_FUNCS
    if mode == "yellow":
        _, endpoints = L._v21_get_yellow_data(rule_code)
        return endpoints
    return {}


def _enterprise_name(search_key, rule_code):
    """复刻 legacy 的企业名占位替换逻辑（显式入参，无状态）。"""
    if not search_key or not rule_code:
        return ""
    if search_key.upper().startswith("YELLOW_RULE_"):
        return "国企规则测试_" + search_key[len("YELLOW_RULE_"):]
    import re as _re
    if _re.match(r"(?i)RULE_[A-Z]", search_key):
        if rule_code.startswith("EBN"):
            return "国企规则测试_" + rule_code
        if rule_code.startswith("ARG"):
            return "关联规则测试_" + rule_code
        return "民营规则测试_" + rule_code
    return ""


def build_kyc(mode, rule_code=None):
    """2003 KYC 响应；make_kyc 已含整数 StatusCode=200（v46 修复）。"""
    if mode == "red":
        data = L.red_kyc_data()
    elif mode == "blue":
        data = L.blue_kyc_data()
    elif mode == "yellow_full":
        data = L.yellow_kyc_data()
    elif mode == "yellow":
        func, _ = L._v21_get_yellow_data(rule_code)
        data = func() if func else L.safe_kyc_data()
    else:
        data = L.safe_kyc_data()
    return L.make_kyc(data)


def _bid_info_items(search_key):
    """EBNP11 中标信息展示记录；WinBidUnitList 名称回声 searchKey 供 ETL 比对。"""
    name = search_key or "YELLOW_ENTERPRISE"
    return [{
        "PublishDate": L.RECENT,
        "Title": "XX市政工程项目",
        "ProjectNo": "ZB2026001",
        "WinBidUnitList": [{"WinBidAmt": "5000万元", "Name": name}],
        "BudgetAmt": "6000万元",
        "BidInviUnitList": [{"Name": "XX市住建局"}],
    }]


def build_list(api_code, mode, rule_code=None, search_key=None):
    """24 个列表接口的风险/安全响应；未映射端点返回安全空数据（隔离保证）。"""
    if str(api_code) == "958" and rule_code == "EBNP11" and mode != "safe":
        return L.make_risk_list(_bid_info_items(search_key))
    func = _endpoint_funcs(mode, rule_code).get(str(api_code))
    if not func:
        return L.make_safe_list()
    items = func()
    if str(api_code) == "887" and search_key and search_key in L.BOUNDARY_887_MAP:
        items = L.BOUNDARY_887_MAP[search_key]()
    ent_name = _enterprise_name(search_key, rule_code)
    if ent_name:
        items = L._replace_placeholders(items, ent_name)
    if search_key and str(api_code) == "887":
        items = L._fix_887_party_names(items, search_key)
    return L.make_risk_list(items)


def build_cert(mode, rule_code=None, search_key=None):
    """255 资质证书响应（Result 为顶层 JSONArray，v23 FIX-255）。"""
    import datetime as _dt
    upper = (search_key or "").upper()
    if mode == "red" and "TC_200" in upper:
        exp = (_dt.datetime.now() - _dt.timedelta(days=10)).strftime("%Y-%m-%d")
        return L.make_risk_cert_255([
            {"Name": "建筑业企业资质证书一级", "EndDate": exp, "Status": "已过期"}])
    if mode == "red":
        return L.make_risk_cert_255([
            {"Name": "建筑业企业资质证书一级", "EndDate": L.FUTURE, "Status": "正常"}])
    if mode == "yellow" and rule_code == "EBNP06":
        exp = (_dt.datetime.now() + _dt.timedelta(days=60)).strftime("%Y-%m-%d")
        return L.make_risk_cert_255([
            {"Name": "建筑业企业资质证书二级", "EndDate": exp, "Status": "即将过期"}])
    if mode == "yellow" and rule_code == "EBNP05":
        return L.make_risk_cert_255([
            {"Name": "建筑业企业资质证书二级", "EndDate": L.FUTURE, "Status": "正常"}])
    if mode == "yellow" and rule_code == "EBNP07":
        # 合同纠偏：EBNP07=距到期≤30天（日期系），非状态异常；20天同时满足>0
        exp = (_dt.datetime.now() + _dt.timedelta(days=20)).strftime("%Y-%m-%d")
        return L.make_risk_cert_255([
            {"Name": "建筑业企业资质证书一级", "EndDate": exp, "Status": "正常"}])
    if mode == "yellow" and rule_code == "EBNP09":
        # 状态异常_极高风险：吊销/撤销；未来日期使 06/07/08 日期系规则不命中
        exp = (_dt.datetime.now() + _dt.timedelta(days=180)).strftime("%Y-%m-%d")
        return L.make_risk_cert_255([
            {"Name": "建筑业企业资质证书一级", "EndDate": exp, "Status": "吊销"}])
    if mode == "yellow" and rule_code == "EBNP10":
        # 状态异常_高风险：注销；未来日期同上隔离
        exp = (_dt.datetime.now() + _dt.timedelta(days=180)).strftime("%Y-%m-%d")
        return L.make_risk_cert_255([
            {"Name": "建筑业企业资质证书一级", "EndDate": exp, "Status": "注销"}])
    if mode == "yellow" and rule_code == "EBNP08":
        exp = (_dt.datetime.now() - _dt.timedelta(days=5)).strftime("%Y-%m-%d")
        return L.make_risk_cert_255([
            {"Name": "建筑业企业资质证书一级", "EndDate": exp, "Status": "已过期"}])
    return L.make_safe_cert_255()


def build_detail(mode, rule_code=None):
    """980 清算核查响应。"""
    if mode == "red":
        return L.make_risk_detail({
            "Leader": "张三;李四", "LiquidationDate": L.RECENT,
            "CaseNo": "(2026)X01清字第001号"})
    if mode == "yellow" and rule_code == "ELDP10":
        return L.make_risk_detail({
            "Leader": "张三", "LiquidationDate": L.RECENT,
            "CaseNo": "(2026)X01清字第002号"})
    return L.make_safe_detail()


def build_credit_xml(mode, rule_code, ent_name, ent_cert_num):
    """企业征信 SOAP XML；仅 ECGX 规则/RED+ECGX 用例返回非零明细。"""
    if mode == "yellow" and rule_code and rule_code.startswith("ECGX"):
        params = ECGX_PARAMS.get(rule_code, {"badloanbal": 5000000, "odloanacctcnt": 3})
        return L._credit_report_xml(ent_name=ent_name, ent_cert_num=ent_cert_num, **params)
    if mode == "red":
        return L._credit_report_xml(
            badloanbal=5000000, odloanacctcnt=3, attnloanacctcnt=2,
            odguaacctcnt=1, badguabal=2000000, attnguaacctcnt=1,
            unpaidintbal=500000, ent_name=ent_name, ent_cert_num=ent_cert_num)
    return L._credit_report_xml(ent_name=ent_name, ent_cert_num=ent_cert_num)


def build_response(api_code, mode, rule_code=None, search_key=None):
    """按接口码分派到 KYC/证书/清算/列表构造函数。"""
    code = str(api_code)
    if code == KYC_CODE:
        return build_kyc(mode, rule_code)
    if code == CERT_CODE:
        return build_cert(mode, rule_code, search_key)
    if code == DETAIL_CODE:
        return build_detail(mode, rule_code)
    return build_list(code, mode, rule_code, search_key)
