"""Load declarative scenario-to-response mappings for the mock service."""

from __future__ import annotations

import json
from pathlib import Path


def load_scenario_registry(path):
    registry_path = Path(path)
    if not registry_path.exists():
        return {}
    payload = json.loads(registry_path.read_text(encoding="utf-8"))
    scenarios = payload.get("scenarios", {})
    if not isinstance(scenarios, dict):
        raise ValueError("scenario registry 的 scenarios 必须是对象")
    for scenario_id, scenario in scenarios.items():
        if not str(scenario_id).startswith("BHJC_"):
            raise ValueError(f"场景ID必须以BHJC_开头: {scenario_id}")
        if not isinstance(scenario, dict):
            raise ValueError(f"场景配置必须是对象: {scenario_id}")
        responses = scenario.get("responses", {})
        if not isinstance(responses, dict):
            raise ValueError(f"responses必须是对象: {scenario_id}")
    return scenarios

