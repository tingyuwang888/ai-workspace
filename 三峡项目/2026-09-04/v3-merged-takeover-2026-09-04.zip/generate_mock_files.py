# -*- coding: utf-8 -*-
"""
为所有 27 个企查查 API 生成 A/B/C 三套固定测试用例，
保存为 JSON 文件到 mock-files/ 目录下。

每个接口按 URL 路径组织子目录，文件名即 searchKey。

用法：
    python3 generate_mock_files.py
"""

import json
import os
import sys

# 将当前目录加入 path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from mock_data import get_mock_response, seed_by_search_key

# ======================== 测试用例定义 ========================

TEST_CASES = [
    {"searchKey": "测试公司A", "label": "A - 正常企业（存续）"},
    {"searchKey": "测试公司B", "label": "B - 风险企业（多条失信/被执行记录）"},
    {"searchKey": "测试公司C", "label": "C - 注销/吊销企业"},
]

# ======================== 接口路径映射 ========================

API_ROUTES = {
    "2003": {"path": "CustomerDueDiligence/KYC", "name": "客户身份识别"},
    "255":  {"path": "ECICertification/SearchCertification", "name": "资质证书"},
    "739":  {"path": "ExceptionCheck/GetList", "name": "经营异常核查"},
    "740":  {"path": "ShixinCheck/GetList", "name": "失信核查"},
    "741":  {"path": "ZhixingCheck/GetList", "name": "被执行人核查"},
    "742":  {"path": "SumptuaryCheck/GetList", "name": "限制高消费核查"},
    "744":  {"path": "JudicialSaleCheck/GetList", "name": "司法拍卖核查"},
    "746":  {"path": "EnvPunishmentCheck/GetList", "name": "环保处罚核查"},
    "748":  {"path": "SeriousIllegalCheck/GetList", "name": "严重违法核查"},
    "751":  {"path": "EquityPledgedCheck/GetList", "name": "股权出质核查"},
    "752":  {"path": "EquityFreezeCheck/GetList", "name": "股权冻结核查"},
    "756":  {"path": "TaxIllegalCheck/GetList", "name": "税收违法核查"},
    "757":  {"path": "TaxOweNoticeCheck/GetList", "name": "欠税公告核查"},
    "758":  {"path": "EndExecuteCaseCheck/GetList", "name": "终本案件核查"},
    "761":  {"path": "BankruptcyCheck/GetList", "name": "破产重整核查"},
    "764":  {"path": "PersonSXCheck/GetList", "name": "失信被执行核查【董监高】", "personName": "张经理"},
    "765":  {"path": "PersonZXCheck/GetList", "name": "被执行人核查【董监高】", "personName": "张经理"},
    "766":  {"path": "PersonSumptuaryCheck/GetList", "name": "限制高消费核查【董监高】", "personName": "张经理"},
    "767":  {"path": "PersonSEFreezeCheck/GetList", "name": "股权冻结核查【董监高】", "personName": "张经理"},
    "768":  {"path": "PersonSEPledgedCheck/GetList", "name": "股权出质核查【董监高】", "personName": "张经理"},
    "771":  {"path": "PersonEndExCaseCheck/GetList", "name": "终本案件核查【董监高】", "personName": "张经理"},
    "865":  {"path": "AdminPenaltyCheck/GetList", "name": "行政处罚核查"},
    "882":  {"path": "CourtNoticeCheck/GetList", "name": "法院公告核查"},
    "887":  {"path": "JudgmentDocCheck/GetList", "name": "裁判文书核查"},
    "888":  {"path": "CourtAnnoCheck/GetList", "name": "开庭公告核查"},
    "958":  {"path": "TenderCheck/GetList", "name": "招投标信息"},
    "980":  {"path": "LiquidationCheck/GetDetail", "name": "清算核查"},
}

# 输出根目录
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mock-files")


def generate_all():
    """生成所有接口的 A/B/C 三套测试用例"""
    total_files = 0

    print(f"输出目录: {OUTPUT_DIR}")
    print(f"接口数量: {len(API_ROUTES)}")
    print(f"每个接口: {len(TEST_CASES)} 套用例")
    print("=" * 60)

    for api_code, route_info in API_ROUTES.items():
        api_path = route_info["path"]
        api_name = route_info["name"]
        api_dir = os.path.join(OUTPUT_DIR, api_path)
        os.makedirs(api_dir, exist_ok=True)

        # 董监高接口 personName 是必填项，不生成无 personName 的基础文件
        skip_base = "personName" in route_info

        print(f"\n[{api_code}] {api_name} -> {api_path}/")
        if skip_base:
            print(f"  (跳过基础文件，personName 为必填项)")

        for tc in TEST_CASES:
            search_key = tc["searchKey"]
            label = tc["label"]

            if skip_base:
                continue

            # 生成分页接口时使用 page_size=50，一次取出全部数据
            response = get_mock_response(
                api_code,
                page_index=1,
                page_size=50,
                search_key=search_key,
            )

            # 对于分页接口，将全量数据的 pageSize 改回 10（标准页大小）
            # 这样服务读取时可以按需切片
            if "Paging" in response:
                response["Paging"]["PageSize"] = 10

            file_path = os.path.join(api_dir, f"{search_key}.json")

            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(response, f, ensure_ascii=False, indent=2)

            # 统计 Result 中的数据量
            result = response.get("Result", {})
            if isinstance(result, dict):
                data = result.get("Data", [])
                if isinstance(data, list):
                    count = f"{len(data)}条记录"
                else:
                    count = "单条详情"
            else:
                count = "单条详情"

            print(f"  ✓ {search_key} ({label}) -> {count}")
            total_files += 1

    print("\n" + "=" * 60)
    print(f"基础用例生成完成！共 {total_files} 个 JSON 文件")

    # 生成带筛选参数的额外用例
    print("\n--- 生成带筛选参数的用例 ---")
    total_files += _generate_filter_files()

    print("\n" + "=" * 60)
    print(f"全部生成完成！共 {total_files} 个 JSON 文件")
    print(f"目录: {OUTPUT_DIR}")

    # 生成索引文件
    _generate_index()


# ======================== 筛选参数文件生成 ========================

# 每个接口的筛选参数组合定义
# 格式: api_code -> list of (param_name, [values_to_generate])
FILTER_VARIANTS = {
    "255": [("isValid", ["0", "1"])],
    "887": [
        ("pubYear", ["2023", "2024"]),
        ("caseIdentity", ["1", "2"]),
    ],
    "888": [("caseIdentity", ["1", "2"])],
    "958": [("msgType", ["3", "4"])],
}


def _generate_filter_files():
    """
    为有筛选参数的接口生成带参数后缀的用例文件。
    文件命名: {searchKey}__{param}={value}.json
    数据内容基于同一个 searchKey 的种子生成，只是通过不同参数名区分。
    """
    total = 0
    for api_code, variants in FILTER_VARIANTS.items():
        route = API_ROUTES.get(api_code)
        if not route:
            continue
        api_path = route["path"]
        api_name = route["name"]
        api_dir = os.path.join(OUTPUT_DIR, api_path)
        os.makedirs(api_dir, exist_ok=True)

        print(f"\n  [{api_code}] {api_name}")

        for tc in TEST_CASES:
            search_key = tc["searchKey"]

            for param_name, values in variants:
                for val in values:
                    # 用 searchKey + apiCode + param组合 做种子，生成有差异的数据
                    seed_str = f"{search_key}::{api_code}::{param_name}={val}"
                    response = get_mock_response(
                        api_code, page_index=1, page_size=50, search_key=seed_str,
                    )
                    if "Paging" in response:
                        response["Paging"]["PageSize"] = 10

                    file_name = f"{search_key}__{param_name}={val}.json"
                    file_path = os.path.join(api_dir, file_name)
                    with open(file_path, "w", encoding="utf-8") as f:
                        json.dump(response, f, ensure_ascii=False, indent=2)
                    print(f"    ✓ {file_name}")
                    total += 1

    # 董监高接口：为每个 searchKey 生成 personName 专用文件
    person_apis = ["764", "765", "766", "767", "768", "771"]
    person_names = ["张经理", "李总监", "王监事"]
    for api_code in person_apis:
        route = API_ROUTES.get(api_code)
        if not route:
            continue
        api_path = route["path"]
        api_name = route["name"]
        api_dir = os.path.join(OUTPUT_DIR, api_path)
        os.makedirs(api_dir, exist_ok=True)

        print(f"\n  [{api_code}] {api_name}")

        for tc in TEST_CASES:
            search_key = tc["searchKey"]
            for pname in person_names:
                seed_str = f"{search_key}::{api_code}::personName={pname}"
                response = get_mock_response(
                    api_code, page_index=1, page_size=50, search_key=seed_str,
                )
                if "Paging" in response:
                    response["Paging"]["PageSize"] = 10

                file_name = f"{search_key}__personName={pname}.json"
                file_path = os.path.join(api_dir, file_name)
                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(response, f, ensure_ascii=False, indent=2)
                print(f"    ✓ {file_name}")
                total += 1

    print(f"\n  筛选参数文件共 {total} 个")
    return total


def _generate_index():
    """生成索引文件 README.json，列出所有预置的测试用例"""
    index = {}
    for api_code, route_info in API_ROUTES.items():
        api_path = route_info["path"]
        api_dir = os.path.join(OUTPUT_DIR, api_path)
        if not os.path.isdir(api_dir):
            continue
        files = [f.replace(".json", "") for f in sorted(os.listdir(api_dir)) if f.endswith(".json")]
        index[api_code] = {
            "name": route_info["name"],
            "path": api_path,
            "test_cases": files,
        }

    index_path = os.path.join(OUTPUT_DIR, "index.json")
    with open(index_path, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2)
    print(f"\n索引文件: {index_path}")


if __name__ == "__main__":
    generate_all()
