"""Runtime helpers for isolated, repeatable third-party mock scenarios."""

from __future__ import annotations

import copy
import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta


SERVICE_VERSION = "3.0.0-merged"
REFERENCE_DATE = date(2026, 5, 31)
SCENARIO_KEY_RE = re.compile(
    r"^(?P<template>BHJC_[A-Z0-9_]+?)"
    r"(?:__(?P<run_id>[A-Za-z0-9._-]+?))?"
    r"(?:__(?P<case_id>[A-Za-z0-9._-]+))?$"
)
ISO_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
KNOWN_SCENARIO_KEYS = {"BHJC_BASE"} | {f"BHJC_{index:03d}" for index in range(1, 11)}


@dataclass(frozen=True)
class ScenarioIdentity:
    raw_key: str
    template_key: str
    run_id: str | None
    case_id: str | None

    @property
    def isolated(self) -> bool:
        return bool(self.run_id and self.case_id)


def parse_scenario_key(search_key: str) -> ScenarioIdentity | None:
    """Parse BHJC_<scenario>__<runId>__<caseId>; non-BHJC keys return None."""
    value = str(search_key or "").strip()
    if not value.startswith("BHJC_"):
        return None
    match = SCENARIO_KEY_RE.fullmatch(value)
    if not match:
        raise ValueError(
            "BHJC场景键格式错误，应为 BHJC_<SCENARIO>__<runId>__<caseId>"
        )
    return ScenarioIdentity(
        raw_key=value,
        template_key=match.group("template"),
        run_id=match.group("run_id"),
        case_id=match.group("case_id"),
    )


def _shift_date_text(value: str, today: date, reference_date: date) -> str:
    if not ISO_DATE_RE.fullmatch(value):
        return value
    try:
        original = datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        return value
    return (original + (today - reference_date)).isoformat()


def rebase_dates(payload, today: date | None = None,
                 reference_date: date = REFERENCE_DATE):
    """Deep-copy a response and shift ISO dates while preserving intervals."""
    today = today or date.today()
    if isinstance(payload, dict):
        return {
            key: rebase_dates(value, today=today, reference_date=reference_date)
            for key, value in payload.items()
        }
    if isinstance(payload, list):
        return [
            rebase_dates(value, today=today, reference_date=reference_date)
            for value in payload
        ]
    if isinstance(payload, str):
        return _shift_date_text(payload, today, reference_date)
    return copy.deepcopy(payload)


def apply_date_offsets(payload, offsets, today: date | None = None):
    """Set declared dotted paths to today +/- an exact day offset."""
    today = today or date.today()
    for dotted_path, days_ago in (offsets or {}).items():
        current = payload
        parts = str(dotted_path).split(".")
        try:
            for part in parts[:-1]:
                current = current[int(part)] if isinstance(current, list) else current[part]
            final = parts[-1]
            value = (today - timedelta(days=int(days_ago))).isoformat()
            if isinstance(current, list):
                current[int(final)] = value
            else:
                current[final] = value
        except (KeyError, IndexError, TypeError, ValueError):
            raise ValueError(f"dateOffsets路径无效: {dotted_path}")
    return payload


def finalize_scenario_response(payload, identity: ScenarioIdentity,
                               today: date | None = None):
    """Rebase dates and stamp a unique order number without changing result data."""
    result = rebase_dates(payload, today=today)
    if isinstance(result, dict):
        offsets = result.pop("__mockDateOffsets", {})
        apply_date_offsets(result, offsets, today=today)
        result["OrderNumber"] = f"MOCK_{identity.raw_key}"
    return result
