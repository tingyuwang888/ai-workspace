# -*- coding: utf-8 -*-
"""V46 与 v3-merged 的响应级差异回归（本地闭环）。

对 migration_manifest 中每条 legacy 规则：
- HIT 对比：legacy 服务 searchKey=RULE_<code>_TC_901（yellow 按规则路由）
            vs v3 服务 searchKey=BHJC_LG_<code>_HIT__REG__C1（显式场景合同）；
- MISS 对比：legacy 服务 searchKey=SAFE_DIFF_<code>（safe 模式）
            vs v3 服务 searchKey=BHJC_LG_<code>_MISS__REG__C1；
- 比对范围：2003 + 场景合同声明的列表/证书/清算接口；
- 归一化：OrderNumber、企业名占位变体、searchKey 回声（887 当事人名/KeyNo）
  属设计差异，替换为占位符后比较；日期为同日生成，直接比较。
输出 diff_report.json / diff_report.md。
"""

import json
import os
import re
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
LEGACY_BASE = os.environ.get("LEGACY_BASE", "http://127.0.0.1:8899")
V3_BASE = os.environ.get("V3_BASE", "http://127.0.0.1:8923")

PATHS = {
    "2003": ("/CustomerDueDiligence/KYC", "searchKey"),
    "255": ("/ECICertification/SearchCertification", "searchKey"),
    "739": ("/ExceptionCheck/GetList", "searchKey"),
    "740": ("/ShixinCheck/GetList", "searchKey"),
    "741": ("/ZhixingCheck/GetList", "searchKey"),
    "742": ("/SumptuaryCheck/GetList", "searchKey"),
    "744": ("/JudicialSaleCheck/GetList", "searchKey"),
    "746": ("/EnvPunishmentCheck/GetList", "searchKey"),
    "748": ("/SeriousIllegalCheck/GetList", "searchKey"),
    "751": ("/EquityPledgedCheck/GetList", "searchKey"),
    "752": ("/EquityFreezeCheck/GetList", "searchKey"),
    "756": ("/TaxIllegalCheck/GetList", "searchKey"),
    "757": ("/TaxOweNoticeCheck/GetList", "searchKey"),
    "758": ("/TerminatedCaseCheck/GetList", "searchKey"),
    "761": ("/BankruptcyCheck/GetList", "searchKey"),
    "764": ("/PersonSXCheck/GetList", "searchKey"),
    "765": ("/PersonZXCheck/GetList", "searchKey"),
    "766": ("/PersonSumptuaryCheck/GetList", "searchKey"),
    "767": ("/PersonSEFreezeCheck/GetList", "searchKey"),
    "768": ("/PersonSEPledgedCheck/GetList", "searchKey"),
    "771": ("/PersonTerminatedCaseCheck/GetList", "searchKey"),
    "865": ("/AdminPenaltyCheck/GetList", "searchKey"),
    "882": ("/CourtNoticeCheck/GetList", "searchKey"),
    "887": ("/JudgmentDocCheck/GetList", "searchKey"),
    "888": ("/CourtAnnoCheck/GetList", "searchKey"),
    "958": ("/TenderCheck/GetList", "keyword"),
    "980": ("/LiquidationCheck/GetDetail", "searchKey"),
}

ENT_VARIANTS = ("YELLOW_ENTERPRISE",)


LEGACY_PATH_OVERRIDE = {
    # V46 只认旧路径（V27 新路径返回空是其已知兼容缺陷，v3 已修复）
    "758": "/EndExecuteCaseCheck/GetList",
    "771": "/PersonEndExCaseCheck/GetList",
}
# V46 子串路由缺陷：/PersonSumptuaryCheck/GetList 先被 SumptuaryCheck(742)
# 匹配，导致个人限高规则(766)数据在 V46 永远返回空；v3 独立路由已修复。
# EBNP07 为 v3 合同纠偏差异（日期系 vs V46 状态系）；EBNP09/10/11 为 v3 新增
# 覆盖（V46 无映射，历史上即 pending 原因）。
KNOWN_V46_DEFECTS = {
    ("PLEP01", "766"), ("PLDX01", "766"),
    ("EBNP07", "255"), ("EBNP09", "255"), ("EBNP10", "255"), ("EBNP11", "958"),
}
EXTRA_PARAMS = {
    code: "&personName=%E5%BC%A0%E4%B8%89"
    for code in ("764", "765", "766", "767", "768", "771")
}


def fetch(base, path, param, key, api):
    url = f"{base}{path}?{param}={urllib.request.quote(key)}{EXTRA_PARAMS.get(api, '')}"
    with urllib.request.urlopen(url, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))


def normalize(obj, keys):
    """替换设计差异字段：OrderNumber 删除；企业名变体/searchKey 回声占位。"""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if k == "OrderNumber":
                continue
            out[k] = normalize(v, keys)
        return out
    if isinstance(obj, list):
        return [normalize(v, keys) for v in obj]
    if isinstance(obj, str):
        value = obj
        for variant in ENT_VARIANTS:
            value = value.replace(variant, "<ENT>")
        value = re.sub(r"(国企|关联|民营)规则测试_[A-Z0-9]+", "<ENT>", value)
        for key in keys:
            if key and key in value:
                value = value.replace(key, "<KEY>")
        return value
    return obj


def first_diff(a, b, path="$"):
    if type(a) is not type(b):
        return path, f"type {type(a).__name__} vs {type(b).__name__}"
    if isinstance(a, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a:
                return f"{path}.{k}", "missing left"
            if k not in b:
                return f"{path}.{k}", "missing right"
            hit = first_diff(a[k], b[k], f"{path}.{k}")
            if hit:
                return hit
        return None
    if isinstance(a, list):
        if len(a) != len(b):
            return path, f"len {len(a)} vs {len(b)}"
        for i, (x, y) in enumerate(zip(a, b)):
            hit = first_diff(x, y, f"{path}[{i}]")
            if hit:
                return hit
        return None
    if a != b:
        return path, f"{a!r} vs {b!r}"
    return None


def main():
    manifest = json.load(open(os.path.join(HERE, "migration_manifest.json"),
                              encoding="utf-8"))
    registry = json.load(open(os.path.join(HERE, "scenarios", "registry.json"),
                              encoding="utf-8"))["scenarios"]
    results = []
    for rule in manifest["rules"]:
        if rule["status"] != "legacy":
            continue
        code = rule["ruleCode"]
        hit_spec = registry.get(f"BHJC_LG_{code}_HIT", {}).get("responses", {})
        api_codes = [c for c in hit_spec if c in PATHS]
        for mode, legacy_key, v3_key in (
            ("hit", f"RULE_{code}_TC_901", f"BHJC_LG_{code}_HIT__REG__C1"),
            ("miss", f"SAFE_DIFF_{code}", f"BHJC_LG_{code}_MISS__REG__C1"),
        ):
            for api in api_codes:
                path, param = PATHS[api]
                legacy_path = LEGACY_PATH_OVERRIDE.get(api, path)
                left = fetch(LEGACY_BASE, legacy_path, param, legacy_key, api)
                right = fetch(V3_BASE, path, param, v3_key, api)
                nl = normalize(left, {legacy_key, v3_key})
                nr = normalize(right, {legacy_key, v3_key})
                diff = first_diff(nl, nr)
                expected_defect = (code, api) in KNOWN_V46_DEFECTS and mode == "hit"
                results.append({
                    "ruleCode": code, "mode": mode, "api": api,
                    "match": diff is None or expected_defect,
                    "expected_v46_defect": expected_defect,
                    "diff": None if diff is None else {"path": diff[0], "detail": diff[1]},
                })
    total = len(results)
    bad = [r for r in results if not r["match"]]
    defects = [r for r in results if r.get("expected_v46_defect")]
    report = {"total": total, "mismatch": len(bad),
              "expected_v46_defects": len(defects), "details": bad}
    with open(os.path.join(HERE, "diff_report.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=2)
    lines = [f"# V46 vs v3-merged 差异回归", "",
             f"比对数: {total}　不一致: {len(bad)}　预期V46缺陷: {len(defects)}", ""]
    for item in bad[:60]:
        lines.append(f"- {item['ruleCode']} [{item['mode']}] api={item['api']} "
                     f"{item['diff']['path']}: {item['diff']['detail']}")
    with open(os.path.join(HERE, "diff_report.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print(f"total={total} mismatch={len(bad)} expected_v46_defects={len(defects)}")
    for item in bad[:20]:
        print(" ", item["ruleCode"], item["mode"], item["api"],
              item["diff"]["path"], item["diff"]["detail"][:120])


if __name__ == "__main__":
    main()
