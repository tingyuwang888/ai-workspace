# 天策测试环境三方数据源手工切换清单

> 平台操作人：用户。Agent 不访问、不修改天策数据源配置。仅限隔离测试环境。

## 汇总

- 接口总数：30
- 可切换：27
- 仅安全基线：1
- 需适配、禁止切换：2

## 切换前

1. 导出并备份每个数据源的完整配置，不只记录 URL。
2. 将 `<MOCK_HOST>` 替换为天策测试运行节点可访问的地址；不能使用 127.0.0.1。
3. 访问 `/health`，确认 HTTP 200、`status=ok`、`strictScenarioKeys=true`。
4. 按 `platform-switch-plan.json` 对每个待切换接口执行探针并保存证据。
5. 确认测试机构和测试渠道隔离，生产流量无法访问 Mock。

## 手工切换表

|序号|接口|分类|原 URL|目标 URL|动作|
|---:|---|---|---|---|---|
|1|企查查2003客户身份识别|ready_to_switch|`https://api.qichacha.com/CustomerDueDiligence/KYC`|`http://<MOCK_HOST>:8899/CustomerDueDiligence/KYC`|探针通过后可切换|
|2|企查查739经营异常核查|ready_to_switch|`https://api.qichacha.com/ExceptionCheck/GetList`|`http://<MOCK_HOST>:8899/ExceptionCheck/GetList`|探针通过后可切换|
|3|企查查740失信核查|ready_to_switch|`https://api.qichacha.com/ShixinCheck/GetList`|`http://<MOCK_HOST>:8899/ShixinCheck/GetList`|探针通过后可切换|
|4|企查查741被执行人核查|ready_to_switch|`https://api.qichacha.com/ZhixingCheck/GetList`|`http://<MOCK_HOST>:8899/ZhixingCheck/GetList`|探针通过后可切换|
|5|企查查742限制高消费核查|ready_to_switch|`https://api.qichacha.com/SumptuaryCheck/GetList`|`http://<MOCK_HOST>:8899/SumptuaryCheck/GetList`|探针通过后可切换|
|6|企查查744司法拍卖核查|ready_to_switch|`https://api.qichacha.com/JudicialSaleCheck/GetList`|`http://<MOCK_HOST>:8899/JudicialSaleCheck/GetList`|探针通过后可切换|
|7|企查查746环保处罚核查|ready_to_switch|`https://api.qichacha.com/EnvPunishmentCheck/GetList`|`http://<MOCK_HOST>:8899/EnvPunishmentCheck/GetList`|探针通过后可切换|
|8|企查查748严重违法核查|ready_to_switch|`https://api.qichacha.com/SeriousIllegalCheck/GetList`|`http://<MOCK_HOST>:8899/SeriousIllegalCheck/GetList`|探针通过后可切换|
|9|企查查751股权出质核查|ready_to_switch|`https://api.qichacha.com/EquityPledgedCheck/GetList`|`http://<MOCK_HOST>:8899/EquityPledgedCheck/GetList`|探针通过后可切换|
|10|企查查752股权冻结核查|ready_to_switch|`https://api.qichacha.com/EquityFreezeCheck/GetList`|`http://<MOCK_HOST>:8899/EquityFreezeCheck/GetList`|探针通过后可切换|
|11|企查查756税收违法核查|ready_to_switch|`https://api.qichacha.com/TaxIllegalCheck/GetList`|`http://<MOCK_HOST>:8899/TaxIllegalCheck/GetList`|探针通过后可切换|
|12|企查查757欠税公告核查|ready_to_switch|`https://api.qichacha.com/TaxOweNoticeCheck/GetList`|`http://<MOCK_HOST>:8899/TaxOweNoticeCheck/GetList`|探针通过后可切换|
|13|企查查758终本案件核查|ready_to_switch|`https://api.qichacha.com/TerminatedCaseCheck/GetList`|`http://<MOCK_HOST>:8899/TerminatedCaseCheck/GetList`|探针通过后可切换|
|14|企查查761破产重整核查|ready_to_switch|`https://api.qichacha.com/BankruptcyCheck/GetList`|`http://<MOCK_HOST>:8899/BankruptcyCheck/GetList`|探针通过后可切换|
|15|企查查764失信被执行核查董监高|ready_to_switch|`https://api.qichacha.com/PersonSXCheck/GetList`|`http://<MOCK_HOST>:8899/PersonSXCheck/GetList`|探针通过后可切换|
|16|企查查765被执行人核查董监高|ready_to_switch|`https://api.qichacha.com/PersonZXCheck/GetList`|`http://<MOCK_HOST>:8899/PersonZXCheck/GetList`|探针通过后可切换|
|17|企查查766限制高消费核查董监高|ready_to_switch|`https://api.qichacha.com/PersonSumptuaryCheck/GetList`|`http://<MOCK_HOST>:8899/PersonSumptuaryCheck/GetList`|探针通过后可切换|
|18|企查查767股权冻结核查董监高|ready_to_switch|`https://api.qichacha.com/PersonSEFreezeCheck/GetList`|`http://<MOCK_HOST>:8899/PersonSEFreezeCheck/GetList`|探针通过后可切换|
|19|企查查768股权出质核查董监高|ready_to_switch|`https://api.qichacha.com/PersonSEPledgedCheck/GetList`|`http://<MOCK_HOST>:8899/PersonSEPledgedCheck/GetList`|探针通过后可切换|
|20|企查查771终本案件核查董监高|ready_to_switch|`https://api.qichacha.com/PersonTerminatedCaseCheck/GetList`|`http://<MOCK_HOST>:8899/PersonTerminatedCaseCheck/GetList`|探针通过后可切换|
|21|企查查865行政处罚核查|ready_to_switch|`https://api.qichacha.com/AdminPenaltyCheck/GetList`|`http://<MOCK_HOST>:8899/AdminPenaltyCheck/GetList`|探针通过后可切换|
|22|企查查882法院公告核查|ready_to_switch|`https://api.qichacha.com/CourtNoticeCheck/GetList`|`http://<MOCK_HOST>:8899/CourtNoticeCheck/GetList`|探针通过后可切换|
|23|企查查887裁判文书核查|ready_to_switch|`https://api.qichacha.com/JudgmentDocCheck/GetList`|`http://<MOCK_HOST>:8899/JudgmentDocCheck/GetList`|探针通过后可切换|
|24|企查查888开庭公告核查|ready_to_switch|`https://api.qichacha.com/CourtAnnoCheck/GetList`|`http://<MOCK_HOST>:8899/CourtAnnoCheck/GetList`|探针通过后可切换|
|25|企查查980清算核查|ready_to_switch|`https://api.qichacha.com/LiquidationCheck/GetDetail`|`http://<MOCK_HOST>:8899/LiquidationCheck/GetDetail`|探针通过后可切换|
|26|企查查255资质证书|ready_to_switch|`https://api.qichacha.com/ECICertification/SearchCertification`|`http://<MOCK_HOST>:8899/ECICertification/SearchCertification`|探针通过后可切换|
|27|企查查958招中标信息|ready_to_switch|`https://api.qichacha.com/TenderCheck/GetList`|`http://<MOCK_HOST>:8899/TenderCheck/GetList`|探针通过后可切换|
|28|企业征信报告|safe_baseline_only|`http://IP:PORT/services/enterpriseCreditQueryTwoCode`|`http://<MOCK_HOST>:8899/services/enterpriseCreditQueryTwoCode`|仅安全基线，ETL验证后切换|
|29|预警通新闻舆情|adapter_required|`预警通API-新闻舆情`|`-`|禁止切换|
|30|预警通区域经济月度大全|adapter_required|`预警通api-tqCibdRegifinMonth`|`-`|禁止切换|

## 切换后验证

1. 先执行一条代表性 SAFE/MISS 用例，检查三方节点 HTTP、状态码和字段结构。
2. 再执行一个已注册 HIT 场景，核对唯一场景键、目标节点和原始响应证据。
3. 未注册场景必须被严格拒绝；缺少证据的规则结果标记为 inconclusive。
4. 企业征信仅允许验证零风险基线，不得据此宣称正向规则已覆盖。
5. 预警通两个接口保持原配置，不能指向本 Mock。

## 回滚

测试结束或任一探针失败时，立即按 `platform-rollback-plan.json` 恢复原 URL，
并确认组件日志不再出现 `<MOCK_HOST>:8899`。
