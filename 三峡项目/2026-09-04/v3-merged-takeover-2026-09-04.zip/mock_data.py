# -*- coding: utf-8 -*-
"""
企查查 Mock 数据生成模块
为所有 27 个 API 生成约 50 条模拟数据（分页接口）或完整数据（非分页接口）
"""

import random
import hashlib
import time
import uuid
from contextlib import contextmanager


@contextmanager
def seed_by_search_key(search_key, api_code=""):
    """
    用 searchKey + apiCode 的 hash 值作为随机种子，
    确保同一个 searchKey 对同一个接口始终返回相同的 Mock 数据。
    """
    state = random.getstate()
    seed_val = int(hashlib.md5(f"{search_key}::{api_code}".encode()).hexdigest(), 16) % (2**32)
    random.seed(seed_val)
    try:
        yield
    finally:
        random.setstate(state)


# ======================== 通用数据池 ========================

PROVINCES = ["北京市", "上海市", "广东省", "浙江省", "江苏省", "四川省", "湖北省", "湖南省", "山东省", "福建省"]
CITIES = {
    "北京市": [("北京市", "海淀区"), ("北京市", "朝阳区"), ("北京市", "西城区")],
    "上海市": [("上海市", "浦东新区"), ("上海市", "徐汇区"), ("上海市", "静安区")],
    "广东省": [("广州市", "天河区"), ("深圳市", "南山区"), ("东莞市", "莞城街道")],
    "浙江省": [("杭州市", "西湖区"), ("宁波市", "鄞州区"), ("温州市", "鹿城区")],
    "江苏省": [("南京市", "鼓楼区"), ("苏州市", "虎丘区"), ("无锡市", "滨湖区")],
    "四川省": [("成都市", "武侯区"), ("绵阳市", "涪城区"), ("德阳市", "旌阳区")],
    "湖北省": [("武汉市", "武昌区"), ("宜昌市", "西陵区"), ("襄阳市", "樊城区")],
    "湖南省": [("长沙市", "岳麓区"), ("株洲市", "天元区"), ("湘潭市", "雨湖区")],
    "山东省": [("济南市", "历下区"), ("青岛市", "市南区"), ("烟台市", "芝罘区")],
    "福建省": [("福州市", "鼓楼区"), ("厦门市", "思明区"), ("泉州市", "丰泽区")],
}

COMPANY_NAMES = [
    "中科智云科技有限公司", "华创数字科技股份有限公司", "明远信息技术咨询有限公司",
    "天宇新能源科技有限公司", "盛达环保科技集团有限公司", "银河智能装备股份有限公司",
    "鼎盛金融服务有限公司", "汇通供应链管理集团有限公司", "鑫源建设工程有限公司",
    "蓝海生物科技股份有限公司", "瑞丰农业发展有限公司", "华信通信技术有限公司",
    "恒基置业集团有限公司", "嘉禾医疗科技有限公司", "博远教育科技有限公司",
    "东方红新材料科技有限公司", "中信安达保险代理有限公司", "绿源清洁能源有限公司",
    "锐思管理咨询有限公司", "万象文化传媒有限公司", "天合光能科技有限公司",
    "金桥软件科技有限公司", "长江水利工程有限公司", "南方航空物流有限公司",
    "北方智能制造有限公司", "东海渔业科技有限公司", "西部矿业集团有限公司",
    "中原物流集团有限公司", "春城旅游发展有限公司", "星辰大数据科技有限公司",
    "龙翔航空技术有限公司", "凤鸣文化传播有限公司", "麒麟芯片科技有限公司",
    "白鹿原生态农业有限公司", "青山绿水环保有限公司", "金沙矿业集团有限公司",
    "银河证券投资有限公司", "北斗导航科技有限公司", "紫荆花药业有限公司",
    "蓝月亮日化有限公司", "红太阳食品有限公司", "黑土地农业科技有限公司",
    "白云山中医药有限公司", "黄河水务集团有限公司", "长江航运物流有限公司",
    "珠江地产集团有限公司", "泰山石敢当建材有限公司", "黄山旅游发展有限公司",
    "昆仑能源有限公司", "天山雪莲生物科技有限公司",
]

PERSON_NAMES = [
    "张伟", "王芳", "李强", "刘洋", "陈明", "杨秀英", "赵磊", "黄丽", "周军", "吴敏",
    "徐超", "孙艳", "马飞", "朱红", "胡建国", "郭建华", "林志强", "何秀兰", "高峰", "梁波",
    "宋涛", "郑丽华", "谢勇", "韩冰", "唐晓明", "冯雪", "于洋", "董明", "萧然", "程璐",
    "曹阳", "袁芳", "邓辉", "许强", "傅静", "沈磊", "曾琳", "彭军", "吕艳", "苏杰",
]

COURT_NAMES = [
    "北京市朝阳区人民法院", "上海市浦东新区人民法院", "广州市天河区人民法院",
    "深圳市南山区人民法院", "杭州市西湖区人民法院", "南京市鼓楼区人民法院",
    "成都市武侯区人民法院", "武汉市武昌区人民法院", "北京市海淀区人民法院",
    "北京市第三中级人民法院", "上海市第一中级人民法院", "广州市中级人民法院",
    "深圳市中级人民法院", "浙江省高级人民法院", "江苏省中级人民法院",
    "北京市第一中级人民法院", "广东省高级人民法院", "四川省中级人民法院",
]

CASE_REASONS = [
    "合同纠纷", "劳动争议", "买卖合同纠纷", "借款合同纠纷", "股权转让纠纷",
    "侵权责任纠纷", "知识产权纠纷", "建设工程合同纠纷", "房屋租赁合同纠纷",
    "金融借款合同纠纷", "信用卡纠纷", "民间借贷纠纷", "劳动争议仲裁",
    "不正当竞争纠纷", "股东损害公司债权人利益责任纠纷", "保证合同纠纷",
]


def _gen_keyno():
    return hashlib.md5(str(uuid.uuid4()).encode()).hexdigest()[:32]


def _gen_credit_code():
    prefix = "91"
    area = str(random.randint(110000, 659999))
    org = str(random.randint(10000000, 99999999))
    check = random.choice("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    return f"{prefix}{area}{org}{check}"


def _gen_date(start_year=2015, end_year=2025):
    y = random.randint(start_year, end_year)
    m = random.randint(1, 12)
    d = random.randint(1, 28)
    return f"{y:04d}-{m:02d}-{d:02d}"


def _gen_cn_date(start_year=2019, end_year=2024):
    """生成中文日期格式，如 2022年3月15日，供 744 ActionRemark 使用"""
    y = random.randint(start_year, end_year)
    m = random.randint(1, 12)
    d = random.randint(1, 28)
    return f"{y}年{m}月{d}日"


def _gen_datetime(start_year=2018, end_year=2025):
    return _gen_date(start_year, end_year) + f" {random.randint(8,17):02d}:{random.randint(0,59):02d}:00"


def _gen_amount(min_val=1000, max_val=10000000):
    return str(round(random.uniform(min_val, max_val), 2))


def _gen_case_no(year=None):
    if year is None:
        year = random.randint(2018, 2025)
    court_code = random.randint(1000, 9999)
    case_type = random.choice(["民初", "民终", "执", "执恢", "破申"])
    seq = random.randint(100, 99999)
    return f"（{year}）京{court_code}{case_type}{seq}号"


def _gen_order_number(prefix=""):
    ts = time.strftime("%Y%m%d%H%M%S")
    rand = str(random.randint(100000, 999999))
    return f"{prefix}{ts}{rand}"


# ======================== API 2003: 客户身份识别 (KYC) ========================

def generate_kyc_data(search_key):
    """生成 KYC 客户身份识别数据（非分页，返回单条完整数据）"""
    company = random.choice(COMPANY_NAMES)
    province = random.choice(PROVINCES)
    city_info = random.choice(CITIES[province])

    data = {
        "VerifyResult": 1,
        "Data": {
            "KeyNo": _gen_keyno(),
            "Name": company,
            "CreditCode": _gen_credit_code(),
            "OperName": random.choice(PERSON_NAMES),
            "DesignatedRepresentativeList": [
                {"PartnerName": random.choice(COMPANY_NAMES), "DelegatedName": random.choice(PERSON_NAMES)}
                for _ in range(random.randint(1, 3))
            ],
            "Status": random.choice(["存续（在营、开业、在册）", "存续", "在业"]),
            "StartDate": _gen_date(2005, 2020),
            "RegistCapi": f"{random.randint(100, 500000)}万元",
            "RegisteredCapital": str(random.randint(100, 500000)),
            "RegisteredCapitalUnit": "万",
            "RegisteredCapitalCCY": "CNY",
            "RealCapi": f"{random.randint(100, 500000)}万元",
            "PaidUpCapital": str(random.randint(100, 500000)),
            "PaidUpCapitalUnit": "万",
            "PaidUpCapitalCCY": "CNY",
            "OrgNo": f"{random.randint(10000000, 99999999)}-{random.randint(0,9)}",
            "No": str(random.randint(100000000000, 999999999999)),
            "TaxNo": _gen_credit_code(),
            "EconKind": random.choice([
                "有限责任公司（自然人投资或控股）",
                "股份有限公司（上市）",
                "有限责任公司（法人独资）",
            ]),
            "TermStart": _gen_date(2005, 2020),
            "TermEnd": _gen_date(2030, 2050),
            "TaxpayerType": random.choice(["一般纳税人", "小规模纳税人"]),
            "PersonScope": random.choice(["50以下", "50-100", "100-500", "500-1000", "1000-5000", "10000以上"]),
            "InsuredCount": str(random.randint(5, 500)),
            "CheckDate": _gen_date(2022, 2025),
            "AreaCode": str(random.randint(110100, 659999)),
            "Area": {"Province": province, "City": city_info[0], "County": city_info[1]},
            "BelongOrg": f"{city_info[0]}{city_info[1]}市场监督管理局",
            "ImExCode": str(random.randint(1000000000, 9999999999)),
            "Industry": {
                "IndustryCode": random.choice(["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M"]),
                "Industry": random.choice(["信息传输、软件和信息技术服务业", "金融业", "制造业", "建筑业", "批发和零售业"]),
                "SubIndustryCode": str(random.randint(10, 99)),
                "SubIndustry": random.choice(["软件和信息技术服务业", "资本市场服务", "计算机、通信和其他电子设备制造业"]),
                "MiddleCategoryCode": str(random.randint(100, 999)),
                "MiddleCategory": random.choice(["软件开发", "信息系统集成服务", "信息技术咨询服务"]),
                "SmallCategoryCode": str(random.randint(1000, 9999)),
                "SmallCategory": random.choice(["基础软件开发", "支撑软件开发", "应用软件开发"]),
            },
            "EnglishName": f"{company[:4].encode('ascii', 'ignore').decode() or 'MockCo'} Inc.",
            "Address": f"{province}{city_info[0]}{city_info[1]}某某路{random.randint(1,999)}号",
            "AddressPostalCode": str(random.randint(100000, 999999)),
            "AnnualAddress": f"{province}{city_info[0]}{city_info[1]}通信地址{random.randint(1,999)}号",
            "AnnualAddressPostalCode": str(random.randint(100000, 999999)),
            "Scope": "技术开发；技术咨询；技术服务；技术推广；技术转让；软件开发；信息系统集成服务；数据处理；企业管理咨询；经济贸易咨询；市场调查；会议服务；承办展览展示活动。",
            "EntType": random.choice(["0", "1", "5"]),
            "OrgCodeList": [{"PrimaryCode": "100100", "SecondaryCode": "100101"}],
            "ImageUrl": f"https://image.qcc.com/logo/{_gen_keyno()}.jpg",
            "RevokeInfo": {"CancelDate": "", "CancelReason": "", "RevokeDate": "", "RevokeReason": ""},
            "OriginalName": [
                {"Name": f"原{company[:4]}有限公司", "ChangeDate": _gen_date(2010, 2018)}
            ],
            "StockInfo": {"StockNumber": "", "StockType": ""},
            "ContactInfo": {
                "WebSiteList": [f"http://www.{company[:4].lower().encode('ascii','ignore').decode() or 'mock'}.com"],
                "Email": f"contact@{company[:4].lower().encode('ascii','ignore').decode() or 'mock'}.com",
                "MoreEmailList": [{"Email": f"info@{company[:4].encode('ascii','ignore').decode() or 'mock'}.com", "Source": "互联网"}],
                "Tel": f"0{random.randint(10,99)}-{random.randint(10000000,99999999)}",
                "MoreTelList": [{"Tel": f"0{random.randint(10,99)}-{random.randint(10000000,99999999)}", "Source": "2023年报"}],
                "MoreAddressList": [
                    {"Address": f"{province}{city_info[0]}某路{random.randint(1,999)}号", "Type": "注册地址", "Source": "工商官网"}
                ],
            },
            "LongLat": {"Longitude": str(round(random.uniform(100, 125), 10)), "Latitude": str(round(random.uniform(20, 50), 10))},
            "BankInfo": {
                "Bank": f"中国工商银行{city_info[0]}支行",
                "BankAccount": str(random.randint(1000000000, 9999999999)),
                "Name": company,
                "CreditCode": _gen_credit_code(),
                "Address": f"{province}{city_info[0]}某路{random.randint(1,999)}号",
                "Tel": f"0{random.randint(10,99)}-{random.randint(10000000,99999999)}",
            },
            "IsSmall": random.choice(["0", "1"]),
            "Scale": random.choice(["L", "M", "S", "XS"]),
            "QccIndustry": {"AName": "科技", "BName": "信息技术", "CName": "软件", "DName": "企业服务"},
            "CompanyType": random.choice(["1", "2", "5", "6"]),
            "FinancialInstitutionType": "",
            "MainProductList": ["企业大数据服务", "智能风控平台", "数据中台"],
            "PartnerList": [
                {
                    "KeyNo": _gen_keyno(), "StockName": random.choice(PERSON_NAMES),
                    "StockType": random.choice(["自然人股东", "企业法人股东"]),
                    "StockPercent": f"{round(random.uniform(5, 60), 4)}%",
                    "ShouldCapi": str(random.randint(100, 50000)),
                    "SubscribedCapital": str(random.randint(100, 50000)),
                    "SubscribedCapitalUnit": "万", "SubscribedCapitalCCY": "CNY",
                    "ShoudDate": _gen_date(2010, 2022), "StakeDate": _gen_date(2005, 2015),
                    "CreditCode": "", "Area": "中国",
                    "SubscribedList": [
                        {"ContributionType": "货币", "Capital": str(random.randint(100, 50000)), "Date": _gen_date(2015, 2023)}
                    ],
                }
                for _ in range(random.randint(2, 5))
            ],
            "PubPartnerList": [
                {
                    "StockName": random.choice(PERSON_NAMES),
                    "StockPercent": f"{round(random.uniform(5, 40), 2)}%",
                    "HoldType": random.choice(["0", "1"]),
                    "Amount": str(random.randint(100000, 999999999)),
                    "SubscribedCapital": "", "SubscribedCapitalUnit": "", "SubscribedCapitalCCY": "",
                    "SubscriptionDate": _gen_date(2020, 2024), "CreditCode": "", "Area": "",
                }
                for _ in range(random.randint(1, 3))
            ],
            "EmployeeList": [
                {"KeyNo": _gen_keyno(), "Name": random.choice(PERSON_NAMES), "Job": random.choice(["董事长,经理,法定代表人", "监事", "董事", "总经理"])}
                for _ in range(random.randint(3, 8))
            ],
            "PubEmployeeList": [
                {"Name": random.choice(PERSON_NAMES), "Job": random.choice(["监事会主席", "独立董事", "财务总监"])}
                for _ in range(random.randint(1, 3))
            ],
            "BranchList": [
                {
                    "KeyNo": _gen_keyno(), "Name": f"{company[:6]}分公司",
                    "CreditCode": _gen_credit_code(), "OperName": random.choice(PERSON_NAMES),
                    "StartDate": _gen_date(2015, 2023), "Status": "存续",
                    "Area": {"Province": random.choice(PROVINCES), "City": city_info[0], "County": city_info[1]},
                }
                for _ in range(random.randint(1, 3))
            ],
            "ChangeList": [
                {
                    "ProjectName": random.choice(["经营范围变更", "注册资本变更", "法定代表人变更", "股东变更"]),
                    "ChangeDate": _gen_date(2018, 2024),
                    "BeforeList": ["变更前内容A", "变更前内容B"],
                    "AfterList": ["变更后内容A", "变更后内容B"],
                    "ChangeSubject": "工商变更",
                }
                for _ in range(random.randint(1, 3))
            ],
            "TagList": [{"Type": "99", "Name": "曾用名"}, {"Type": "208", "Name": "投资机构"}],
            "Parent": {"KeyNo": _gen_keyno(), "Name": f"中{company[:3]}集团有限公司", "OperName": random.choice(PERSON_NAMES), "StartDate": _gen_date(2000, 2015), "Status": "存续", "RegistCapi": f"{random.randint(10000,100000)}万元"},
            "BeneficiaryList": [
                {"KeyNo": _gen_keyno(), "Name": random.choice(PERSON_NAMES), "FinalBenefitPercent": f"{round(random.uniform(25, 80), 4)}%", "Reason": "穿透识别出直接或间接拥有超过25%公司股权或者表决权的自然人"}
            ],
            "ActualControllerList": [
                {"KeyNo": _gen_keyno(), "Name": random.choice(PERSON_NAMES), "FinalBenefitPercent": f"{round(random.uniform(30, 80), 4)}%", "ControlPercent": f"{round(random.uniform(30, 80), 4)}%", "IsActual": "1"}
            ],
            "EmergingIndustyList": [],
            "GroupInfo": {"GroupId": _gen_keyno(), "Name": f"{company[:4]}集团", "Logo": f"https://image.qcc.com/group/{_gen_keyno()}.jpg"},
            "InvestmentList": [
                {
                    "KeyNo": _gen_keyno(), "Name": f"深圳{random.choice(COMPANY_NAMES)[:6]}有限公司",
                    "StartDate": _gen_date(2015, 2023), "Status": "存续",
                    "FundedRatio": f"{round(random.uniform(10, 100), 2)}%",
                    "ShouldCapi": f"{random.randint(100, 10000)}万元",
                    "SubscribedCapital": str(random.randint(100, 10000)),
                    "SubscribedCapitalUnit": "万", "SubscribedCapitalCCY": "CNY",
                    "Industry": {"IndustryCode": "I", "Industry": "信息传输、软件和信息技术服务业", "SubIndustryCode": "65", "SubIndustry": "软件和信息技术服务业", "MiddleCategoryCode": "651", "MiddleCategory": "软件开发", "SmallCategoryCode": "6511", "SmallCategory": "基础软件开发"},
                    "Area": {"Province": "广东省", "City": "深圳市", "County": "南山区"},
                }
                for _ in range(random.randint(2, 5))
            ],
            "ProductList": [
                {"Name": "企业风控平台", "StartDate": _gen_date(2018, 2022), "RoundDesc": "A轮", "Location": "北京", "Description": "基于大数据的企业风险管理平台"}
            ],
            "AdminLicenseList": [
                {"LicensDocNo": f"京网文〔{random.randint(2020,2025)}〕{random.randint(1000,9999)}号", "LicensDocName": "网络文化经营许可证", "ValidityFrom": _gen_date(2022, 2024), "ValidityTo": _gen_date(2025, 2028), "LicensOffice": f"{city_info[0]}文化和旅游局", "LicensContent": "经营性互联网文化单位审批", "Source": "信用中国"}
            ],
            "ApproveSiteList": [
                {"Name": company, "WebAddress": f"www.{company[:4].encode('ascii','ignore').decode() or 'mock'}.com", "DomainName": f"{company[:4].encode('ascii','ignore').decode() or 'mock'}.com", "LesenceNo": f"京ICP备{random.randint(10000000,99999999)}号-1", "AuditDate": _gen_date(2020, 2024)}
            ],
            "SpotCheckList": [
                {"ExecutiveOrg": f"{city_info[1]}市场监督管理局", "Type": "检查", "Date": _gen_date(2022, 2024), "Consequence": "符合"}
            ],
            "TaxCreditList": [
                {"TaxNo": _gen_credit_code(), "Year": str(random.randint(2020, 2024)), "Level": random.choice(["A", "B", "M"]), "Org": "国家税务总局"}
            ],
            "FinancialInformation": {"AccountTitle": "营业收入", "Amount": f"{round(random.uniform(1, 100), 2)}亿元", "Year": str(random.randint(2022, 2024))},
            "IndustryChainList": [
                {"IndustryChainName": "大数据", "NodeList": [{"NodeName": "企业大数据", "RelevanceLevel": "强"}, {"NodeName": "人工智能", "RelevanceLevel": "较强"}]}
            ],
        },
    }
    return data


# ======================== API 255: 资质证书 ========================

CERT_TYPES = ["000001", "000002", "000003", "000004", "000005"]
CERT_TYPE_DESCS = {
    "000001": "强制性产品认证(CCC)", "000002": "管理体系认证",
    "000003": "服务认证", "000004": "自愿性产品认证", "000005": "信息安全认证",
}
CERT_NAMES = [
    # IT/管理体系认证（非工程资质，ETL 过滤后不计入）
    "ISO9001质量管理体系认证", "ISO14001环境管理体系认证", "ISO27001信息安全管理体系认证",
    "CMMI 5级认证", "ITSS信息技术服务标准", "高新技术企业证书",
    "安全生产许可证", "信息系统集成及服务资质",
    "软件企业认定证书", "信息系统安全等级保护", "CCC强制性产品认证",
    "计算机信息系统集成资质",
    # 建筑工程类资质（ETL isQualRelated=True，用于测试等级提取）
    "建筑业企业资质 特级", "建筑业企业资质 一级", "建筑业企业资质 二级", "建筑业企业资质 三级",
    "建设工程施工总承包资质 甲级", "建设工程施工总承包资质 乙级",
    "建设工程监理资质 甲级", "建设工程监理资质 乙级",
    "工程设计资质 甲级", "工程勘察资质 乙级",
    "安防工程企业资质 一级", "安防工程企业资质 二级",
    "电子与智能化工程专业承包 一级",
]
CERT_STATUSES = ["有效", "已过期", "暂停", "撤销"]
INSTITUTIONS = [
    "中国质量认证中心", "方圆标志认证集团", "兴源认证中心有限公司",
    "北京中大华远认证中心", "上海质量体系审核中心", "深圳华测检测技术有限公司",
]

def _gen_cert_records(count=50):
    records = []
    for i in range(count):
        ctype = random.choice(CERT_TYPES)
        records.append({
            "Id": _gen_keyno(),
            "Name": random.choice(CERT_NAMES),
            "Type": ctype,
            "StartDate": _gen_date(2018, 2023),
            "EndDate": _gen_date(2024, 2028),
            "No": f"CERT{random.randint(10000000, 99999999)}{random.randint(1000, 9999)}",
            "TypeDesc": CERT_TYPE_DESCS.get(ctype, "其他认证"),
            "InstitutionList": [random.choice(INSTITUTIONS)],
            "Status": random.choice(CERT_STATUSES),
        })
    return records


# ======================== API 739: 经营异常核查 ========================

ADD_REASONS = [
    "未依照《企业信息公示暂行条例》第八条规定的期限公示年度报告的",
    "通过登记的住所或者经营场所无法联系的",
    "公示企业信息隐瞒真实情况、弄虚作假的",
    "未按照工商行政管理部门责令的期限公示有关企业信息的",
]
DECISION_OFFICES = [
    "苏州市姑苏区市场监督管理局", "北京市海淀区市场监督管理局",
    "上海市浦东新区市场监督管理局", "深圳市南山区市场监督管理局",
    "杭州市西湖区市场监督管理局", "广州市天河区市场监督管理局",
]

def _gen_exception_records(count=50):
    records = []
    for i in range(count):
        has_remove = random.random() > 0.5
        records.append({
            "AddReason": random.choice(ADD_REASONS),
            "AddDate": _gen_date(2016, 2023),
            "RomoveReason": random.choice(["已补报年度报告并公示", "已办理住所变更登记", ""]) if has_remove else "",
            "RemoveDate": _gen_date(2018, 2024) if has_remove else "",
            "DecisionOffice": random.choice(DECISION_OFFICES),
            "RemoveDecisionOffice": random.choice(DECISION_OFFICES) if has_remove else "",
        })
    return records


# ======================== API 740: 失信核查 ========================

EXECUTE_STATUSES = ["全部未履行", "部分未履行", "全部已履行"]
ACTION_REMARKS = [
    "有履行能力而拒不履行生效法律文书确定义务",
    "违反财产报告制度",
    "伪造证据、暴力、威胁等方法妨碍、抗拒执行",
    "虚假诉讼、虚假仲裁或者以隐匿、转移财产等方法规避执行",
    "违反限制高消费令",
]

def _gen_shixin_records(count=50):
    records = []
    for i in range(count):
        records.append({
            "Id": _gen_keyno(),
            "Liandate": _gen_date(2018, 2024),
            "Anno": _gen_case_no(),
            "Executegov": random.choice(COURT_NAMES),
            "Executestatus": random.choice(EXECUTE_STATUSES),
            "Publicdate": _gen_date(2019, 2025),
            "Executeno": _gen_case_no(random.randint(2017, 2023)),
            "ActionRemark": random.choice(ACTION_REMARKS),
            "Amount": _gen_amount(10000, 50000000),
        })
    return records


# ======================== API 741: 被执行人核查 ========================

def _gen_zhixing_records(count=50):
    records = []
    for i in range(count):
        records.append({
            "Id": _gen_keyno(),
            "Liandate": _gen_date(2018, 2024),
            "Anno": _gen_case_no(),
            "ExecuteGov": random.choice(COURT_NAMES),
            "Biaodi": _gen_amount(100000, 100000000),
            "SuspectedApplicant": random.choice(COMPANY_NAMES + PERSON_NAMES),
        })
    return records


# ======================== API 742: 限制高消费核查 ========================

def _gen_sumptuary_records(count=50):
    records = []
    for i in range(count):
        company = random.choice(COMPANY_NAMES)
        person = random.choice(PERSON_NAMES)
        records.append({
            "Id": _gen_keyno(),
            "CaseNo": _gen_case_no(),
            "PersonName": person,
            "PersonId": _gen_keyno(),
            "JudgeDate": _gen_date(2018, 2024),
            "PublishDate": _gen_date(2019, 2025),
            "KeyNo": _gen_keyno(),
            "CompanyName": company,
            "Applicant": random.choice(COMPANY_NAMES + PERSON_NAMES),
            "ApplicantNo": _gen_keyno(),
            "Amount": _gen_amount(10000, 100000000),
            "ExecuteCourt": random.choice(COURT_NAMES),
        })
    return records


# ======================== API 744: 司法拍卖核查 ========================

def _gen_judicial_sale_records(count=50):
    auction_items = [
        "名下的房产", "名下的车辆", "名下的股权", "名下的机器设备",
        "名下的土地使用权", "名下的库存商品", "名下的知识产权",
        "名下的名人字画", "名下的办公设备", "名下的商铺",
    ]
    records = []
    for i in range(count):
        company = random.choice(COMPANY_NAMES)
        yi_wu = random.randint(1000, 10000000)
        records.append({
            "Id": _gen_keyno(),
            "Name": f"{company[:6]}{random.choice(auction_items)}",
            "CaseNo": _gen_case_no(),
            "Executegov": random.choice(COURT_NAMES),
            "ActionRemark": f"{_gen_cn_date(2019, 2024)}上午10时至{_gen_cn_date(2019, 2024)}上午10时止",
            "YiWu": str(yi_wu),
            "EvaluationPrice": str(yi_wu + random.randint(0, 1000000)),
        })
    return records


# ======================== API 746: 环保处罚核查 ========================

PUNISH_GOVS = [
    "北京市延庆区生态环境局", "上海市生态环境局", "广州市生态环境局",
    "深圳市生态环境局", "杭州市生态环境局", "南京市生态环境局",
    "成都市生态环境局", "武汉市生态环境局",
]

def _gen_env_punishment_records(count=50):
    records = []
    for i in range(count):
        records.append({
            "Id": _gen_keyno(),
            "CaseNo": f"环环保监察罚字〔{random.randint(2018, 2024)}〕{random.randint(100, 999)}号",
            "PunishDate": _gen_date(2018, 2024),
            "IllegalType": "",
            "PunishGov": random.choice(PUNISH_GOVS),
            "PunishAmt": str(random.randint(1000, 500000)),
        })
    return records


# ======================== API 748: 严重违法核查 ========================

ILLEGAL_REASONS = [
    "被列入经营异常名录届满3年仍未履行相关义务的",
    "提交虚假材料或者采取其他欺诈手段隐瞒重要事实，取得公司登记的",
    "虚假出资的",
    "利用公司名义从事危害国家安全、社会公共利益的严重违法行为的",
]

def _gen_serious_illegal_records(count=50):
    records = []
    for i in range(count):
        has_remove = random.random() > 0.6
        records.append({
            "Type": "",
            "AddReason": random.choice(ILLEGAL_REASONS),
            "AddDate": _gen_date(2015, 2022),
            "AddOffice": random.choice(["山东省工商行政管理局", "北京市工商行政管理局", "上海市市场监督管理局", "广东省市场监督管理局"]),
            "RemoveReason": random.choice(["已纠正违法行为", ""]) if has_remove else "",
            "RemoveDate": _gen_date(2020, 2024) if has_remove else "",
            "RemoveOffice": random.choice(["山东省市场监督管理局", "北京市市场监督管理局"]) if has_remove else "",
        })
    return records


# ======================== API 751: 股权出质核查 ========================

def _gen_equity_pledged_records(count=50):
    records = []
    for i in range(count):
        pledgor = random.choice(PERSON_NAMES + COMPANY_NAMES)
        pledgee = random.choice(COMPANY_NAMES)
        target = random.choice(COMPANY_NAMES)
        records.append({
            "Id": _gen_keyno(),
            "RegistNo": f"股质登记字〔{random.randint(2018, 2024)}〕{random.randint(1000, 9999)}号",
            "PledgorName": pledgor,
            "PledgeeName": pledgee,
            "RegDate": _gen_date(2018, 2024),
            "Status": random.choice(["有效", "无效", "已注销"]),
            "RelatedCompanyName": target,
            "PledgedAmount": f"{random.randint(100, 50000)}万股",
            "PledgeeList": [{"Name": pledgee, "KeyNo": _gen_keyno()}],
            "PledgorList": [{"Name": pledgor, "KeyNo": _gen_keyno()}],
        })
    return records


# ======================== API 752: 股权冻结核查 ========================

def _gen_equity_freeze_records(count=50):
    records = []
    for i in range(count):
        execute_name = random.choice(COMPANY_NAMES + PERSON_NAMES)
        records.append({
            "Id": _gen_keyno(),
            "ExecuteName": execute_name,
            "ExecuteKeyNo": _gen_keyno(),
            "EquityAmount": f"{random.randint(10, 10000)}万元人民币",
            "ExecuteCourt": random.choice(COURT_NAMES),
            "ExecutionNoticeNum": f"（{random.randint(2018, 2024)}）法执字第{random.randint(100, 9999)}号",
            "Status": random.choice(["股权冻结|冻结", "股权冻结|解冻"]),
            "RelatedInfo": {"KeyNo": _gen_keyno(), "Name": random.choice(COMPANY_NAMES)},
            "FreezeStartDate": _gen_date(2018, 2023),
            "FreezeEndDate": _gen_date(2024, 2028),
        })
    return records


# ======================== API 756: 税收违法核查 ========================

TAX_GOVS = [
    "国家税务总局北京市税务局", "国家税务总局上海市税务局",
    "国家税务总局广州市税务局", "国家税务总局深圳市税务局",
    "国家税务总局杭州市税务局", "国家税务总局南京市税务局",
]
CASE_NATURES = [
    "经税务机关检查确认走逃（失联）",
    "偷税",
    "逃避追缴欠税",
    "骗取出口退税",
    "虚开增值税专用发票",
]

def _gen_tax_illegal_records(count=50):
    records = []
    for i in range(count):
        amt = round(random.uniform(1, 100), 2)
        fine = round(amt * random.uniform(0.5, 2), 2)
        records.append({
            "Id": _gen_keyno(),
            "PublishDate": _gen_date(2018, 2024),
            "CaseNature": random.choice(CASE_NATURES),
            "TaxGov": random.choice(TAX_GOVS),
            "IllegalContent": f"该纳税人在{random.randint(2016, 2022)}年至{random.randint(2019, 2023)}年期间存在税收违法行为。",
            "PunishContent": f"依照《中华人民共和国税收征收管理法》等相关法律法规的有关规定，对其处以追缴税款{amt}万元的行政处理、处以罚款{fine}万元的行政处罚。",
        })
    return records


# ======================== API 757: 欠税公告核查 ========================

TAX_TYPES = ["增值税", "企业所得税", "个人所得税", "城市维护建设税", "房产税", "印花税", "土地增值税", "城镇土地使用税"]
ISSUED_BYS = [
    "北京市国家税务局", "上海市国家税务局", "广州市地方税务局",
    "深圳市国家税务局", "杭州市国家税务局", "南京市地方税务局",
]

def _gen_tax_owe_records(count=50):
    records = []
    for i in range(count):
        amount = round(random.uniform(1000, 5000000), 2)
        records.append({
            "Id": _gen_keyno(),
            "Title": random.choice(TAX_TYPES),
            "Amount": str(amount),
            "NewAmount": str(round(random.uniform(0, amount * 0.1), 2)),
            "PublishDate": _gen_date(2017, 2024),
            "IssuedBy": random.choice(ISSUED_BYS),
        })
    return records


# ======================== API 758: 终本案件核查 ========================

def _gen_end_execute_records(count=50):
    records = []
    for i in range(count):
        subject = random.randint(100000, 10000000)
        unperformed = random.randint(10000, subject)
        records.append({
            "Id": _gen_keyno(),
            "CaseNo": _gen_case_no(),
            "Court": random.choice(COURT_NAMES),
            "EndDate": _gen_date(2018, 2024),
            "LianDate": _gen_date(2016, 2022),
            "ExecuteSubject": str(subject),
            "UnperformedAmt": str(unperformed),
        })
    return records


# ======================== API 761: 破产重整核查 ========================

def _gen_bankruptcy_records(count=50):
    records = []
    for i in range(count):
        records.append({
            "Id": _gen_keyno(),
            "CaseNo": f"（{random.randint(2018, 2024)}）{random.choice(['浙', '京', '沪', '粤', '苏'])}{random.randint(1000, 9999)}破申{random.randint(10, 999)}号",
            "PublicDate": _gen_date(2018, 2024),
            "ApplicantList": [
                {"Name": random.choice(COMPANY_NAMES), "KeyNo": _gen_keyno()}
                for _ in range(random.randint(1, 2))
            ],
            "RespondentList": [
                {"Name": random.choice(COMPANY_NAMES), "KeyNo": _gen_keyno()}
                for _ in range(random.randint(1, 2))
            ],
        })
    return records


# ======================== 董监高 APIs (764/765/766/767/768/771) ========================
# 这些接口需要额外的 personName 参数，数据结构与企业版类似

def _gen_person_shixin_records(count=50):
    """764: 失信被执行核查【董监高】"""
    records = []
    for i in range(count):
        records.append({
            "Id": _gen_keyno(),
            "Liandate": _gen_date(2018, 2024),
            "Anno": _gen_case_no(),
            "Executegov": random.choice(COURT_NAMES),
            "Executestatus": random.choice(EXECUTE_STATUSES),
            "Publicdate": _gen_date(2019, 2025),
            "Executeno": _gen_case_no(random.randint(2017, 2023)),
            "ActionRemark": random.choice(ACTION_REMARKS),
            "Amount": _gen_amount(10000, 100000000),
        })
    return records


def _gen_person_zhixing_records(count=50):
    """765: 被执行人核查【董监高】"""
    records = []
    for i in range(count):
        records.append({
            "Id": _gen_keyno(),
            "Liandate": _gen_date(2018, 2024),
            "Anno": _gen_case_no(),
            "ExecuteGov": random.choice(COURT_NAMES),
            "Biaodi": _gen_amount(100000, 500000000),
            "SuspectedApplicant": random.choice(COMPANY_NAMES + PERSON_NAMES),
        })
    return records


def _gen_person_sumptuary_records(count=50):
    """766: 限制高消费核查【董监高】"""
    records = []
    for i in range(count):
        company = random.choice(COMPANY_NAMES)
        person = random.choice(PERSON_NAMES)
        records.append({
            "Id": _gen_keyno(),
            "CaseNo": _gen_case_no(),
            "LimitObject": company,
            "LimitObjectKeyNo": _gen_keyno(),
            "RelatedName": person,
            "RelatedKeyNo": _gen_keyno(),
            "JudgeDate": _gen_date(2018, 2024),
            "PublishDate": _gen_date(2019, 2025),
            "Applicant": random.choice(COMPANY_NAMES + PERSON_NAMES),
            "ApplicantKeyNo": _gen_keyno(),
        })
    return records


def _gen_person_freeze_records(count=50):
    """767: 股权冻结核查【董监高】"""
    records = []
    for i in range(count):
        records.append({
            "Id": _gen_keyno(),
            "ExecuteName": random.choice(PERSON_NAMES),
            "ExecuteKeyNo": _gen_keyno(),
            "EquityAmount": f"{random.randint(10, 100000)}万元人民币",
            "ExecuteCourt": random.choice(COURT_NAMES),
            "ExecutionNoticeNum": f"（{random.randint(2018, 2024)}）{random.choice(['晋', '京', '沪', '浙'])}xx执xxx号",
            "Status": random.choice(["股权冻结|冻结", "股权冻结|解冻"]),
            "FreezeStartDate": _gen_date(2018, 2023),
            "FreezeEndDate": _gen_date(2024, 2028),
            "RelatedInfo": {"KeyNo": _gen_keyno(), "Name": random.choice(COMPANY_NAMES)},
        })
    return records


def _gen_person_pledged_records(count=50):
    """768: 股权出质核查【董监高】"""
    records = []
    for i in range(count):
        pledgor = random.choice(PERSON_NAMES)
        pledgee = random.choice(COMPANY_NAMES)
        records.append({
            "Id": _gen_keyno(),
            "RegistNo": f"股质登记字〔{random.randint(2018, 2024)}〕{random.randint(1000, 9999)}号",
            "PledgorName": pledgor,
            "PledgeeName": pledgee,
            "PledgedAmount": f"{random.randint(100, 50000)}万股",
            "RegDate": _gen_date(2018, 2024),
            "Status": random.choice(["有效", "无效", "已注销"]),
            "RelatedCompanyName": random.choice(COMPANY_NAMES),
        })
    return records


def _gen_person_end_ex_records(count=50):
    """771: 终本案件核查【董监高】"""
    records = []
    for i in range(count):
        subject = random.randint(100000, 1000000000)
        unperformed = random.randint(10000, subject)
        records.append({
            "Id": _gen_keyno(),
            "CaseNo": _gen_case_no(),
            "Court": random.choice(COURT_NAMES),
            "EndDate": _gen_date(2018, 2024),
            "LianDate": _gen_date(2016, 2022),
            "ExecuteSubject": str(subject),
            "UnperformedAmt": str(unperformed),
        })
    return records


# ======================== API 865: 行政处罚核查 ========================

PENALTY_OFFICES = [
    "北京市住房和城乡建设局", "上海市城市管理行政执法局",
    "广州市市场监督管理局", "深圳市交通运输局",
    "杭州市环境保护局", "南京市安全生产监督管理局",
    "成都市食品药品监督管理局", "武汉市工商行政管理局",
]

def _gen_admin_penalty_records(count=50):
    penalty_reasons = [
        "未取得施工许可证擅自施工", "超标排放污染物",
        "生产安全事故", "无证经营", "虚假宣传",
        "未按规定进行安全评估", "违反消防法规",
        "未依法进行招投标", "偷工减料", "违反劳动保障法规",
    ]
    records = []
    for i in range(count):
        amt = round(random.uniform(100, 500000), 2)
        records.append({
            "Id": _gen_keyno(),
            "DocNo": f"罚字〔{random.randint(2018, 2024)}〕第{random.randint(1000, 9999)}号",
            "PunishReason": random.choice(penalty_reasons),
            "PunishResult": f"罚款人民币{amt}元",
            "PunishOffice": random.choice(PENALTY_OFFICES),
            "PunishDate": _gen_date(2018, 2024),
            "Source": random.choice(["工商局", "信用中国", "生态环境局", "住建局"]),
            "SourceCode": "",
            "PunishAmt": str(amt),
        })
    return records


# ======================== API 882: 法院公告核查 ========================

CATEGORIES = [
    "起诉状、上诉状副本", "开庭公告", "裁判文书", "送达公告",
    "破产文书", "执行文书", "申请公示催告", "遗失声明",
]

def _gen_court_notice_records(count=50):
    records = []
    for i in range(count):
        prosecutor = random.choice(COMPANY_NAMES)
        defendant = random.choice(COMPANY_NAMES)
        records.append({
            "Id": _gen_keyno(),
            "CaseNo": _gen_case_no(),
            "CaseReason": random.choice(CASE_REASONS),
            "Category": random.choice(CATEGORIES),
            "Court": random.choice(COURT_NAMES),
            "PublishDate": _gen_date(2018, 2024),
            "ProsecutorList": [{"KeyNo": _gen_keyno(), "Name": prosecutor}],
            "DefendantList": [{"KeyNo": _gen_keyno(), "Name": defendant}],
            "RoleList": [
                {"RoleType": "0", "RoleName": "原告/上诉人", "RoleItemList": [{"KeyNo": _gen_keyno(), "Name": prosecutor}]},
                {"RoleType": "1", "RoleName": "被告/被上诉人", "RoleItemList": [{"KeyNo": _gen_keyno(), "Name": defendant}]},
            ],
        })
    return records


# ======================== API 887: 裁判文书核查 ========================

CASE_TYPES = ["ms", "zx", "xz", "xs", "zscq", "pc"]
CASE_TYPE_NAMES = {"ms": "民事", "zx": "执行", "xz": "行政", "xs": "刑事", "zscq": "知识产权", "pc": "赔偿"}

def _gen_judgment_doc_records(count=50):
    records = []
    for i in range(count):
        case_type = random.choice(CASE_TYPES)
        records.append({
            "Id": _gen_keyno(),
            "CaseName": f"{random.choice(PERSON_NAMES)}与{random.choice(COMPANY_NAMES)}{random.choice(CASE_REASONS)}一审民事判决书",
            "CaseReason": random.choice(CASE_REASONS),
            "CaseNo": _gen_case_no(),
            "Amount": _gen_amount(1000, 5000000),
            "IsProsecutor": random.choice(["true", "false"]),
            "IsDefendant": random.choice(["true", "false"]),
            "JudgeResult": f"一、被告于本判决生效之日起十日内支付原告{round(random.uniform(1000, 1000000), 2)}元。\n二、驳回原告的其他诉讼请求。",
            "JudgeDate": _gen_date(2018, 2024),
            "PublishDate": _gen_date(2019, 2025),
            "PartyList": [
                {"Name": random.choice(PERSON_NAMES), "RoleType": "原告", "Statement": random.choice(["胜诉", "对方撤诉", ""]), "Keyno": _gen_keyno()},
                {"Name": random.choice(PERSON_NAMES), "RoleType": "被告", "Statement": "", "Keyno": _gen_keyno()},
            ],
            "CaseType": case_type,
        })
    return records


# ======================== API 888: 开庭公告核查 ========================

def _gen_court_anno_records(count=50):
    records = []
    for i in range(count):
        plaintiff = random.choice(COMPANY_NAMES + PERSON_NAMES)
        defendant = random.choice(COMPANY_NAMES + PERSON_NAMES)
        records.append({
            "Id": _gen_keyno(),
            "CaseNo": _gen_case_no(),
            "CaseReason": random.choice(CASE_REASONS),
            "Court": random.choice(COURT_NAMES),
            "CourtTime": _gen_datetime(2023, 2026),
            "PartyList": [
                {"Name": plaintiff, "RoleType": "2", "Keyno": _gen_keyno()},
                {"Name": defendant, "RoleType": "1", "Keyno": _gen_keyno()},
            ],
            "RoleList": [
                {"RoleType": "0", "RoleName": "原告", "RoleItemList": [{"KeyNo": _gen_keyno(), "Name": plaintiff}]},
                {"RoleType": "1", "RoleName": "被告", "RoleItemList": [{"KeyNo": _gen_keyno(), "Name": defendant}]},
            ],
        })
    return records


# ======================== API 958: 招投标信息 ========================

CHANNEL_NAMES = ["采购公告公示", "中标公告", "竞争性谈判", "单一来源采购", "询价采购"]
INDUSTRY_DESCS = ["工程建筑", "信息技术", "医疗卫生", "教育科研", "交通运输", "水利工程", "环保绿化"]
BID_PROGRESS = [["招标公告", "询价", "评标", "中标公告"], ["招标公告", "竞争性谈判", "结果公示"], ["招标公告", "开标", "中标候选人公示"]]

def _gen_tender_records(count=50):
    records = []
    for i in range(count):
        province = random.choice(PROVINCES)
        city_info = random.choice(CITIES[province])
        records.append({
            "Id": _gen_keyno(),
            "Title": f"{random.choice(['信息系统建设', '设备采购', '工程监理', '软件开发', '数据中心建设', '网络安全服务', '平台升级'])}采购公告",
            "ProjectNo": f"WHYX-{random.choice(['GC', 'IT', 'FW'])}-{random.choice(['GKXJ', 'JZXTP', 'DYLY'])}-{random.randint(20, 25):02d}-{random.randint(1000, 9999)}",
            "ChannelName": random.choice(CHANNEL_NAMES),
            "Province": province,
            "City": city_info[0],
            "IndustryDesc": random.choice(INDUSTRY_DESCS),
            "BudgetAmt": str(random.randint(100000, 50000000)),
            "PublishDate": _gen_date(2020, 2025),
            "OpenDate": _gen_date(2021, 2025),
            "ObtainEndDate": _gen_date(2021, 2025),
            "BidInviUnitList": [
                {"KeyNo": _gen_keyno(), "Name": random.choice(COMPANY_NAMES), "Contact": random.choice(PERSON_NAMES), "TelNo": f"0{random.randint(10,99)}-{random.randint(10000000,99999999)}"}
            ],
            "WinBidUnitList": (
                [{"WinBidAmt": str(random.randint(100000, 50000000)), "KeyNo": _gen_keyno(), "Name": random.choice(COMPANY_NAMES), "Contact": random.choice(PERSON_NAMES), "TelNo": f"0{random.randint(10,99)}-{random.randint(10000000,99999999)}"}]
                if random.random() > 0.3 else []
            ),
            "AgentUnitList": (
                [{"KeyNo": _gen_keyno(), "Name": random.choice(COMPANY_NAMES), "Contact": random.choice(PERSON_NAMES), "TelNo": f"0{random.randint(10,99)}-{random.randint(10000000,99999999)}"}]
                if random.random() > 0.5 else []
            ),
            "BidProgressList": random.choice(BID_PROGRESS),
            "BidEndDate": _gen_datetime(2021, 2025),
            "ContentUrl": f"https://www.example.com/tender/{_gen_keyno()}",
            "ContractEndTime": _gen_date(2023, 2027),
        })
    return records


# ======================== API 980: 清算核查 ========================

def _gen_liquidation_data():
    """生成清算核查数据（非分页，返回单条数据）"""
    members = random.sample(PERSON_NAMES, random.randint(2, 5))
    return {
        "VerifyResult": 1,
        "Data": {
            "Leader": random.choice(members),
            "Member": ";".join(members),
        },
    }


# ======================== 数据注册表 ========================
# 每个 API 对应的数据生成函数和分页标识

MOCK_DATA_REGISTRY = {
    # code: (generator_func, is_paginated, prefix_for_order_number)
    "2003": {"generator": None, "paginated": False, "prefix": "ENTERPRISEINFO", "type": "kyc"},
    "255":  {"generator": _gen_cert_records, "paginated": True, "prefix": "ECICERTIFICATION"},
    "739":  {"generator": _gen_exception_records, "paginated": False, "prefix": "EXCEPTIONCHECK", "list_wrapper": True},
    "740":  {"generator": _gen_shixin_records, "paginated": True, "prefix": "SHIXINCHECK"},
    "741":  {"generator": _gen_zhixing_records, "paginated": True, "prefix": "ZHIXINGCHECK"},
    "742":  {"generator": _gen_sumptuary_records, "paginated": True, "prefix": "SUMPTUARYCHECK"},
    "744":  {"generator": _gen_judicial_sale_records, "paginated": True, "prefix": "JUDICIALSALECHECK"},
    "746":  {"generator": _gen_env_punishment_records, "paginated": True, "prefix": "ENVPUNISHMENTCHECK"},
    "748":  {"generator": _gen_serious_illegal_records, "paginated": False, "prefix": "SERIOUSILLEGALCHECK", "list_wrapper": True},
    "751":  {"generator": _gen_equity_pledged_records, "paginated": True, "prefix": "EQUITYPLEDGEDCHECK"},
    "752":  {"generator": _gen_equity_freeze_records, "paginated": True, "prefix": "EQUITYFREEZECHECK"},
    "756":  {"generator": _gen_tax_illegal_records, "paginated": True, "prefix": "TAXILLEGALCHECK"},
    "757":  {"generator": _gen_tax_owe_records, "paginated": True, "prefix": "TAXOWENOTICECHECK"},
    "758":  {"generator": _gen_end_execute_records, "paginated": True, "prefix": "ENDEXECUTECASECHECK"},
    "761":  {"generator": _gen_bankruptcy_records, "paginated": True, "prefix": "BANKRUPTCYCHECK"},
    "764":  {"generator": _gen_person_shixin_records, "paginated": True, "prefix": "PERSONSXCHECK"},
    "765":  {"generator": _gen_person_zhixing_records, "paginated": True, "prefix": "PERSONZXCHECK"},
    "766":  {"generator": _gen_person_sumptuary_records, "paginated": True, "prefix": "PERSONSUMPTUARYCHECK"},
    "767":  {"generator": _gen_person_freeze_records, "paginated": True, "prefix": "PERSONSEFREEZECHECK"},
    "768":  {"generator": _gen_person_pledged_records, "paginated": True, "prefix": "PERSONSEPLEDGEDCHECK"},
    "771":  {"generator": _gen_person_end_ex_records, "paginated": True, "prefix": "PERSONENDEXCASECHECK"},
    "865":  {"generator": _gen_admin_penalty_records, "paginated": True, "prefix": "ADMINPENALTYCHECK"},
    "882":  {"generator": _gen_court_notice_records, "paginated": True, "prefix": "COURTNOTICECHECK"},
    "887":  {"generator": _gen_judgment_doc_records, "paginated": True, "prefix": "JUDGMENTDOCCHECK"},
    "888":  {"generator": _gen_court_anno_records, "paginated": True, "prefix": "COURTANNOCHECK"},
    "958":  {"generator": _gen_tender_records, "paginated": True, "prefix": "TENDERCHECK"},
    "980":  {"generator": None, "paginated": False, "prefix": "LIQUIDATIONCHECK", "type": "liquidation"},
}


def get_mock_response(api_code, page_index=1, page_size=10, search_key=""):
    """
    统一获取 Mock 响应数据

    Args:
        api_code: API 编号（字符串）
        page_index: 页码（分页接口有效）
        page_size: 每页条数（分页接口有效）
        search_key: 搜索关键词，用于固定映射（同一 searchKey 始终返回相同数据）

    Returns:
        dict: 完整的 API 响应数据
    """
    config = MOCK_DATA_REGISTRY.get(str(api_code))
    if not config:
        return {
            "Status": "203",
            "Message": "【有效请求】参数异常",
            "OrderNumber": _gen_order_number(),
        }

    order_number = _gen_order_number(config["prefix"])

    with seed_by_search_key(search_key, api_code):
        # 特殊处理 KYC (2003)
        if config.get("type") == "kyc":
            return {
                "Status": "200",
                "Message": "【有效请求】查询成功",
                "OrderNumber": order_number,
                "Result": generate_kyc_data(search_key),
            }

        # 特殊处理清算 (980)
        if config.get("type") == "liquidation":
            return {
                "Status": "200",
                "Message": "【有效请求】查询成功",
                "OrderNumber": order_number,
                "Result": _gen_liquidation_data(),
            }

        # 生成分页数据
        if config["paginated"]:
            all_records = config["generator"](50)
            total = len(all_records)
            start = (page_index - 1) * page_size
            end = start + page_size
            page_records = all_records[start:end]

            return {
                "Status": "200",
                "Message": "【有效请求】查询成功",
                "OrderNumber": order_number,
                "Paging": {
                    "PageSize": page_size,
                    "PageIndex": page_index,
                    "TotalRecords": total,
                },
                "Result": {
                    "VerifyResult": 1 if page_records else 0,
                    "Data": page_records,
                },
            }

        # 非分页的列表接口 (739, 748)
        if config.get("list_wrapper"):
            all_records = config["generator"](50)
            return {
                "Status": "200",
                "Message": "【有效请求】查询成功",
                "OrderNumber": order_number,
                "Result": {
                    "VerifyResult": 1,
                    "Data": all_records,
                },
            }

    return {
        "Status": "200",
        "Message": "【有效请求】查询成功",
        "OrderNumber": order_number,
    }
