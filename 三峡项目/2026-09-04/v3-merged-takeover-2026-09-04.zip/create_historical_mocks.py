# -*- coding: utf-8 -*-
"""
为"超期/历史"场景生成专属 mock 文件，替代已缓存的 测试公司A/B/C。

所有日期均使用 2022-2023 范围，距今 > 90天（基准2026-06-06），
用于验证 earlyStop 行为（期望输出=0）。
"""

import json, os

BASE_DIR = os.path.join(os.path.dirname(__file__), "mock-files")

def write(path_parts, data):
    dir_path = os.path.join(BASE_DIR, *path_parts[:-1])
    os.makedirs(dir_path, exist_ok=True)
    fp = os.path.join(dir_path, path_parts[-1] + ".json")
    with open(fp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"  created: {fp}")

def paging(total=5, page_size=10, page_index=1):
    return {"PageSize": page_size, "PageIndex": page_index, "TotalRecords": total}

COURTS = ["北京市朝阳区人民法院", "上海市浦东新区人民法院", "广州市中级人民法院"]
OLD_DATES = ["2022-08-10", "2022-05-20", "2023-01-15", "2022-11-30", "2023-03-08"]

# ─── 740 历史失信企业（Liandate 2022-2023，全部>90天）───
write(["ShixinCheck", "GetList", "历史失信企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "SHIXINCHECK20260606200000000001",
    "Paging": paging(5),
    "Result": {
        "VerifyResult": 1,
        "Data": [{
            "Id": f"hs740{i:02d}", "Liandate": OLD_DATES[i],
            "Anno": f"（2022）京100{i}执{1000+i}号",
            "Executegov": COURTS[i % 3], "Executestatus": "全部未履行",
            "Publicdate": OLD_DATES[i],
            "Executeno": f"（2022）京100{i}民初{2000+i}号",
            "ActionRemark": "有履行能力而拒不履行", "Amount": str(100000*(i+1)),
        } for i in range(5)],
    },
})

# ─── 741 历史被执行企业 ───
write(["ZhixingCheck", "GetList", "历史被执行企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ZHIXINGCHECK20260606200000000001",
    "Paging": paging(5),
    "Result": {
        "VerifyResult": 1,
        "Data": [{
            "Id": f"hs741{i:02d}", "Liandate": OLD_DATES[i],
            "Anno": f"（2022）京100{i}执{3000+i}号",
            "ExecuteGov": COURTS[i % 3],
            "Biaodi": str(200000*(i+1)),
            "SuspectedApplicant": f"历史申请人{i+1}有限公司",
        } for i in range(5)],
    },
})

# ─── 742 历史限消企业（JudgeDate 2022-2023）───
write(["SumptuaryCheck", "GetList", "历史限消企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "SUMPTUARYCHECK20260606200000000001",
    "Paging": paging(5),
    "Result": {
        "VerifyResult": 1,
        "Data": [{
            "Id": f"hs742{i:02d}",
            "CaseNo": f"（2022）京100{i}执{4000+i}号",
            "PersonName": f"历史限消人员{i+1}",
            "PersonId": f"pid742h{i:02d}",
            "JudgeDate": OLD_DATES[i],
            "PublishDate": OLD_DATES[i],
            "KeyNo": f"kn742h{i:02d}",
            "CompanyName": "历史限消企业",
            "Applicant": f"历史债权人{i+1}",
            "ApplicantNo": f"an742h{i:02d}",
            "Amount": str(300000*(i+1)),
            "ExecuteCourt": COURTS[i % 3],
        } for i in range(5)],
    },
})

# ─── 744 历史司法拍卖企业（ActionRemark 用中文日期，但日期>90天）───
write(["JudicialSaleCheck", "GetList", "历史司法拍卖企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "JUDICIALSALECHECK20260606200000000001",
    "Paging": paging(5),
    "Result": {
        "VerifyResult": 1,
        "Data": [{
            "Id": f"hs744{i:02d}",
            "Name": f"历史司法拍卖企业名下的资产{i+1}",
            "CaseNo": f"（2022）京100{i}执{5000+i}号",
            "Executegov": COURTS[i % 3],
            "ActionRemark": f"2022年{8+i}月{10+i}日上午10时至2022年{8+i}月{11+i}日上午10时止",
            "YiWu": str(500000*(i+1)),
            "EvaluationPrice": str(550000*(i+1)),
        } for i in range(5)],
    },
})

# ─── 746 历史环保处罚企业（PunishDate 2022-2023）───
write(["EnvPunishmentCheck", "GetList", "历史环保处罚企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ENVPUNISHMENTCHECK20260606200000000001",
    "Paging": paging(5),
    "Result": {
        "VerifyResult": 1,
        "Data": [{
            "Id": f"hs746{i:02d}",
            "CaseNo": f"环罚字〔2022〕第{100+i}号",
            "PunishDate": OLD_DATES[i],
            "IllegalType": "",
            "PunishGov": "北京市延庆区生态环境局",
            "PunishAmt": str(10000*(i+1)),
        } for i in range(5)],
    },
})

# ─── 756 历史税收违法企业（PublishDate 2022-2023）───
write(["TaxIllegalCheck", "GetList", "历史税收违法企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "TAXILLEGALCHECK20260606200000000001",
    "Paging": paging(5),
    "Result": {
        "VerifyResult": 1,
        "Data": [{
            "Id": f"hs756{i:02d}",
            "PublishDate": OLD_DATES[i],
            "CaseNature": "偷税",
            "TaxGov": "国家税务总局北京市税务局",
            "IllegalContent": f"历史税收违法内容{i+1}",
            "PunishContent": f"罚款{(i+1)*5}万元",
        } for i in range(5)],
    },
})

# ─── 757 历史欠税企业（PublishDate 2022-2023）───
write(["TaxOweNoticeCheck", "GetList", "历史欠税企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "TAXOWENOTICECHECK20260606200000000001",
    "Paging": paging(5),
    "Result": {
        "VerifyResult": 1,
        "Data": [{
            "Id": f"hs757{i:02d}",
            "Title": ["增值税", "企业所得税", "城建税", "房产税", "印花税"][i],
            "Amount": str(10000*(i+1)),
            "NewAmount": "0",
            "PublishDate": OLD_DATES[i],
            "IssuedBy": "北京市国家税务局",
        } for i in range(5)],
    },
})

# ─── 758 历史终本案件企业（LianDate 2022-2023）───
write(["EndExecuteCaseCheck", "GetList", "历史终本案件企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ENDEXECUTECASECHECK20260606200000000001",
    "Paging": paging(5),
    "Result": {
        "VerifyResult": 1,
        "Data": [{
            "Id": f"hs758{i:02d}",
            "CaseNo": f"（2022）京100{i}执终{6000+i}号",
            "Court": COURTS[0],
            "EndDate": OLD_DATES[i],
            "LianDate": OLD_DATES[i],
            "ExecuteSubject": str(500000*(i+1)),
            "UnperformedAmt": str(400000*(i+1)),
        } for i in range(5)],
    },
})

# ─── 865 历史行政处罚企业（PunishDate 2022-2023）───
write(["AdminPenaltyCheck", "GetList", "历史行政处罚企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ADMINPENALTYCHECK20260606200000000001",
    "Paging": paging(5),
    "Result": {
        "VerifyResult": 1,
        "Data": [{
            "Id": f"hs865{i:02d}",
            "DocNo": f"罚字〔2022〕第{300+i}号",
            "PunishReason": "无证经营",
            "PunishResult": f"罚款{(i+1)*1000}元",
            "PunishOffice": "北京市市场监督管理局",
            "PunishDate": OLD_DATES[i],
            "Source": "市场监督管理局",
            "SourceCode": "",
            "PunishAmt": str((i+1)*1000),
        } for i in range(5)],
    },
})

# ─── 882 非借款类被告企业（CaseReason非借款，PublishDate 2022-2023）───
write(["CourtNoticeCheck", "GetList", "非借款类被告企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "COURTNOTICECHECK20260606200000000001",
    "Paging": paging(4),
    "Result": {
        "VerifyResult": 1,
        "Data": [{
            "Id": f"hs882{i:02d}",
            "CaseNo": f"（2022）京100{i}民初{8000+i}号",
            "CaseReason": ["劳动争议", "买卖合同纠纷", "股权转让纠纷", "知识产权纠纷"][i],
            "Category": "裁判文书",
            "Court": COURTS[0],
            "PublishDate": OLD_DATES[i],
            "ProsecutorList": [{"KeyNo": f"p88{i}", "Name": f"原告方{i+1}"}],
            "DefendantList": [{"KeyNo": f"d88{i}", "Name": "非借款类被告企业"}],
            "RoleList": [
                {"RoleType": "0", "RoleName": "原告/上诉人",
                 "RoleItemList": [{"KeyNo": f"p88{i}", "Name": f"原告方{i+1}"}]},
                {"RoleType": "1", "RoleName": "被告/被上诉人",
                 "RoleItemList": [{"KeyNo": f"d88{i}", "Name": "非借款类被告企业"}]},
            ],
        } for i in range(4)],
    },
})
# 期望：ent3mCourtNoticeLoanDisputeDefendantCntQcc=0（非借款类 + 且都已超90天）

# ─── 888 开庭公告查询企业（部分近90天，验证基本流程）───
write(["CourtAnnoCheck", "GetList", "开庭公告查询企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "COURTANNOCHECK20260606200000000001",
    "Paging": paging(3),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": "ca888_01", "CaseNo": "（2026）京0101民初9001号",
                "CaseReason": "借款合同纠纷",
                "Court": COURTS[0],
                "CourtTime": "2026-05-15 09:00:00",  # 近期，在90天内
                "PartyList": [
                    {"Name": "某银行", "RoleType": "2", "Keyno": "p8881"},
                    {"Name": "开庭公告查询企业", "RoleType": "1", "Keyno": "d8881"},
                ],
                "RoleList": [
                    {"RoleType": "0", "RoleName": "原告",
                     "RoleItemList": [{"KeyNo": "p8881", "Name": "某银行"}]},
                    {"RoleType": "1", "RoleName": "被告",
                     "RoleItemList": [{"KeyNo": "d8881", "Name": "开庭公告查询企业"}]},
                ],
            },
            {
                "Id": "ca888_02", "CaseNo": "（2026）京0101民初9002号",
                "CaseReason": "金融借款合同纠纷",
                "Court": COURTS[0],
                "CourtTime": "2026-04-10 10:00:00",  # 近期，在90天内
                "PartyList": [
                    {"Name": "金融机构", "RoleType": "2", "Keyno": "p8882"},
                    {"Name": "开庭公告查询企业", "RoleType": "1", "Keyno": "d8882"},
                ],
                "RoleList": [
                    {"RoleType": "0", "RoleName": "原告",
                     "RoleItemList": [{"KeyNo": "p8882", "Name": "金融机构"}]},
                    {"RoleType": "1", "RoleName": "被告",
                     "RoleItemList": [{"KeyNo": "d8882", "Name": "开庭公告查询企业"}]},
                ],
            },
            {
                "Id": "ca888_03", "CaseNo": "（2022）京0101民初9003号",
                "CaseReason": "借款合同纠纷",
                "Court": COURTS[0],
                "CourtTime": "2022-08-10 09:00:00",  # 超期，>90天，earlyStop后不计入
                "PartyList": [
                    {"Name": "债权人", "RoleType": "2", "Keyno": "p8883"},
                    {"Name": "开庭公告查询企业", "RoleType": "1", "Keyno": "d8883"},
                ],
                "RoleList": [
                    {"RoleType": "0", "RoleName": "原告",
                     "RoleItemList": [{"KeyNo": "p8883", "Name": "债权人"}]},
                    {"RoleType": "1", "RoleName": "被告",
                     "RoleItemList": [{"KeyNo": "d8883", "Name": "开庭公告查询企业"}]},
                ],
            },
        ],
    },
})
# 期望：ent3mcourtannoloandisputedefendantcntqcc=2（前两条在90天内+借款+被告）

# ─── 739 经营异常检查企业（含未移除的异常记录）───
write(["ExceptionCheck", "GetList", "经营异常检查企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "EXCEPTIONCHECK20260606200000000001",
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "AddReason": "未依照规定公示年度报告",
                "AddDate": "2022-03-01",
                "RomoveReason": "",
                "RemoveDate": "",        # 仍在列 → 计入
                "DecisionOffice": "北京市海淀区市场监督管理局",
                "RemoveDecisionOffice": "",
            },
            {
                "AddReason": "通过登记的住所无法联系",
                "AddDate": "2021-06-15",
                "RomoveReason": "",
                "RemoveDate": "",        # 仍在列 → 计入
                "DecisionOffice": "北京市朝阳区市场监督管理局",
                "RemoveDecisionOffice": "",
            },
            {
                "AddReason": "未依照规定公示年度报告",
                "AddDate": "2020-01-10",
                "RomoveReason": "已补报年度报告",
                "RemoveDate": "2020-08-01",  # 已移除 → 不计入
                "DecisionOffice": "上海市浦东新区市场监督管理局",
                "RemoveDecisionOffice": "上海市浦东新区市场监督管理局",
            },
        ],
    },
})
# 期望：bizabnormalflag=2（RemoveDate为空的2条）

# ─── 748 严重违法在列企业（含RemoveDate为空的记录）───
write(["SeriousIllegalCheck", "GetList", "严重违法在列企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "SERIOUSILLEGALCHECK20260606200000000001",
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Type": "",
                "AddReason": "被列入经营异常名录届满3年仍未履行相关义务的",
                "AddDate": "2021-05-20",
                "AddOffice": "北京市工商行政管理局",
                "RemoveReason": "",
                "RemoveDate": "",       # 仍在列 → 计入
                "RemoveOffice": "",
            },
            {
                "Type": "",
                "AddReason": "提交虚假材料取得公司登记的",
                "AddDate": "2020-03-10",
                "AddOffice": "上海市市场监督管理局",
                "RemoveReason": "已纠正违法行为",
                "RemoveDate": "2023-06-01",  # 已移除 → 不计入
                "RemoveOffice": "上海市市场监督管理局",
            },
            {
                "Type": "",
                "AddReason": "虚假出资的",
                "AddDate": "2022-11-08",
                "AddOffice": "广东省市场监督管理局",
                "RemoveReason": "",
                "RemoveDate": "",       # 仍在列 → 计入
                "RemoveOffice": "",
            },
        ],
    },
})
# 期望：seriousviolflag=2（RemoveDate为空的2条）

# ─── 980 清算有负责人企业 ───
write(["LiquidationCheck", "GetDetail", "清算有负责人企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "LIQUIDATIONCHECK20260606200000000001",
    "Result": {
        "VerifyResult": 1,
        "Data": {
            "Leader": "张三;李四",    # 2名负责人
            "Member": "张三;李四;王五;赵六",
        },
    },
})
# 期望：liquidFlag=2（Leader分号分割非空count=2）

# ─── 767 高管股权冻结企业 ───
write(["PersonSEFreezeCheck", "GetList", "高管股权冻结企业__personName=高管甲"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "PERSONSEFREEZECHECK20260606200000000001",
    "Paging": paging(3),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": "pef767_01", "ExecuteName": "高管甲",
                "ExecuteKeyNo": "ek76701",
                "EquityAmount": "500万元人民币",
                "ExecuteCourt": COURTS[0],
                "ExecutionNoticeNum": "（2025）法执字第001号",
                "Status": "股权冻结|冻结",       # 冻结中 → 计入
                "FreezeStartDate": "2025-01-01",
                "FreezeEndDate": "2027-12-31",   # 未过期 → 计入
                "RelatedInfo": {"KeyNo": "ri76701", "Name": "高管股权冻结企业"},
            },
            {
                "Id": "pef767_02", "ExecuteName": "高管甲",
                "ExecuteKeyNo": "ek76702",
                "EquityAmount": "200万元人民币",
                "ExecuteCourt": COURTS[1],
                "ExecutionNoticeNum": "（2024）法执字第002号",
                "Status": "股权冻结|解冻",       # 已解冻 → 不计入
                "FreezeStartDate": "2024-06-01",
                "FreezeEndDate": "2025-12-31",   # 已过期 → 不计入
                "RelatedInfo": {"KeyNo": "ri76702", "Name": "高管股权冻结企业"},
            },
            {
                "Id": "pef767_03", "ExecuteName": "高管甲",
                "ExecuteKeyNo": "ek76703",
                "EquityAmount": "300万元人民币",
                "ExecuteCourt": COURTS[2],
                "ExecutionNoticeNum": "（2025）法执字第003号",
                "Status": "股权冻结|冻结",       # 冻结中 → 计入
                "FreezeStartDate": "2025-03-01",
                "FreezeEndDate": "2027-06-30",   # 未过期 → 计入
                "RelatedInfo": {"KeyNo": "ri76703", "Name": "高管股权冻结企业"},
            },
        ],
    },
})
# 期望：pequityfreezeflag=2（第1、3条满足）

# ─── 768 高管股权出质企业 ───
write(["PersonSEPledgedCheck", "GetList", "高管股权出质企业__personName=高管乙"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "PERSONSEPLEDGEDCHECK20260606200000000001",
    "Paging": paging(3),
    "Result": {
        "VerifyResult": 1,
        "Data": [
            {
                "Id": "pep768_01",
                "RegistNo": "股质登记字〔2024〕第001号",
                "PledgorName": "高管乙",
                "PledgeeName": "质权银行A",
                "PledgedAmount": "100万股",
                "RegDate": "2024-01-01",
                "Status": "有效",           # → 计入
                "RelatedCompanyName": "高管股权出质企业",
            },
            {
                "Id": "pep768_02",
                "RegistNo": "股质登记字〔2023〕第002号",
                "PledgorName": "高管乙",
                "PledgeeName": "质权银行B",
                "PledgedAmount": "50万股",
                "RegDate": "2023-06-01",
                "Status": "无效",           # → 不计入
                "RelatedCompanyName": "高管股权出质企业",
            },
            {
                "Id": "pep768_03",
                "RegistNo": "股质登记字〔2024〕第003号",
                "PledgorName": "高管乙",
                "PledgeeName": "质权银行C",
                "PledgedAmount": "200万股",
                "RegDate": "2024-09-01",
                "Status": "有效",           # → 计入
                "RelatedCompanyName": "高管股权出质企业",
            },
        ],
    },
})
# 期望：pequitypledgeflag=2（第1、3条 Status='有效'）

# ─── 2003 KYC查询目标企业 ───
write(["CustomerDueDiligence", "KYC", "KYC查询目标企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "ENTERPRISEINFO20260606200000000001",
    "Result": {
        "VerifyResult": 1,
        "Data": {
            "KeyNo": "kyc00112233445566778899aabbccdd",
            "Name": "KYC查询目标企业",
            "CreditCode": "9161010000112233Q",
            "OperName": "王法人",
            "Status": "在业",
            "StartDate": "2010-03-15",
            "RegistCapi": "5000万元",      # → registcapi=5000
            "RegisteredCapital": "5000",
            "RegisteredCapitalUnit": "万",
            "RealCapi": "3000万元",        # → realpaidcap=3000
            "PaidUpCapital": "3000",
            "PaidUpCapitalUnit": "万",
            # 变更记录：90天内的法人变更（2026-05-01）
            "ChangeList": [
                {
                    "ProjectName": "法定代表人变更",
                    "ChangeDate": "2026-05-01",   # 90天内 → 计入 legalchange90d
                    "BeforeList": ["张旧法人"], "AfterList": ["王法人"],
                    "ChangeSubject": "工商变更",
                },
                {
                    "ProjectName": "经营范围变更",
                    "ChangeDate": "2025-01-10",   # 超90天 → 不计入
                    "BeforeList": ["旧经营范围"], "AfterList": ["新经营范围"],
                    "ChangeSubject": "工商变更",
                },
            ],
            "RevokeInfo": {
                "CancelDate": "", "CancelReason": "",
                "RevokeDate": "", "RevokeReason": "",
            },
            "TaxCreditList": [
                {"TaxNo": "9161010000112233Q", "Year": "2024", "Level": "A", "Org": "国家税务总局"},
                {"TaxNo": "9161010000112233Q", "Year": "2023", "Level": "B", "Org": "国家税务总局"},
            ],
            # 股东列表：含一个>20%的大股东
            "PubPartnerList": [
                {
                    "StockName": "大股东甲", "StockPercent": "35.00%",
                    "HoldType": "1", "Amount": "1750000000",
                    "SubscribedCapital": "", "SubscribedCapitalUnit": "",
                    "SubscribedCapitalCCY": "", "SubscriptionDate": "2018-01-01",
                    "CreditCode": "", "Area": "",
                },
                {
                    "StockName": "小股东乙", "StockPercent": "15.00%",
                    "HoldType": "0", "Amount": "750000000",
                    "SubscribedCapital": "", "SubscribedCapitalUnit": "",
                    "SubscribedCapitalCCY": "", "SubscriptionDate": "2018-01-01",
                    "CreditCode": "", "Area": "",
                },
            ],
            # 被投资企业：一个>20%持股
            "InvestmentList": [
                {
                    "KeyNo": "inv0001", "Name": "KYC目标子公司A",
                    "StartDate": "2018-06-01", "Status": "存续",
                    "FundedRatio": "51.00%",
                    "ShouldCapi": "1000万元",
                    "SubscribedCapital": "1000", "SubscribedCapitalUnit": "万",
                    "SubscribedCapitalCCY": "CNY",
                    "Industry": {"IndustryCode": "I", "Industry": "信息技术",
                                 "SubIndustryCode": "65", "SubIndustry": "软件",
                                 "MiddleCategoryCode": "651", "MiddleCategory": "软件开发",
                                 "SmallCategoryCode": "6511", "SmallCategory": "应用软件"},
                    "Area": {"Province": "北京市", "City": "北京市", "County": "海淀区"},
                },
                {
                    "KeyNo": "inv0002", "Name": "KYC目标参股公司B",
                    "StartDate": "2019-01-01", "Status": "存续",
                    "FundedRatio": "10.00%",   # <20% → 不输出
                    "ShouldCapi": "500万元",
                    "SubscribedCapital": "500", "SubscribedCapitalUnit": "万",
                    "SubscribedCapitalCCY": "CNY",
                    "Industry": {"IndustryCode": "F", "Industry": "批发零售",
                                 "SubIndustryCode": "51", "SubIndustry": "批发业",
                                 "MiddleCategoryCode": "511", "MiddleCategory": "农副产品",
                                 "SmallCategoryCode": "5111", "SmallCategory": "粮食"},
                    "Area": {"Province": "上海市", "City": "上海市", "County": "浦东新区"},
                },
            ],
        },
    },
})
# 期望：
#   registcapi=5000, realpaidcap=3000
#   legalchange90d=1（2026-05-01法人变更在90天内）
#   scopechange90d=0（2025-01-10超90天）
#   taxcreditlevel='A'（2024年最新）
#   shareholders=['大股东甲 35%']（>20%的1个）
#   investtargets=['KYC目标子公司A 51%']（>20%的1个）

# ─── 独立的 VerifyResult=0 文件（每个接口专属，避免混用）───
for route, prefix in [
    (["ShixinCheck", "GetList", "失信无记录企业"],       "SHIXINCHECK"),
    (["ZhixingCheck", "GetList", "被执行无记录企业"],    "ZHIXINGCHECK"),
    (["SumptuaryCheck", "GetList", "限消无记录企业"],    "SUMPTUARYCHECK"),
    (["JudicialSaleCheck", "GetList", "司法拍卖无记录企业"], "JUDICIALSALECHECK"),
    (["EnvPunishmentCheck", "GetList", "环保处罚无记录企业"], "ENVPUNISHMENTCHECK"),
    (["TaxIllegalCheck", "GetList", "税收违法无记录企业"], "TAXILLEGALCHECK"),
    (["TaxOweNoticeCheck", "GetList", "欠税无记录企业"], "TAXOWENOTICECHECK"),
    (["EndExecuteCaseCheck", "GetList", "终本案件无记录企业"], "ENDEXECUTECASECHECK"),
    (["AdminPenaltyCheck", "GetList", "行政处罚无记录企业"], "ADMINPENALTYCHECK"),
    (["EquityPledgedCheck", "GetList", "股权出质无记录企业"], "EQUITYPLEDGEDCHECK"),
    (["EquityFreezeCheck", "GetList", "股权冻结无记录企业"], "EQUITYFREEZECHECK"),
    (["BankruptcyCheck", "GetList", "破产重整无记录企业"], "BANKRUPTCYCHECK"),
    (["CourtNoticeCheck", "GetList", "法院公告无记录企业"], "COURTNOTICECHECK"),
    (["JudgmentDocCheck", "GetList", "裁判文书无记录企业"], "JUDGMENTDOCCHECK"),
    (["CourtAnnoCheck", "GetList", "开庭公告无记录企业"], "COURTANNOCHECK"),
    (["SeriousIllegalCheck", "GetList", "严重违法无记录企业"], "SERIOUSILLEGALCHECK"),
    (["ExceptionCheck", "GetList", "经营异常无记录企业"], "EXCEPTIONCHECK"),
    (["PersonSXCheck", "GetList", "失信高管无记录企业__personName=无失信高管"], "PERSONSXCHECK"),
    (["PersonEndExCaseCheck", "GetList", "终本高管无记录企业__personName=无违规高管乙"], "PERSONENDEXCASECHECK"),
]:
    is_list = prefix in ("SERIOUSILLEGALCHECK", "EXCEPTIONCHECK")
    if is_list:
        data = {
            "Status": "200", "Message": "【有效请求】查询成功",
            "OrderNumber": f"{prefix}20260606300000000000",
            "Result": {"VerifyResult": 0, "Data": []},
        }
    else:
        data = {
            "Status": "200", "Message": "【有效请求】查询成功",
            "OrderNumber": f"{prefix}20260606300000000000",
            "Paging": {"PageSize": 10, "PageIndex": 1, "TotalRecords": 0},
            "Result": {"VerifyResult": 0, "Data": []},
        }
    write(route, data)

# ─── 非200错误场景文件 ───
for route, prefix in [
    (["CustomerDueDiligence", "KYC", "KYC无数据企业"],          "ENTERPRISEINFO"),
    (["ECICertification", "SearchCertification", "资质查询异常企业"], "ECICERTIFICATION"),
    (["LiquidationCheck", "GetDetail", "清算查询异常企业"],       "LIQUIDATIONCHECK"),
    (["PersonSXCheck", "GetList", "失信高管无记录企业__personName=无失信高管"], None),
]:
    if prefix is None:
        continue
    write(route, {
        "Status": "203",
        "Message": "【有效请求】参数异常",
        "OrderNumber": f"{prefix}20260606400000000000",
    })

print("\n✅ 历史/专属 mock 文件全部创建完成！")
