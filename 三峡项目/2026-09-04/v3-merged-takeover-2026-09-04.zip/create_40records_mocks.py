# -*- coding: utf-8 -*-
"""
为 pageSize=20 的跨页累积测试创建 40 条 mock 文件。
40 条 / pageSize=20 = 2 页，全部在窗口期内，验证跨页累积正确。
base date 2026-06-07  90天截止 2026-03-09  12月截止 2025-06-07
"""
import json, os

BASE_DIR = os.path.join(os.path.dirname(__file__), "mock-files")
COURTS = ["北京市朝阳区人民法院", "上海市浦东新区人民法院", "广州市中级人民法院"]

# 40条近期日期（全部在90天内，降序，覆盖两页各20条）
RECENT_40 = [
    "2026-06-05","2026-06-03","2026-06-01","2026-05-30","2026-05-28",
    "2026-05-26","2026-05-24","2026-05-22","2026-05-20","2026-05-18",
    "2026-05-16","2026-05-14","2026-05-12","2026-05-10","2026-05-08",
    "2026-05-06","2026-05-04","2026-05-02","2026-04-30","2026-04-28",  # page1 (idx 0-19)
    "2026-04-26","2026-04-24","2026-04-22","2026-04-20","2026-04-18",
    "2026-04-16","2026-04-14","2026-04-12","2026-04-10","2026-04-08",
    "2026-04-06","2026-04-04","2026-04-02","2026-03-31","2026-03-29",
    "2026-03-27","2026-03-25","2026-03-23","2026-03-21","2026-03-18",  # page2 (idx 20-39)
]

# 12月窗口内的40条日期（用于958）
RECENT_40_12M = [
    "2026-06-05","2026-06-01","2026-05-20","2026-05-10","2026-04-25",
    "2026-04-15","2026-04-01","2026-03-20","2026-03-10","2026-02-28",
    "2026-02-15","2026-02-01","2026-01-20","2026-01-10","2025-12-25",
    "2025-12-10","2025-11-30","2025-11-15","2025-11-01","2025-10-20",  # page1 idx 0-19
    "2025-10-01","2025-09-20","2025-09-01","2025-08-20","2025-08-01",
    "2025-07-15","2025-07-01","2025-06-25","2025-06-20","2025-06-15",
    "2025-06-14","2025-06-13","2025-06-12","2025-06-11","2025-06-10",
    "2025-06-09","2025-06-08","2025-06-08","2025-06-07","2025-06-07",  # page2 idx 20-39
]

def write(path_parts, data):
    d = os.path.join(BASE_DIR, *path_parts[:-1])
    os.makedirs(d, exist_ok=True)
    fp = os.path.join(d, path_parts[-1] + ".json")
    with open(fp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"  ✓ {'/'.join(path_parts)}.json")

def p40(data_arr, prefix):
    return {
        "Status": "200", "Message": "【有效请求】查询成功",
        "OrderNumber": f"{prefix}20260607",
        "Paging": {"PageSize": 20, "PageIndex": 1, "TotalRecords": len(data_arr)},
        "Result": {"VerifyResult": 1, "Data": data_arr}
    }

def cn_date(s):
    y,m,d = s.split("-"); return f"{y}年{int(m)}月{int(d)}日"

# ── 740 失信 ──────────────────────────────────────────────
write(["ShixinCheck","GetList","40条失信企业"], p40([
    {"Id": f"s40_{i}", "Liandate": RECENT_40[i],
     "Anno": f"（2026）京{1001+i%3}执{10000+i}号",
     "Executegov": COURTS[i%3], "Executestatus": ["全部未履行","部分未履行"][i%2],
     "Publicdate": RECENT_40[i], "Executeno": f"（2026）京{1001+i%3}民初{20000+i}号",
     "ActionRemark": "有履行能力而拒不履行", "Amount": str(50000*(i+1))}
    for i in range(40)
], "SHIXINCHECK"))
# pageSize=20：page1(0-19)→count=20，page2(20-39)→count=40，total=40

# ── 741 被执行 ─────────────────────────────────────────────
write(["ZhixingCheck","GetList","40条被执行企业"], p40([
    {"Id": f"z40_{i}", "Liandate": RECENT_40[i],
     "Anno": f"（2026）京{1001+i%3}执{30000+i}号",
     "ExecuteGov": COURTS[i%3], "Biaodi": str(100000*(i+1)),
     "SuspectedApplicant": f"债权申请人{i+1}"}
    for i in range(40)
], "ZHIXINGCHECK"))

# ── 742 限消 ───────────────────────────────────────────────
write(["SumptuaryCheck","GetList","40条限消企业"], p40([
    {"Id": f"sm40_{i}", "CaseNo": f"（2026）京{1001+i%3}执{40000+i}号",
     "PersonName": f"限消人员{i+1}", "PersonId": f"pid40{i}",
     "JudgeDate": RECENT_40[i], "PublishDate": RECENT_40[i],
     "KeyNo": f"kn40{i}", "CompanyName": "40条限消企业",
     "Applicant": f"债权人{i+1}", "ApplicantNo": f"an40{i}",
     "Amount": str(80000*(i+1)), "ExecuteCourt": COURTS[i%3]}
    for i in range(40)
], "SUMPTUARYCHECK"))

# ── 744 司法拍卖（中文日期）──────────────────────────────────
write(["JudicialSaleCheck","GetList","40条司法拍卖企业"], p40([
    {"Id": f"jsc40_{i}", "Name": f"40条司法拍卖企业名下资产{i+1}",
     "CaseNo": f"（2026）京{1001+i%3}执{50000+i}号", "Executegov": COURTS[i%3],
     "ActionRemark": f"{cn_date(RECENT_40[i])}上午10时至{cn_date(RECENT_40[i])}下午14时止",
     "YiWu": str(300000*(i+1)), "EvaluationPrice": str(350000*(i+1))}
    for i in range(40)
], "JUDICIALSALECHECK"))

# ── 746 环保处罚 ────────────────────────────────────────────
write(["EnvPunishmentCheck","GetList","40条环保处罚企业"], p40([
    {"Id": f"ep40_{i}", "CaseNo": f"环罚字〔2026〕第{400+i}号",
     "PunishDate": RECENT_40[i], "IllegalType": "超标排放",
     "PunishGov": ["北京市生态环境局","上海市生态环境局"][i%2],
     "PunishAmt": str(20000*(i+1))}
    for i in range(40)
], "ENVPUNISHMENTCHECK"))

# ── 756 税收违法 ────────────────────────────────────────────
write(["TaxIllegalCheck","GetList","40条税收违法企业"], p40([
    {"Id": f"ti40_{i}", "PublishDate": RECENT_40[i],
     "CaseNature": ["偷税","虚开增值税专用发票","骗取出口退税"][i%3],
     "TaxGov": ["国家税务总局北京市税务局","国家税务总局上海市税务局"][i%2],
     "IllegalContent": f"税收违法内容{i+1}", "PunishContent": f"罚款{(i+1)*5}万元"}
    for i in range(40)
], "TAXILLEGALCHECK"))

# ── 757 欠税（金额累积）─────────────────────────────────────
AMOUNTS_757 = [str(5000*(i+1)) for i in range(40)]  # 5000,10000,...200000
# 两页合计：sum(5000*(1..20))+sum(5000*(21..40))=5000*(1+...+40)=5000*820=4100000
write(["TaxOweNoticeCheck","GetList","40条欠税企业"], p40([
    {"Id": f"to40_{i}", "Title": ["增值税","企业所得税","城建税","房产税","印花税"][i%5],
     "Amount": AMOUNTS_757[i], "NewAmount": "0",
     "PublishDate": RECENT_40[i], "IssuedBy": "北京市国家税务局"}
    for i in range(40)
], "TAXOWENOTICECHECK"))
# pageSize=20：page1=sum(5000*1..20)=5000*210=1050000，page2=sum(5000*21..40)=5000*610=3050000
# total taxarrearsamt=4100000，taxarrearsflag=40

# ── 758 终本案件 ────────────────────────────────────────────
write(["EndExecuteCaseCheck","GetList","40条终本案件企业"], p40([
    {"Id": f"ec40_{i}", "CaseNo": f"（2026）京{1001+i%3}执终{60000+i}号",
     "Court": COURTS[i%3], "EndDate": RECENT_40[i], "LianDate": RECENT_40[i],
     "ExecuteSubject": str(500000*(i+1)), "UnperformedAmt": str(400000*(i+1))}
    for i in range(40)
], "ENDEXECUTECASECHECK"))

# ── 865 行政处罚（金额累积）───────────────────────────────────
AMOUNTS_865 = [str(10000*(i+1)) for i in range(40)]  # 10000..400000
# total=10000*(1+..+40)=10000*820=8200000
write(["AdminPenaltyCheck","GetList","40条行政处罚企业"], p40([
    {"Id": f"ap40_{i}", "DocNo": f"罚字〔2026〕第{2000+i}号",
     "PunishReason": "违法行为", "PunishResult": f"罚款{10*(i+1)}万元",
     "PunishOffice": ["北京市市场监督管理局","上海市市场监督管理局"][i%2],
     "PunishDate": RECENT_40[i], "Source": "机关", "SourceCode": "",
     "PunishAmt": AMOUNTS_865[i]}
    for i in range(40)
], "ADMINPENALTYCHECK"))

# ── 751 股权出质（无earlyStop，全翻2页）──────────────────────
write(["EquityPledgedCheck","GetList","40条股权出质企业"], p40([
    {"Id": f"eq40_{i}", "RegistNo": f"股质登记字〔2024〕第{500+i}号",
     "PledgorName": f"出质人{i+1}", "PledgeeName": f"银行{i+1}",
     "RegDate": "2024-01-01", "Status": "有效",
     "RelatedCompanyName": "40条股权出质企业",
     "PledgedAmount": f"{(i+1)*50}万股",
     "PledgeeList": [{"Name": f"银行{i+1}", "KeyNo": f"kp{500+i}"}],
     "PledgorList": [{"Name": f"出质人{i+1}", "KeyNo": f"kq{500+i}"}]}
    for i in range(40)
], "EQUITYPLEDGEDCHECK"))
# pageSize=20：page1=20，page2=20，equitypledgeflag=40（全部有效）

# ── 752 股权冻结（无earlyStop，全翻2页）──────────────────────
write(["EquityFreezeCheck","GetList","40条股权冻结企业"], p40([
    {"Id": f"ef40_{i}", "ExecuteName": f"被冻结人{i+1}", "ExecuteKeyNo": f"ek40{i}",
     "EquityAmount": f"{(i+1)*100}万元人民币", "ExecuteCourt": COURTS[i%3],
     "ExecutionNoticeNum": f"（2025）法执字第{500+i}号",
     "Status": "股权冻结|冻结",
     "FreezeStartDate": "2025-01-01", "FreezeEndDate": "2027-12-31",
     "RelatedInfo": {"KeyNo": f"ri40{i}", "Name": "40条股权冻结企业"}}
    for i in range(40)
], "EQUITYFREEZECHECK"))
# equityfreezeflag=40（全部冻结+未过期）

# ── 882 法院公告（名称匹配，40条被告）───────────────────────
LOAN_REASONS = ["借款合同纠纷","金融借款合同纠纷","民间借贷纠纷","融资租赁合同纠纷","票据纠纷"]
write(["CourtNoticeCheck","GetList","40条涉贷被告公司"], p40([
    {"Id": f"cn40_{i}",
     "CaseNo": f"（2026）京{1001+i%3}民初{70000+i}号",
     "CaseReason": LOAN_REASONS[i%5], "Category": "起诉状、上诉状副本",
     "Court": COURTS[i%3], "PublishDate": RECENT_40[i],
     "ProsecutorList": [{"KeyNo": f"px40{i}", "Name": f"原告银行{i+1}"}],
     "DefendantList": [{"KeyNo": f"dx40{i}", "Name": "40条涉贷被告公司"}],
     "RoleList": [
         {"RoleType": "0", "RoleName": "原告", "RoleItemList": [{"KeyNo": f"px40{i}", "Name": f"原告银行{i+1}"}]},
         {"RoleType": "1", "RoleName": "被告", "RoleItemList": [{"KeyNo": f"dx40{i}", "Name": "40条涉贷被告公司"}]},
     ]}
    for i in range(40)
], "COURTNOTICECHECK"))
# searchKey="40条涉贷被告公司"，pageSize=20→2页，cnt=40

# ── 887 裁判文书（三类混合40条）────────────────────────────
jd887_40 = []
for i in range(40):
    mod = i % 5
    if mod in (0, 1):  # 借款被告
        jd887_40.append({
            "Id": f"jd40_{i}", "CaseName": f"某银行{i}期借款纠纷",
            "CaseReason": LOAN_REASONS[mod], "CaseNo": f"（2026）京01民初{90000+i}号",
            "Amount": str(200000*(mod+1)), "JudgeDate": RECENT_40[i],
            "PublishDate": RECENT_40[i],
            "PartyList": [
                {"Name": f"原告银行{i}", "RoleType": "原告", "Statement": "", "Keyno": f"p40{i}"},
                {"Name": "40条涉贷被告公司", "RoleType": "被告", "Statement": "", "Keyno": f"d40{i}"},
            ], "CaseType": "ms"
        })
    elif mod == 2:  # 原告（自诉）
        jd887_40.append({
            "Id": f"jd40_{i}", "CaseName": f"40条涉贷被告公司诉供应商{i}",
            "CaseReason": "买卖合同纠纷", "CaseNo": f"（2026）京01民初{90000+i}号",
            "Amount": "100000", "JudgeDate": RECENT_40[i],
            "PublishDate": RECENT_40[i],
            "PartyList": [
                {"Name": "40条涉贷被告公司", "RoleType": "原告", "Statement": "", "Keyno": f"p40{i}"},
                {"Name": f"供应商{i}", "RoleType": "被告", "Statement": "", "Keyno": f"d40{i}"},
            ], "CaseType": "ms"
        })
    elif mod == 3:  # 被保全
        jd887_40.append({
            "Id": f"jd40_{i}", "CaseName": f"财产保全{i}",
            "CaseReason": "财产保全", "CaseNo": f"（2026）京01民初{90000+i}号",
            "Amount": "50000", "JudgeDate": RECENT_40[i],
            "PublishDate": RECENT_40[i],
            "PartyList": [
                {"Name": f"申请人{i}", "RoleType": "原告", "Statement": "", "Keyno": f"p40{i}"},
                {"Name": "40条涉贷被告公司", "RoleType": "被告", "Statement": "", "Keyno": f"d40{i}"},
            ], "CaseType": "bq"
        })
    else:  # 无关（劳动争议）
        jd887_40.append({
            "Id": f"jd40_{i}", "CaseName": f"劳动争议{i}",
            "CaseReason": "劳动争议", "CaseNo": f"（2026）京01民初{90000+i}号",
            "Amount": "30000", "JudgeDate": RECENT_40[i],
            "PublishDate": RECENT_40[i],
            "PartyList": [
                {"Name": f"员工{i}", "RoleType": "原告", "Statement": "", "Keyno": f"p40{i}"},
                {"Name": "40条涉贷被告公司", "RoleType": "被告", "Statement": "", "Keyno": f"d40{i}"},
            ], "CaseType": "ms"
        })

write(["JudgmentDocCheck","GetList","40条涉贷被告公司"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "JUDGMENTDOCCHECK20260607",
    "Paging": {"PageSize": 20, "PageIndex": 1, "TotalRecords": 40},
    "Result": {"VerifyResult": 1, "Data": jd887_40}
})
# 40条中：mod0/1=借款被告(16条)，mod2=原告(8条)，mod3=被保全(8条)，mod4=无关(8条)
# loandisputecnt=16, selfcnt=8, preservcnt=8（pageSize=20，2页累积）

# ── 888 开庭公告（40条被告）────────────────────────────────
write(["CourtAnnoCheck","GetList","40条开庭被告公司"], p40([
    {"Id": f"ca40_{i}",
     "CaseNo": f"（2026）京{1001+i%3}民初{80000+i}号",
     "CaseReason": LOAN_REASONS[i%5], "Court": COURTS[i%3],
     "CourtTime": f"{RECENT_40[i]} 09:00:00",
     "PartyList": [
         {"Name": f"原告方{i+1}", "RoleType": "2", "Keyno": f"p40{i}"},
         {"Name": "40条开庭被告公司", "RoleType": "1", "Keyno": f"d40{i}"},
     ],
     "RoleList": [
         {"RoleType": "0", "RoleName": "原告", "RoleItemList": [{"KeyNo": f"p40{i}", "Name": f"原告方{i+1}"}]},
         {"RoleType": "1", "RoleName": "被告", "RoleItemList": [{"KeyNo": f"d40{i}", "Name": "40条开庭被告公司"}]},
     ]}
    for i in range(40)
], "COURTANNOCHECK"))

# ── 764 失信【董监高】40条 ───────────────────────────────
write(["PersonSXCheck","GetList","40条失信高管__personName=近期违规高管"], p40([
    {"Id": f"ps764x{i}", "Liandate": RECENT_40[i],
     "Anno": f"（2026）京{1001+i%3}执{100000+i}号",
     "Executegov": COURTS[i%3], "Executestatus": ["全部未履行","部分未履行"][i%2],
     "Publicdate": RECENT_40[i], "Executeno": f"（2026）京{1001+i%3}民初{200000+i}号",
     "ActionRemark": "有履行能力而拒不履行", "Amount": str(50000*(i+1))}
    for i in range(40)
], "PERSONSXCHECK"))

# ── 765 被执行【董监高】40条 ─────────────────────────────
write(["PersonZXCheck","GetList","40条被执行高管__personName=近期违规高管"], p40([
    {"Id": f"pz765x{i}", "Liandate": RECENT_40[i],
     "Anno": f"（2026）京{1001+i%3}执{300000+i}号",
     "ExecuteGov": COURTS[i%3], "Biaodi": str(100000*(i+1)),
     "SuspectedApplicant": f"债权人{i+1}"}
    for i in range(40)
], "PERSONZXCHECK"))

# ── 766 限消【董监高】40条 ─────────────────────────────
write(["PersonSumptuaryCheck","GetList","40条限消高管__personName=近期违规高管"], p40([
    {"Id": f"pm766x{i}", "CaseNo": f"（2026）京{1001+i%3}执{400000+i}号",
     "LimitObject": "限消高管供职公司", "LimitObjectKeyNo": f"lo766x{i}",
     "RelatedName": "近期违规高管", "RelatedKeyNo": f"rk766x{i}",
     "JudgeDate": RECENT_40[i], "PublishDate": RECENT_40[i],
     "Applicant": f"申请方{i+1}", "ApplicantKeyNo": f"ak766x{i}"}
    for i in range(40)
], "PERSONSUMPTUARYCHECK"))

# ── 771 终本案件【董监高】40条 ──────────────────────────
write(["PersonEndExCaseCheck","GetList","40条终本高管__personName=近期违规高管"], p40([
    {"Id": f"pe771x{i}", "CaseNo": f"（2026）京{1001+i%3}执终{500000+i}号",
     "Court": COURTS[i%3], "EndDate": RECENT_40[i], "LianDate": RECENT_40[i],
     "ExecuteSubject": str(500000*(i+1)), "UnperformedAmt": str(400000*(i+1))}
    for i in range(40)
], "PERSONENDEXCASECHECK"))

# ── 767 股权冻结【董监高】40条（无earlyStop）───────────────
write(["PersonSEFreezeCheck","GetList","40条冻结高管企业__personName=高管甲"], p40([
    {"Id": f"pef767x{i}", "ExecuteName": "高管甲", "ExecuteKeyNo": f"ek767x{i}",
     "EquityAmount": f"{(i+1)*30}万元人民币", "ExecuteCourt": COURTS[i%3],
     "ExecutionNoticeNum": f"（2025）法执字第{700+i}号",
     "Status": "股权冻结|冻结",
     "FreezeStartDate": "2025-01-01", "FreezeEndDate": "2027-12-31",
     "RelatedInfo": {"KeyNo": f"ri767x{i}", "Name": "40条冻结高管企业"}}
    for i in range(40)
], "PERSONSEFREEZECHECK"))
# pequityfreezeflag=40，全翻2页

# ── 768 股权出质【董监高】40条（无earlyStop）───────────────
write(["PersonSEPledgedCheck","GetList","40条出质高管企业__personName=高管乙"], p40([
    {"Id": f"pep768x{i}", "RegistNo": f"股质登记字〔2024〕第{900+i}号",
     "PledgorName": "高管乙", "PledgeeName": f"质权银行{i+1}",
     "PledgedAmount": f"{(i+1)*30}万股", "RegDate": "2024-01-01",
     "Status": "有效", "RelatedCompanyName": "40条出质高管企业"}
    for i in range(40)
], "PERSONSEPLEDGEDCHECK"))
# pequitypledgeflag=40

# ── 958 招投标 40条（12月窗口）──────────────────────────
COMPANY_NAMES = ["三峡工程建设公司","长江水利开发公司","大坝建设集团","峡谷投资管理","融通担保服务"]
write(["TenderCheck","GetList","40条近期招标企业"], {
    "Status": "200", "Message": "【有效请求】查询成功",
    "OrderNumber": "TENDERCHECK20260607",
    "Paging": {"PageSize": 20, "PageIndex": 1, "TotalRecords": 40},
    "Result": {"VerifyResult": 1, "Data": [
        {"Id": f"td40_{i}", "Title": f"第{i+1}期工程建设采购",
         "ProjectNo": f"WHYX-IT-GKXJ-26-{4000+i}",
         "ChannelName": "中标公告", "Province": "湖北省", "City": "宜昌市",
         "IndustryDesc": "工程建筑", "BudgetAmt": str(3000000*(i+1)),
         "PublishDate": RECENT_40_12M[i], "OpenDate": RECENT_40_12M[i],
         "ObtainEndDate": RECENT_40_12M[i],
         "BidInviUnitList": [{"KeyNo": "bi001","Name":"三峡融担招标方","Contact":"李总","TelNo":"0717-12345"}],
         "WinBidUnitList": [{"WinBidAmt": str(2500000*(i+1)), "KeyNo": "kw001",
                              "Name": COMPANY_NAMES[i%5], "Contact":"王总","TelNo":"010-12345"}],
         "AgentUnitList": [], "BidProgressList": ["招标公告","中标公告"],
         "BidEndDate": f"{RECENT_40_12M[i]} 17:00:00",
         "ContentUrl": f"https://example.com/td40_{i}",
         "ContractEndTime": "2027-12-31"}
        for i in range(40)
    ]}
})
# bidinfo='40'，pageSize=20→2页

print("\n✅ 所有 40 条跨页文件创建完成！")
print("\n说明（pageSize=20，40条=2页）:")
print("  earlyStop接口 (740~865): 40条全部在窗口期内，2页全部计入，验证bussMap跨页累积")
print("  751/752:      40条全部满足Status条件，equityXflag=40")
print("  882:          40条全部借款被告，cnt=40")
print("  887:          16借款被告+8原告+8保全+8无关，跨2页累积")
print("  888:          40条开庭被告，cnt=40")
print("  764-771:      40条高管记录，cnt=40（pageSize=20翻2页）")
print("  958:          40条12月内招标，bidinfo='40'")
