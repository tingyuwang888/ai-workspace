# Ant Design 组件交互技巧

天策平台基于 Ant Design（tnt 定制版），以下是在 agent-browser 中操作各组件的实战经验。

---

## 核心原则

**`eval` vs `click` 选择规则**：

| 操作 | 推荐方式 | 原因 |
|------|---------|------|
| 点击按钮/链接 | `agent-browser click "CSS"` | 模拟真实鼠标事件 |
| 填写输入框 | `agent-browser fill "#id" "value"` | 触发 React onChange |
| 读取 DOM 信息 | `agent-browser eval "..."` | 只读操作安全 |
| 选择下拉选项 | `eval` 找到 li 后 `.click()` | 下拉菜单在 body 下，需用文本匹配 |

**绝对不要**用 `eval` + `nativeInputValueSetter` 修改表单输入框值——React 状态不会同步，提交时仍发送旧值。

---

## Select 下拉框

### DOM 结构

```
.ant-select                        ← 容器
  .ant-select-selection            ← 可点击区域
    .ant-select-selection__placeholder  ← 占位文本
    .ant-select-selection__rendered     ← 已选值
  .ant-select-arrow                ← 箭头图标

.ant-select-dropdown               ← 下拉菜单（挂在 body 下）
  li.ant-select-dropdown-menu-item ← 选项
```

### 打开下拉框

```bash
# 方法1：agent-browser click（推荐，最可靠）
agent-browser click ".ant-drawer-body .ant-select:nth-of-type(N) .ant-select-selection"

# 方法2：eval + mousedown（备用）
agent-browser eval "(() => {
  const sel = document.querySelectorAll('.ant-select')[N];
  sel.querySelector('.ant-select-selection')
     .dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
})()"
```

### 选择选项

```bash
# 按文本匹配（最可靠）
agent-browser eval "(() => {
  const dds = document.querySelectorAll(
    '.ant-select-dropdown:not(.ant-select-dropdown-hidden)');
  for (const dd of dds) {
    for (const item of dd.querySelectorAll('li')) {
      if (item.textContent.trim().includes('目标文本')) {
        item.click();
        return 'selected';
      }
    }
  }
  return 'not found';
})()"
```

### 注意事项

- 下拉菜单 DOM 挂在 `document.body` 下，不在 `.ant-drawer` 内
- 同时可能有多个隐藏下拉菜单，用 `:not(.ant-select-dropdown-hidden)` 过滤
- 按钮文本可能有空格（如 "登 录"），用 `.includes()` 而非 `===`

---

## Input 输入框

### 填写值（正确方式）

```bash
# 1. 先分配唯一 ID
agent-browser eval "(() => {
  const drawer = document.querySelector('.ant-drawer');
  drawer.querySelectorAll('.ant-form-item').forEach(item => {
    const label = item.querySelector('.ant-form-item-label');
    const input = item.querySelector('input');
    if (label && input && !input.id) {
      input.id = 'field_' + label.textContent.trim()
        .replace('*', '').trim()
        .replace(/[^a-zA-Z0-9\u4e00-\u9fa5_]/g, '_');
    }
  });
})()"

# 2. 用 fill 命令填写（自动触发 input/change/blur 事件）
agent-browser fill "#field_客户编号" "CUST_PRE_R003_2"
agent-browser fill "#field_区域合并已用额度" "15000000"
```

### 为什么不能用 eval

```javascript
// 错误方式 - React 状态不会更新！
input.value = 'new value';  // 只改 DOM，React 不知道
input.dispatchEvent(new Event('input', { bubbles: true }));  // 也不够

// 正确方式 - agent-browser fill 命令内部处理了 React 事件合成
```

---

## Drawer 抽屉面板

天策的"新增单笔测试"使用的是 `ant-drawer`（不是 `ant-modal`）：

```bash
# 检查抽屉是否打开
agent-browser eval "document.querySelector('.ant-drawer-open') ? 'open' : 'closed'"

# 关闭抽屉
agent-browser eval "document.querySelector('.ant-drawer-close')?.click()"

# 获取抽屉内所有表单字段
agent-browser eval "(() => {
  const drawer = document.querySelector('.ant-drawer-body');
  const inputs = drawer.querySelectorAll('input');
  return inputs.length + ' inputs';
})()"
```

---

## Form 表单验证

### 检查验证错误

```bash
agent-browser eval "(() => {
  const errors = document.querySelectorAll(
    '.ant-form-explain, .ant-form-item-explain');
  const texts = [];
  errors.forEach(e => {
    const t = e.textContent.trim();
    if (t) texts.push(t);
  });
  return texts.join(' | ');
})()"
```

### 定位出错字段

```bash
agent-browser eval "(() => {
  const errorItems = document.querySelectorAll('.has-error');
  const results = [];
  errorItems.forEach(item => {
    const formItem = item.closest('.ant-form-item');
    const label = formItem?.querySelector('.ant-form-item-label');
    results.push(label?.textContent.trim() || 'unknown');
  });
  return results.join(', ');
})()"
```

---

## Modal 确认框

测试提交成功后的"测试执行中"弹窗：

```bash
# 读取测试流水号
agent-browser eval "(() => {
  const modal = document.querySelector('.ant-modal-confirm-body');
  return modal ? modal.textContent : 'no modal';
})()"

# 关闭弹窗
agent-browser click ".ant-modal-confirm-btns .ant-btn-primary"
```

---

## 网络请求拦截

用于调试 API 调用：

```bash
agent-browser eval "(() => {
  window._captured = [];
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(m, u) {
    this._m = m; this._u = u.toString(); this._h = {};
    return origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function(body) {
    window._captured.push({
      method: this._m, url: this._u,
      body: body ? String(body).substring(0, 2000) : null
    });
    return origSend.apply(this, arguments);
  };
  // fetch 拦截
  const origFetch = window.fetch;
  window.fetch = function(url, opts) {
    window._captured.push({
      type: 'fetch', method: opts?.method || 'GET',
      url: String(url), body: opts?.body ? String(opts.body).substring(0,2000) : null
    });
    return origFetch.apply(this, arguments);
  };
  return 'interceptors installed';
})()"
```

查看捕获的请求：

```bash
agent-browser eval "JSON.stringify(window._captured.filter(r => !r.url?.includes('.css')), null, 2)"
```
