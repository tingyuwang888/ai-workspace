# 通用比对框架

## 概述

测试结果比对不再使用策略专属的硬编码函数，而是通过策略配置文件中的 `comparisonRules` 字段声明比对规则。
`comparison_engine.py` 中的 `compare_generic()` 函数读取这些规则并执行比对。

## 比对规则类型

### alias_group（别名匹配）
用于处理同一结果有多种表述的情况（如中英文对照）。

配置示例：
```json
{"type": "alias_group", "groups": [
  ["红色预警", "redwarnbh"],
  ["黄色预警", "yellowwarnbh"],
  ["通过", "Accept", "无风险"]
]}
```
逻辑：如果预期匹配某组中的任一别名，实际结果也须匹配同组中的任一别名。

### keyword_present（关键词存在）
预期包含某关键词时，实际结果也必须包含目标关键词。

```json
{"type": "keyword_present", "triggers": ["触发", "超限"], "target": "超限"}
```

### keyword_absent（关键词不存在）
预期包含某关键词时，实际结果不应包含目标关键词。

```json
{"type": "keyword_absent", "triggers": ["不触发", "通过"], "target": "超限"}
```

### numeric_tolerance（数值容差）
从预期和实际文本中提取数值，在容差范围内视为匹配。

```json
{"type": "numeric_tolerance", "expectedPattern": "评分[=≈]?\\s*([\\d.]+)\\s*分",
 "actualPattern": "风险预警总分[=≈]?\\s*([\\d.]+)", "tolerance": 1.0}
```

### exploratory（探索性）
预期为探索性描述时，只要实际结果包含任一有效指标即通过。

```json
{"type": "exploratory", "trigger": "待探索",
 "validIndicators": ["低风险", "中低风险", "中高风险", "高风险"]}
```

### pass_through（直接通过）
预期包含特定关键词时，实际结果包含匹配值即通过。

```json
{"type": "pass_through", "triggers": ["通过", "Accept"],
 "matchActual": ["Accept", "通过"]}
```

### invalid_expectation（无效预期）
预期值不合理时直接判定未通过。

```json
{"type": "invalid_expectation", "triggers": ["次级", "可疑", "损失"],
 "note": "策略不支持这些输出"}
```

### fuzzy_alias（模糊别名）
预期匹配某固定模式时，实际结果须匹配指定的别名列表之一。适合"一对多"的模糊映射场景。

```json
{"type": "fuzzy_alias", "pattern": "中风险预警",
 "matches": ["黄色预警", "蓝色预警", "yellowwarnbh", "bluewarnbh"],
 "note": "中风险=黄色或蓝色预警，须在alias_group之前匹配"}
```

注意：fuzzy_alias 必须在 alias_group 之前声明，否则 alias_group 会先截获匹配。

### regex_match（正则匹配）
预期匹配某正则时，实际结果须匹配另一正则。

```json
{"type": "regex_match", "triggerPattern": "命中.*EBGS01",
 "actualPattern": "EBGS01.*命中"}
```

## 字段名规范

配置文件中的字段名与 `compare_generic()` 函数兼容两种写法：

| 字段 | 推荐写法 | 兼容写法 | 说明 |
|------|---------|---------|------|
| triggers | `triggers`（数组） | `trigger`（字符串或数组） | 预期结果的触发关键词 |
| validIndicators | `validIndicators` | `indicators` | exploratory 的有效指标列表 |
| groups | `groups` | — | alias_group 的别名组（列表的列表） |
| pattern + matches | `pattern` + `matches` | — | fuzzy_alias 的匹配模式和目标列表 |
| target | `target` | — | keyword_present/absent 的目标关键词 |
| matchActual | `matchActual` | — | pass_through 的实际结果匹配列表 |

## 比对执行顺序

规则按数组顺序依次执行，第一个匹配的规则返回结果。如果没有任何规则匹配，返回
`None`（无法判定）。调用方必须把它记录为 `inconclusive/待确认`，禁止退化为“API
成功即通过”。

## 编写比对规则的最佳实践

1. 把最具体的规则放前面，最宽泛的放后面
2. alias_group 适合有明确枚举值的结果（如风险等级）
3. keyword_present/absent 适合文本描述类结果（如"超限"/"通过"）
4. numeric_tolerance 适合有评分/计数的结果
5. exploratory 用于不确定预期结果的探索性测试
6. 每个策略至少需要一个 alias_group 或 keyword 类型的规则

## 从旧比对函数迁移

| 旧函数 | 对应配置 |
|--------|---------|
| compare_jzd | keyword_absent + keyword_present |
| compare_jt | alias_group + numeric_tolerance + exploratory |
| compare_wjfl | alias_group + invalid_expectation |
| compare_bhjc | pass_through + alias_group + fuzzy_alias |

## 使用方式

```bash
# 重新比对 - 指定策略配置
python3 scripts/update_report.py --relabel report.xlsx --config strategies/bhjcpostMainBefore.json

# 重新比对 - 自动检测（按sheet名匹配配置文件）
python3 scripts/update_report.py --relabel report.xlsx
```
