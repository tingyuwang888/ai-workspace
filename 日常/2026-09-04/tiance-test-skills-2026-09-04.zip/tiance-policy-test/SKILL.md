---
name: tiance-policy-test
description: >
  天策(Tiance/Noah)决策平台通用策略测试自动化。支持API单笔/区间执行和UI备用提交。
  覆盖 策略发现 → 语义预检 → 隔离数据 → 单笔提交 → 结构化证据 → Excel报告 全流程。
  适用于天策平台上任意策略的回归测试和验证，通过策略配置文件支持新策略快速接入。
  当用户提到"策略测试"、"跑用例"、"天策测试"、"policytest"、"规则集测试"、
  "Noah测试"、"批量提交测试用例"时使用。
---

# 天策策略测试自动化（通用框架）

## 概述

对天策决策平台的任意策略进行自动化测试的通用框架。两种提交方式：

- **Python API执行器**（推荐）：强制平台门禁、参数预检、断点续跑和证据比对
- **浏览器/API或UI交互**（仅备用）：用于直接认证不可用或诊断单条用例

```
会话检查 → 平台门禁 → 语义/mock预检 → Fixture → 单笔执行
→ 结构化证据比对 → 15列Excel报告 → Fixture清理
```

**平台地址**: `http://{HOST}/noah/policyTest` | **API前缀**: `/noahApi/` (form-encoded, 需session认证) | **DB**: MySQL `{DB_HOST}:3306`, 库`tiance`, 用户`tongdun`

## 前置条件

1. 用户已登录天策平台
2. 已取得有效 Cookie/CSRF；需要浏览器备用流程时加载浏览器控制技能
3. 策略配置文件存在于 `strategies/` 目录（或通过 `discover_strategy.py` 自动发现）
4. DB验证需设置环境变量：`export TIANCE_DB_PASS=<密码>`（config.json 使用 `$ENV:TIANCE_DB_PASS` 占位符）

## 核心流程

### Step 0: 会话健康检查（每次提交前必做）

执行器自动处理 CSRF 和 401。浏览器备用流程先运行
[api-reference.md](api-reference.md) 的会话健康检查；失败时停止，不提交用例。

### Step 1: 加载并校验策略配置（强制平台校验）

**这是通用化的关键步骤。** 所有策略特有信息均从配置文件加载，SKILL.md 不含任何策略特定内容。

> **⚠️ 强制校验规则：无论本地配置文件是否存在，每次测试前必须查询平台 API 核对 `policyVersion` 和 `businessType`。** 本地缓存可能过期（策略发布了新版本、业务类型配置变更），使用错误值会导致测试结果无效。

`scripts/execute_tests.py` 在提交前自动查询平台元数据，并严格比对：

| 字段 | 平台字段 | 本地字段 | 不一致时 |
|------|----------|----------|----------|
| 版本号 | `platformVersion` | `policyVersion` | **必须用平台值**，更新本地配置 |
| 业务类型 | `businessType` | `bizType` | **必须用平台值**，更新本地配置 |
| 策略名 | `policyName` | `policyName` | 警告但不阻断 |

策略不存在、状态非已发布、版本或业务类型不一致时阻断提交。不要自动修改本地
配置；先确认差异来源，再显式更新配置并重新运行。

元数据接口不可用时，从已登录浏览器导出完整 API JSON 响应，再使用：

```json
{
  "capturedAt": "2026-07-29T12:00:00+08:00",
  "payload": {"success": true, "data": []}
}
```

```bash
python3 scripts/platform_guard.py \
  --config strategies/{policyCode}.json \
  --raw-payload browser_response.json \
  --output platform_snapshot.json
```

批量执行时追加 `--platform-snapshot platform_snapshot.json`。快照必须在十分钟内生成；
缺少时间、版本、业务类型或发布状态都会被阻断。

**配置文件不存在时**——执行完整自动发现：
```bash
python3 scripts/discover_strategy.py \
  --host {host} --cookie "{cookie}" --org-code {orgCode} --biz-type {bizType} \
  --output strategies/{policyCode}.json \
  discover --policy-code {policyCode}
```
然后执行平台门禁。

自动发现后必须补充 `routingFields`、`subStrategies`、`comparisonRules`、
`params.strategySpecific` 和数据源执行约束。

**配置文件关键字段**：

| 字段 | 用途 |
|------|------|
| `policyCode`/`policyName`/`policyVersion`/`bizType` | 提交API必需的策略标识（**必须从平台校验获取**） |
| `params.common` | 通用公共参数定义 |
| `params.strategySpecific` | 策略特有参数定义 |
| `decisionResults` | 决策结果列表（含别名） |
| `comparisonRules` | 比对规则 |
| `subStrategies` | 子策略列表（policyCode + 角色） |
| `routingFields` | 路由字段（决策分支条件） |
| `testExecution.requiredParams` | 提交前必须存在的数据源/执行参数 |
| `testExecution.defaults` | 仅在用例缺失字段时补入的安全测试默认值 |
| `testExecution.defaultsByCaseType` | 按正/反案例选择命中或安全数据，且不覆盖用例显式值 |

配置格式详见 [comparison-framework.md](comparison-framework.md) 和 [examples.md — 策略配置文件示例](examples.md#策略配置文件示例)。

**版本规则**：始终使用平台最新发布版本（`publishConfig.ordinaryConfig.version`），除非用户明确指定其他版本。**禁止凭记忆或历史值填写版本号。**

### Step 2: 准备测试用例

测试用例以JSON数组定义：

```json
{
  "id": "TC_001", "desc": "用例描述", "group": "分组名",
  "caseType": "正案例", "scenario": "测试场景", "expected": "预期结果",
  "params": { /* API params 键值对 */ }
}
```

#### 模块分组（4大类）

| 模块 | 说明 | 覆盖目标 |
|------|------|---------|
| 规则 | 验证单条规则命中/未命中及阈值边界 | 每条规则至少1正1反 |
| 函数 | 验证函数输出值/评分及边界条件 | 函数分支覆盖 |
| 决策流分支覆盖 | 验证决策流路由 | 各分支路径 |
| 策略预警等级覆盖 | 验证最终预警等级 | 各级别覆盖 |

> Excel报告中Col2"模块"列只填4大类名称。

#### 预期结果格式

- **规则级**：`命中：规则编号(规则中文名)[风险等级]` / `未命中：未命中规则编号(规则中文名)`
- **函数级**：`函数输出：函数中文名(函数编码)+字段名=值`
- **策略级**：`预警等级名称`（如红色预警、黄色预警、通过）

> 规则编号后**必须附中文名**，不能只写编号。

#### 参数组装

`params` 必须包含策略所需全部入参：
1. **公共参数**（从配置 `params.common` 获取）
2. **策略特有参数**（从配置 `params.strategySpecific` 获取）
3. **数据源查询参数**（从配置 `testExecution.requiredParams` 获取）

> **S_S_BIZID 必填**：缺失时 API 返回 `success:true` 但 `data` 为空，不报错，极难排查。

#### 提交前参数预检（强制）

生成用例后、提交前运行：

```bash
python3 scripts/prepare_testcases.py \
  --config strategies/{policyCode}.json \
  --testcases testcases.json \
  --output testcases.prepared.json
```

后续提交必须使用 `testcases.prepared.json`。脚本会：

- 补入 `params.common` 中的 `fixed/default` 值
- 补入 `testExecution.defaults`，但不覆盖用例显式值
- 按 `testExecution.defaultsByCaseType` 选择正/反例数据，不覆盖用例显式值
- 校验 `params.common.required` 和 `testExecution.requiredParams`
- 任一用例缺少必需参数时以退出码 `2` 阻断提交
- 将模块限制为“规则/函数/决策流分支覆盖/策略预警等级覆盖”
- 使用 `parsed_strategy.json` 校验目标规则编号和中文名
- 在严格模式下拦截策略未声明参数、无效枚举和路由值
- 按 `testExecution.ruleDependencies` 校验三方节点证据契约

`params.strategySpecific.required/fixed/default` 与 `params.common` 使用同一套预检。

策略配置启用：

```json
{
  "testExecution": {
    "semanticValidation": {
      "requireMetadata": true,
      "strictParams": true
    },
    "ruleCatalog": [{"code": "R001", "name": "规则中文名"}],
    "ruleDependencies": {
      "R001": ["third_party_realtime", "third_party_offline"]
    }
  }
}
```

规则用例声明必须核对的证据：

```json
{
  "targetRule": "R001",
  "expectedEvidence": {
    "rules": ["R001"],
    "thirdPartyNodes": [
      {"nodeName": "third_party_realtime", "fields": ["amount"]},
      "third_party_offline"
    ]
  }
}
```

#### 异常用例和 mock

异常用例必须声明真实 mock 契约：

```json
{
  "caseType": "异常案例",
  "executionMode": "mock",
  "mockScenario": "third_party_timeout"
}
```

策略配置在 `testExecution.mockScenarios` 声明场景。只有隔离环境确实启用后，提交命令
才可追加 `--enabled-mock-scenario third_party_timeout`。未声明、未启用或普通请求伪装
成异常用例都会被预检阻断。

存在 `probe` 的场景必须先生成十分钟内有效的就绪证明：

```bash
python3 scripts/mock_probe.py \
  --config strategies/{policyCode}.json \
  --host {host} \
  --scenario third_party_timeout \
  --output mock_readiness.json
```

执行时传 `--mock-readiness mock_readiness.json`。探针失败时禁止执行异常用例。

配置了 MySQL 数据源时，必须把 SQL 中每个 `#{变量}` 对应的系统字段加入
`testExecution.requiredParams`。否则三方节点可能返回 `10907`
（`解析sql不完整，存在未替换变量`），且后续函数会以 `0/null` 继续执行，
造成“策略运行成功但规则结果错误”的假象。

#### 路由字段校验

配置文件有 `routingFields` 时，提交前必须确认这些字段已正确设置——设错会导致走错误分支。

#### searchKey 唯一性

每条规则命中用例使用唯一 searchKey（如 `RULE_{规则码}_TC_{编号}`），避免数据源缓存干扰。

用例设计原则见 [examples.md — 测试用例示例](examples.md#测试用例示例)，三方数据覆盖见 [api-reference.md](api-reference.md)。

### Step 3: 提交测试

优先使用 Python API 执行器，API 不可用时才切换浏览器或 UI。

---

#### 方式A: Python API执行器（推荐）

```bash
python3 scripts/execute_tests.py \
  --host {host} \
  --cookie "{cookie}" \
  --org-code {orgCode} \
  --strategy-config strategies/{policyCode}.json \
  --testcases testcases.json \
  --output results.json
```

需要断点续跑时追加 `--resume`。执行器会依次完成平台门禁、参数/mock 预检、
提交重试、组件日志采集和预期比对。

优先按单笔或小区间执行，不使用平台批量导入：

```bash
# 单条
python3 scripts/execute_tests.py ... --case-id TC_005 --fast

# 多条仍逐笔提交，证据查询最多4并发
python3 scripts/execute_tests.py ... \
  --case-range TC_005:TC_008 --fast
```

`--fast` 只取消固定等待并并行采集已完成流水的证据，不会把多条用例合并为一个请求。
结果旁生成 `results.timings.json`，记录预检、平台门禁、提交、证据和总耗时。

结果字段必须按以下语义使用：

| 字段 | 含义 |
|------|------|
| `executionOk` | 平台调用和策略执行是否完成 |
| `assertionStatus` | `passed` / `failed` / `inconclusive` / `skipped` |
| `evidenceStatus` | 规则、函数或三方证据是否完整 |
| `pass` | 仅当 `assertionStatus=passed` 时为 `true` |

禁止把 `runStatus=2` 单独解释成测试通过；证据不足必须保持 `inconclusive`。
存在 `expectedEvidence` 时必须逐项满足；缺少任一规则、函数、三方节点或字段均保持
`inconclusive`，禁止仅凭出现一次“三方节点”判定证据完整。

#### 方式B: 浏览器批量API（备用）

使用 `scripts/submit_batch.js` 时必须对所有 `{{...}}` 占位符做全局替换，而不是只替换
第一次出现的位置。模板只负责提交和重试，不能替代 Python 执行器的证据比对。

---

#### 方式C: UI交互提交（备用）

详见 [ant-design-tips.md](ant-design-tips.md)。流程：打开新增 → 选类型/策略/版本 → 生成测试数据 → 修改参数（用 `fill`，禁止 eval 改DOM）→ 提交。

关键：下拉菜单DOM挂在 `document.body` 下，用 `:not(.ant-select-dropdown-hidden)` 过滤；`fill` 自动触发 React onChange。

### Step 4: 验证测试结果

> **自主验证闭环**：自己通过API或浏览器验证，不让用户手动查看。

#### 验证层级（先轻后重）

| 层级 | 方式 | 验证内容 |
|------|------|---------|
| 1 | create API响应 | `policyDealTypeName`（整体决策） |
| 2 | runData `nodeType=8` | 各子策略 `finalDecision` |
| 3 | runData `nodeType=1` | `hitRuleList`（规则命中）、`inputFieldList`（ETL字段） |
| 4 | runData `nodeType=5` | 函数输出值、评分 |
| 5 | getAllCompontlog | 完整执行路径、三方数据、分支走向 |
| 6 | 浏览器导航 | 可视化确认 |

> 仅验证整体决策不够，还需验证**具体规则命中**、**函数输出**、**ETL字段值**。

#### 验证API

runData（分层查询）和 getAllCompontlog（全组件日志）的详细用法、JS调用模板、nodeType类型表均见 [api-reference.md](api-reference.md) "结果验证API" 节。

关键原则：
- **常规验证**用 runData 分层查（nodeType=8→子策略token → nodeType=1→规则命中 / nodeType=5→函数输出）
- **排查问题**用 getAllCompontlog（完整执行路径+三方数据+分支走向）
- **不要依赖 `getHitRuleList` API**——可能返回0条，用 runData nodeType=8+1 组合

#### 浏览器导航验证

报告URL：`http://{HOST}/noah/policyTest/report?token={uuid}&type=1`（uuid 是 `data.uuid`，不是 token）

#### DB验证

连接信息读取 `config.json` 的 `db` 配置，或通过环境变量 `TIANCE_DB_HOST`/`TIANCE_DB_PORT`/`TIANCE_DB_USER`/`TIANCE_DB_PASS`/`TIANCE_DB_NAME` 覆盖。DB表结构详见 [api-reference.md](api-reference.md) "DB验证" 节。

```bash
python3 scripts/verify_result.py --last 5
python3 scripts/verify_result.py --uuid "xxx" --json
```

需要创建三方测试数据时使用 Fixture 清单，不手写临时 SQL：

```bash
python3 scripts/fixture_manager.py validate \
  --manifest fixtures/{policyCode}.json --run-id {uniqueRunId}
python3 scripts/fixture_manager.py setup \
  --manifest fixtures/{policyCode}.json --run-id {uniqueRunId}
python3 scripts/fixture_manager.py verify \
  --manifest fixtures/{policyCode}.json --run-id {uniqueRunId}
# 报告完成后
python3 scripts/fixture_manager.py cleanup \
  --manifest fixtures/{policyCode}.json --run-id {uniqueRunId}
```

Fixture 的 `keyColumns` 至少一个值必须包含 `${RUN_ID}`。插入前如发现同键存量数据，
脚本直接回滚；清理只按本次渲染后的隔离键执行。

#### 结果比对

**不能只用字符串匹配。** 使用配置文件的 `comparisonRules` 比对：

| 类型 | 说明 |
|------|------|
| `alias_group` | 别名组（"红色预警"="redwarnbh"） |
| `pass_through` | 直通（"通过"="Accept"） |
| `fuzzy_alias` | 模糊别名（"中风险"→黄色或蓝色） |
| `numeric_tolerance` | 数值容差（±1.0） |
| `invalid_expectation` | 无效预期标记 |

详见 [comparison-framework.md](comparison-framework.md)。

### Step 5: 生成测试报告

> 增量更新，不全量重建。

**策略主Sheet**（以策略名命名），固定15列（列名定义见 `excel_formatter.py` 的 `COL_NAMES`，详细说明见 [api-reference.md](api-reference.md) "Excel报告标准列" 节）。

> **Col13 必须填 `data.uuid`**（32位小写hex），不能填 `data.token`。uuid 用于报告URL，token 是执行流水号。

**Col8 格式**：`提交策略测试API\npolicyCode=...\npolicyVersion=...\nbizType=...\n\n【关键入参】\n参数=值`

**Col10 格式**：
- 规则命中：`命中：规则编号(中文名)[风险等级] ✓`
- 规则未命中：`未命中规则编号(中文名)`
- 函数输出：`函数输出：函数名(编码)+字段=值`
- 禁止添加子策略汇总文字；决策流分支只确认路由

**样式**：表头蓝底白字 | 数据行微软雅黑9号 | 仅Col11着色（绿/红）| 全部细边框+顶部对齐+自动换行

```bash
python3 scripts/update_report.py results.json report.xlsx --config strategies/{policyCode}.json
python3 scripts/update_report.py --validate-report report.xlsx
```

报告采用临时文件保存并在结构校验通过后原子替换，要求前15列表头完全符合标准、
状态枚举有效且 Col13 为32位小写 UUID。工作簿标记为打开时完整重算公式；只在所有
结果完成后写入和渲染一次。

### Step 6: 获取真实三方数据（可选）

```
GET /noahApi/policy/report/test/baseInfo?id={uuid}&token={uuid}&tokenId={uuid}&type=1
```

查询参数用 **UUID**（`data.uuid`），不是 token。baseInfo 详细用法和返回结构见 [api-reference.md](api-reference.md) "baseInfo 报告详情" 节。

UUID/Token/childToken 三者的区别和获取方式见 [api-reference.md](api-reference.md) "UUID vs Token vs childToken" 节。核心要点：

- **UUID**（32位小写hex）：报告URL、baseInfo查询、Col13
- **Token**（35位混合大小写）：runData nodeType=8 查子策略
- **childToken**：从 nodeType=8 获取，用于 nodeType=1 查规则命中

> 流程：`create token` → `nodeType=8(token)` → `childToken` → `nodeType=1(childToken)` → 规则命中详情

## 新策略接入流程

1. **获取 policyCode**：用户提供或从平台确认
2. **自动发现**：`python3 scripts/discover_strategy.py discover --policy-code {code} --host {host} --csrf {token} --output strategies/{code}.json`
3. **补充配置**：检查并补充 `routingFields`、`subStrategies`、`comparisonRules`、`params.strategySpecific`
4. **编写用例**：按 Step 2 格式，参数参考配置文件的 `params` 定义
5. **执行测试**：按 Step 3~5 流程

## 常见问题（通用）

### FUNC_002 决策流调用失败
平台侧间歇性故障，`runStatus=-2`，`errorMsg="决策流调用失败"`。不是用例问题，记录为平台故障。

### 登录失效
创建新tab → 导航确认登录状态 → 提示用户重新登录 → Step 0 检查CSRF。

### 参数格式差异
数值型（`91`）、JSON数组字符串（`"[{...}]"`）、金额型、区域级别等，提交前确认配置文件中的参数类型。

### UI表单验证错误
"该项必填"=必填为空 | "请选择测试数据"=DOM修改未更新React状态，需用 `fill` 重填 | 提交无API请求=必须用 `fill` 不用 eval。

### searchKey 路由与缓存
引擎传给数据源的 searchKey **不一定等于用例参数**。多用例同名称时可能用缓存数据。**最佳实践**：每条用例用唯一企业名称。

### 规则预期值必须与平台配置一致
预期结果必须与平台规则定义的"命中结果"一致，否则判为未通过。从配置文件或落地方案校准。

### 外部数据源覆盖
某些入参会被三方数据源覆盖。检查配置文件的 `thirdPartyOverrides` 或 `notes`。

### 三方数据源返回 10907

先查数据源 `inputConfig`，确认 SQL 占位符与 `sqlParam` 映射；再查执行日志中的
`FeatureServiceNode.nodeInputList`。如果映射正确但 `nodeInputList` 为空，问题在测试
请求缺少系统字段，不要修改 SQL。把对应字段加入 `testExecution.requiredParams`，
配置可命中的测试默认值，并用 `prepare_testcases.py` 重新生成后再提交。

## 浏览器操作注意事项

- `tabId` 必须是 number 类型，不能是 string
- IIFE 语法：`(async function(){...})()`
- 注意 null 检查避免 `Cannot read properties of undefined`
- 超时设置 `timeout: 120` 秒

## 补充参考

- [api-reference.md](api-reference.md) — 通用API文档、三方数据覆盖详解
- [comparison-framework.md](comparison-framework.md) — 通用比对框架与配置文件格式说明
- [examples.md](examples.md) — 策略配置文件示例与测试用例示例
- [ant-design-tips.md](ant-design-tips.md) — Ant Design组件交互技巧
