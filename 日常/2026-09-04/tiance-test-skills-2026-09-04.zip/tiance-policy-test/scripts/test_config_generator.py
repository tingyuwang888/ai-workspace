#!/usr/bin/env python3
"""
config_generator.py 单元测试

覆盖：
  - extract_decision_results_from_raw()  — 原始 dealType 数据转换
  - generate_comparison_rules()          — 比对规则自动生成
  - generate_strategy_config()           — 完整策略配置组装
  - _safe_json()                         — JSON 安全解析
  - _is_pass_type() / _is_level_based()  — 内部辅助函数
"""
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock

# 确保 scripts/ 在 sys.path 中
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config_generator import (
    extract_decision_results_from_raw,
    generate_comparison_rules,
    generate_strategy_config,
    _safe_json,
    _is_pass_type,
    _is_level_based,
)


# ═══════════════════════════════════════════════════════
#  _safe_json
# ═══════════════════════════════════════════════════════

class TestSafeJson(unittest.TestCase):

    def test_none_input(self):
        self.assertIsNone(_safe_json(None))

    def test_response_with_json_method(self):
        resp = MagicMock()
        resp.json.return_value = {"status": "ok"}
        self.assertEqual(_safe_json(resp), {"status": "ok"})

    def test_response_json_raises(self):
        # .json() 存在但抛异常时，_safe_json 直接返回 None（无 text 回退）
        resp = MagicMock()
        resp.json.side_effect = ValueError("bad json")
        result = _safe_json(resp)
        self.assertIsNone(result)

    def test_response_text_only(self):
        class FakeResp:
            text = '{"a": 1}'
        result = _safe_json(FakeResp())
        self.assertEqual(result, {"a": 1})

    def test_string_input(self):
        result = _safe_json('{"key": "value"}')
        self.assertEqual(result, {"key": "value"})


# ═══════════════════════════════════════════════════════
#  _is_pass_type / _is_level_based
# ═══════════════════════════════════════════════════════

class TestIsPassType(unittest.TestCase):

    def test_pass_by_name(self):
        self.assertTrue(_is_pass_type("通过", []))
        self.assertTrue(_is_pass_type("Accept", []))

    def test_pass_by_alias(self):
        self.assertTrue(_is_pass_type("自定义名", ["通过审批"]))

    def test_not_pass(self):
        self.assertFalse(_is_pass_type("高风险", ["预警"]))
        self.assertFalse(_is_pass_type("拒绝", []))


class TestIsLevelBased(unittest.TestCase):

    def test_empty(self):
        self.assertFalse(_is_level_based([]))

    def test_single(self):
        self.assertFalse(_is_level_based([{"name": "高风险"}]))

    def test_level_system(self):
        results = [
            {"name": "高风险"},
            {"name": "中风险"},
            {"name": "低风险"},
        ]
        self.assertTrue(_is_level_based(results))

    def test_non_level_system(self):
        results = [
            {"name": "通过"},
            {"name": "拒绝"},
            {"name": "人工审批"},
        ]
        self.assertFalse(_is_level_based(results))


# ═══════════════════════════════════════════════════════
#  extract_decision_results_from_raw
# ═══════════════════════════════════════════════════════

class TestExtractDecisionResults(unittest.TestCase):

    def test_empty_input(self):
        self.assertEqual(extract_decision_results_from_raw(None), [])
        self.assertEqual(extract_decision_results_from_raw([]), [])

    def test_standard_format(self):
        raw = [
            {"name": "高风险", "code": "HIGH", "priority": 1},
            {"name": "低风险", "code": "LOW", "priority": 2},
        ]
        result = extract_decision_results_from_raw(raw)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]["name"], "高风险")
        self.assertEqual(result[0]["code"], "HIGH")
        self.assertEqual(result[0]["priority"], 1)
        self.assertIn("高风险", result[0]["aliases"])
        self.assertIn("HIGH", result[0]["aliases"])

    def test_alternative_field_names(self):
        raw = [{"typeName": "通过", "typeCode": "PASS"}]
        result = extract_decision_results_from_raw(raw)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["name"], "通过")
        self.assertEqual(result[0]["code"], "PASS")

    def test_deal_type_field_names(self):
        raw = [{"dealTypeName": "拒绝", "dealTypeCode": "REJECT"}]
        result = extract_decision_results_from_raw(raw)
        self.assertEqual(result[0]["name"], "拒绝")

    def test_label_field(self):
        raw = [{"label": "人工审批", "value": "MANUAL"}]
        result = extract_decision_results_from_raw(raw)
        self.assertEqual(result[0]["name"], "人工审批")
        self.assertEqual(result[0]["code"], "MANUAL")

    def test_skip_non_dict(self):
        raw = ["string_item", 42, {"name": "有效"}]
        result = extract_decision_results_from_raw(raw)
        self.assertEqual(len(result), 1)

    def test_skip_empty_name(self):
        raw = [{"code": "NO_NAME"}, {"name": "有效", "code": "OK"}]
        result = extract_decision_results_from_raw(raw)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["name"], "有效")

    def test_priority_defaults_to_index(self):
        raw = [{"name": "A"}, {"name": "B"}]
        result = extract_decision_results_from_raw(raw)
        self.assertEqual(result[0]["priority"], 0)
        self.assertEqual(result[1]["priority"], 1)

    def test_code_equals_name_single_alias(self):
        raw = [{"name": "通过", "code": "通过"}]
        result = extract_decision_results_from_raw(raw)
        self.assertEqual(result[0]["aliases"], ["通过"])


# ═══════════════════════════════════════════════════════
#  generate_comparison_rules
# ═══════════════════════════════════════════════════════

class TestGenerateComparisonRules(unittest.TestCase):

    def test_empty_input(self):
        self.assertEqual(generate_comparison_rules([]), [])
        self.assertEqual(generate_comparison_rules(None), [])

    def test_level_system_generates_alias_group(self):
        drs = [
            {"name": "高风险", "code": "HIGH", "aliases": ["HIGH"], "priority": 1},
            {"name": "中风险", "code": "MED", "aliases": ["MED"], "priority": 2},
            {"name": "低风险", "code": "LOW", "aliases": ["LOW"], "priority": 3},
        ]
        rules = generate_comparison_rules(drs)
        types = [r["type"] for r in rules]
        self.assertIn("alias_group", types)
        self.assertIn("keyword_present", types)

    def test_non_level_generates_keyword_present_per_result(self):
        drs = [
            {"name": "通过", "code": "PASS", "aliases": [], "priority": 1},
            {"name": "拒绝", "code": "REJECT", "aliases": [], "priority": 2},
        ]
        rules = generate_comparison_rules(drs)
        types = [r["type"] for r in rules]
        self.assertIn("keyword_absent", types)
        self.assertIn("keyword_present", types)

    def test_exploratory_rule(self):
        drs = [
            {"name": "高风险", "code": "H", "aliases": [], "priority": 1},
            {"name": "待探索", "code": "EXP", "aliases": [], "priority": 9},
        ]
        rules = generate_comparison_rules(drs)
        types = [r["type"] for r in rules]
        self.assertIn("exploratory", types)
        exp_rule = next(r for r in rules if r["type"] == "exploratory")
        self.assertIn("待探索", exp_rule["triggers"])
        self.assertIn("高风险", exp_rule["validIndicators"])

    def test_invalid_expectation_rule(self):
        drs = [
            {"name": "通过", "code": "P", "aliases": [], "priority": 1},
            {"name": "待验证", "code": "TV", "aliases": [], "priority": 9},
        ]
        rules = generate_comparison_rules(drs)
        types = [r["type"] for r in rules]
        self.assertIn("invalid_expectation", types)

    def test_fallback_error_detection_always_present(self):
        drs = [{"name": "通过", "code": "P", "aliases": [], "priority": 1}]
        rules = generate_comparison_rules(drs)
        last = rules[-1]
        self.assertEqual(last["type"], "keyword_present")
        self.assertIn("报错", last["triggers"])

    def test_skip_placeholder_names_in_alias_group(self):
        drs = [
            {"name": "高风险", "code": "H", "aliases": [], "priority": 1},
            {"name": "低风险", "code": "L", "aliases": [], "priority": 2},
            {"name": "待探索", "code": "EXP", "aliases": [], "priority": 9},
            {"name": "待验证", "code": "TV", "aliases": [], "priority": 10},
        ]
        rules = generate_comparison_rules(drs)
        ag = next((r for r in rules if r["type"] == "alias_group"), None)
        self.assertIsNotNone(ag)
        all_aliases = []
        for g in ag["groups"]:
            all_aliases.extend(g)
        self.assertNotIn("待探索", all_aliases)
        self.assertNotIn("待验证", all_aliases)


# ═══════════════════════════════════════════════════════
#  generate_strategy_config
# ═══════════════════════════════════════════════════════

class TestGenerateStrategyConfig(unittest.TestCase):

    def _make_drs(self):
        return [
            {"name": "通过", "code": "PASS", "aliases": [], "priority": 1},
            {"name": "拒绝", "code": "REJECT", "aliases": [], "priority": 2},
        ]

    def test_basic_structure(self):
        detail = {
            "policyName": "测试策略",
            "bizType": "借款类",
            "publishConfig": {
                "ordinaryConfig": {"version": "5"}
            },
        }
        drs = self._make_drs()
        config = generate_strategy_config("P_TEST_001", detail, drs)

        self.assertEqual(config["policyCode"], "P_TEST_001")
        self.assertEqual(config["policyName"], "测试策略")
        self.assertEqual(config["policyVersion"], 5)
        self.assertEqual(config["bizType"], "借款类")
        self.assertIn("comparisonRules", config)
        self.assertIn("params", config)
        self.assertIn("common", config["params"])

    def test_version_string_fallback(self):
        detail = {
            "policyName": "X",
            "publishConfig": {"ordinaryConfig": {"version": "abc"}},
        }
        config = generate_strategy_config("P_X", detail, [])
        self.assertEqual(config["policyVersion"], "abc")

    def test_empty_policy_detail(self):
        config = generate_strategy_config("P_EMPTY", None, [])
        self.assertEqual(config["policyCode"], "P_EMPTY")
        self.assertEqual(config["policyName"], "")
        self.assertEqual(config["policyVersion"], "")

    def test_sub_strategies_included(self):
        subs = [{"code": "SUB1", "name": "子策略1"}]
        config = generate_strategy_config("P_SUB", {}, self._make_drs(),
                                          sub_strategies=subs)
        self.assertIn("subStrategies", config)
        self.assertEqual(len(config["subStrategies"]), 1)

    def test_sub_strategies_omitted_when_empty(self):
        config = generate_strategy_config("P_SUB", {}, self._make_drs(),
                                          sub_strategies=[])
        self.assertNotIn("subStrategies", config)

    def test_raw_dtypes_stored(self):
        raw = [{"name": "通过", "code": "PASS"}]
        config = generate_strategy_config("P_DT", {}, self._make_drs(),
                                          raw_dtypes=raw)
        self.assertIn("_platformDecisionTypes", config)
        self.assertEqual(config["_platformDecisionTypes"], raw)

    def test_metadata_fields(self):
        config = generate_strategy_config("P_META", {}, [])
        self.assertIn("_generatedBy", config)
        self.assertIn("_generatedAt", config)
        self.assertIn("_note", config)

    def test_common_params_present(self):
        config = generate_strategy_config("P_PARAMS", {}, [])
        common = config["params"]["common"]
        self.assertIn("S_S_BIZID", common)
        self.assertIn("S_S_CUSTNO", common)
        self.assertIn("S_S_ORGCODE", common)
        self.assertIn("testExecution", config)
        self.assertEqual(
            config["testExecution"]["mockRequiredCaseTypes"],
            ["异常案例"],
        )

    def test_publish_config_as_string(self):
        detail = {
            "policyName": "字符串配置",
            "publishConfig": json.dumps({
                "ordinaryConfig": {"version": "3"}
            }),
        }
        config = generate_strategy_config("P_STR", detail, [])
        self.assertEqual(config["policyCode"], "P_STR")
        self.assertEqual(config["policyVersion"], 3)


if __name__ == "__main__":
    unittest.main()
