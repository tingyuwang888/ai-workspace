#!/usr/bin/env python3

import unittest

from mock_probe import run_probes


class FakeResponse:
    status_code = 200
    text = '{"status":"ready"}'

    def json(self):
        return {"status": "ready"}


class FakeSession:
    def request(self, method, url, headers, timeout, json):
        self.last_request = {
            "method": method,
            "url": url,
            "headers": headers,
            "timeout": timeout,
            "json": json,
        }
        return FakeResponse()


class TestMockProbe(unittest.TestCase):

    def test_emits_ready_proof_only_after_contract_matches(self):
        session = FakeSession()
        config = {
            "policyCode": "P_TEST",
            "testExecution": {
                "mockScenarios": {
                    "timeout": {
                        "probe": {
                            "path": "/mock/timeout/health",
                            "jsonEquals": {"status": "ready"},
                        }
                    }
                }
            },
        }

        proof = run_probes(
            config,
            "http://example.test",
            scenarios=["timeout"],
            session=session,
        )

        self.assertTrue(proof["scenarios"]["timeout"]["ready"])
        self.assertEqual(proof["policyCode"], "P_TEST")
        self.assertEqual(
            session.last_request["url"],
            "http://example.test/mock/timeout/health",
        )

    def test_unknown_scenario_is_not_ready(self):
        proof = run_probes(
            {"testExecution": {"mockScenarios": {}}},
            "http://example.test",
            scenarios=["unknown"],
            session=FakeSession(),
        )

        self.assertFalse(proof["scenarios"]["unknown"]["ready"])


if __name__ == "__main__":
    unittest.main()
