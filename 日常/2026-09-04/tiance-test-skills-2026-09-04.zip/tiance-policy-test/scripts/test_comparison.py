#!/usr/bin/env python3
"""
compare_generic() 单元测试 — 覆盖 9 种比对规则类型。

运行: cd scripts && python3 -m unittest test_comparison -v
"""
import os
import sys
import json
from pathlib import Path
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comparison_engine import compare_generic


class TestAliasGroup(unittest.TestCase):
    """alias_group: 别名组匹配"""

    def setUp(self):
        self.rules = [{
            "type": "alias_group",
            "groups": [
                ["红色预警", "redwarn", "redwarnbh"],
                ["黄色预警", "yellowwarn"],
                ["通过", "Accept", "pass"],
            ],
            "description": "别名组",
        }]

    def test_match_same_group(self):
        self.assertEqual(compare_generic("红色预警", "redwarnbh", self.rules), "通过")

    def test_mismatch_different_group(self):
        self.assertEqual(compare_generic("红色预警", "yellowwarn", self.rules), "未通过")

    def test_no_trigger_returns_none(self):
        """expected 不在任何组中 → 返回 None"""
        self.assertIsNone(compare_generic("未知结果", "redwarn", self.rules))

    def test_aliases_fallback(self):
        """没有 groups 时回退到 aliases（二维数组）"""
        rules = [{
            "type": "alias_group",
            "aliases": [
                ["绿灯", "greenalert"],
                ["红灯", "redalert"],
            ],
        }]
        self.assertEqual(compare_generic("绿灯", "redalert", rules), "未通过")
        self.assertEqual(compare_generic("绿灯", "greenalert", rules), "通过")


class TestKeywordPresent(unittest.TestCase):
    """keyword_present: 预期含 trigger 时，实际需包含 target"""

    def setUp(self):
        self.rules = [{
            "type": "keyword_present",
            "triggers": ["拒绝", "Reject"],
            "target": "拒绝",
            "description": "拒绝关键字",
        }]

    def test_trigger_hit_target_present(self):
        self.assertEqual(compare_generic("拒绝申请", "操作结果：拒绝", self.rules), "通过")

    def test_trigger_hit_target_absent(self):
        self.assertEqual(compare_generic("拒绝申请", "操作结果：通过", self.rules), "未通过")

    def test_trigger_miss_returns_none(self):
        self.assertIsNone(compare_generic("通过申请", "操作结果：拒绝", self.rules))

    def test_target_as_list(self):
        rules = [{
            "type": "keyword_present",
            "triggers": ["报错"],
            "target": ["失败", "错误", "异常"],
        }]
        self.assertEqual(compare_generic("系统报错", "执行失败", rules), "通过")
        self.assertEqual(compare_generic("系统报错", "执行成功", rules), "未通过")


class TestKeywordAbsent(unittest.TestCase):
    """keyword_absent: 预期含 trigger 时，实际不应包含 target"""

    def setUp(self):
        self.rules = [{
            "type": "keyword_absent",
            "triggers": ["通过", "Accept"],
            "target": ["拒绝", "失败", "红色预警"],
            "description": "通过时不应含失败关键字",
        }]

    def test_trigger_hit_target_absent_pass(self):
        self.assertEqual(compare_generic("通过", "Accept 正常", self.rules), "通过")

    def test_trigger_hit_target_present_fail(self):
        self.assertEqual(compare_generic("通过", "拒绝申请", self.rules), "未通过")

    def test_trigger_miss_returns_none(self):
        self.assertIsNone(compare_generic("待审核", "Accept", self.rules))


class TestNumericTolerance(unittest.TestCase):
    """numeric_tolerance: 数值容差比对"""

    def setUp(self):
        self.rules = [{
            "type": "numeric_tolerance",
            "expectedPattern": r"(\d+\.?\d*)",
            "actualPattern": r"(\d+\.?\d*)",
            "tolerance": 1.0,
        }]

    def test_within_tolerance(self):
        self.assertEqual(compare_generic("评分95.5", "评分=96.0", self.rules), "通过")

    def test_outside_tolerance(self):
        self.assertEqual(compare_generic("评分100", "评分=80", self.rules), "未通过")

    def test_exact_match(self):
        self.assertEqual(compare_generic("金额500", "金额=500", self.rules), "通过")

    def test_no_numbers_skips(self):
        """无数字时跳过，返回 None"""
        self.assertIsNone(compare_generic("无数字", "也没有", self.rules))


class TestExploratory(unittest.TestCase):
    """exploratory: 探索性用例"""

    def setUp(self):
        self.rules = [{
            "type": "exploratory",
            "triggers": ["待探索"],
            "validIndicators": ["红色预警", "黄色预警", "通过"],
        }]

    def test_valid_indicator_pass(self):
        self.assertEqual(compare_generic("待探索", "黄色预警", self.rules), "通过")

    def test_invalid_indicator_fail(self):
        self.assertEqual(compare_generic("待探索", "系统错误", self.rules), "未通过")

    def test_trigger_miss_returns_none(self):
        self.assertIsNone(compare_generic("正常预期", "黄色预警", self.rules))


class TestPassThrough(unittest.TestCase):
    """pass_through: 透传匹配"""

    def setUp(self):
        self.rules = [{
            "type": "pass_through",
            "triggers": ["通过"],
            "matchActual": ["Accept", "pass", "通过"],
        }]

    def test_match_actual_hit(self):
        self.assertEqual(compare_generic("通过", "Accept", self.rules), "通过")

    def test_match_actual_miss(self):
        self.assertEqual(compare_generic("通过", "Reject", self.rules), "未通过")

    def test_trigger_miss_returns_none(self):
        self.assertIsNone(compare_generic("拒绝", "Accept", self.rules))


class TestInvalidExpectation(unittest.TestCase):
    """invalid_expectation: 无效预期直接返回未通过"""

    def setUp(self):
        self.rules = [{
            "type": "invalid_expectation",
            "triggers": ["待验证", "待确认"],
        }]

    def test_trigger_hit_returns_fail(self):
        self.assertEqual(compare_generic("待验证", "任何结果", self.rules), "未通过")

    def test_trigger_miss_returns_none(self):
        self.assertIsNone(compare_generic("正常预期", "任何结果", self.rules))


class TestFuzzyAlias(unittest.TestCase):
    """fuzzy_alias: 模糊别名匹配"""

    def setUp(self):
        self.rules = [{
            "type": "fuzzy_alias",
            "pattern": "中风险",
            "matches": ["黄色预警", "蓝色预警"],
        }]

    def test_pattern_match_hit(self):
        self.assertEqual(compare_generic("中风险等级", "黄色预警", self.rules), "通过")

    def test_pattern_match_miss(self):
        self.assertEqual(compare_generic("中风险等级", "红色预警", self.rules), "未通过")

    def test_pattern_no_match_returns_none(self):
        self.assertIsNone(compare_generic("高风险", "黄色预警", self.rules))


class TestRegexMatch(unittest.TestCase):
    """regex_match: 正则匹配"""

    def setUp(self):
        self.rules = [{
            "type": "regex_match",
            "triggerPattern": r"评分[>=<]+\s*\d+",
            "actualPattern": r"score[=:]\s*\d+",
        }]

    def test_trigger_match_actual_hit(self):
        self.assertEqual(
            compare_generic("评分>=80", "score=85", self.rules), "通过"
        )

    def test_trigger_match_actual_miss(self):
        self.assertEqual(
            compare_generic("评分>=80", "result=pass", self.rules), "未通过"
        )

    def test_trigger_no_match_returns_none(self):
        self.assertIsNone(compare_generic("无评分信息", "score=85", self.rules))


class TestNoRuleMatch(unittest.TestCase):
    """所有规则未命中 → 返回 None"""

    def test_empty_rules(self):
        self.assertIsNone(compare_generic("任何", "结果", []))

    def test_no_trigger_match(self):
        rules = [
            {"type": "keyword_present", "triggers": ["拒绝"], "target": "拒绝"},
            {"type": "keyword_absent", "triggers": ["通过"], "target": "失败"},
        ]
        self.assertIsNone(compare_generic("待审核", "正常", rules))


class TestFirstMatchWins(unittest.TestCase):
    """第一条命中规则决定结果"""

    def test_first_rule_decides(self):
        rules = [
            {"type": "keyword_present", "triggers": ["拒绝"], "target": "拒绝"},
            {"type": "keyword_absent", "triggers": ["拒绝"], "target": "通过"},
        ]
        # 第一条 keyword_present 命中，target="拒绝" 在实际中存在 → 通过
        result = compare_generic("拒绝申请", "操作：拒绝", rules)
        self.assertEqual(result, "通过")

    def test_pre_concentration_negative_limit_precedes_generic_limit(self):
        config_path = (
            Path(__file__).resolve().parent.parent
            / "strategies"
            / "DF_PRE_CONC_001.json"
        )
        rules = json.loads(config_path.read_text(encoding="utf-8"))[
            "comparisonRules"
        ]

        result = compare_generic(
            "区域集中度未超限（额度低于阈值）",
            "C_S_AREACONCRESULT=Accept\n综合结果: 全部通过",
            rules,
        )

        self.assertEqual(result, "通过")


if __name__ == "__main__":
    unittest.main()
