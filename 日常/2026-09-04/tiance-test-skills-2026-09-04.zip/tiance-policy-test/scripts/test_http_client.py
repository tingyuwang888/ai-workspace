#!/usr/bin/env python3

import argparse
import unittest

from http_client import build_session


class TestHttpClient(unittest.TestCase):

    def test_uses_tiance_csrf_headers(self):
        session = build_session(argparse.Namespace(
            csrf="TOKEN",
            csrf_token=None,
            cookie="JSESSIONID=session",
        ))

        self.assertEqual(session.headers["X-Cf-Random"], "TOKEN")
        self.assertEqual(session.headers["_csrf_"], "TOKEN")
        self.assertNotIn("X-CSRF-TOKEN", session.headers)
        self.assertNotIn("X-XSRF-TOKEN", session.headers)
        self.assertNotIn("Content-Type", session.headers)


if __name__ == "__main__":
    unittest.main()
