#!/usr/bin/env python3

import unittest
import time

from platform_guard import (
    find_policy,
    make_snapshot,
    validate_platform_config,
    validate_snapshot_freshness,
)


class TestPlatformGuard(unittest.TestCase):

    def setUp(self):
        self.config = {
            "policyCode": "P001",
            "policyVersion": 2,
            "bizType": 1,
        }

    def test_parses_nested_contents_and_publish_config_string(self):
        snapshot = {
            "success": True,
            "data": {
                "contents": [{
                    "policyCode": "P001",
                    "policyName": "测试策略",
                    "businessType": 1,
                    "status": 4,
                    "publishConfig": '{"ordinaryConfig":{"version":2}}',
                }]
            },
        }

        policy = find_policy(snapshot, "P001")
        report = validate_platform_config(self.config, snapshot)

        self.assertEqual(policy["policyVersion"], 2)
        self.assertTrue(report["ok"], report["errors"])

    def test_blocks_version_and_biz_type_mismatch(self):
        snapshot = [{
            "code": "P001",
            "name": "测试策略",
            "version": 3,
            "businessType": 4,
            "statusName": "已发布",
        }]

        report = validate_platform_config(self.config, snapshot)

        self.assertFalse(report["ok"])
        self.assertTrue(any("版本不一致" in e for e in report["errors"]))
        self.assertTrue(any("业务类型不一致" in e for e in report["errors"]))

    def test_blocks_unpublished_or_missing_policy(self):
        unpublished = [{
            "policyCode": "P001",
            "policyVersion": 2,
            "bizType": 1,
            "status": 2,
        }]

        self.assertFalse(
            validate_platform_config(self.config, unpublished)["ok"]
        )
        self.assertFalse(
            validate_platform_config(self.config, [])["ok"]
        )

    def test_snapshot_requires_recent_capture_time(self):
        recent = {
            "capturedAt": int(time.time()),
            "payload": [],
        }
        stale = {
            "capturedAt": int(time.time()) - 601,
            "payload": [],
        }

        self.assertTrue(validate_snapshot_freshness(recent))
        with self.assertRaisesRegex(RuntimeError, "已过期"):
            validate_snapshot_freshness(stale)
        with self.assertRaisesRegex(RuntimeError, "缺少 capturedAt"):
            validate_snapshot_freshness({"payload": []})

    def test_wraps_raw_browser_payload_with_fresh_timestamp(self):
        raw = [{"policyCode": "P001"}]

        snapshot = make_snapshot(raw)

        self.assertEqual(snapshot["payload"], raw)
        self.assertEqual(snapshot["source"], "browser-network")
        self.assertTrue(validate_snapshot_freshness(snapshot))


if __name__ == "__main__":
    unittest.main()
