#!/usr/bin/env python3

import unittest

from openpyxl import Workbook

from excel_formatter import (
    COL_NAMES,
    extend_summary_formula_ranges,
    find_report_sheet,
    prepare_workbook_for_recalculation,
    validate_report_schema,
)


class TestExcelFormatter(unittest.TestCase):

    def test_validates_standard_headers_status_and_uuid(self):
        workbook = Workbook()
        sheet = workbook.active
        sheet.append(COL_NAMES)
        sheet.append([
            "TC_001", "规则", "规则命中", "", "", "正案例", "", "",
            "命中", "命中", "通过", "2026-07-30 12:00:00",
            "0123456789abcdef0123456789abcdef", "", "",
        ])

        self.assertEqual(validate_report_schema(sheet), [])

    def test_rejects_bad_header_status_and_token_in_uuid_column(self):
        workbook = Workbook()
        sheet = workbook.active
        bad_headers = list(COL_NAMES)
        bad_headers[3] = "错误表头"
        sheet.append(bad_headers)
        sheet.append([
            "TC_001", "规则", "", "", "", "", "", "", "", "",
            "已完成", "", "TOKEN_NOT_UUID", "", "",
        ])

        errors = validate_report_schema(sheet)

        self.assertTrue(any("表头" in error for error in errors))
        self.assertTrue(any("测试状态无效" in error for error in errors))
        self.assertTrue(any("UUID格式无效" in error for error in errors))

    def test_marks_workbook_for_full_recalculation(self):
        workbook = Workbook()

        prepare_workbook_for_recalculation(workbook)

        self.assertTrue(workbook.calculation.fullCalcOnLoad)
        self.assertTrue(workbook.calculation.forceFullCalc)
        self.assertEqual(workbook.calculation.calcMode, "auto")

    def test_finds_testcase_sheet_when_summary_is_active(self):
        workbook = Workbook()
        workbook.active.title = "汇总"
        workbook.active["A1"] = "策略测试报告"
        testcase_sheet = workbook.create_sheet("策略明细")
        testcase_sheet.append(COL_NAMES)

        found = find_report_sheet(workbook)

        self.assertEqual(found.title, "策略明细")

    def test_extends_summary_ranges_to_last_testcase_row(self):
        workbook = Workbook()
        summary = workbook.active
        summary.title = "汇总"
        detail = workbook.create_sheet("策略明细")
        detail.append(COL_NAMES)
        detail.append(["TC_001"])
        detail.append(["TC_002"])
        summary["A1"] = "=COUNTA('策略明细'!A2:A99)"
        summary["A2"] = '=COUNTIF(\'策略明细\'!K2:K99,"通过")'

        changed = extend_summary_formula_ranges(workbook, detail)

        self.assertEqual(changed, 2)
        self.assertEqual(summary["A1"].value, "=COUNTA('策略明细'!A2:A3)")
        self.assertEqual(
            summary["A2"].value,
            '=COUNTIF(\'策略明细\'!K2:K3,"通过")',
        )


if __name__ == "__main__":
    unittest.main()
