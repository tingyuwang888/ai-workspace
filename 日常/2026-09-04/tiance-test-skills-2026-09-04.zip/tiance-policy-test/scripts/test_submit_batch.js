const fs = require('fs');
const assert = require('assert');

global.sessionStorage = { getItem: () => 'TOKEN' };
global.document = { cookie: '' };
global.setTimeout = (callback) => {
  callback();
  return 0;
};

async function runWithResponses(responses) {
  let calls = 0;
  global.fetch = async () => responses[calls++];

  let source = fs.readFileSync(
    __dirname + '/submit_batch.js',
    'utf8'
  );
  const replacements = {
    '{{POLICY_CODE}}': 'P001',
    '{{POLICY_NAME}}': '测试策略',
    '{{POLICY_VERSION}}': '1',
    '{{BIZ_TYPE}}': '1',
    '{{TEST_CASES}}': JSON.stringify([
      {id: 'TC_001', expected: '通过', params: {A: 1}}
    ])
  };
  for (const [placeholder, value] of Object.entries(replacements)) {
    source = source.split(placeholder).join(value);
  }

  const result = JSON.parse(await eval(source));
  return {calls, result};
}

(async () => {
  const retriedHttp = await runWithResponses([
    {status: 500, ok: false, json: async () => ({success: false})},
    {
      status: 200,
      ok: true,
      json: async () => ({
        success: true,
        data: {runStatus: '2', policyDealTypeName: '通过'}
      })
    }
  ]);
  assert.strictEqual(retriedHttp.calls, 2);
  assert.strictEqual(retriedHttp.result.length, 1);
  assert.strictEqual(retriedHttp.result[0].ok, true);

  const exhausted = await runWithResponses([
    {
      status: 200,
      ok: true,
      json: async () => ({success: false, message: 'busy'})
    },
    {
      status: 200,
      ok: true,
      json: async () => ({success: false, message: 'busy'})
    },
    {
      status: 200,
      ok: true,
      json: async () => ({success: false, message: 'busy'})
    }
  ]);
  assert.strictEqual(exhausted.calls, 3);
  assert.strictEqual(exhausted.result.length, 1);
  assert.match(exhausted.result[0].err, /^RETRY_EXHAUSTED:/);

  console.log('submit_batch.js tests passed');
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
