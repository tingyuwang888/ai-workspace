#!/usr/bin/env python3
"""
天策策略测试 — 通用比对引擎

将策略配置加载、验证、比对逻辑从 update_report.py 中拆分出来，
作为独立模块供 report 更新、relabel、validate 等场景复用。

Public API:
    STRATEGIES_DIR          — 顶层 strategies/ 目录路径
    SHEET_POLICY_MAP        — sheet名 → policyCode 映射
    _LEGACY_STRATEGY_MAP    — 旧版缩写 → 完整 policyCode 映射
    load_strategy_config()  — 加载策略配置JSON
    validate_strategy_config() — 校验配置格式
    compare_generic()       — 配置驱动的通用比对函数
    resolve_comparator()    — 按优先级解析比对器
"""
import json
import re
import sys
from pathlib import Path

# ── 脚本所在目录 → 顶层 strategies/ 目录 ──
_SCRIPT_DIR = Path(__file__).resolve().parent
STRATEGIES_DIR = _SCRIPT_DIR.parent / "strategies"

# ── sheet名 → 默认 policyCode 的映射（用于自动推断） ──
SHEET_POLICY_MAP = {
    '保前集中度判断_单户关联户区域': 'DF_PRE_CONC_001',
    '保后单户及关联户集中度': 'DF_POST_SH_002',
    '保后区域集中度': 'DF_POST_AREA_003',
    '集团预警等级判定策略': 'Group_Warning_Level_Strategy',
    '五级分类自动评级策略': 'automated_5_tier_rating_strategy',
    '保后检查贷前主策略': 'bhjcpostMainBefore',
}

# ── 旧版策略名 → 配置文件名映射（向后兼容 --strategy 参数） ──
_LEGACY_STRATEGY_MAP = {
    'jzd': 'DF_PRE_CONC_001',
    'jt': 'Group_Warning_Level_Strategy',
    'wjfl': 'automated_5_tier_rating_strategy',
    'bhjc': 'bhjcpostMainBefore',
}

# ── 日志辅助（输出到 stderr，不影响正常输出） ──
def _log(msg):
    print(f"[comparison_engine] {msg}", file=sys.stderr)


# ── 比对规则合法类型 ──
_VALID_COMPARISON_TYPES = {
    'alias_group', 'keyword_present', 'keyword_absent',
    'numeric_tolerance', 'exploratory', 'pass_through',
    'invalid_expectation', 'regex_match', 'fuzzy_alias',
}


# ═══════════════════════════════════════════════════════
#  策略配置加载与验证
# ═══════════════════════════════════════════════════════

def load_strategy_config(policy_code_or_path):
    """
    加载策略配置JSON文件。

    参数:
        policy_code_or_path: 可以是以下之一：
            - 文件路径（绝对或相对路径，指向.json文件）
            - policyCode（如 'DF_PRE_CONC_001'），自动查找 strategies/{policyCode}.json

    返回:
        (rules: list, config_path: Path)

    异常:
        FileNotFoundError / json.JSONDecodeError / ValueError
    """
    input_str = str(policy_code_or_path).strip()

    # 情况1：直接是文件路径
    if input_str.endswith('.json') or '/' in input_str or input_str.startswith('.'):
        config_path = Path(input_str)
        if not config_path.is_absolute():
            config_path = config_path.resolve()
    else:
        # 情况2：作为 policyCode，查找顶层 strategies/ 目录
        config_path = STRATEGIES_DIR / f"{input_str}.json"

    if not config_path.exists():
        raise FileNotFoundError(
            f"策略配置文件不存在: {config_path}\n"
            f"  如果是 policyCode，请确认 strategies/ 目录下有 {input_str}.json"
        )

    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)

    if 'comparisonRules' not in config:
        raise ValueError(f"配置文件中缺少 'comparisonRules' 字段: {config_path}")

    rules = config['comparisonRules']
    if not isinstance(rules, list):
        raise ValueError(f"'comparisonRules' 必须是数组: {config_path}")

    return rules, config_path


def _validate_config_structure(config, config_path):
    """
    验证策略配置JSON的顶层必填字段。

    返回:
        (errors: list[str], warnings: list[str])
    """
    errors = []
    warnings = []

    # ── 必填字段检查 ──
    required_string = ['policyCode', 'policyName']
    for field in required_string:
        val = config.get(field)
        if not val or not isinstance(val, str):
            errors.append(f"缺少或格式错误: '{field}' 须为非空字符串")

    # policyVersion: int 或 string 均可
    ver = config.get('policyVersion')
    if ver is None:
        errors.append("缺少: 'policyVersion'")
    elif not isinstance(ver, (int, str)):
        errors.append(f"格式错误: 'policyVersion' 须为 int 或 string，当前为 {type(ver).__name__}")

    # bizType: int
    bt = config.get('bizType')
    if bt is None:
        errors.append("缺少: 'bizType'")
    elif not isinstance(bt, int):
        errors.append(f"格式错误: 'bizType' 须为 int，当前为 {type(bt).__name__}")

    # decisionResults: array，每项须有 name
    dr = config.get('decisionResults')
    if dr is None:
        warnings.append("未定义 'decisionResults'（比对时可能无法识别决策结果）")
    elif not isinstance(dr, list):
        errors.append(f"格式错误: 'decisionResults' 须为数组，当前为 {type(dr).__name__}")
    else:
        for i, item in enumerate(dr):
            if not isinstance(item, dict):
                errors.append(f"decisionResults[{i}]: 须为对象")
            elif 'name' not in item:
                errors.append(f"decisionResults[{i}]: 缺少 'name' 字段")

    # params: object，须有 common 或 strategySpecific
    params = config.get('params')
    if params is None:
        warnings.append("未定义 'params'（用例参数需手动组装）")
    elif not isinstance(params, dict):
        errors.append(f"格式错误: 'params' 须为对象，当前为 {type(params).__name__}")
    else:
        has_common = 'common' in params
        has_specific = 'strategySpecific' in params
        if not has_common and not has_specific:
            warnings.append("'params' 中没有 'common' 也没有 'strategySpecific'，用例参数需手动组装")
        for group_name in ('common', 'strategySpecific'):
            group = params.get(group_name, {})
            if not isinstance(group, dict):
                errors.append(
                    f"格式错误: 'params.{group_name}' 须为对象"
                )
                continue
            for field, spec in group.items():
                if not isinstance(spec, dict):
                    errors.append(
                        f"格式错误: params.{group_name}.{field} 须为对象"
                    )

    known_params = set()
    if isinstance(params, dict):
        for group_name in ('common', 'strategySpecific'):
            group = params.get(group_name, {})
            if isinstance(group, dict):
                known_params.update(group)

    routing_fields = config.get('routingFields')
    if routing_fields is not None:
        if not isinstance(routing_fields, dict):
            errors.append("格式错误: 'routingFields' 须为对象")
        else:
            for field, spec in routing_fields.items():
                if not isinstance(spec, dict):
                    errors.append(
                        f"格式错误: routingFields.{field} 须为对象"
                    )
                if field not in known_params:
                    errors.append(
                        f"routingFields.{field} 未在 params 中定义"
                    )

    third_party = config.get('thirdPartyOverrides')
    if third_party is not None:
        if not isinstance(third_party, list):
            errors.append("格式错误: 'thirdPartyOverrides' 须为数组")
        else:
            for i, override in enumerate(third_party):
                if not isinstance(override, dict):
                    errors.append(
                        f"thirdPartyOverrides[{i}] 须为对象"
                    )
                    continue
                if not override.get('field') or not override.get('source'):
                    errors.append(
                        f"thirdPartyOverrides[{i}] 缺少 field/source"
                    )

    execution = config.get('testExecution')
    if execution is not None and not isinstance(execution, dict):
        errors.append("格式错误: 'testExecution' 须为对象")
    elif isinstance(execution, dict):
        required_params = execution.get('requiredParams', [])
        if not isinstance(required_params, list) or not all(
            isinstance(field, str) and field
            for field in required_params
        ):
            errors.append(
                "格式错误: testExecution.requiredParams 须为非空字符串数组"
            )

        for key in ('defaults', 'defaultsByCaseType', 'mockScenarios'):
            value = execution.get(key, {})
            if not isinstance(value, dict):
                errors.append(f"格式错误: testExecution.{key} 须为对象")

        defaults_by_type = execution.get('defaultsByCaseType', {})
        if isinstance(defaults_by_type, dict):
            for case_type, defaults in defaults_by_type.items():
                if not isinstance(defaults, dict):
                    errors.append(
                        "格式错误: "
                        f"testExecution.defaultsByCaseType.{case_type} 须为对象"
                    )

        mock_required_types = execution.get(
            'mockRequiredCaseTypes',
            ['异常案例'],
        )
        if not isinstance(mock_required_types, list) or not all(
            isinstance(case_type, str) and case_type
            for case_type in mock_required_types
        ):
            errors.append(
                "格式错误: testExecution.mockRequiredCaseTypes "
                "须为非空字符串数组"
            )

        declared_fields = set(required_params) | known_params
        defaults = execution.get('defaults', {})
        if isinstance(defaults, dict):
            for field in defaults:
                if field not in declared_fields:
                    warnings.append(
                        f"testExecution.defaults.{field} 未在 params/"
                        "requiredParams 中声明"
                    )
    elif isinstance(third_party, list) and third_party:
        warnings.append(
            "存在 thirdPartyOverrides 但未定义 testExecution；"
            "无法预检数据源查询参数"
        )

    # comparisonRules: 必须存在（已由 load_strategy_config 检查，此处再验一次）
    cr = config.get('comparisonRules')
    if cr is None:
        errors.append("缺少: 'comparisonRules'")
    elif not isinstance(cr, list):
        errors.append(f"格式错误: 'comparisonRules' 须为数组，当前为 {type(cr).__name__}")
    elif len(cr) == 0:
        warnings.append("'comparisonRules' 为空数组，所有比对将返回 None")

    return errors, warnings


def validate_strategy_config(policy_code_or_path):
    """
    验证策略配置JSON文件的完整性和格式正确性。

    包含两层验证：
    1. 顶层结构验证（policyCode、policyName、bizType 等必填字段）
    2. comparisonRules 规则级验证（每条规则的类型和必填属性）

    返回:
        (is_valid: bool, errors: list[str], warnings: list[str])
    """
    errors = []
    warnings = []

    # ── 加载完整配置（用于结构验证） ──
    try:
        input_str = str(policy_code_or_path).strip()
        if input_str.endswith('.json') or '/' in input_str or input_str.startswith('.'):
            config_path = Path(input_str)
            if not config_path.is_absolute():
                config_path = config_path.resolve()
        else:
            config_path = STRATEGIES_DIR / f"{input_str}.json"

        if not config_path.exists():
            return False, [f"策略配置文件不存在: {config_path}"], []

        with open(config_path, 'r', encoding='utf-8') as f:
            full_config = json.load(f)
    except json.JSONDecodeError as e:
        return False, [f"JSON 解析失败: {e}"], []

    # ── 第一层：顶层结构验证 ──
    struct_errors, struct_warnings = _validate_config_structure(full_config, config_path)
    errors.extend(struct_errors)
    warnings.extend(struct_warnings)

    # ── 第二层：comparisonRules 规则级验证 ──
    rules = full_config.get('comparisonRules', [])
    if not isinstance(rules, list):
        rules = []  # 已在结构验证中报错，这里防止后续崩溃

    def _check_triggers(rule, prefix, rtype):
        """检查 trigger/triggers 字段是否存在"""
        if 'trigger' not in rule and 'triggers' not in rule:
            keys = list(rule.keys())
            errors.append(f"{prefix}: {rtype} 缺少 'trigger'/'triggers'，现有键: {keys}")

    for i, rule in enumerate(rules):
        prefix = f"规则[{i}]"

        if not isinstance(rule, dict):
            errors.append(f"{prefix}: 须为对象，当前为 {type(rule).__name__}")
            continue

        rtype = rule.get('type')
        if not rtype:
            keys = list(rule.keys())
            errors.append(f"{prefix}: 缺少 'type' 字段，现有键: {keys}")
            continue
        if rtype not in _VALID_COMPARISON_TYPES:
            errors.append(
                f"{prefix}: 不支持的类型 '{rtype}'，"
                f"合法类型: {sorted(_VALID_COMPARISON_TYPES)}"
            )
            continue

        if rtype == 'alias_group':
            # 修复：同时检查 'aliases' 回退键（与 compare_generic 一致）
            if 'trigger' not in rule and 'groups' not in rule and 'aliases' not in rule:
                errors.append(f"{prefix}: alias_group 缺少 'groups'/'aliases'/'trigger'")

        elif rtype == 'keyword_present':
            _check_triggers(rule, prefix, rtype)
            if 'target' not in rule:
                errors.append(f"{prefix}: keyword_present 缺少 'target'")

        elif rtype == 'keyword_absent':
            _check_triggers(rule, prefix, rtype)
            if 'target' not in rule:
                errors.append(f"{prefix}: keyword_absent 缺少 'target'")

        elif rtype == 'numeric_tolerance':
            if 'expectedPattern' not in rule:
                errors.append(f"{prefix}: numeric_tolerance 缺少 'expectedPattern'")
            if 'actualPattern' not in rule:
                errors.append(f"{prefix}: numeric_tolerance 缺少 'actualPattern'")
            if 'tolerance' not in rule:
                warnings.append(f"{prefix}: numeric_tolerance 未设置 'tolerance'，默认0.5")
            for pat_field in ('expectedPattern', 'actualPattern'):
                pat = rule.get(pat_field)
                if pat:
                    try:
                        re.compile(pat)
                    except re.error as e:
                        errors.append(f"{prefix}: '{pat_field}' 正则无效: {e} (pattern: {pat!r})")

        elif rtype == 'exploratory':
            _check_triggers(rule, prefix, rtype)
            indicators = rule.get('validIndicators') or rule.get('indicators')
            if not indicators or not isinstance(indicators, list):
                errors.append(f"{prefix}: exploratory 缺少 'validIndicators'/'indicators' 或格式错误")

        elif rtype == 'pass_through':
            _check_triggers(rule, prefix, rtype)
            if 'matchActual' not in rule or not isinstance(rule.get('matchActual'), list):
                errors.append(f"{prefix}: pass_through 缺少 'matchActual' 或格式错误")

        elif rtype == 'invalid_expectation':
            _check_triggers(rule, prefix, rtype)

        elif rtype == 'fuzzy_alias':
            if 'pattern' not in rule:
                errors.append(f"{prefix}: fuzzy_alias 缺少 'pattern'")
            if 'matches' not in rule or not isinstance(rule.get('matches'), list):
                errors.append(f"{prefix}: fuzzy_alias 缺少 'matches' 或格式错误")

        elif rtype == 'regex_match':
            if 'triggerPattern' not in rule:
                errors.append(f"{prefix}: regex_match 缺少 'triggerPattern'")
            if 'actualPattern' not in rule:
                errors.append(f"{prefix}: regex_match 缺少 'actualPattern'")
            for pat_field in ('triggerPattern', 'actualPattern'):
                pat = rule.get(pat_field)
                if pat:
                    try:
                        re.compile(pat)
                    except re.error as e:
                        errors.append(f"{prefix}: '{pat_field}' 正则无效: {e} (pattern: {pat!r})")

        if 'description' not in rule:
            warnings.append(f"{prefix}: 建议添加 'description' 字段")

    is_valid = len(errors) == 0
    return is_valid, errors, warnings


# ═══════════════════════════════════════════════════════
#  通用比对函数（配置驱动）
# ═══════════════════════════════════════════════════════

def compare_generic(expected, actual, comparison_rules):
    """
    根据 comparisonRules 配置列表，逐条规则比对预期结果与实际结果。

    规则按顺序执行，第一条命中的规则决定最终结果。
    如果所有规则都未命中，返回 None（表示"无法判断"）。

    参数:
        expected: 预期结果字符串
        actual: 实际结果字符串
        comparison_rules: 规则列表（来自策略配置JSON的 comparisonRules）

    返回:
        '通过' | '未通过' | None
    """
    exp = str(expected or '')
    act = str(actual or '')

    for rule in comparison_rules:
        rtype = rule.get('type')

        # 兼容 trigger(单数) 和 triggers(复数) 两种写法
        triggers = rule.get('triggers') or rule.get('trigger') or []
        if isinstance(triggers, str):
            triggers = [triggers]

        # ── alias_group: 别名组匹配 ──
        if rtype == 'alias_group':
            groups = rule.get('groups', [])
            if not groups:
                groups = rule.get('aliases', [])

            for group in groups:
                if not isinstance(group, list):
                    continue
                exp_in_group = any(alias in exp for alias in group)
                if exp_in_group:
                    act_in_group = any(alias in act for alias in group)
                    return '通过' if act_in_group else '未通过'

        # ── keyword_present: 预期含trigger时，实际需包含target ──
        elif rtype == 'keyword_present':
            target = rule.get('target', '')

            if any(k in exp for k in triggers):
                if isinstance(target, list):
                    return '通过' if any(t in act for t in target) else '未通过'
                return '通过' if target in act else '未通过'

        # ── keyword_absent: 预期含trigger时，实际不应包含target ──
        elif rtype == 'keyword_absent':
            target = rule.get('target', '')

            if any(k in exp for k in triggers):
                if isinstance(target, list):
                    return '通过' if not any(t in act for t in target) else '未通过'
                return '通过' if target not in act else '未通过'

        # ── numeric_tolerance: 数值容差比对 ──
        elif rtype == 'numeric_tolerance':
            exp_pattern = rule.get('expectedPattern', '')
            act_pattern = rule.get('actualPattern', '')
            tolerance = rule.get('tolerance', 0.5)

            exp_nums = re.findall(exp_pattern, exp)
            act_nums = re.findall(act_pattern, act)

            if exp_nums and act_nums:
                try:
                    exp_val = float(exp_nums[0])
                    act_val = float(act_nums[0])
                    return '通过' if abs(exp_val - act_val) <= tolerance else '未通过'
                except (ValueError, IndexError) as e:
                    _log(f"numeric_tolerance: 数值转换失败 ({e}), exp={exp_nums}, act={act_nums}")
                    continue

        # ── exploratory: 探索性用例 ──
        elif rtype == 'exploratory':
            indicators = rule.get('validIndicators') or rule.get('indicators') or []

            if any(k in exp for k in triggers):
                if any(ind in act for ind in indicators):
                    return '通过'
                return '未通过'

        # ── pass_through: 透传匹配 ──
        elif rtype == 'pass_through':
            match_actual = rule.get('matchActual', [])

            if any(k in exp for k in triggers):
                return '通过' if any(m in act for m in match_actual) else '未通过'

        # ── invalid_expectation: 无效预期（直接判定未通过） ──
        elif rtype == 'invalid_expectation':
            if any(k in exp for k in triggers):
                return '未通过'

        # ── fuzzy_alias: 模糊别名匹配 ──
        elif rtype == 'fuzzy_alias':
            pattern = rule.get('pattern', '')
            matches = rule.get('matches', [])

            if pattern and pattern in exp:
                return '通过' if any(m in act for m in matches) else '未通过'

        # ── regex_match: 正则匹配 ──
        elif rtype == 'regex_match':
            trigger_pattern = rule.get('triggerPattern', '')
            actual_pattern = rule.get('actualPattern', '')

            try:
                if re.search(trigger_pattern, exp):
                    return '通过' if re.search(actual_pattern, act) else '未通过'
            except re.error as e:
                _log(f"regex_match: 正则执行失败 ({e}), triggerPattern={trigger_pattern!r}")
                continue

    return None


# ═══════════════════════════════════════════════════════
#  比对器解析（统一入口）
# ═══════════════════════════════════════════════════════

def resolve_comparator(config_arg=None, strategy_arg=None, sheet_name=None):
    """
    根据参数解析比对函数。统一走配置驱动。

    优先级：--config → --strategy → sheet名自动推断

    参数:
        config_arg: --config 参数值（policyCode 或 JSON 文件路径）
        strategy_arg: --strategy 参数值（旧版策略名，自动映射到配置文件）
        sheet_name: 当前 sheet 名称（用于自动推断）

    返回:
        comparator_fn(expected, actual) -> '通过'|'未通过'|None
    """
    def _make_comparator(policy_code_or_path, label=""):
        try:
            rules, config_path = load_strategy_config(policy_code_or_path)
            print(f"  {label}使用配置: {config_path.name} ({len(rules)} 条规则)")
            return lambda exp, act: compare_generic(exp, act, rules)
        except (FileNotFoundError, json.JSONDecodeError, ValueError) as e:
            print(f"  警告: 配置加载失败 ({e})", file=sys.stderr)
            return None

    if config_arg:
        return _make_comparator(config_arg)

    if strategy_arg:
        mapped = _LEGACY_STRATEGY_MAP.get(strategy_arg, strategy_arg)
        return _make_comparator(mapped, f"[{strategy_arg}→{mapped}] ")

    if sheet_name:
        policy_code = SHEET_POLICY_MAP.get(sheet_name)
        if policy_code:
            return _make_comparator(policy_code, f"{sheet_name}: 自动匹配 ")

    return None
