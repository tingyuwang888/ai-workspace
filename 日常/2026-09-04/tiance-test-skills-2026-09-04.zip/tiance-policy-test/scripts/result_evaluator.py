#!/usr/bin/env python3
"""Evaluate policy test assertions without fabricating execution evidence."""

import importlib.util
import re
from decimal import Decimal, InvalidOperation
from pathlib import Path

try:
    from comparison_engine import compare_generic
except ModuleNotFoundError:
    _comparison_path = Path(__file__).resolve().with_name("comparison_engine.py")
    _comparison_spec = importlib.util.spec_from_file_location(
        "tiance_policy_test_comparison_engine",
        _comparison_path,
    )
    if _comparison_spec is None or _comparison_spec.loader is None:
        raise RuntimeError(f"无法加载比对引擎: {_comparison_path}")
    _comparison_module = importlib.util.module_from_spec(_comparison_spec)
    _comparison_spec.loader.exec_module(_comparison_module)
    compare_generic = _comparison_module.compare_generic


ASSERTION_PASSED = "passed"
ASSERTION_FAILED = "failed"
ASSERTION_INCONCLUSIVE = "inconclusive"
ASSERTION_SKIPPED = "skipped"


def _contract_values_match(actual, expected, tolerance=None):
    """Compare numeric contracts by value while keeping strings strict."""
    if str(actual) == str(expected):
        return True

    numeric_types = (int, float, Decimal)
    numeric_contract = (
        tolerance is not None
        or (
            not isinstance(expected, bool)
            and isinstance(expected, numeric_types)
        )
    )
    if not numeric_contract:
        return False

    try:
        actual_number = Decimal(str(actual).strip())
        expected_number = Decimal(str(expected).strip())
        if tolerance is None:
            return actual_number == expected_number
        return abs(actual_number - expected_number) <= Decimal(
            str(tolerance).strip()
        )
    except (InvalidOperation, TypeError, ValueError):
        return False


def build_actual_text(result):
    """Return only evidence that came back from the platform."""
    parts = []
    detail = str(result.get("actual_decision") or "").strip()
    if detail:
        parts.append(detail)

    decision_name = str(result.get("dt") or "").strip()
    decision_code = str(result.get("dtCode") or "").strip()
    if decision_name or decision_code:
        decision = decision_name
        if decision_code and decision_code not in decision_name:
            decision = f"{decision_name}({decision_code})" if decision_name else decision_code
        parts.append(f"整体决策: {decision}")

    return "\n".join(parts)


def required_evidence(expected):
    """Classify the minimum evidence required by an expectation."""
    text = str(expected or "")
    if "函数输出" in text:
        return "function"
    if any(
        marker in text
        for marker in (
            "三方",
            "接口异常",
            "超时",
            "空数据",
            "10907",
            "降级",
            "默认值",
            "边界保护",
            "不崩溃",
        )
    ):
        return "third_party"
    if "命中" in text or "规则" in text:
        return "rule"
    return "decision"


def _has_required_evidence(kind, detail):
    if kind == "decision":
        return True
    if not detail:
        return False
    if kind == "function":
        return "函数输出:" in detail
    if kind == "third_party":
        return "三方节点:" in detail
    if kind == "rule":
        return "规则集执行:" in detail or "规则命中" in detail or "规则未命中" in detail
    return False


def validate_evidence_contract(expected_evidence, evidence):
    """Return missing structured evidence items declared by a testcase."""
    if not expected_evidence:
        return []
    if not isinstance(expected_evidence, dict):
        return ["expectedEvidence 必须是对象"]
    if not isinstance(evidence, dict):
        return ["缺少结构化 evidence"]

    missing = []
    rule_codes = {
        str(hit.get("ruleCode"))
        for node in evidence.get("rules", []) or []
        if isinstance(node, dict)
        for hit in node.get("hitRules", []) or []
        if isinstance(hit, dict) and hit.get("ruleCode")
    }
    required_rules = (
        expected_evidence.get("rules")
        or expected_evidence.get("requiredRules")
        or []
    )
    for code in required_rules:
        if str(code) not in rule_codes:
            missing.append(f"规则:{code}")
    for code in expected_evidence.get("forbiddenRules", []) or []:
        if str(code) in rule_codes:
            missing.append(f"规则不应命中:{code}")

    third_party = {
        str(node.get("nodeName")): node
        for node in evidence.get("thirdPartyNodes", []) or []
        if isinstance(node, dict) and node.get("nodeName")
    }
    required_nodes = (
        expected_evidence.get("thirdPartyNodes")
        or expected_evidence.get("requiredThirdPartyNodes")
        or []
    )
    for requirement in required_nodes:
        if isinstance(requirement, str):
            if requirement not in third_party:
                missing.append(f"三方节点:{requirement}")
            continue
        if not isinstance(requirement, dict):
            missing.append(f"无效三方节点契约:{requirement!r}")
            continue
        node_name = requirement.get("nodeName") or requirement.get("name")
        node = third_party.get(str(node_name))
        if not node:
            missing.append(f"三方节点:{node_name}")
            continue
        actual_fields = node.get("fields", {}) or {}
        for field in requirement.get("fields", []) or []:
            if field not in actual_fields:
                missing.append(f"三方字段:{node_name}.{field}")
        for field, expected_value in (requirement.get("fieldValues", {}) or {}).items():
            if field not in actual_fields:
                missing.append(f"三方字段:{node_name}.{field}")
            elif not _contract_values_match(actual_fields[field], expected_value):
                missing.append(
                    f"三方字段值:{node_name}.{field}="
                    f"{actual_fields[field]!r} != {expected_value!r}"
                )
        for field in requirement.get("absentFields", []) or []:
            if field in actual_fields:
                missing.append(f"三方字段不应存在:{node_name}.{field}")

    function_outputs = {
        (str(item.get("nodeName")), str(item.get("field"))): item.get("value")
        for item in evidence.get("functions", []) or []
        if isinstance(item, dict)
    }
    required_functions = (
        expected_evidence.get("functions")
        or expected_evidence.get("requiredFunctions")
        or []
    )
    for requirement in required_functions:
        if isinstance(requirement, str):
            if not any(node_name == requirement for node_name, _ in function_outputs):
                missing.append(f"函数:{requirement}")
            continue
        if not isinstance(requirement, dict):
            missing.append(f"无效函数契约:{requirement!r}")
            continue
        key = (
            str(requirement.get("nodeName") or requirement.get("name")),
            str(requirement.get("field")),
        )
        if key not in function_outputs:
            missing.append(f"函数输出:{key[0]}.{key[1]}")
        elif "value" in requirement:
            actual_value = function_outputs[key]
            expected_value = requirement["value"]
            tolerance = requirement.get("tolerance")
            values_match = _contract_values_match(
                actual_value,
                expected_value,
                tolerance=tolerance,
            )
            if not values_match:
                tolerance_text = (
                    f" (容差 {tolerance})" if tolerance is not None else ""
                )
                missing.append(
                    f"函数值:{key[0]}.{key[1]}="
                    f"{actual_value!r} != {expected_value!r}{tolerance_text}"
                )
    return missing


def _evaluate_structured_expectation(expected, actual, kind):
    """Evaluate evidence patterns that do not need strategy-specific aliases."""
    if kind == "function":
        assignments = re.findall(
            r"\b([A-Z][A-Z0-9_]+)\s*=\s*([^,\s，；;]+)",
            expected,
        )
        if assignments:
            return all(f"{field}={value}" in actual for field, value in assignments)

    if kind == "rule":
        codes = re.findall(r"\b[A-Z][A-Z0-9_]*\d+\b", expected)
        if codes and "未命中" not in expected:
            return all(code in actual for code in codes)
        if codes and "未命中" in expected:
            return not any(
                re.search(rf"命中:\s*{re.escape(code)}\b", actual)
                for code in codes
            )

    return None


def evaluate_result(expected, result, comparison_rules=None):
    """Return normalized execution, assertion, and evidence states."""
    execution_ok = bool(
        result.get(
            "executionOk",
            result.get("pass", False),
        )
    )
    if not execution_ok:
        return {
            "executionOk": False,
            "assertionStatus": ASSERTION_FAILED,
            "evidenceStatus": "execution_failed",
            "pass": False,
        }

    expected_text = str(expected or "").strip()
    if not expected_text:
        return {
            "executionOk": True,
            "assertionStatus": ASSERTION_INCONCLUSIVE,
            "evidenceStatus": "missing_expectation",
            "pass": False,
        }

    missing_contract = validate_evidence_contract(
        result.get("expectedEvidence"),
        result.get("evidence"),
    )
    if missing_contract:
        return {
            "executionOk": True,
            "assertionStatus": ASSERTION_INCONCLUSIVE,
            "evidenceStatus": "missing_required_evidence",
            "missingEvidence": missing_contract,
            "pass": False,
        }

    detail = str(result.get("actual_decision") or "").strip()
    actual = build_actual_text(result)
    evidence_kind = required_evidence(expected_text)
    if not _has_required_evidence(evidence_kind, detail):
        return {
            "executionOk": True,
            "assertionStatus": ASSERTION_INCONCLUSIVE,
            "evidenceStatus": f"missing_{evidence_kind}_evidence",
            "pass": False,
        }

    structured = _evaluate_structured_expectation(
        expected_text,
        actual,
        evidence_kind,
    )
    if structured is not None:
        verdict = "通过" if structured else "未通过"
    else:
        verdict = None
        if comparison_rules:
            verdict = compare_generic(expected_text, actual, comparison_rules)
        if verdict is None and expected_text in actual:
            verdict = "通过"

    if verdict == "通过":
        status = ASSERTION_PASSED
    elif verdict == "未通过":
        status = ASSERTION_FAILED
    else:
        status = ASSERTION_INCONCLUSIVE

    return {
        "executionOk": True,
        "assertionStatus": status,
        "evidenceStatus": "complete" if status != ASSERTION_INCONCLUSIVE else "unmatched_evidence",
        "pass": status == ASSERTION_PASSED,
    }
