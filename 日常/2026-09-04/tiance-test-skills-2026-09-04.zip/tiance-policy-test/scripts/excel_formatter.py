#!/usr/bin/env python3
"""
天策策略测试 — Excel 格式化公共模块

将 Excel 报告中的颜色常量、列映射、备份、着色等格式化逻辑
从 update_report.py 中拆分出来，供报告更新、relabel、
以及未来其他需要操作 Excel 的场景复用。

Public API:
    COL_NAMES / COL_NAMES_16    — 标准列名定义
    GREEN_FILL / GREEN_FONT     — 通过状态样式
    RED_FILL / RED_FONT         — 未通过状态样式
    backup_excel()              — 创建备份
    get_col_map()               — 表头列名→列号映射
    detect_col_format()         — 检测15列/16列格式
    get_uuid_col()              — 获取UUID列号（兼容旧列名）
    color_status_cell()         — 为测试状态单元格着色
    HEADER_FILL / HEADER_FONT   — 表头样式（蓝底白字）
"""
import shutil
import re

try:
    from openpyxl.styles import PatternFill, Font, Border, Side, Alignment
    from openpyxl.workbook.properties import CalcProperties
except ImportError:
    print("需要 openpyxl: pip install openpyxl")
    raise


# ═══════════════════════════════════════════════════════
#  颜色与样式常量
# ═══════════════════════════════════════════════════════

# ── 测试状态着色 ──
GREEN_FILL = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
GREEN_FONT = Font(color='006100')
RED_FILL = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
RED_FONT = Font(color='9C0006')

# ── 表头样式（蓝底白字、雅黑9号） ──
HEADER_FILL = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
HEADER_FONT = Font(name='微软雅黑', size=9, color='FFFFFF', bold=True)
HEADER_ALIGN = Alignment(horizontal='center', vertical='center', wrap_text=True)
THIN_BORDER = Border(
    left=Side(style='thin'),
    right=Side(style='thin'),
    top=Side(style='thin'),
    bottom=Side(style='thin'),
)


# ═══════════════════════════════════════════════════════
#  列名定义
# ═══════════════════════════════════════════════════════

# ── 15列标准列名（固定模板） ──
COL_NAMES = [
    '用例编号', '模块', '用例名称', '业务描述', '测试场景',
    '用例类型', '前置条件', '测试步骤', '预期结果', '实际结果',
    '测试状态', '测试时间', '测试流水号UUID', '测试数据', '三方数据'
]

# ── 16列扩展列名（含备注列） ──
COL_NAMES_16 = COL_NAMES + ['备注']


# ═══════════════════════════════════════════════════════
#  工具函数
# ═══════════════════════════════════════════════════════

def backup_excel(path):
    """创建备份文件（.bak后缀）"""
    backup_path = path + ".bak"
    shutil.copy2(path, backup_path)
    print(f"已备份: {backup_path}")
    return backup_path


def find_header_row(ws, max_scan_rows=10):
    """Find the standard report header row in a sheet."""
    for row in range(1, min(ws.max_row, max_scan_rows) + 1):
        values = {
            str(ws.cell(row=row, column=column).value or "").strip()
            for column in range(1, min(ws.max_column, len(COL_NAMES_16)) + 1)
        }
        if {"用例编号", "模块", "测试状态"}.issubset(values):
            return row
    return None


def find_report_sheet(workbook):
    """Return the first sheet containing a standard testcase header."""
    for sheet in workbook.worksheets:
        if find_header_row(sheet):
            return sheet
    return None


def get_col_map(ws, header_row=None):
    """从表头行构建列名→列号映射，兼容15列和16列格式"""
    header_row = header_row or find_header_row(ws) or 1
    col = {}
    for ci, cell in enumerate(ws[header_row], 1):
        if cell.value:
            col[str(cell.value).strip()] = ci
    return col


def detect_col_format(col):
    """检测当前列格式，返回 '16col' 或 '15col'"""
    if '备注' in col:
        return '16col'
    return '15col'


def get_uuid_col(col):
    """
    获取流水号UUID列号，统一使用 '测试流水号UUID' 列名。
    兼容旧版 '测试Token/流水号' 列名作为降级。
    """
    if '测试流水号UUID' in col:
        return col['测试流水号UUID']
    # 降级：兼容旧列名
    if '测试Token/流水号' in col:
        return col['测试Token/流水号']
    return 13  # 默认第13列


def color_status_cell(ws, row, status_col, status_value):
    """
    为测试状态单元格着色。

    通过 → 绿底深绿字
    未通过 → 红底深红字
    其他值不着色
    """
    cell = ws.cell(row=row, column=status_col)
    if status_value == '通过':
        cell.fill = GREEN_FILL
        cell.font = GREEN_FONT
    elif status_value == '未通过':
        cell.fill = RED_FILL
        cell.font = RED_FONT


def validate_report_schema(ws, require_15_columns=True):
    """Return structural errors for a Skill-standard test report sheet."""
    errors = []
    header_row = find_header_row(ws)
    if header_row is None:
        return ["未找到 Skill 标准测试用例表头"]
    headers = [
        str(ws.cell(row=header_row, column=index).value or "").strip()
        for index in range(1, len(COL_NAMES) + 1)
    ]
    if require_15_columns and headers != COL_NAMES:
        errors.append(
            "报告前15列表头不符合 Skill 标准: "
            f"actual={headers!r}"
        )
    col = get_col_map(ws, header_row=header_row)
    status_col = col.get("测试状态")
    uuid_col = col.get("测试流水号UUID")
    allowed_statuses = {"", "通过", "未通过", "待确认", "未执行"}
    uuid_pattern = re.compile(r"^[0-9a-f]{32}$")
    for row in range(header_row + 1, ws.max_row + 1):
        if status_col:
            status = str(ws.cell(row=row, column=status_col).value or "").strip()
            if status not in allowed_statuses:
                errors.append(f"第{row}行测试状态无效: {status!r}")
        if uuid_col:
            uuid_value = str(ws.cell(row=row, column=uuid_col).value or "").strip()
            if uuid_value and not uuid_pattern.fullmatch(uuid_value):
                errors.append(f"第{row}行测试流水号UUID格式无效: {uuid_value!r}")
    return errors


def prepare_workbook_for_recalculation(workbook):
    """Ask Excel/LibreOffice to fully recalculate formulas after opening."""
    calculation = getattr(workbook, "calculation", None)
    if calculation is None:
        calculation = CalcProperties()
        workbook.calculation = calculation
    calculation.fullCalcOnLoad = True
    calculation.forceFullCalc = True
    calculation.calcMode = "auto"


def extend_summary_formula_ranges(workbook, report_sheet):
    """Extend same-column summary ranges to the current testcase last row."""
    header_row = find_header_row(report_sheet)
    if header_row is None:
        return 0
    first_data_row = header_row + 1
    last_data_row = report_sheet.max_row
    quoted_title = re.escape(report_sheet.title)
    sheet_ref = rf"(?:'{quoted_title}'|{quoted_title})"
    range_pattern = re.compile(
        rf"({sheet_ref}!\$?([A-Z]+)\$?{first_data_row}:"
        rf"\$?\2\$?)(\d+)"
    )
    changed = 0
    for sheet in workbook.worksheets:
        if sheet is report_sheet:
            continue
        for row in sheet.iter_rows():
            for cell in row:
                value = cell.value
                if not isinstance(value, str) or not value.startswith("="):
                    continue
                updated = range_pattern.sub(
                    lambda match: f"{match.group(1)}{last_data_row}",
                    value,
                )
                if updated != value:
                    cell.value = updated
                    changed += 1
    return changed
