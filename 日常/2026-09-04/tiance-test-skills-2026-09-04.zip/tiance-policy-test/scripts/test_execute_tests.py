#!/usr/bin/env python3

import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from execute_tests import (
    execute_tests,
    parse_component_evidence,
    render_component_evidence,
    select_test_cases,
)


class TestCaseSelection(unittest.TestCase):

    def setUp(self):
        self.cases = [
            {"id": "TC_001"},
            {"id": "TC_002"},
            {"id": "TC_003"},
            {"id": "TC_004"},
        ]

    def test_selects_explicit_ids_in_source_order(self):
        selected = select_test_cases(
            self.cases,
            case_ids=["TC_004", "TC_002"],
        )

        self.assertEqual(
            [case["id"] for case in selected],
            ["TC_002", "TC_004"],
        )

    def test_selects_inclusive_range(self):
        selected = select_test_cases(
            self.cases,
            case_range="TC_002:TC_004",
        )

        self.assertEqual(
            [case["id"] for case in selected],
            ["TC_002", "TC_003", "TC_004"],
        )

    def test_rejects_unknown_case(self):
        with self.assertRaisesRegex(ValueError, "找不到用例"):
            select_test_cases(self.cases, case_ids=["TC_999"])


class TestComponentEvidence(unittest.TestCase):

    def test_extracts_and_renders_structured_evidence(self):
        response = {
            "success": True,
            "data": {
                "flowModelinAndOutputParams": [
                    {
                        "nodeType": "RuleSetServiceNode",
                        "nodeName": "区域规则集",
                        "nodeOutputList": [{"fieldName": "decision", "value": "Reject"}],
                        "extension": {
                            "executeDetail": (
                                '{"hitRules":[{"ruleCode":"R003",'
                                '"ruleName":"地市级","riskLevelName":"超限"}]}'
                            )
                        },
                    },
                    {
                        "nodeType": "FunctionServiceNode",
                        "nodeName": "区域额度计算",
                        "nodeOutputList": [{"fieldName": "TOTAL", "value": 20}],
                    },
                    {
                        "nodeType": "FeatureServiceNode",
                        "nodeName": "city_realtime",
                        "nodeInputList": [{"name": "city", "value": "340100"}],
                        "nodeOutputList": [{"fieldName": "amount", "value": 10}],
                    },
                ]
            },
        }

        evidence = parse_component_evidence(response)
        rendered = render_component_evidence(evidence)

        self.assertEqual(
            evidence["rules"][0]["hitRules"][0]["ruleCode"],
            "R003",
        )
        self.assertEqual(
            evidence["thirdPartyNodes"][0]["fields"]["amount"],
            10,
        )
        self.assertIn("命中: R003(地市级)[超限]", rendered)
        self.assertIn("三方节点: city_realtime amount=10", rendered)

    def test_maps_name_and_opaque_id_to_city_rule_catalog_entry(self):
        response = {
            "success": True,
            "data": {
                "flowModelinAndOutputParams": [
                    {
                        "nodeType": "RuleSetServiceNode",
                        "nodeName": "保前集中度判断_区域",
                        "nodeOutputList": [],
                        "extension": {
                            "executeDetail": json.dumps({
                                "hitRules": [{
                                    "id": "8b91215c1c4f4d2aacde",
                                    "name": "保前区域集中度判断",
                                }],
                            }, ensure_ascii=False),
                        },
                    },
                    {
                        "nodeType": "FeatureServiceNode",
                        "nodeName": "市级区域集中度表查询_实时",
                        "nodeOutputList": [],
                    },
                ],
            },
        }
        catalog = [
            {"code": "R003", "name": "保前区域集中度判断_地市级"},
            {"code": "R004", "name": "保前区域集中度判断_区县级"},
        ]

        evidence = parse_component_evidence(response, rule_catalog=catalog)
        hit = evidence["rules"][0]["hitRules"][0]

        self.assertEqual(hit["ruleCode"], "R003")
        self.assertEqual(hit["ruleName"], "保前区域集中度判断_地市级")
        self.assertEqual(hit["platformRuleId"], "8b91215c1c4f4d2aacde")

    def test_maps_area_name_to_district_rule_from_executed_route(self):
        response = {
            "success": True,
            "data": {
                "flowModelinAndOutputParams": [
                    {
                        "nodeType": "RuleSetServiceNode",
                        "nodeName": "保前集中度判断_区域",
                        "nodeOutputList": [],
                        "extension": {
                            "executeDetail": json.dumps({
                                "hitRules": [{
                                    "id": "opaque-rule-id",
                                    "name": "保前区域集中度判断",
                                }],
                            }, ensure_ascii=False),
                        },
                    },
                    {
                        "nodeType": "FeatureServiceNode",
                        "nodeName": "区级区域集中度表查询_离线",
                        "nodeOutputList": [],
                    },
                ],
            },
        }
        catalog = [
            {"code": "R003", "name": "保前区域集中度判断_地市级"},
            {"code": "R004", "name": "保前区域集中度判断_区县级"},
        ]

        evidence = parse_component_evidence(response, rule_catalog=catalog)

        self.assertEqual(
            evidence["rules"][0]["hitRules"][0]["ruleCode"],
            "R004",
        )

    def test_fast_single_case_writes_results_and_timing_summary(self):
        response = {
            "success": True,
            "data": {
                "runStatus": 2,
                "policyDealTypeName": "通过",
                "policyDealType": "Accept",
                "uuid": "0123456789abcdef0123456789abcdef",
                "token": "token-001",
            },
        }
        component_log = {
            "success": True,
            "data": {
                "flowModelinAndOutputParams": [],
                "contextFields": {"S_S_FINALDEALTYPE": "通过"},
            },
        }
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "results.json"
            with patch("execute_tests.post_test_case", return_value=(200, response)):
                with patch(
                    "execute_tests.query_component_log",
                    return_value=(200, component_log),
                ):
                    results = execute_tests(
                        host="http://example.test",
                        cookie="cookie",
                        csrf="csrf",
                        policy_code="P001",
                        policy_name="测试策略",
                        policy_version=1,
                        biz_type=1,
                        test_cases=[{
                            "id": "TC_001",
                            "expected": "通过",
                            "params": {"S_S_BIZID": "1"},
                        }],
                        output_path=str(output),
                        batch_delay=0,
                        evidence_delay=0,
                        evidence_workers=1,
                    )

            timing = json.loads(
                output.with_suffix(".timings.json").read_text(encoding="utf-8")
            )
            self.assertTrue(results[0]["pass"])
            self.assertIn("submit", results[0]["timingsMs"])
            self.assertIn("evidence", results[0]["timingsMs"])
            self.assertEqual(timing["caseCount"], 1)


if __name__ == "__main__":
    unittest.main()
