#!/usr/bin/env python3

import unittest

from result_evaluator import (
    build_actual_text,
    evaluate_result,
    validate_evidence_contract,
)


class TestResultEvaluator(unittest.TestCase):

    def test_execution_success_without_rule_evidence_is_inconclusive(self):
        result = {
            "executionOk": True,
            "dt": "通过",
            "dtCode": "Accept",
            "actual_decision": "",
        }

        evaluated = evaluate_result("未命中：R001(规则一)", result, [])

        self.assertFalse(evaluated["pass"])
        self.assertEqual(evaluated["assertionStatus"], "inconclusive")
        self.assertEqual(evaluated["evidenceStatus"], "missing_rule_evidence")

    def test_rule_evidence_can_pass_with_configured_comparator(self):
        result = {
            "executionOk": True,
            "dt": "单户集中度超限",
            "dtCode": "Reject",
            "actual_decision": (
                "规则集执行:\n"
                "保前集中度判断_单户 → Reject\n"
                "  命中: R001(单户集中度超限)[高风险]"
            ),
        }
        rules = [{
            "type": "keyword_present",
            "triggers": ["超限"],
            "target": "超限",
        }]

        evaluated = evaluate_result("命中：R001(单户)[单户集中度超限]", result, rules)

        self.assertTrue(evaluated["pass"])
        self.assertEqual(evaluated["assertionStatus"], "passed")
        self.assertEqual(evaluated["evidenceStatus"], "complete")

    def test_target_rule_check_precedes_generic_limit_keyword(self):
        result = {
            "executionOk": True,
            "dt": "单户集中度超限",
            "actual_decision": (
                "规则集执行:\n"
                "  命中: R001(保前单户集中度判断)[]\n"
                "综合结果: 单户集中度超限"
            ),
        }
        rules = [{
            "type": "keyword_present",
            "triggers": ["超限"],
            "target": "超限",
        }]

        evaluated = evaluate_result(
            "命中：R003(保前区域集中度判断_地市级)[区域集中度超限]",
            result,
            rules,
        )

        self.assertFalse(evaluated["pass"])
        self.assertEqual(evaluated["assertionStatus"], "failed")

    def test_function_output_requires_matching_assignment(self):
        result = {
            "executionOk": True,
            "actual_decision": "函数输出: 额度计算 C_F_TOTAL=12.5",
        }

        passed = evaluate_result("函数输出：C_F_TOTAL=12.5", result, [])
        failed = evaluate_result("函数输出：C_F_TOTAL=10", result, [])

        self.assertTrue(passed["pass"])
        self.assertEqual(failed["assertionStatus"], "failed")

    def test_third_party_case_requires_third_party_evidence(self):
        result = {
            "executionOk": True,
            "actual_decision": "规则集执行:\n规则一 → Accept",
        }

        evaluated = evaluate_result("接口异常时走降级逻辑", result, [])

        self.assertEqual(evaluated["assertionStatus"], "inconclusive")
        self.assertEqual(evaluated["evidenceStatus"], "missing_third_party_evidence")

    def test_actual_text_contains_only_platform_fields(self):
        actual = build_actual_text({
            "actual_decision": "",
            "dt": "通过",
            "dtCode": "Accept",
            "expected": "不应出现在实际结果",
        })

        self.assertEqual(actual, "整体决策: 通过(Accept)")
        self.assertNotIn("不应出现在实际结果", actual)

    def test_structured_contract_requires_every_third_party_node(self):
        result = {
            "executionOk": True,
            "actual_decision": (
                "规则集执行:\n命中: R003(地市级)[区域集中度超限]\n"
                "三方节点: city_realtime amount=10"
            ),
            "evidence": {
                "rules": [{
                    "nodeName": "区域规则",
                    "hitRules": [{"ruleCode": "R003"}],
                }],
                "thirdPartyNodes": [{
                    "nodeName": "city_realtime",
                    "fields": {"amount": 10},
                }],
            },
            "expectedEvidence": {
                "rules": ["R003"],
                "thirdPartyNodes": ["city_realtime", "city_offline"],
            },
        }

        evaluated = evaluate_result(
            "命中：R003(地市级)[区域集中度超限]",
            result,
            [],
        )

        self.assertEqual(evaluated["assertionStatus"], "inconclusive")
        self.assertEqual(evaluated["evidenceStatus"], "missing_required_evidence")
        self.assertEqual(evaluated["missingEvidence"], ["三方节点:city_offline"])

    def test_structured_contract_checks_fields_and_function_values(self):
        missing = validate_evidence_contract(
            {
                "thirdPartyNodes": [{
                    "nodeName": "area_source",
                    "fields": ["amount", "limit"],
                }],
                "functions": [{
                    "nodeName": "额度计算",
                    "field": "TOTAL",
                    "value": 20,
                }],
            },
            {
                "thirdPartyNodes": [{
                    "nodeName": "area_source",
                    "fields": {"amount": 10},
                }],
                "functions": [{
                    "nodeName": "额度计算",
                    "field": "TOTAL",
                    "value": 19,
                }],
            },
        )

        self.assertIn("三方字段:area_source.limit", missing)
        self.assertTrue(any(item.startswith("函数值:") for item in missing))

    def test_structured_function_value_supports_numeric_tolerance(self):
        missing = validate_evidence_contract(
            {
                "functions": [{
                    "nodeName": "合并金额",
                    "field": "TOTAL",
                    "value": 438271.46,
                    "tolerance": 0.01,
                }],
            },
            {
                "functions": [{
                    "nodeName": "合并金额",
                    "field": "TOTAL",
                    "value": 438271.4600000001,
                }],
            },
        )

        self.assertEqual(missing, [])

    def test_numeric_contract_accepts_platform_decimal_strings(self):
        missing = validate_evidence_contract(
            {
                "thirdPartyNodes": [{
                    "nodeName": "area_source",
                    "fieldValues": {"amount": 0},
                }],
                "functions": [{
                    "nodeName": "额度计算",
                    "field": "TOTAL",
                    "value": 40000000,
                }],
            },
            {
                "thirdPartyNodes": [{
                    "nodeName": "area_source",
                    "fields": {"amount": "0.0"},
                }],
                "functions": [{
                    "nodeName": "额度计算",
                    "field": "TOTAL",
                    "value": "40000000.0",
                }],
            },
        )

        self.assertEqual(missing, [])

    def test_string_contract_does_not_coerce_numeric_codes(self):
        missing = validate_evidence_contract(
            {
                "thirdPartyNodes": [{
                    "nodeName": "area_source",
                    "fieldValues": {"areaCode": "001"},
                }],
            },
            {
                "thirdPartyNodes": [{
                    "nodeName": "area_source",
                    "fields": {"areaCode": "1"},
                }],
            },
        )

        self.assertTrue(any(item.startswith("三方字段值:") for item in missing))

    def test_structured_contract_rejects_forbidden_rule_and_wrong_third_party_value(self):
        missing = validate_evidence_contract(
            {
                "forbiddenRules": ["R002"],
                "thirdPartyNodes": [{
                    "nodeName": "area_source",
                    "fieldValues": {"amount": -1},
                    "absentFields": ["unexpected"],
                }],
            },
            {
                "rules": [{"hitRules": [{"ruleCode": "R002"}]}],
                "thirdPartyNodes": [{
                    "nodeName": "area_source",
                    "fields": {"amount": 0, "unexpected": 1},
                }],
            },
        )

        self.assertIn("规则不应命中:R002", missing)
        self.assertTrue(any(item.startswith("三方字段值:area_source.amount") for item in missing))
        self.assertIn("三方字段不应存在:area_source.unexpected", missing)


if __name__ == "__main__":
    unittest.main()
