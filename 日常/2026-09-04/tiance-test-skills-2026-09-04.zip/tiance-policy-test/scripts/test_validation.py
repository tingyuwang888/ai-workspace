#!/usr/bin/env python3
"""
validate_strategy_config() 单元测试 — 覆盖配置验证的关键路径。

运行: cd scripts && python3 -m unittest test_validation -v
"""
import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comparison_engine import validate_strategy_config


def _make_config(**overrides):
    """构造一个最小有效配置，允许通过 overrides 覆盖任意字段"""
    base = {
        "policyCode": "TEST_POLICY",
        "policyName": "测试策略",
        "policyVersion": 1,
        "bizType": 100,
        "decisionResults": [
            {"name": "通过", "code": "Accept", "priority": 0, "aliases": ["通过"]},
            {"name": "拒绝", "code": "Reject", "priority": 100, "aliases": ["拒绝"]},
        ],
        "params": {"common": {}, "strategySpecific": {}},
        "comparisonRules": [
            {
                "type": "alias_group",
                "groups": [["通过", "Accept"], ["拒绝", "Reject"]],
                "description": "别名组",
            }
        ],
    }
    base.update(overrides)
    return base


def _write_tmp_config(config_dict):
    """写入临时 JSON 配置文件，返回路径"""
    fd, path = tempfile.mkstemp(suffix=".json")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(config_dict, f, ensure_ascii=False)
    return path


class TestValidConfig(unittest.TestCase):
    """完整有效配置通过验证"""

    def test_valid_config_passes(self):
        config = _make_config()
        path = _write_tmp_config(config)
        try:
            is_valid, errors, warnings = validate_strategy_config(path)
            self.assertTrue(is_valid, f"Expected valid, got errors: {errors}")
            self.assertEqual(len(errors), 0)
        finally:
            os.unlink(path)

    def test_existing_strategy_valid(self):
        """验证已有的 bhjcpostMainBefore 配置"""
        is_valid, errors, warnings = validate_strategy_config("bhjcpostMainBefore")
        self.assertTrue(is_valid, f"Expected valid, got errors: {errors}")


class TestMissingType(unittest.TestCase):
    """缺少 type 字段报错"""

    def test_missing_type_reports_error(self):
        config = _make_config(comparisonRules=[
            {"triggers": ["test"], "target": "test", "description": "no type"},
        ])
        path = _write_tmp_config(config)
        try:
            is_valid, errors, _ = validate_strategy_config(path)
            self.assertFalse(is_valid)
            self.assertTrue(any("缺少 'type'" in e for e in errors),
                            f"Expected 'type' error, got: {errors}")
        finally:
            os.unlink(path)


class TestInvalidType(unittest.TestCase):
    """无效 type 报错"""

    def test_invalid_type_reports_error(self):
        config = _make_config(comparisonRules=[
            {"type": "nonexistent_type", "triggers": ["test"], "description": "bad type"},
        ])
        path = _write_tmp_config(config)
        try:
            is_valid, errors, _ = validate_strategy_config(path)
            self.assertFalse(is_valid)
            self.assertTrue(any("不支持的类型" in e for e in errors),
                            f"Expected invalid type error, got: {errors}")
        finally:
            os.unlink(path)


class TestAliasGroupValidation(unittest.TestCase):
    """alias_group 验证（P1 修复后的 aliases 回退）"""

    def test_groups_present_passes(self):
        config = _make_config(comparisonRules=[
            {"type": "alias_group", "groups": [["a", "b"]], "description": "ok"},
        ])
        path = _write_tmp_config(config)
        try:
            is_valid, errors, _ = validate_strategy_config(path)
            self.assertTrue(is_valid, f"errors: {errors}")
        finally:
            os.unlink(path)

    def test_aliases_fallback_passes(self):
        """只有 aliases（无 groups）时不应报错 — P1 修复验证"""
        config = _make_config(comparisonRules=[
            {"type": "alias_group", "aliases": [["a", "b"]], "description": "aliases fallback"},
        ])
        path = _write_tmp_config(config)
        try:
            is_valid, errors, _ = validate_strategy_config(path)
            self.assertTrue(is_valid, f"aliases fallback should pass, got errors: {errors}")
        finally:
            os.unlink(path)

    def test_missing_groups_and_aliases_fails(self):
        """既无 groups 也无 aliases 时报错"""
        config = _make_config(comparisonRules=[
            {"type": "alias_group", "description": "no groups or aliases"},
        ])
        path = _write_tmp_config(config)
        try:
            is_valid, errors, _ = validate_strategy_config(path)
            self.assertFalse(is_valid)
            self.assertTrue(any("alias_group" in e for e in errors),
                            f"Expected alias_group error, got: {errors}")
        finally:
            os.unlink(path)


class TestNumericToleranceValidation(unittest.TestCase):
    """numeric_tolerance 缺少 expectedPattern 报错"""

    def test_missing_expected_pattern(self):
        config = _make_config(comparisonRules=[
            {"type": "numeric_tolerance", "actualPattern": r"(\d+)",
             "tolerance": 1.0, "description": "missing exp"},
        ])
        path = _write_tmp_config(config)
        try:
            is_valid, errors, _ = validate_strategy_config(path)
            self.assertFalse(is_valid)
            self.assertTrue(any("expectedPattern" in e for e in errors),
                            f"Expected expectedPattern error, got: {errors}")
        finally:
            os.unlink(path)


class TestRegexMatchValidation(unittest.TestCase):
    """regex_match 无效正则报错"""

    def test_invalid_regex_in_trigger_pattern(self):
        config = _make_config(comparisonRules=[
            {"type": "regex_match", "triggerPattern": "[invalid",
             "actualPattern": r"\d+", "description": "bad regex"},
        ])
        path = _write_tmp_config(config)
        try:
            is_valid, errors, _ = validate_strategy_config(path)
            self.assertFalse(is_valid)
            self.assertTrue(any("正则无效" in e for e in errors),
                            f"Expected regex error, got: {errors}")
        finally:
            os.unlink(path)


class TestMissingDescriptionWarning(unittest.TestCase):
    """缺少 description 产生 warning"""

    def test_missing_description_warning(self):
        config = _make_config(comparisonRules=[
            {"type": "alias_group", "groups": [["a", "b"]]},  # no description
        ])
        path = _write_tmp_config(config)
        try:
            is_valid, errors, warnings = validate_strategy_config(path)
            self.assertTrue(is_valid)
            self.assertTrue(any("description" in w for w in warnings),
                            f"Expected description warning, got: {warnings}")
        finally:
            os.unlink(path)


class TestExecutionConfigValidation(unittest.TestCase):

    def test_invalid_execution_shapes_fail(self):
        config = _make_config(testExecution={
            "requiredParams": "S_S_CUSTNAME",
            "defaults": [],
            "defaultsByCaseType": {"正案例": []},
            "mockScenarios": [],
            "mockRequiredCaseTypes": "异常案例",
        })
        path = _write_tmp_config(config)
        try:
            is_valid, errors, _ = validate_strategy_config(path)
            self.assertFalse(is_valid)
            self.assertTrue(any("requiredParams" in e for e in errors))
            self.assertTrue(any("defaults" in e for e in errors))
            self.assertTrue(any("mockScenarios" in e for e in errors))
        finally:
            os.unlink(path)

    def test_unknown_routing_field_fails(self):
        config = _make_config(
            routingFields={"UNKNOWN_ROUTE": {"enum": ["A", "B"]}},
        )
        path = _write_tmp_config(config)
        try:
            is_valid, errors, _ = validate_strategy_config(path)
            self.assertFalse(is_valid)
            self.assertTrue(any("UNKNOWN_ROUTE" in e for e in errors))
        finally:
            os.unlink(path)

    def test_third_party_without_execution_config_warns(self):
        config = _make_config(
            thirdPartyOverrides=[{
                "field": "C_F_TOTAL",
                "source": "third_service",
            }],
        )
        path = _write_tmp_config(config)
        try:
            is_valid, errors, warnings = validate_strategy_config(path)
            self.assertTrue(is_valid, errors)
            self.assertTrue(
                any("thirdPartyOverrides" in w for w in warnings)
            )
        finally:
            os.unlink(path)


class TestFileNotFound(unittest.TestCase):
    """文件不存在时报错"""

    def test_nonexistent_file(self):
        is_valid, errors, _ = validate_strategy_config("NONEXISTENT_POLICY_XYZ")
        self.assertFalse(is_valid)
        self.assertTrue(any("不存在" in e for e in errors),
                        f"Expected file not found error, got: {errors}")


if __name__ == "__main__":
    unittest.main()
