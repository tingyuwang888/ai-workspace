#!/usr/bin/env python3

from datetime import datetime, timezone
import unittest

from prepare_testcases import (
    collect_constraints,
    collect_rule_catalog,
    prepare_testcase_document,
    prepare_testcases,
    validate_semantics,
)


class TestCollectConstraints(unittest.TestCase):

    def test_combines_common_and_execution_constraints(self):
        config = {
            "params": {
                "common": {
                    "FIXED": {"fixed": "x"},
                    "DEFAULT": {"default": 1},
                    "REQUIRED": {"required": True},
                }
            },
            "testExecution": {
                "requiredParams": ["SOURCE_KEY", "REQUIRED"],
                "defaults": {"SOURCE_KEY": "safe"},
            },
        }

        required, defaults = collect_constraints(config)

        self.assertEqual(required, ["REQUIRED", "SOURCE_KEY"])
        self.assertEqual(
            defaults,
            {"FIXED": "x", "DEFAULT": 1, "SOURCE_KEY": "safe"},
        )

    def test_includes_strategy_specific_constraints(self):
        config = {
            "params": {
                "strategySpecific": {
                    "SCENARIO": {"required": True},
                    "TYPE": {"fixed": "enterprise"},
                }
            }
        }

        required, defaults = collect_constraints(config)

        self.assertEqual(required, ["SCENARIO"])
        self.assertEqual(defaults, {"TYPE": "enterprise"})


class TestPrepareTestcases(unittest.TestCase):

    def setUp(self):
        self.config = {
            "params": {
                "common": {
                    "S_S_BIZID": {"required": True},
                    "S_E_APIMODEL": {"fixed": "30"},
                }
            },
            "testExecution": {
                "requiredParams": ["S_S_CUSTNAME"],
                "defaults": {"S_S_CUSTNAME": "测试企业"},
            },
        }

    def test_fills_defaults_without_overwriting_explicit_values(self):
        cases = [
            {"id": "TC_001", "params": {"S_S_BIZID": "1"}},
            {
                "id": "TC_002",
                "params": {
                    "S_S_BIZID": "2",
                    "S_S_CUSTNAME": "指定企业",
                },
            },
        ]

        prepared, errors, summary = prepare_testcases(cases, self.config)

        self.assertEqual(errors, [])
        self.assertEqual(prepared[0]["params"]["S_S_CUSTNAME"], "测试企业")
        self.assertEqual(prepared[1]["params"]["S_S_CUSTNAME"], "指定企业")
        self.assertEqual(prepared[0]["params"]["S_E_APIMODEL"], "30")
        self.assertEqual(summary["changedCases"], 2)

    def test_reports_missing_required_field(self):
        config = {
            "testExecution": {"requiredParams": ["MISSING_FIELD"]}
        }
        cases = [{"id": "TC_001", "params": {}}]

        _, errors, summary = prepare_testcases(cases, config)

        self.assertEqual(len(errors), 1)
        self.assertIn("MISSING_FIELD", errors[0])
        self.assertEqual(summary["errorCount"], 1)

    def test_rejects_non_object_params(self):
        cases = [{"id": "TC_001", "params": []}]

        _, errors, _ = prepare_testcases(cases, self.config)

        self.assertEqual(errors, ["TC_001: params 必须是对象"])

    def test_no_fill_keeps_missing_default_as_error(self):
        cases = [{"id": "TC_001", "params": {"S_S_BIZID": "1"}}]

        _, errors, _ = prepare_testcases(
            cases,
            self.config,
            fill_defaults=False,
        )

        self.assertEqual(len(errors), 1)
        self.assertIn("S_S_CUSTNAME", errors[0])

    def test_preserves_wrapped_document_metadata(self):
        document = {
            "strategyCode": "DF_PRE_CONC_001",
            "testCases": [
                {"id": "TC_001", "params": {"S_S_BIZID": "1"}},
            ],
        }

        prepared, errors, summary = prepare_testcase_document(
            document,
            self.config,
        )

        self.assertEqual(errors, [])
        self.assertEqual(prepared["strategyCode"], "DF_PRE_CONC_001")
        self.assertEqual(
            prepared["testCases"][0]["params"]["S_S_CUSTNAME"],
            "测试企业",
        )
        self.assertEqual(summary["totalCases"], 1)

    def test_case_type_default_overrides_only_global_default(self):
        config = {
            "testExecution": {
                "requiredParams": ["S_S_CUSTNAME"],
                "defaults": {"S_S_CUSTNAME": "默认企业"},
                "defaultsByCaseType": {
                    "正案例": {"S_S_CUSTNAME": "命中企业"},
                    "反案例": {"S_S_CUSTNAME": "安全企业"},
                },
            },
        }
        cases = [
            {"id": "TC_001", "caseType": "正案例", "params": {}},
            {"id": "TC_002", "caseType": "反案例", "params": {}},
            {
                "id": "TC_003",
                "caseType": "反案例",
                "params": {"S_S_CUSTNAME": "显式企业"},
            },
        ]

        prepared, errors, summary = prepare_testcases(cases, config)

        self.assertEqual(errors, [])
        self.assertEqual(prepared[0]["params"]["S_S_CUSTNAME"], "命中企业")
        self.assertEqual(prepared[1]["params"]["S_S_CUSTNAME"], "安全企业")
        self.assertEqual(prepared[2]["params"]["S_S_CUSTNAME"], "显式企业")
        self.assertEqual(summary["filledFields"]["S_S_CUSTNAME"], 2)

    def test_abnormal_case_requires_enabled_mock_contract(self):
        config = {
            "testExecution": {
                "mockScenarios": {
                    "third_party_timeout": {
                        "description": "三方接口超时"
                    }
                }
            }
        }
        incomplete = [{
            "id": "TC_MOCK_001",
            "caseType": "异常案例",
            "params": {},
        }]

        _, errors, _ = prepare_testcases(incomplete, config)

        self.assertTrue(any("executionMode=mock" in e for e in errors))
        self.assertTrue(any("mockScenario" in e for e in errors))

        complete = [{
            "id": "TC_MOCK_002",
            "caseType": "异常案例",
            "executionMode": "mock",
            "mockScenario": "third_party_timeout",
            "params": {},
        }]
        _, disabled_errors, _ = prepare_testcases(complete, config)
        _, enabled_errors, summary = prepare_testcases(
            complete,
            config,
            enabled_mock_scenarios=["third_party_timeout"],
        )

        self.assertTrue(any("本次执行中启用" in e for e in disabled_errors))
        self.assertEqual(enabled_errors, [])
        self.assertEqual(summary["mockCases"], 1)

    def test_mock_with_probe_requires_readiness_proof(self):
        config = {
            "testExecution": {
                "mockScenarios": {
                    "third_party_timeout": {
                        "probe": {"path": "/mock/health"},
                    }
                }
            }
        }
        case = [{
            "id": "TC_MOCK_003",
            "caseType": "异常案例",
            "executionMode": "mock",
            "mockScenario": "third_party_timeout",
            "params": {},
        }]

        _, missing_errors, _ = prepare_testcases(
            case,
            config,
            enabled_mock_scenarios=["third_party_timeout"],
        )
        _, ready_errors, _ = prepare_testcases(
            case,
            config,
            enabled_mock_scenarios=["third_party_timeout"],
            mock_readiness={
                "capturedAt": datetime.now(timezone.utc).isoformat(),
                "scenarios": {
                    "third_party_timeout": {"ready": True},
                }
            },
        )

        self.assertTrue(any("就绪探针证明" in error for error in missing_errors))
        self.assertEqual(ready_errors, [])

    def test_rejects_nonstandard_group_and_duplicate_id(self):
        cases = [
            {"id": "TC_001", "group": "跨子策略综合", "params": {"S_S_BIZID": "1"}},
            {"id": "TC_001", "group": "规则", "params": {"S_S_BIZID": "2"}},
        ]

        _, errors, _ = prepare_testcases(cases, self.config)

        self.assertTrue(any("group 必须是标准模块" in error for error in errors))
        self.assertTrue(any("用例 ID 重复" in error for error in errors))

    def test_validates_rule_identity_against_strategy_model(self):
        model = {
            "rules": [{"code": "R003", "name": "区域集中度判断_地市级"}]
        }
        case = {
            "id": "TC_003",
            "group": "规则",
            "caseType": "正案例",
            "scenario": "命中地市级规则",
            "targetRule": "R003",
            "expected": "命中：R003(错误名称)[区域集中度超限]",
            "params": {"S_S_BIZID": "3"},
        }

        _, errors, _ = prepare_testcases(
            [case],
            self.config,
            strategy_model=model,
        )

        self.assertTrue(any("中文名不一致" in error for error in errors))

    def test_requires_declared_third_party_evidence_for_rule(self):
        config = {
            "testExecution": {
                "ruleDependencies": {
                    "R003": ["city_realtime", "city_offline"],
                }
            }
        }
        case = {
            "id": "TC_003",
            "group": "规则",
            "caseType": "正案例",
            "scenario": "命中地市级规则",
            "targetRule": "R003",
            "expected": "命中：R003(区域集中度判断)[区域集中度超限]",
            "expectedEvidence": {"thirdPartyNodes": ["city_realtime"]},
            "params": {},
        }

        errors = validate_semantics(config, case)

        self.assertTrue(any("city_offline" in error for error in errors))

    def test_strict_parameter_and_routing_validation(self):
        config = {
            "params": {
                "strategySpecific": {
                    "LEVEL": {"enum": ["市级", "区县级"]},
                }
            },
            "routingFields": [
                {"field": "LEVEL", "values": ["市级", "区县级"]},
            ],
            "testExecution": {
                "semanticValidation": {"strictParams": True},
            },
        }
        case = {
            "id": "TC_001",
            "group": "决策流分支覆盖",
            "params": {"LEVEL": "省级", "UNKNOWN": 1},
        }

        errors = validate_semantics(config, case)

        self.assertTrue(any("未声明参数 UNKNOWN" in error for error in errors))
        self.assertTrue(any("不在枚举" in error for error in errors))
        self.assertTrue(any("路由字段 LEVEL" in error for error in errors))

    def test_collect_rule_catalog_prefers_available_metadata(self):
        catalog = collect_rule_catalog(
            {"testExecution": {"ruleCatalog": [{"code": "R001", "name": "旧"}]}},
            {"rules": [{"code": "R002", "name": "新"}]},
        )

        self.assertEqual(set(catalog), {"R001", "R002"})


if __name__ == "__main__":
    unittest.main()
