#!/usr/bin/env python3

import unittest

from fixture_manager import (
    build_insert,
    build_key_query,
    group_fixture_rows,
    render_absence_checks,
    render_fixture_rows,
    validate_manifest,
)


class TestFixtureManager(unittest.TestCase):

    def setUp(self):
        self.manifest = {
            "fixtures": [{
                "id": "city_realtime",
                "table": "ads_area_realtime",
                "keyColumns": ["cust_name"],
                "rows": [{
                    "cust_name": "POLICY_TEST_${RUN_ID}",
                    "amount": 10,
                }],
            }]
        }

    def test_valid_manifest_and_run_id_rendering(self):
        self.assertEqual(validate_manifest(self.manifest), [])

        rendered = render_fixture_rows(self.manifest, "run_001")

        self.assertEqual(
            rendered[0]["rows"][0]["cust_name"],
            "POLICY_TEST_run_001",
        )

    def test_requires_run_id_in_cleanup_key(self):
        self.manifest["fixtures"][0]["rows"][0]["cust_name"] = "existing"

        errors = validate_manifest(self.manifest)

        self.assertTrue(any("${RUN_ID}" in error for error in errors))

    def test_builds_parameterized_sql(self):
        row = {"cust_name": "POLICY_TEST_run_001", "amount": 10}

        insert_sql, insert_values = build_insert("ads_area_realtime", row)
        query_sql, query_values = build_key_query(
            "ads_area_realtime",
            ["cust_name"],
            row,
        )

        self.assertIn("VALUES (%s, %s)", insert_sql)
        self.assertEqual(insert_values, ("POLICY_TEST_run_001", 10))
        self.assertIn("WHERE `cust_name` = %s", query_sql)
        self.assertEqual(query_values, ("POLICY_TEST_run_001",))

    def test_rejects_unsafe_identifier(self):
        self.manifest["fixtures"][0]["table"] = "table; DROP TABLE x"

        errors = validate_manifest(self.manifest)

        self.assertTrue(any("安全的 SQL 标识符" in error for error in errors))

    def test_allows_absence_only_manifest(self):
        manifest = {
            "fixtures": [],
            "absenceChecks": [{
                "id": "empty_customer",
                "table": "ads_area_realtime",
                "keyColumns": ["cust_name"],
                "row": {"cust_name": "POLICY_TEST_${RUN_ID}"},
            }],
        }

        self.assertEqual(validate_manifest(manifest), [])
        rendered = render_absence_checks(manifest, "run_001")
        self.assertEqual(rendered[0]["row"]["cust_name"], "POLICY_TEST_run_001")

    def test_groups_multi_rows_by_service_query_key(self):
        fixture = {
            "id": "city_multi_row",
            "table": "ads_area_realtime",
            "keyColumns": ["city_code"],
            "rows": [
                {"city_code": "CITY_${RUN_ID}", "district": "A", "amount": 10},
                {"city_code": "CITY_${RUN_ID}", "district": "B", "amount": 20},
            ],
        }
        manifest = {"fixtures": [fixture]}

        self.assertEqual(validate_manifest(manifest), [])
        groups = group_fixture_rows(fixture)
        self.assertEqual(len(groups), 1)
        self.assertEqual(len(groups[0]), 2)


if __name__ == "__main__":
    unittest.main()
