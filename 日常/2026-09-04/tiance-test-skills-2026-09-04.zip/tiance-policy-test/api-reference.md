# API参考文档

## 提交测试API

| 项目 | 值 |
|------|------|
| 端点 | `POST /noahApi/lab/policytest/create` |
| Content-Type | `application/x-www-form-urlencoded;charset=UTF-8` |
| 认证 | Header `X-Cf-Random` + `_csrf_` = `sessionStorage.getItem('_csrf_')` |

### 请求体字段

| 字段 | 必填 | 说明 |
|------|------|------|
| policyCode | 是 | 策略标识 |
| policyName | 是 | 策略中文名 |
| policyVersion | 是 | 策略版本号（默认运行区最新版） |
| bizType | 是 | 业务类型 |
| testcase | 是 | 固定 `"1"` |
| customParams | 是 | 固定 `"{}"` |
| params | 是 | 策略入参JSON字符串（需JSON.stringify） |

### 响应字段

| 字段 | 说明 |
|------|------|
| `data.runStatus` | `"2"`=成功, `"-2"`=失败 |
| `data.policyDealTypeName` | 决策结果中文名 |
| `data.policyDealType` | 决策结果英文code |
| `data.uuid` | 执行记录UUID（32位小写hex，用于报告URL和查询） |
| `data.token` | 执行记录Token/流水号（35位混合大小写） |
| `data.errorMsg` | 错误信息（失败时） |

`runStatus="2"` 只表示策略执行完成，不表示测试断言通过。执行器还会输出：

| 字段 | 说明 |
|------|------|
| `executionOk` | HTTP、平台和策略执行是否成功 |
| `assertionStatus` | `passed`、`failed`、`inconclusive` 或 `skipped` |
| `evidenceStatus` | 预期所需的规则、函数或三方节点证据状态 |

没有实际组件证据时禁止根据 `expected` 构造实际结果。

### 数据源配置查询

```
GET /bridgeApi/serviceConfig/getById?uuid={dataSourceUuid}
```

重点检查 `data.inputConfig`：

- `type=constant, sendSpace=sql`：SQL 模板，包含 `#{sql_param}`
- `type=variable, sendSpace=sqlParam`：系统字段 `field` 到 `serviceParam` 的映射
- SQL 中每个占位符都必须有同名 `serviceParam`
- 测试请求必须提供对应的系统字段 `field`

当执行日志中的三方节点返回 `S_S_THIRDRESCODE=10907`
（`解析sql不完整，存在未替换变量`）时：

1. 用本接口确认 SQL 占位符和 `serviceParam` 是否一致。
2. 查 `getAllCompontlog` 中该 `FeatureServiceNode.nodeInputList`。
3. 映射一致但 `nodeInputList` 为空，说明测试请求缺字段；不要修改 SQL。
4. 将系统字段加入策略配置 `testExecution.requiredParams`，配置测试默认值。
5. 运行 `scripts/prepare_testcases.py` 后重新提交。

### 会话健康检查

批量提交前务必先检查会话是否有效：

```javascript
(async function(){
  var csrf = sessionStorage.getItem('_csrf_')
    || decodeURIComponent((document.cookie.match(/_csrf_=([^;]+)/)||[])[1]||'');
  if (!csrf) return JSON.stringify({ok:false, reason:'CSRF token为空，请先登录'});
  try {
    var resp = await fetch('/noahApi/lab/policytest/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'X-Cf-Random': csrf, '_csrf_': csrf
      },
      body: new URLSearchParams({policyCode:'__health_check__'}).toString()
    });
    if (resp.status === 401) return JSON.stringify({ok:false, reason:'会话已过期，请重新登录'});
    var d = await resp.json();
    return JSON.stringify({ok:true, csrf:csrf.substring(0,8)+'...'});
  } catch(e) {
    return JSON.stringify({ok:false, reason:e.message});
  }
})()
```

如果返回 `ok:false`，提示用户在浏览器中重新登录后再继续。

---

## 策略发现API

### 获取策略列表

```
GET /noahApi/policy/list
```

需要 `orgCode`, `startTime`, `endTime`, `bizType` 参数。
返回 `data.contents[]` 数组，每条含 `policyCode`, `policyName`, `publishConfig.ordinaryConfig.version`。

不同平台版本也可能返回 `data.rows[]`、`code/name/businessType`，解析时使用
`scripts/platform_guard.py` 的兼容逻辑。策略不存在、版本/业务类型不一致、状态非已发布
时必须阻断提交。

## 异常用例 mock 契约

异常用例必须同时具备 `executionMode=mock` 和 `mockScenario`。策略配置通过
`testExecution.mockScenarios` 声明支持的场景，执行时通过
`--enabled-mock-scenario` 明确确认隔离环境已经启用。该参数不是开启 mock 的动作，只是
执行前确认；没有真实 mock 环境时不得传入。

### 获取测试入参

通过提交一个空参数的测试请求，从错误响应中获取所需参数列表。
或使用 `discover_strategy.py` 脚本自动发现。

---

## 结果验证API

### runData 分层查询

```
GET /noahApi/policy/report/runData?nodeType={N}&reportAuth=false&tokenId={token}&type=1
```

| nodeType | 验证内容 |
|----------|---------|
| 8 | 子策略token和决策结果 |
| 1 | 规则集命中详情（hitRuleList, inputFieldList） |
| 5 | 函数执行详情（评分、中间变量） |

### getAllCompontlog 全组件日志

```
GET /noahApi/policy/report/getAllCompontlog?id={token}&reportAuth=false&tokenId={token}&type=1
```

返回 `data` 中关键字段：
- `flowModelinAndOutputParams`: 每个节点的执行详情
- `contextFields`: 执行上下文中所有字段的最终值
- `diagramLine`: 决策流执行路径
- `fieldMap`: 字段映射表

nodeType 类型对照：

| nodeType | 含义 | 用途 |
|----------|------|------|
| RuleSetServiceNode | 规则集节点 | 解析 extension.executeDetail 获取 hitRules |
| FeatureServiceNode | 数据源节点 | 查看三方数据返回 |
| SubPolicyNode | 子策略节点 | 获取子策略 tokenId |
| ExclusiveGateway | 排他网关 | 确认分支路由 |

### baseInfo 报告详情

```
GET /noahApi/policy/report/test/baseInfo?id={uuid}&token={uuid}&tokenId={uuid}&type=1
```

返回主策略+子策略共N条记录。

> **注意**：子策略数组顺序不固定，必须通过 `policyVersionDTO.policyCode` 匹配，不能用固定index。

### 查找历史测试记录

```
GET /noahApi/lab/policytest/list?uuid={uuid}&orgCode={orgCode}&startTime=&endTime=&bizType={bizType}
```

返回 `data.contents` 数组。

---

## DB验证

表：`tiangong_policy_test`

连接：读取 `config.json` 中的 `db` 配置，或通过环境变量 `TIANCE_DB_HOST`/`TIANCE_DB_USER`/`TIANCE_DB_PASS`/`TIANCE_DB_NAME` 覆盖

| 字段 | 说明 |
|------|------|
| id | 自增主键 |
| uuid | 执行记录UUID |
| token | 执行记录Token |
| gmt_create | 创建时间 |
| policy_code | 策略编码 |
| policy_deal_type_name | 决策结果 |
| run_status | 2=完成, -2=失败 |
| test_details | 完整测试参数JSON |

---

## Excel报告标准列（15列固定模板）

| # | 列名 | 说明 |
|---|------|------|
| 1 | 用例编号 | TC_NNN 格式 |
| 2 | 模块 | 4类之一：规则/函数/决策流分支覆盖/策略预警等级覆盖 |
| 3 | 用例名称 | 简明描述，附规则编号(中文名) |
| 4 | 业务描述 | 规则描述/函数描述/场景含义 |
| 5 | 测试场景 | 场景描述文本 |
| 6 | 用例类型 | `正案例` / `反案例` |
| 7 | 前置条件 | bizType/policyVersion等 |
| 8 | 测试步骤 | 含policyCode + 【关键入参】 + 关键字段=值 |
| 9 | 预期结果 | 按模块格式（规则级/函数级/策略级） |
| 10 | 实际结果 | API返回 + 验证详情（命中规则名/函数输出值） |
| 11 | 测试状态 | **唯一着色列**：`通过`(C6EFCE绿底) / `未通过`(FFC7CE红底) |
| 12 | 测试时间 | YYYY-MM-DD HH:mm |
| 13 | 测试流水号UUID | API返回的uuid（用于报告URL和查询） |
| 14 | 测试数据 | 请求参数键值对（C_D_ESTABDATE=... C_F_PAIDCAP=...） |
| 15 | 三方数据 | 三方数据返回摘要（纳税信用等级=A; 实缴比例=100.0...） |

**报告Sheet结构**：汇总(第1个) + 策略主Sheet（以策略名命名，15列数据）。

**表头样式**：填充色 `#4472C4`（深蓝），字体白色。字体微软雅黑9号，thin边框，wrap_text + top对齐。

**状态着色**：仅Col11着色。通过 → 浅绿底(`#C6EFCE`)，未通过 → 浅红底(`#FFC7CE`)。

---

## UUID vs Token vs childToken

| 标识符 | 长度 | 格式 | 用途 |
|--------|------|------|------|
| UUID | 32位 | 小写hex | 报告URL、baseInfo查询、历史记录查找 |
| Token | 35位 | 混合大小写 | runData查询、getAllCompontlog查询 |
| childToken | 35位 | 混合大小写 | 子策略runData查询（从nodeType=8获取） |

**获取方式**：
- UUID和Token从提交API的响应 `data.uuid` 和 `data.token` 获取
- childToken从 `runData?nodeType=8` 响应的子策略记录中获取
