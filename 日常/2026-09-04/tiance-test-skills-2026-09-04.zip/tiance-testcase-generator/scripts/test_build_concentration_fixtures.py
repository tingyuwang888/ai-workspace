#!/usr/bin/env python3
import importlib.util
import unittest
from pathlib import Path


SCRIPT_PATH = Path(__file__).with_name("build_concentration_fixtures.py")
SPEC = importlib.util.spec_from_file_location("build_concentration_fixtures", SCRIPT_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class BuildConcentrationFixturesTest(unittest.TestCase):
    def _case(self, case_id="TC_007", area_key="city"):
        return {
            "id": case_id,
            "requiresIsolatedThirdPartyData": True,
            "fixtureProfile": {"single": "miss", "related": "miss", "area": "hit"},
            "fixtureQueryKeys": {"areaKey": area_key},
            "params": {
                "S_S_CUSTNAME": f"DF_PRE_CONC_001_{case_id}_RUN123",
                "C_S_AREAPROVINCECODE": "440000",
                "C_S_AREACITYCODE": f"449007_RUN123",
                "C_S_AREADISTRICTCODE": f"448007_RUN123",
            },
        }

    def test_builds_six_rows_per_case_with_cleanup_placeholders(self):
        source = {"strategyCode": "DF_PRE_CONC_001", "testCases": [self._case()]}
        manifest = MODULE.build_manifest(source, "RUN123", ["TC_007"])

        self.assertEqual(manifest["caseIds"], ["TC_007"])
        self.assertEqual(len(manifest["fixtures"]), 6)
        for fixture in manifest["fixtures"]:
            row = fixture["rows"][0]
            self.assertTrue(any(
                MODULE.RUN_ID_PLACEHOLDER in str(row[key])
                for key in fixture["keyColumns"]
            ))

        area_batch = next(
            fixture for fixture in manifest["fixtures"]
            if fixture["id"] == "TC_007_area_batch"
        )
        self.assertEqual(area_batch["keyColumns"], ["rgst_addr_city_cd"])
        self.assertEqual(area_batch["rows"][0]["area_quota"], 1_000_000)

    def test_rejects_case_without_isolation_contract(self):
        source = {"strategyCode": "DF_PRE_CONC_001", "testCases": [{"id": "TC_001"}]}
        with self.assertRaisesRegex(ValueError, "未声明隔离数据合同"):
            MODULE.build_manifest(source, "RUN123", ["TC_001"])

    def test_boundary_rows_equal_offline_quota(self):
        case = self._case()
        case["fixtureProfile"] = {
            "single": "boundary", "related": "boundary", "area": "boundary"
        }
        manifest = MODULE.build_manifest(
            {"strategyCode": "DF_PRE_CONC_001", "testCases": [case]},
            "RUN123",
        )
        single_rows = [
            fixture["rows"][0] for fixture in manifest["fixtures"]
            if fixture["id"].startswith("TC_007_single")
        ]
        self.assertEqual(
            sum(row["duty_bal"] + row["reserve_amount"] for row in single_rows),
            1_000_000,
        )
        area_rows = [
            fixture["rows"][0] for fixture in manifest["fixtures"]
            if "_area_" in fixture["id"]
        ]
        self.assertEqual(
            sum(row["in_guar_bal"] + row["reserve_amount"] for row in area_rows),
            1_000_000,
        )

    def test_builds_numeric_fixture_and_empty_absence_contracts(self):
        numeric = self._case("TC_047")
        numeric.update({
            "executionMode": "fixture",
            "fixtureScenario": "numeric_boundary",
            "fixtureInterfaceCode": "dhjzdsearch",
        })
        empty = self._case("TC_046")
        empty.update({
            "executionMode": "fixture",
            "fixtureScenario": "empty_result",
            "fixtureInterfaceCode": "dhjzdoffsearch",
        })
        source = {"strategyCode": "DF_PRE_CONC_001", "testCases": [numeric, empty]}
        manifest = MODULE.build_manifest(source, "RUN123")

        self.assertEqual(len(manifest["fixtures"]), 1)
        self.assertIsNone(manifest["fixtures"][0]["rows"][0]["reserve_amount"])
        self.assertEqual(len(manifest["absenceChecks"]), 11)

    def test_district_fixture_allows_static_city_code(self):
        case = self._case("TC_059", area_key="district")
        case["params"]["C_S_AREACITYCODE"] = "500100"
        case.update({
            "executionMode": "fixture",
            "fixtureScenario": "numeric_boundary",
            "fixtureInterfaceCode": "qjqyjzdsearch",
        })
        manifest = MODULE.build_manifest(
            {"strategyCode": "DF_PRE_CONC_001", "testCases": [case]},
            "RUN123",
        )

        row = manifest["fixtures"][0]["rows"][0]
        self.assertEqual(row["rgst_addr_city_cd"], "500100")
        self.assertIn(MODULE.RUN_ID_PLACEHOLDER, row["rgst_addr_area_cd"])

    def test_semantic_overrides_support_absent_sources_and_multi_rows(self):
        source_isolation = self._case("TC_030")
        source_isolation["fixtureOverrides"] = {
            "single_realtime": {"duty_bal": 600_000, "reserve_amount": 400_000},
            "single_batch": {"absent": True},
        }
        multi_row = self._case("TC_040")
        multi_row["fixtureOverrides"] = {
            "city_realtime": {"rows": [
                {"in_guar_bal": 200_000, "reserve_amount": 100_000},
                {"in_guar_bal": 300_000, "reserve_amount": 100_000},
            ]},
            "city_batch": {"rows": [
                {"in_guar_bal": 100_000, "reserve_amount": 50_000},
                {"in_guar_bal": 100_000, "reserve_amount": 50_000},
            ]},
        }
        source = {
            "strategyCode": "DF_PRE_CONC_001",
            "testCases": [source_isolation, multi_row],
        }

        manifest = MODULE.build_manifest(source, "RUN123")

        self.assertTrue(any(
            check["id"] == "TC_030_single_batch_absent"
            for check in manifest["absenceChecks"]
        ))
        realtime = next(
            fixture for fixture in manifest["fixtures"]
            if fixture["id"] == "TC_040_area_realtime"
        )
        self.assertEqual(len(realtime["rows"]), 2)
        self.assertEqual(
            len({row["rgst_addr_area_cd"] for row in realtime["rows"]}), 2)
        self.assertEqual(
            {row["rgst_addr_city_cd"] for row in realtime["rows"]},
            {"449007_${RUN_ID}"},
        )


if __name__ == "__main__":
    unittest.main()
