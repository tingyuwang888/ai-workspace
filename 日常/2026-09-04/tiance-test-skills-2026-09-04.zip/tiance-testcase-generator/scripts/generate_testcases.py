#!/usr/bin/env python3
"""
天策策略测试用例生成引擎 v2.7.2

从 parsed_strategy.json 生成完整的结构化测试用例。
覆盖：规则级(正/反/边界/条件拆解) + 函数级(含格式兼容/健壮性) +
      决策流分支(含DEFAULT/异常路径) + 预警等级 + 跨子策略综合场景

v2.6.0 变更：
  - 集中度策略改用真实 MySQL Fixture 状态模型，不再生成空参数函数、规则集调用占位和重复综合用例
  - hit/miss/boundary、R004 双 OR 路由和三维联动均绑定唯一查询键
  - 每条用例携带规则、函数、六个三方节点的结构化证据合同
  - 覆盖率只统计具备必填参数、Fixture 和证据合同的可执行用例

v2.6.1 变更：
  - 三方证据从“字段存在”增强为原始 fieldValues/absentFields 精确断言
  - Excel 的“三方数据”列改名为“预期执行证据”，明确区分预期合同与实际返回

v2.7.0 变更：
  - 集中度策略补充行政区全称、四川非成都、多行区域聚合语义回归
  - 三个聚合函数分别覆盖小数精度、仅实时、仅离线 Fixture
  - 覆盖率增加语义场景维度，避免“节点出现过”被误计为函数场景全覆盖

v2.7.1 变更：
  - 语义场景改为从规则表达式、函数输入、字段类型和三方接口动态判定是否适用
  - 覆盖率区分 applicableTags 与 notApplicableTags，不再对所有集中度策略固定要求12个标签

v2.7.2 变更：
  - 多行聚合仅在模板明确声明函数接收数组、集合或同一查询键多条记录时生成
  - SUM、汇总、分组等数据源预聚合描述不再单独触发函数多行用例

v2.5.0 变更：
  - 仅支持 no-mock，生成当前环境可用唯一查询键或 MySQL Fixture 实现的三方空返回/数值边界用例
  - 不再生成超时、错误码、字段类型错误等依赖 Mock 环境的异常用例
  - 无 mock 三方韧性用例使用四大标准模块、正/反案例类型、唯一查询键和明确的可执行性元数据

v2.4.2 变更：
  - _extract_threshold_fallback 增强：_resolve_field() 前缀模糊匹配，修复截断字段名（如"按集中度管理策略限额标准"→"按集中度管理策略限额标准_离线集中度"）
  - has_threshold_condition / is_strict_operator 扩展：识别 gte_field / gt_field / lte_field / lt_field / gte_float / lte_float 类型
  - construct_param_value 精确化：gte_field 与 gt_field 边界值分离（1000000 vs 1000001）
  - field_code 碰撞检测：AND 拆解前检查 field_code 去重，避免 areaprovince 双值覆盖
  - 扁平架构新增三类生成器：generate_ruleset_cross_matrix（2^n 联动矩阵）、generate_region_templates（区域特化模板）、apiRequiredFields 自检注入
  - section 2/3 同步使用 _resolve_field，三个解析分支全部支持模糊匹配

v2.4.1 变更：
  - 新增 detect_strategy_architecture()：根据 ruleSets 的 bizScenarios × enterpriseType 路由维度区分 tripartite / flat 架构
  - 架构感知的生成路由：tripartite 走 generate_flow_coverage_cases / generate_alert_level_cases / generate_combined_scenarios；flat 走 generate_simple_flow_cases / generate_simple_combined_cases
  - 路由参数注入加架构守卫：C_S_BIZSCENARIO / S_S_ENTERPRISETYPE 仅对 tripartite 注入，避免污染扁平架构策略（如 DF_PRE_CONC_001）的用例
  - 修复"串台"问题：保后检查（三子策略）专用模板不再生成到扁平架构策略的用例中

v2.4.0 变更：
  - 新增 --feedback / -f 参数：接收上轮 Agent Loop 的 feedback.json，自动修正用例
  - 支持 fixParams（修正入参）、adjustExpected（调整预期）、removeCases（移除无效用例）
  - 匹配优先级：targetRule > scenario 关键词 > desc 关键词
  - CLI 从 sys.argv 迁移到 argparse，向后兼容位置参数

v2.3.1 变更：
  - BUG-2 fix: Excel 报告 Col5/Col6 数据与表头错位修正（caseType→用例类型，ruleSet/rule→测试场景）
  - BUG-3 fix: 规则级用例自动注入路由参数（C_S_BIZSCENARIO / S_S_ENTERPRISETYPE），基于 ruleSet 元数据推导

v2.3.0 变更：
  - 新增 export_excel：同时输出 JSON + Excel 测试报告（16列、蓝底白字表头、汇总+用例双Sheet）
  - openpyxl 为可选依赖，未安装时自动跳过 Excel 导出

v2.2.0 变更：
  - get_detail_template 重构：if/elif链 → 数据驱动有序规则表(_DETAIL_RULES)
  - 新增时间窗口边界用例：自动检测"距今≤N天"模式，生成日期临界测试
  - 新增 _safe_date_days_ago / _extract_day_window 辅助函数

v2.1.0 变更：
  - 正则模式列表抽为模块级 _field_patterns()，消除三处重复
  - 支持 || OR 运算符（除中文"或"外）
  - 中文全角括号（）自动归一化为半角
  - 枚举值内的"或"不再被误判为 OR（如"为d或D"）
  - thirdPartyMock 输出结构化对象（interfaces/fields/mockHint）
  - slash_enum 完整捕获所有斜杠分隔的枚举值
  - 负数表达式支持（如 = -999）
  - gte_years 闰年安全日期计算
  - SAFE 基线用例填充实际安全参数值
  - generate_all 增加错误处理与友好提示
  - 函数用例增加模糊名称匹配回退
  - 清理 construct_param_value 死代码
"""
import argparse
import json
import re
import sys
from pathlib import Path
from datetime import datetime, timedelta
from decimal import Decimal

VERSION = "2.7.2"

# v2.3.1: Excel 报告输出（可选依赖）
try:
    from openpyxl import Workbook
    from openpyxl.styles import PatternFill, Font, Border, Side, Alignment
    from openpyxl.utils import get_column_letter
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

# v2.4.2 Phase 4-2: 数据驱动场景配置（scenarios.yaml）
try:
    import yaml as _yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False

_scenarios_config = None


def _load_scenarios(path=None):
    """懒加载 scenarios.yaml 配置。"""
    global _scenarios_config
    if _scenarios_config is not None:
        return _scenarios_config
    if not HAS_YAML:
        _scenarios_config = {}
        return _scenarios_config
    config_path = Path(path) if path else Path(__file__).resolve().parent / "scenarios.yaml"
    if not config_path.exists():
        _scenarios_config = {}
        return _scenarios_config
    try:
        with open(config_path, encoding="utf-8") as f:
            _scenarios_config = _yaml.safe_load(f) or {}
    except Exception:
        _scenarios_config = {}
    return _scenarios_config


def _get_common_params():
    """从 scenarios.yaml 获取通用参数，回退到硬编码默认值。"""
    config = _load_scenarios()
    yaml_params = config.get("common_params", {})
    defaults = {
        "S_S_BIZID": "TC_BIZ_{tc_id}",
        "S_S_CUSTNO": "TC_CUST_{tc_id}",
        "S_S_ORGCODE": "010117",
        "S_E_APIMODEL": "30",
    }
    return {**defaults, **yaml_params}


def _expand_common_value(value, tc_id):
    """展开字符串模板，同时保留 number/bool/null 的原始类型。"""
    return value.format(tc_id=tc_id) if isinstance(value, str) else value


def _get_func_templates(func_name):
    """从 scenarios.yaml 获取函数级用例模板，回退到 FUNC_CASE_MAP。"""
    config = _load_scenarios()
    templates = config.get("function_templates", {})
    if func_name in templates:
        return templates[func_name]
    for key, cases in templates.items():
        if key in func_name or func_name in key:
            return cases
    return []


# v2.4.2 Phase 4-3: cases_library 按策略类型归档模板库
_cases_library_cache = {}


def _detect_strategy_type(strategy_code, strategy_name=""):
    """根据策略编码/名称自动匹配 cases_library 中的策略类型。"""
    _lib_dir = Path(__file__).resolve().parent / "cases_library"
    _index_path = _lib_dir / "index.json"
    if not _index_path.exists():
        return None
    try:
        import re as _re
        _index = json.loads(_index_path.read_text(encoding="utf-8"))
    except Exception:
        return None
    combined = f"{strategy_code} {strategy_name}"
    for rule in _index.get("auto_detect_rules", []):
        pattern = rule.get("pattern", "")
        if _re.search(pattern, combined, _re.IGNORECASE):
            return rule.get("strategy_type")
    return None


def _load_cases_library(strategy_type):
    """加载指定策略类型的模板库 YAML，返回解析后的配置或 None。"""
    if not HAS_YAML or not strategy_type:
        return None
    if strategy_type in _cases_library_cache:
        return _cases_library_cache[strategy_type]
    _lib_dir = Path(__file__).resolve().parent / "cases_library"
    _index_path = _lib_dir / "index.json"
    if not _index_path.exists():
        _cases_library_cache[strategy_type] = None
        return None
    try:
        _index = json.loads(_index_path.read_text(encoding="utf-8"))
        st_info = _index.get("strategy_types", {}).get(strategy_type, {})
        tpl_file = st_info.get("template_file", "")
        if not tpl_file:
            _cases_library_cache[strategy_type] = None
            return None
        tpl_path = _lib_dir / tpl_file
        if not tpl_path.exists():
            _cases_library_cache[strategy_type] = None
            return None
        with open(tpl_path, encoding="utf-8") as f:
            cfg = _yaml.safe_load(f) or {}
        _cases_library_cache[strategy_type] = cfg
        return cfg
    except Exception:
        _cases_library_cache[strategy_type] = None
        return None


# ---------------------------------------------------------------------------
# 公共参数（每条用例都需包含）
# ---------------------------------------------------------------------------
COMMON_PARAMS = {
    "S_S_BIZID": "TC_BIZ_{tc_id}",
    "S_S_CUSTNO": "TC_CUST_{tc_id}",
    "S_S_ORGCODE": "010117",
    "S_E_APIMODEL": "30",
}

# v2.1.0: 常用字段安全默认值（用于 SAFE 基线用例）
SAFE_DEFAULTS = {
    "C_N_LEGREPPERSONCHANGECOUNT_": 0,
    "C_N_SHAREHOLDERCHANGECOUNT_": 0,
    "C_N_BIZSCOPECHANGECOUNT_": 0,
    "C_N_REGISTCAPIDECOUNT_": 0,
    "C_N_REGISTCAPIDECAMOUNT_": 0,
    "C_N_REGISTCAPIINCCOUNT_": 0,
    "C_N_REGISTCAPIINCAMOUNT_": 0,
    "C_N_DISHONESTCOUNT_": 0,
    "C_N_EXECUTEDCOUNT_": 0,
    "C_N_HIGHCONSUMECOUNT_": 0,
    "C_N_TERMINATEDCOUNT_": 0,
    "C_N_PRESERVATIONCOUNT_": 0,
    "C_N_DEFENDANTCASECOUNT_": 0,
    "C_N_LOANDISPUTEDOCCOUNT_": 0,
    "C_N_BANKRUPTCOUNT_": 0,
    "C_N_LIQUIDATIONCOUNT_": 0,
    "C_N_TAXARREARSCOUNT_": 0,
    "C_N_TAXVIOLATIONCOUNT_": 0,
    "C_N_EQUITYFREEZECOUNT_": 0,
    "C_N_EQUITYPLEDGECOUNT_": 0,
    "C_N_SERIOUSVIOLATIONCOUNT_": 0,
    "C_N_JUDICIALAUCTIONCOUNT_": 0,
    "C_N_ADMINPENALTYCOUNT_": 0,
    "C_N_BIZABNORMALCOUNT_": 0,
    "C_N_OVERDUELOANCOUNT_": 0,
    "C_N_ATTENTIONLOANCOUNT_": 0,
    "C_N_OVERDUEGUARANTEECOUNT_": 0,
    "C_N_SELFPROSECUTIONCOUNT_": 0,
    "C_N_NEGATIVEPUBLICOPINIONCOUNT_": 0,
    "C_N_COURTANNOUNCEMENTCOUNT_": 0,
    "C_N_COURTNOTICECOUNT_": 0,
}

# ---------------------------------------------------------------------------
# 详情字段模板（按业务含义分类）
# ---------------------------------------------------------------------------
RECENT_DATE = (datetime.now() - timedelta(days=15)).strftime("%Y-%m-%d")
RECENT_DATE_2 = (datetime.now() - timedelta(days=45)).strftime("%Y-%m-%d")

DETAIL_TEMPLATES = {
    "change_record": [
        {"ChangeDate": RECENT_DATE, "ProjectName": "{keyword}", "BeforeList": "变更前内容", "AfterList": "变更后内容"}
    ],
    "revoke_record": [
        {"CancelDate": RECENT_DATE, "RevokeDate": "", "RevokeReason": "决议解散"}
    ],
    "dishonest_record": [
        {"Liandate": RECENT_DATE, "Anno": "未履行法院判决", "ExecuteGov": "某市人民法院", "ExecuteStatus": "执行中", "Publicdate": RECENT_DATE}
    ],
    "executed_record": [
        {"Liandate": RECENT_DATE, "Anno": "民事判决", "ExecuteGov": "某市人民法院", "Biaodi": 100000, "SuspectedApplicant": "测试企业"}
    ],
    "high_consume_record": [
        {"Liandate": RECENT_DATE, "Anno": "限制消费令", "ExecuteGov": "某市人民法院", "CaseCode": "(2026)某执限字第001号"}
    ],
    "preservation_record": [
        {"Liandate": RECENT_DATE, "Anno": "财产保全", "ExecuteGov": "某市人民法院", "Amount": 500000}
    ],
    "terminated_record": [
        {"Liandate": RECENT_DATE, "Anno": "终结本次执行", "ExecuteGov": "某市人民法院", "ExecuteAmount": 200000}
    ],
    "defendant_case": [
        {"CaseRole": "被告", "CaseAmount": 6000000, "CaseType": "借款合同纠纷", "FilingDate": RECENT_DATE}
    ],
    "loan_dispute_doc": [
        {"CaseRole": "被告", "CaseType": "借款合同纠纷", "Court": "某市人民法院", "FilingDate": RECENT_DATE}
    ],
    "court_announcement": [
        {"CaseRole": "被告", "CaseType": "金融借款合同纠纷", "Court": "某市人民法院", "AnnouncementDate": RECENT_DATE}
    ],
    "court_notice": [
        {"CaseRole": "被告", "CaseType": "票据纠纷", "Court": "某市人民法院", "NoticeDate": RECENT_DATE}
    ],
    "bankrupt_record": [
        {"CompanyName": "测试企业", "FilingDate": RECENT_DATE, "Court": "某市人民法院", "CaseType": "破产清算"}
    ],
    "tax_arrears_record": [
        {"TaxType": "增值税", "ArrearsAmount": 50000, "TaxOrg": "某税务局", "Period": "2026年1月"}
    ],
    "tax_violation_record": [
        {"ViolationType": "偷税", "PenaltyAmount": 100000, "DecisionDate": RECENT_DATE, "TaxOrg": "某税务局"}
    ],
    "equity_freeze_record": [
        {"FrozenAmount": 1000000, "FreezeCourt": "某市人民法院", "FreezeDate": RECENT_DATE, "FreezePeriod": "2年"}
    ],
    "equity_pledge_record": [
        {"PledgeAmount": 500000, "Pledgor": "测试企业", "Pledgee": "某银行", "RegistrationDate": RECENT_DATE}
    ],
    "serious_violation_record": [
        {"ViolationType": "严重违法", "DecisionDate": RECENT_DATE, "DecisionOffice": "某市场监管局", "RemoveDate": ""}
    ],
    "judicial_auction_record": [
        {"AuctionDate": RECENT_DATE, "AuctionAmount": 2000000, "Court": "某市人民法院", "Subject": "不动产"}
    ],
    "admin_penalty_record": [
        {"PenaltyDate": RECENT_DATE, "PenaltyAmount": 50000, "PenaltyReason": "违规经营", "DecisionOffice": "某市场监管局"}
    ],
    "env_penalty_record": [
        {"PenaltyDate": RECENT_DATE, "PenaltyAmount": 30000, "PenaltyReason": "超标排放", "DecisionOffice": "某生态环境局"}
    ],
    "biz_abnormal_record": [
        {"AddReason": "通过登记住所无法联系", "AddDate": RECENT_DATE, "RemoveReason": "", "RemoveDate": "", "DecisionOffice": "某市场监管局"}
    ],
    "overdue_loan_record": [
        {"AccountNo": "LOAN001", "OverdueDays": 90, "OverdueAmount": 500000, "Lender": "某银行"}
    ],
    "attention_loan_record": [
        {"AccountNo": "LOAN002", "Status": "关注", "Balance": 300000, "Lender": "某银行"}
    ],
    "overdue_guarantee_record": [
        {"GuaranteeNo": "GUA001", "OverdueDays": 60, "OverdueAmount": 200000, "Borrower": "被担保企业"}
    ],
    "attention_guarantee_record": [
        {"GuaranteeNo": "GUA002", "Status": "关注", "Balance": 150000, "Borrower": "被担保企业"}
    ],
    "personal_dishonest_record": [
        {"Liandate": RECENT_DATE, "Anno": "未履行法院判决", "ExecuteGov": "某市人民法院", "ExecuteStatus": "执行中"}
    ],
    "personal_executed_record": [
        {"Liandate": RECENT_DATE, "Anno": "民事判决", "ExecuteGov": "某市人民法院", "Biaodi": 80000}
    ],
    "personal_high_consume_record": [
        {"Liandate": RECENT_DATE, "Anno": "限制消费令", "ExecuteGov": "某市人民法院"}
    ],
    "personal_terminated_record": [
        {"Liandate": RECENT_DATE, "Anno": "终结本次执行", "ExecuteGov": "某市人民法院"}
    ],
    "related_revoke_record": [
        {"RelatedCorpName": "关联测试企业", "CancelDate": RECENT_DATE, "RevokeDate": "", "RevokeReason": "决议解散"}
    ],
    "shareholder_dishonest_record": [
        {"CompanyName": "股东公司A", "KeyNo": "KEY001", "Liandate": RECENT_DATE, "Anno": "未履行判决", "ExecuteGov": "某市人民法院"}
    ],
    "investee_dishonest_record": [
        {"CompanyName": "被投资公司B", "KeyNo": "KEY002", "Liandate": RECENT_DATE, "Anno": "合同纠纷", "ExecuteGov": "某市人民法院"}
    ],
    "self_prosecution_case": [
        {"CaseRole": "原告", "CaseAmount": 12000000, "CaseType": "合同纠纷", "FilingDate": RECENT_DATE}
    ],
    "negative_news": [
        {"Title": "某企业涉嫌违规", "Source": "某媒体", "PublishDate": RECENT_DATE, "Sentiment": "负面"}
    ],
    "qualification_cert": [
        {"Name": "建筑工程施工总承包一级", "EndDate": "2027-06-01", "Status": "正常"}
    ],
    "qualification_near_expiry": [
        {"Name": "建筑工程施工总承包一级", "EndDate": "", "Status": "正常"}
    ],
    # v2.2.0: 原 get_detail_template 内联模板提升为正式条目
    "legal_rep_change": [
        {"ChangeDate": RECENT_DATE, "ProjectName": "法定代表人变更", "BeforeList": "张三", "AfterList": "李四"}
    ],
    "shareholder_change": [
        {"ChangeDate": RECENT_DATE, "ProjectName": "股东变更", "BeforeList": "张三", "AfterList": "李四"}
    ],
    "biz_scope_change": [
        {"ChangeDate": RECENT_DATE, "ProjectName": "经营范围变更", "BeforeList": "技术服务", "AfterList": "技术咨询"}
    ],
    "regist_capi_decrease": [
        {"ChangeDate": RECENT_DATE, "ProjectName": "注册资本变更", "BeforeList": "5000万元", "AfterList": "2000万元"}
    ],
    "regist_capi_increase": [
        {"ChangeDate": RECENT_DATE, "ProjectName": "注册资本变更", "BeforeList": "2000万元", "AfterList": "5000万元"}
    ],
    "bid_record": [
        {"ProjectName": "某市政工程项目", "BidAmount": 5000000, "WinDate": RECENT_DATE}
    ],
    "generic_detail": [
        {"detail": "测试详情数据", "date": RECENT_DATE}
    ],
}


def get_detail_template(field_name):
    """根据字段中文名选择合适的详情模板。
    v2.2.0: 数据驱动有序规则表，新增匹配只需在 _DETAIL_RULES 中追加一行。"""
    for keywords, template_key in _DETAIL_RULES:
        if all(kw in field_name for kw in keywords):
            return json.dumps(DETAIL_TEMPLATES[template_key], ensure_ascii=False)
    return json.dumps(DETAIL_TEMPLATES["generic_detail"], ensure_ascii=False)


# v2.2.0: 有序规则表 — 每条 (关键词元组, DETAIL_TEMPLATES键)
# 匹配逻辑：all(keywords) 必须全部出现在字段名中，按顺序匹配首条命中。
_DETAIL_RULES = [
    # ── 工商变更类（含特化 ProjectName）──
    (("法定代表人变更",),                        "legal_rep_change"),
    (("股权变更",),                              "shareholder_change"),
    (("经营范围变更",),                          "biz_scope_change"),
    (("注册资本减少", "详情"),                    "regist_capi_decrease"),
    (("注册资本增加", "详情"),                    "regist_capi_increase"),
    # ── 注销吊销类 ──
    (("关联", "注销吊销"),                       "related_revoke_record"),
    (("注销吊销",),                              "revoke_record"),
    # ── 失信类（按主体区分）──
    (("个人", "失信"),                           "personal_dishonest_record"),
    (("股东公司", "失信"),                       "shareholder_dishonest_record"),
    (("被投资公司", "失信"),                     "investee_dishonest_record"),
    (("持股", "失信"),                           "investee_dishonest_record"),
    (("失信",),                                  "dishonest_record"),
    # ── 被执行类 ──
    (("个人", "被执行", "详情"),                 "personal_executed_record"),
    (("被执行", "详情"),                         "executed_record"),
    # ── 限制高消费类 ──
    (("个人", "限制高消费", "详情"),             "personal_high_consume_record"),
    (("限制高消费", "详情"),                     "high_consume_record"),
    # ── 财产保全 ──
    (("被保全", "详情"),                         "preservation_record"),
    # ── 终本类 ──
    (("个人", "终本", "详情"),                   "personal_terminated_record"),
    (("终本", "详情"),                           "terminated_record"),
    # ── 司法文书类 ──
    (("裁判文书", "借款合同", "详情"),           "loan_dispute_doc"),
    (("开庭公告", "借款合同", "详情"),           "court_announcement"),
    (("法院公告", "借款合同", "详情"),           "court_notice"),
    # ── 破产/清算 ──
    (("破产", "详情"),                           "bankrupt_record"),
    (("清算", "详情"),                           "bankrupt_record"),
    # ── 税务类 ──
    (("欠税", "详情"),                           "tax_arrears_record"),
    (("税收违法", "详情"),                       "tax_violation_record"),
    # ── 股权类 ──
    (("股权冻结", "详情"),                       "equity_freeze_record"),
    (("股权出质", "详情"),                       "equity_pledge_record"),
    # ── 违法/拍卖 ──
    (("严重违法", "详情"),                       "serious_violation_record"),
    (("司法拍卖", "详情"),                       "judicial_auction_record"),
    # ── 处罚类 ──
    (("行政处罚", "详情"),                       "admin_penalty_record"),
    (("环保处罚", "详情"),                       "env_penalty_record"),
    # ── 经营异常 ──
    (("经营异常", "详情"),                       "biz_abnormal_record"),
    # ── 借贷/担保类 ──
    (("逾期借贷账户", "详情"),                   "overdue_loan_record"),
    (("关注类借贷", "详情"),                     "attention_loan_record"),
    (("逾期对外担保", "详情"),                   "overdue_guarantee_record"),
    (("关注类担保", "详情"),                     "attention_guarantee_record"),
    # ── 案件类 ──
    (("自诉", "详情"),                           "self_prosecution_case"),
    (("为被告", "详情"),                         "defendant_case"),
    # ── 舆情 ──
    (("负面舆情",),                              "negative_news"),
    # ── 资质证书类 ──
    (("资质", "到期"),                           "qualification_near_expiry"),
    (("资质", "天数"),                           "qualification_near_expiry"),
    (("资质", "剩余"),                           "qualification_near_expiry"),
    (("资质", "状态"),                           "qualification_cert"),
    (("资质", "等级"),                           "qualification_cert"),
    # ── 中标 ──
    (("中标",),                                  "bid_record"),
]


# ---------------------------------------------------------------------------
# v2.1.0: 统一模式匹配（消除三处重复）
# ---------------------------------------------------------------------------

def _field_patterns(fname):
    """为指定字段名生成完整的 (正则, 条件类型) 模式列表。
    所有解析函数共用此列表，新增模式只需改一处。"""
    f = re.escape(fname)
    return [
        (rf'{f}\s*>=\s*(\d+)\s*万', 'gte_amount_wan'),
        (rf'{f}\s*≥\s*(\d+)\s*万', 'gte_amount_wan'),
        (rf'{f}\s*>=\s*(\d+(?:\.\d+)?)\s*%', 'gte_percent'),
        (rf'{f}\s*≥\s*(\d+(?:\.\d+)?)\s*%', 'gte_percent'),
        (rf'{f}\s*<\s*(\d+(?:\.\d+)?)\s*%', 'lt_percent'),
        (rf'{f}\s*>\s*(\d+(?:\.\d+)?)\s*万', 'gt_amount_wan'),
        (rf'{f}\s*≤\s*(\d+)\s*天', 'lte_int'),
        (rf'{f}\s*<=\s*(\d+)\s*天', 'lte_int'),
        (rf'{f}\s*≥\s*(\d+)\s*年', 'gte_years'),
        (rf'{f}\s*>=\s*(\d+)\s*年', 'gte_years'),
        (rf'{f}\s*<=\s*(\d+)', 'lte_int'),
        (rf'{f}\s*≤\s*(\d+)', 'lte_int'),
        (rf'{f}\s*<\s*(\d+)', 'lt_int'),
        (rf'{f}\s*>=\s*(\d+)', 'gte_int'),
        (rf'{f}\s*≥\s*(\d+)', 'gte_int'),
        (rf'{f}\s*>\s*(\d+)', 'gt_int'),
        # v2.1.0: negative number support (e.g., = -999)
        (rf'{f}\s*=\s*(-?\d+)', 'eq_int'),
        (rf'{f}\s*<>空', 'not_empty'),
        # v2.1.0: slash-delimited enum (完整捕获所有斜杠分隔值)
        (rf'{f}\s*为/([^/]+(?:/[^/]+)*)', 'slash_enum'),
        # v2.1.0: enum_match 允许"或"和||出现在枚举值内部（如 为d或D）
        (rf'{f}\s*为([^\s且（）]+)', 'enum_match'),
    ]


def _match_patterns(expr, fname, fcode, ftype):
    """尝试用 fname 匹配表达式中的条件，返回 (matched, condition_dict)"""
    for pat, ctype in _field_patterns(fname):
        m = re.search(pat, expr)
        if m:
            val = m.group(1) if m.lastindex else None
            return True, {
                "field_name": fname, "field_code": fcode,
                "field_type": ftype, "operator": ctype,
                "value": val, "condition_type": ctype,
            }
    return False, None


def _normalize_parens(expr):
    """v2.1.0: 将中文全角括号（）归一化为半角()"""
    return expr.replace('（', '(').replace('）', ')')


# ---------------------------------------------------------------------------
# v2.4.2: 阈值/等值比较 fallback 解析器
# 当 parse_expression_conditions 返回 0 条件时兜底，专治 inputParamsMapped
# 不完整（如扁平架构 DF_PRE_CONC_001 的 4 条规则 inputParamsMapped 字段名
# 与 code 映射错位，导致 _match_patterns 全 miss）。
# ---------------------------------------------------------------------------

# 比较运算符 → condition_type 前缀映射
_CMP_OPS = [
    (">=", "gte"), ("<=", "lte"), (">", "gt"), ("<", "lt"),
    ("<>", "neq"), ("=", "eq"),
]


def _extract_threshold_fallback(expression, fields_dict):
    """正则兜底提取阈值/等值条件。

    Args:
        expression: 规则表达式（原始文本）
        fields_dict: 字段字典 {field_name: {code, type, ...}}，用于按名查 code

    Returns:
        list[dict]：结构化条件列表，结构与 parse_expression_conditions 一致。
    """
    if not fields_dict:
        return []
    conditions = []
    seen = set()
    expr = _normalize_parens(expression)
    # 移除"条件1："、"1："等前缀，避免干扰
    expr_clean = re.sub(r'(?:条件\s*\d+\s*[:：])|(?:\d+\s*[:：])', '', expr)

    # v2.4.2: 前缀模糊匹配——表达式中的截断字段名 → fields_dict 中的完整字段名
    _field_prefix_cache = {}
    def _resolve_field(name):
        """精确匹配优先，然后前缀匹配（取最短匹配避免歧义）。"""
        if name in fields_dict:
            return name
        if name in _field_prefix_cache:
            return _field_prefix_cache[name]
        candidates = [k for k in fields_dict if k.startswith(name) and len(k) > len(name)]
        result = min(candidates, key=len) if candidates else None
        _field_prefix_cache[name] = result
        return result

    # 1) 字段-字段比较：X >= Y / X <= Y / X > Y / X < Y / X = Y / X <> Y
    #    v2.4.2: 右值必须也在 fields_dict 中才算字段-字段比较，否则留给字符串等值分支
    for op, prefix in _CMP_OPS:
        op_esc = re.escape(op)
        pat = rf'([\w\u4e00-\u9fa5_]+)\s*{op_esc}\s*([\w\u4e00-\u9fa5_]+)'
        for m in re.finditer(pat, expr_clean):
            left_raw, right_raw = m.group(1).strip(), m.group(2).strip()
            # 过滤纯数字右值（那是常量比较，走下面分支）
            if re.fullmatch(r'\d+(\.\d+)?', right_raw):
                continue
            # v2.4.2: 用模糊匹配解析字段名
            left = _resolve_field(left_raw)
            right = _resolve_field(right_raw)
            # 右值必须是已知字段，否则让给字符串等值分支
            if right is None:
                continue
            if left is None or (left, right) in seen:
                continue
            seen.add((left, right))
            left_meta = fields_dict[left]
            right_meta = fields_dict.get(right, {})
            conditions.append({
                "field_name": left,
                "field_code": left_meta.get("code"),
                "field_type": left_meta.get("type", "小数型"),
                "operator": op,
                "value": right,
                "value_field_code": right_meta.get("code"),
                "value_field_type": right_meta.get("type"),
                "condition_type": f"{prefix}_field",
            })

    # 2) 字段-常量比较：X >= 100 / X = "重庆" 等
    #    v2.4.2: 用模糊匹配解析字段名（表达式可能用截断名）
    for op, prefix in _CMP_OPS:
        op_esc = re.escape(op)
        pat = rf'([\w\u4e00-\u9fa5_]+)\s*{op_esc}\s*(\d+(?:\.\d+)?)'
        for m in re.finditer(pat, expr_clean):
            fname_raw, val = m.group(1).strip(), m.group(2)
            fname = _resolve_field(fname_raw)
            if fname is None or (fname, val) in seen:
                continue
            seen.add((fname, val))
            meta = fields_dict[fname]
            conditions.append({
                "field_name": fname,
                "field_code": meta.get("code"),
                "field_type": meta.get("type", "小数型"),
                "operator": op,
                "value": val,
                "condition_type": f"{prefix}_int" if "." not in val else f"{prefix}_float",
            })

    # 3) 字符串等值：字段 = "重庆" / 字段 <> "成都"（引号/非引号都兼容）
    #    v2.4.2: 用模糊匹配解析字段名
    str_pat = re.compile(
        r'([\w\u4e00-\u9fa5_]+)\s*(=|<>)\s*["\']?([\u4e00-\u9fa5A-Za-z][\w\u4e00-\u9fa5]*)["\']?'
    )
    for m in str_pat.finditer(expr_clean):
        fname_raw, op, val = m.group(1).strip(), m.group(2), m.group(3).strip()
        # 跳过数值（已被上面分支处理）
        if re.fullmatch(r'\d+(\.\d+)?', val):
            continue
        fname = _resolve_field(fname_raw)
        if fname is None or (fname, val) in seen:
            continue
        seen.add((fname, val))
        meta = fields_dict[fname]
        prefix = "eq" if op == "=" else "neq"
        conditions.append({
            "field_name": fname,
            "field_code": meta.get("code"),
            "field_type": meta.get("type", "字符型"),
            "operator": op,
            "value": val,
            "condition_type": f"{prefix}_str",
        })

    return [c for c in conditions if c.get("field_code")]


# ---------------------------------------------------------------------------
# 表达式解析与参数值构造
# ---------------------------------------------------------------------------

def parse_expression_conditions(expression, input_params_mapped):
    """解析规则表达式，提取条件列表。"""
    conditions = []
    expr = _normalize_parens(expression.strip())

    expanded_params = []
    for p in input_params_mapped:
        name = p["name"]
        if "\n" in name:
            for sub_name in name.split("\n"):
                sub_name = sub_name.strip()
                if sub_name:
                    expanded_params.append({
                        "name": sub_name, "code": p.get("code"),
                        "type": p.get("type", "整数型"), "fuzzyMatch": sub_name,
                    })
        else:
            expanded_params.append(p)

    for p in expanded_params:
        fname = p["name"]
        fcode = p.get("code")
        ftype = p.get("type", "整数型")
        if not fcode:
            continue

        matched, cond = _match_patterns(expr, fname, fcode, ftype)
        if matched:
            conditions.append(cond)
            continue

        if "_" in fname:
            fname_norm = fname.replace("_", "")
            matched, cond = _match_patterns(expr, fname_norm, fcode, ftype)
            if matched:
                cond["field_name"] = fname
                conditions.append(cond)

    return conditions


def construct_param_value(condition, mode):
    """根据条件和模式(hit/miss/boundary)构造参数值。"""
    ctype = condition["condition_type"]
    fname = condition["field_name"]
    ftype = condition["field_type"]
    val = condition.get("value")

    if ctype == "gt_int" and val == "0":
        return 3 if mode == "hit" else (0 if mode == "miss" else 1)

    elif ctype == "not_empty":
        if mode == "miss":
            return "[]"
        return get_detail_template(fname)

    elif ctype == "gte_percent":
        threshold = float(val)
        if mode == "hit": return round(threshold + 10, 1)
        elif mode == "miss": return round(max(0, threshold - 15), 1)
        return threshold

    elif ctype == "lt_percent":
        threshold = float(val)
        if mode == "hit": return round(max(0, threshold - 5), 1)
        elif mode == "miss": return round(threshold + 10, 1)
        return round(threshold - 0.1, 2)

    elif ctype == "gte_amount_wan":
        t = int(val)
        if mode == "hit": return t + 100
        elif mode == "miss": return max(0, t - 100)
        return t

    elif ctype == "gt_amount_wan":
        t = int(val)
        if mode == "hit": return t + 100
        elif mode == "miss": return t
        return t + 1

    elif ctype == "gte_int":
        t = int(val)
        if t == 0:
            return 3 if mode == "hit" else (0 if mode == "miss" else 1)
        if mode == "hit": return t + 1
        elif mode == "miss": return t - 1
        return t

    elif ctype == "gt_int":
        t = int(val)
        if mode == "hit": return t + 3
        elif mode == "miss": return t
        return t + 1

    elif ctype == "lte_int":
        t = int(val)
        if mode == "hit": return t - 1
        elif mode == "miss": return t + 5
        return t

    elif ctype == "lt_int":
        t = int(val)
        if mode == "hit": return t - 1
        elif mode == "miss": return t + 1
        return t - 1

    elif ctype == "eq_int":
        t = int(val)
        if mode == "hit": return t
        elif mode == "miss": return t + 5
        return t

    elif ctype == "enum_match":
        all_vals = _split_enum_values(val)
        if mode == "hit": return all_vals[0]
        elif mode == "miss": return "其他值"
        return all_vals[-1] if len(all_vals) > 1 else all_vals[0]

    elif ctype == "slash_enum":
        all_vals = _parse_slash_enum_values(val)
        if mode == "hit": return all_vals[0]
        elif mode == "miss": return "正常"
        return all_vals[-1] if len(all_vals) > 1 else all_vals[0]

    elif ctype == "gte_years":
        years = int(val)
        today = datetime.now()
        if mode == "hit":
            return _safe_date_years_ago(today, years + 1).strftime("%Y-%m-%d")
        elif mode == "miss":
            return _safe_date_years_ago(today, max(years - 1, 0)).strftime("%Y-%m-%d")
        return _safe_date_years_ago(today, years).strftime("%Y-%m-%d")

    # v2.4.2: fallback 解析器产出的 condition_type（字段-字段 / 字段-字符串 / 字段-浮点常量）
    # field-to-field 比较：只能控制 LHS 字段值，RHS 由测试环境提供。启发式 500万/50万/100万。
    if ctype == "gte_field":
        return 5000000 if mode == "hit" else (500000 if mode == "miss" else 1000000)
    if ctype == "gt_field":
        return 5000000 if mode == "hit" else (500000 if mode == "miss" else 1000001)
    if ctype == "lte_field":
        return 500000 if mode == "hit" else (5000000 if mode == "miss" else 1000000)
    if ctype == "lt_field":
        return 500000 if mode == "hit" else (5000000 if mode == "miss" else 999999)
    if ctype == "eq_field":
        return 1000000 if mode in ("hit", "boundary") else 500000
    if ctype == "neq_field":
        # 字符串不等：hit 给一个不在常见枚举中的值，miss 给一个典型值
        if str(val) in ("重庆", "四川", "成都") or any("\u4e00" <= ch <= "\u9fa5" for ch in str(val)):
            return "其他省" if mode == "hit" else val
        return 999 if mode == "hit" else 1000000
    if ctype == "eq_str":
        return val if mode in ("hit", "boundary") else f"非{val}"
    if ctype == "neq_str":
        return f"非{val}" if mode == "hit" else val
    if ctype in ("gte_float", "gt_float"):
        t = float(val)
        if mode == "hit": return round(t + max(t * 0.2, 1), 2)
        if mode == "miss": return round(max(0, t * 0.5), 2)
        return t
    if ctype in ("lte_float", "lt_float"):
        t = float(val)
        if mode == "hit": return round(max(0, t * 0.5), 2)
        if mode == "miss": return round(t + max(t * 0.2, 1), 2)
        return t
    if ctype == "eq_int":  # fallback 路径的 eq_int（常量比较）
        t = int(val)
        return t if mode in ("hit", "boundary") else t + 5

    # fallback by type
    if ftype == "整数型":
        return 1 if mode == "hit" else 0
    elif ftype == "小数型":
        return 0.5 if mode == "hit" else 0.0
    return "测试值" if mode == "hit" else ""


def _split_enum_values(enum_val):
    """v2.1.0: 将枚举值字符串按 或/|| 拆分为列表。"""
    if not enum_val:
        return [enum_val]
    parts = re.split(r'\|\||或', enum_val)
    return [p.strip() for p in parts if p.strip()] or [enum_val]


def _parse_slash_enum_values(raw):
    """v2.1.0: 解析斜杠分隔的枚举值。如 '吊销/或/撤销' → ['吊销', '撤销']"""
    if not raw:
        return [raw]
    parts = [p.strip() for p in raw.split('/') if p.strip() and p.strip() != '或']
    return parts if parts else [raw]


def _safe_date_years_ago(base_date, years):
    """v2.1.0: 安全地计算 N 年前的日期，处理闰年 2/29 问题。"""
    target_year = base_date.year - years
    try:
        return base_date.replace(year=target_year)
    except ValueError:
        return base_date.replace(year=target_year, day=28)


def _safe_date_days_ago(base_date, days):
    """v2.2.0: 安全地计算 N 天前的日期。"""
    return base_date - timedelta(days=days)


def _extract_day_window(expression):
    """v2.2.0: 从表达式中提取 '距今≤N天' 的天数阈值。
    匹配模式：≤N天、<=N天、<N天。返回 (天数, 运算符) 或 None。"""
    m = re.search(r'[≤<]=?\s*(\d+)\s*天', expression)
    if m:
        days = int(m.group(1))
        op = "lt" if "≤" not in m.group(0) and "<" in m.group(0) and "=" not in m.group(0) else "lte"
        return days, op
    return None


def generate_time_boundary_cases(code, name, rs_code, hit_result, expression, conditions):
    """v2.2.0: 为含时间窗口条件的规则生成日期边界用例。
    专门测试'距今≤N天'类条件的日期临界值。"""
    day_window = _extract_day_window(expression)
    if not day_window:
        return []

    days, op = day_window
    today = datetime.now()
    cases = []

    # 确定详情字段 — 找到 not_empty 条件对应的字段
    detail_cond = None
    count_cond = None
    for c in conditions:
        if c["condition_type"] == "not_empty":
            detail_cond = c
        elif c["condition_type"] in ("gt_int", "gte_int") and c.get("value") == "0":
            count_cond = c

    if not detail_cond:
        return []

    # ── 边界命中：记录恰好在窗口内（N-1天前 / N天前）──
    params_hit = {}
    for k, v in _get_common_params().items():
        params_hit[k] = _expand_common_value(v, f"{code}_TBH")
    # 设置 count > 0
    if count_cond:
        params_hit[count_cond["field_code"]] = 1
    # 设置详情，日期恰好=窗口边界
    boundary_date = _safe_date_days_ago(today, days).strftime("%Y-%m-%d")
    detail_tpl = json.loads(get_detail_template(detail_cond["field_name"]))
    if detail_tpl and isinstance(detail_tpl, list) and len(detail_tpl) > 0:
        # 找到日期字段并设置为边界日期
        for key in detail_tpl[0]:
            if "date" in key.lower() or "Date" in key or "日期" in key:
                detail_tpl[0][key] = boundary_date
                break
    params_hit[detail_cond["field_code"]] = json.dumps(detail_tpl, ensure_ascii=False)

    op_desc = "≤" if op == "lte" else "<"
    cases.append({
        "id": f"TC_{code}_TBH",
        "desc": f"时间窗口边界命中：{name} - 记录恰好{days}天前",
        "group": "规则", "caseType": "边界案例",
        "scenario": f"时间窗口边界：记录日期={boundary_date}(恰好{days}天前)，{op_desc}{days}天条件应命中",
        "expected": f"命中：{code}({name})[{hit_result}]",
        "params": params_hit, "targetRuleSet": rs_code, "targetRule": code,
    })

    # ── 边界未命中：记录刚好在窗口外（N+1天前）──
    params_miss = {}
    for k, v in _get_common_params().items():
        params_miss[k] = _expand_common_value(v, f"{code}_TBM")
    if count_cond:
        params_miss[count_cond["field_code"]] = 1
    outside_date = _safe_date_days_ago(today, days + 1).strftime("%Y-%m-%d")
    detail_tpl_miss = json.loads(get_detail_template(detail_cond["field_name"]))
    if detail_tpl_miss and isinstance(detail_tpl_miss, list) and len(detail_tpl_miss) > 0:
        for key in detail_tpl_miss[0]:
            if "date" in key.lower() or "Date" in key or "日期" in key:
                detail_tpl_miss[0][key] = outside_date
                break
    params_miss[detail_cond["field_code"]] = json.dumps(detail_tpl_miss, ensure_ascii=False)

    cases.append({
        "id": f"TC_{code}_TBM",
        "desc": f"时间窗口边界未命中：{name} - 记录恰好{days+1}天前",
        "group": "规则", "caseType": "边界案例",
        "scenario": f"时间窗口边界：记录日期={outside_date}(恰好{days+1}天前)，超出{op_desc}{days}天窗口应不命中",
        "expected": f"未命中：{code}({name})",
        "params": params_miss, "targetRuleSet": rs_code, "targetRule": code,
    })

    return cases


def has_threshold_condition(conditions):
    """检查是否有阈值条件（需要生成边界用例）"""
    threshold_types = {"gte_percent", "lt_percent", "gte_amount_wan", "gt_amount_wan",
                       "gte_int", "gt_int", "lte_int", "lt_int", "eq_int", "gte_years",
                       # v2.4.2: fallback 解析器产出的数值型 condition_type
                       "gte_field", "lte_field", "gte_float", "lte_float"}
    return any(c["condition_type"] in threshold_types and c.get("value") not in ("0", None) for c in conditions)


# ---------------------------------------------------------------------------
# AND/OR 条件拆解
# ---------------------------------------------------------------------------

def is_strict_operator(condition_type):
    return condition_type in ("gt_int", "lt_int", "gt_amount_wan",
                              "gt_field", "lt_field", "gt_float", "lt_float")


def has_or_connection(expression):
    """v2.1.0: 检测表达式是否包含 OR 条件（字段间的"或"或"||"）
    排除枚举值内的"或"（如"为d或D"）。"""
    if not expression:
        return False
    expr = _normalize_parens(expression)
    # 移除枚举值段
    cleaned = re.sub(r'为(?:[^\s且|（）]+(?:或|\|\|))*[^\s且|（）]+', '', expr)
    if "或" in cleaned:
        return True
    if "||" in cleaned:
        return True
    return False


def split_or_branches(expression, input_params_mapped):
    """v2.1.0: 将 OR 表达式拆分为独立分支。
    支持"或"和"||"，正确处理括号嵌套。"""
    expr = _normalize_parens(expression.strip())

    expanded_params = []
    for p in input_params_mapped:
        name = p["name"]
        if "\n" in name:
            for sub_name in name.split("\n"):
                sub_name = sub_name.strip()
                if sub_name:
                    expanded_params.append({"name": sub_name, "code": p.get("code"), "type": p.get("type", "整数型")})
        else:
            expanded_params.append(p)

    field_positions = []
    for p in expanded_params:
        fname = p["name"]
        fcode = p.get("code")
        if not fcode:
            continue
        pos = expr.find(fname)
        if pos >= 0:
            field_positions.append((pos, p))

    if len(field_positions) < 2:
        return [parse_expression_conditions(expression, input_params_mapped)]

    field_positions.sort(key=lambda x: x[0])

    branches = []
    current_branch_fields = [field_positions[0]]

    for i in range(1, len(field_positions)):
        prev_end = current_branch_fields[-1][0] + len(current_branch_fields[-1][1]["name"])
        curr_start = field_positions[i][0]
        between = expr[prev_end:curr_start]
        between_clean = re.sub(r'为(?:[^\s且|（）]+(?:或|\|\|))*[^\s且|（）]+', '', between)

        # 检查括号深度：只在最外层 OR 处拆分
        depth = 0
        has_or_at_top = False
        j = 0
        while j < len(between_clean):
            ch = between_clean[j]
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            elif depth == 0:
                if ch == '或':
                    has_or_at_top = True
                    break
                if ch == '|' and j + 1 < len(between_clean) and between_clean[j + 1] == '|':
                    has_or_at_top = True
                    break
            j += 1

        if has_or_at_top:
            branches.append(current_branch_fields)
            current_branch_fields = [field_positions[i]]
        else:
            current_branch_fields.append(field_positions[i])

    branches.append(current_branch_fields)

    result = []
    for branch_fields in branches:
        branch_conditions = []
        for _, p in branch_fields:
            fname = p["name"]
            fcode = p.get("code")
            ftype = p.get("type", "整数型")
            matched, cond = _match_patterns(expr, fname, fcode, ftype)
            if matched:
                branch_conditions.append(cond)
            elif "_" in fname:
                matched, cond = _match_patterns(expr, fname.replace("_", ""), fcode, ftype)
                if matched:
                    cond["field_name"] = fname
                    branch_conditions.append(cond)
        if branch_conditions:
            result.append(branch_conditions)

    return result if result else [parse_expression_conditions(expression, input_params_mapped)]


def generate_and_decomposition_cases(code, name, rs_code, hit_result, conditions):
    cases = []
    if len(conditions) < 2:
        return cases

    for i, target_cond in enumerate(conditions):
        if target_cond["condition_type"] in ("not_empty", "enum_match"):
            continue

        params = {}
        for k, v in _get_common_params().items():
            params[k] = _expand_common_value(v, f"{code}_AND{i}")

        for j, cond in enumerate(conditions):
            mode = "miss" if j == i else "hit"
            params[cond["field_code"]] = construct_param_value(cond, mode)

        cases.append({
            "id": f"TC_{code}_AND{i}",
            "desc": f"AND拆解：{name} - 仅{target_cond['field_name']}不满足",
            "group": "规则", "caseType": "反案例",
            "scenario": f"AND条件拆解：仅第{i+1}个条件({target_cond['field_name']})不满足，其余满足，验证不命中",
            "expected": f"未命中：{code}({name})",
            "params": params, "targetRuleSet": rs_code, "targetRule": code,
        })

    return cases


def generate_or_branch_cases(code, name, rs_code, hit_result, or_branches):
    cases = []
    if len(or_branches) < 2:
        return cases

    for i, branch in enumerate(or_branches):
        if not branch:
            continue

        params_hit = {}
        for k, v in _get_common_params().items():
            params_hit[k] = _expand_common_value(v, f"{code}_OR{i}_H")

        for j, other_branch in enumerate(or_branches):
            mode = "hit" if j == i else "miss"
            for cond in other_branch:
                params_hit[cond["field_code"]] = construct_param_value(cond, mode)

        branch_desc = "、".join(c["field_name"] for c in branch)
        cases.append({
            "id": f"TC_{code}_OR{i}_HIT",
            "desc": f"OR分支命中：{name} - 仅满足{branch_desc}",
            "group": "规则", "caseType": "正案例",
            "scenario": f"OR条件分支：仅第{i+1}个分支满足，验证规则命中 {hit_result}",
            "expected": f"命中：{code}({name})[{hit_result}]",
            "params": params_hit, "targetRuleSet": rs_code, "targetRule": code,
        })

        has_boundary = any(c["condition_type"] in ("gte_int", "gte_percent", "gte_amount_wan", "gt_int", "lt_int", "lt_percent") for c in branch)
        if has_boundary:
            params_bound = {}
            for k, v in _get_common_params().items():
                params_bound[k] = _expand_common_value(v, f"{code}_OR{i}_B")
            for j, other_branch in enumerate(or_branches):
                mode = "boundary" if j == i else "miss"
                for cond in other_branch:
                    params_bound[cond["field_code"]] = construct_param_value(cond, mode)
            cases.append({
                "id": f"TC_{code}_OR{i}_BOUND",
                "desc": f"OR分支边界：{name} - {branch_desc}在阈值上",
                "group": "规则", "caseType": "边界案例",
                "scenario": f"OR条件边界：第{i+1}个分支在精确阈值上，验证包含/不包含等于",
                "expected": f"命中：{code}({name})[{hit_result}]",
                "params": params_bound, "targetRuleSet": rs_code, "targetRule": code,
            })

    params_all_miss = {}
    for k, v in _get_common_params().items():
        params_all_miss[k] = _expand_common_value(v, f"{code}_OR_MISS")
    for branch in or_branches:
        for cond in branch:
            params_all_miss[cond["field_code"]] = construct_param_value(cond, "miss")

    cases.append({
        "id": f"TC_{code}_OR_MISS",
        "desc": f"OR全不满足：{name} - 所有分支均不满足",
        "group": "规则", "caseType": "反案例",
        "scenario": "OR条件全不满足：所有分支均不满足，验证不命中",
        "expected": f"未命中：{code}({name})",
        "params": params_all_miss, "targetRuleSet": rs_code, "targetRule": code,
    })

    return cases


def generate_strict_boundary_cases(code, name, rs_code, hit_result, conditions):
    cases = []
    for i, cond in enumerate(conditions):
        if not is_strict_operator(cond["condition_type"]):
            continue
        val = cond.get("value")
        if val is None:
            continue

        params = {}
        for k, v in _get_common_params().items():
            params[k] = _expand_common_value(v, f"{code}_STRICT{i}")

        for j, other_cond in enumerate(conditions):
            if j == i:
                params[cond["field_code"]] = int(val)
            else:
                params[other_cond["field_code"]] = construct_param_value(other_cond, "hit")

        op_symbol = ">" if "gt" in cond["condition_type"] else "<"
        cases.append({
            "id": f"TC_{code}_STRICT{i}",
            "desc": f"严格边界：{name} - {cond['field_name']}={val}（{op_symbol}不含等于）",
            "group": "规则", "caseType": "边界案例",
            "scenario": f"严格运算符边界：{cond['field_name']}恰好={val}，{op_symbol}不含等于，应不命中",
            "expected": f"未命中：{code}({name})",
            "params": params, "targetRuleSet": rs_code, "targetRule": code,
        })

    return cases


# ---------------------------------------------------------------------------
# ruleSetCode 自动推导（v2.4.2: 修 parsed_strategy.json 中 ruleSetCode 为空的问题）
# ---------------------------------------------------------------------------

def _infer_ruleset_codes(rules, rule_sets):
    """从 ruleSet 名称关键词反推每条 rule 的 ruleSetCode。
    当 rule.ruleSetCode 为空时，根据 rule.name 中的关键词匹配 ruleSet.name 填充。
    """
    if not rule_sets:
        return
    # 构建关键词 → ruleSet code 映射
    keyword_map = {}
    for rs in rule_sets:
        rs_name = rs.get("name", "")
        rs_code = rs.get("code", "")
        if not rs_code:
            continue
        # 提取中文关键词（去掉通用前缀如"保前集中度判断_"）
        parts = rs_name.replace("_", " ").split()
        for p in parts:
            if len(p) >= 2:
                keyword_map[p] = rs_code

    filled = 0
    for rule in rules:
        if rule.get("ruleSetCode", ""):
            continue  # 已有，跳过
        rname = rule.get("name", "")
        # 按关键词长度降序匹配（优先更具体的关键词）
        for kw in sorted(keyword_map.keys(), key=len, reverse=True):
            if kw in rname:
                rule["ruleSetCode"] = keyword_map[kw]
                filled += 1
                break
    if filled:
        print(f"[ruleSetCode推导] 已填充 {filled}/{len(rules)} 条规则的 ruleSetCode", file=sys.stderr)


# ---------------------------------------------------------------------------
# 数据链路解析：函数输出 → 函数输入，比较目标字段提取
# v2.5: 解决规则用例传函数输出字段码被平台重新计算覆盖的问题
# ---------------------------------------------------------------------------

_SKIP_SYSTEM_KEYS = {
    'S_S_BIZID', 'S_S_CUSTNO', 'S_S_IDNO', 'C_F_RANDOMNUM',
    'S_E_APIMODEL', 'S_S_ORGCODE',
}


def _build_func_chain(functions):
    """从 parsed_strategy['functions'] 构建函数数据链路（中间态）。

    parsed_strategy.json 的 inputs/outputs 可能是:
    - 换行分隔的名称字符串（扁平架构常见）
    - dict 列表 [{name, code}]
    - 字符串列表

    返回中间态，需要 _resolve_func_chain 用 fields 字典补全 code。

    返回:
        func_output_map: {output_name_or_code: {inputs: [(name, code_or_empty), ...]}}
        name_to_code:    {field_name: field_code}  (仅包含有 code 的条目)
    """
    func_output_map = {}
    name_to_code = {}

    for f in (functions or []):
        finputs_raw = f.get('inputs', [])
        foutputs_raw = f.get('outputs', [])

        if isinstance(finputs_raw, str):
            finputs_raw = [s.strip() for s in finputs_raw.split('\n') if s.strip()]
        if isinstance(foutputs_raw, str):
            foutputs_raw = [s.strip() for s in foutputs_raw.split('\n') if s.strip()]

        inputs = []
        for i in finputs_raw:
            iname = i.get('name', i) if isinstance(i, dict) else str(i)
            icode = i.get('code', '') if isinstance(i, dict) else ''
            inputs.append((iname, icode))
            if icode:
                name_to_code[iname] = icode

        for o in foutputs_raw:
            oname = o.get('name', o) if isinstance(o, dict) else str(o)
            ocode = o.get('code', '') if isinstance(o, dict) else ''
            # 用 code 作 key（如果有），否则用 name 作 key（后续 resolve 会替换）
            key = ocode if ocode else oname
            func_output_map[key] = {'inputs': inputs, '_output_name': oname, '_output_code': ocode}
            if ocode:
                name_to_code[oname] = ocode

    return func_output_map, name_to_code


def _resolve_func_chain(func_output_map, name_to_code):
    """v2.5.1: 用 fields 字典将函数 input/output 名称解析为 field_code。

    在 generate_rule_test_cases 加载完 fields → name_to_code 后调用。
    返回: resolved func_output_map，所有 key 和 input code 都是 field_code。
    """
    resolved = {}
    for key, info in func_output_map.items():
        inputs = info.get('inputs', [])
        oname = info.get('_output_name', key)
        ocode = info.get('_output_code', '') or name_to_code.get(oname, '')

        # 解析 input 名称为 code
        resolved_inputs = []
        for iname, icode in inputs:
            if not icode:
                icode = name_to_code.get(iname, '')
            resolved_inputs.append((iname, icode))

        if ocode:
            resolved[ocode] = {'inputs': resolved_inputs}
        else:
            # 仍然无法解析 code，保留原 key（不会匹配任何 params，安全降级）
            resolved[key] = {'inputs': resolved_inputs}

    return resolved


def _extract_threshold_codes(conditions, name_to_code):
    """从 gte_field / gt_field 等条件中提取比较目标字段的 field_code。

    v2.5.1: 修复 fallback 解析器字段名不匹配问题。
    fallback 将右值字段存为 value(字段名) + value_field_code(字段码)，
    而非 threshold_field_name / threshold。

    返回: set of threshold field codes
    """
    threshold_codes = set()
    for cond in conditions:
        ctype = cond.get('condition_type', '')
        if ctype not in ('gte_field', 'gt_field', 'lte_field', 'lt_field', 'eq_field', 'neq_field'):
            continue

        # 优先: fallback 解析器直接存的字段码
        vfc = cond.get('value_field_code', '')
        if vfc and isinstance(vfc, str) and not vfc.replace('.', '').replace('-', '').isdigit():
            threshold_codes.add(vfc)
            continue

        # 其次: fallback 解析器存的字段名 → 通过 name_to_code 解析
        val = cond.get('value', '')
        if val and isinstance(val, str) and not val.replace('.', '').replace('-', '').isdigit():
            tcode = name_to_code.get(val, '')
            if tcode:
                threshold_codes.add(tcode)
                continue

        # 兜底: 兼容旧版 key 名
        tname = cond.get('threshold_field_name', '') or cond.get('threshold', '')
        if tname and isinstance(tname, str) and not tname.replace('.', '').replace('-', '').isdigit():
            tcode = name_to_code.get(tname, '')
            if tcode:
                threshold_codes.add(tcode)

    return threshold_codes


def _expand_params_for_execution(params, mode, func_output_map, threshold_codes):
    """将 params 中的函数输出字段码替换为函数输入字段码，并补充比较目标字段。

    v2.5.1: threshold_codes 改为 set，限额值按 mode 设定。
    - hit: 限额设低(1M)，使 LHS >= 限额 成立 → 规则命中
    - miss: 限额设高(100M)，使 LHS >= 限额 不成立 → 规则未命中
    - boundary: 限额设中(5M)，与 LHS 接近 → 边界测试
    """
    expanded = {}
    for k, v in params.items():
        if k in _SKIP_SYSTEM_KEYS:
            expanded[k] = v
            continue

        if k in func_output_map:
            # 这是函数输出字段码 → 替换为函数输入字段码
            inputs = func_output_map[k]['inputs']
            n_inputs = len(inputs)
            if n_inputs == 0:
                expanded[k] = v
                continue

            try:
                total = float(v)
            except (ValueError, TypeError):
                total = 5000000 if mode == 'hit' else 500000

            per_input = total / n_inputs
            for iname, icode in inputs:
                if icode:
                    expanded[icode] = int(per_input)
        else:
            expanded[k] = v

    # 补充比较目标字段（限额等），按 mode 设定合理值
    _THRESHOLD_BY_MODE = {'hit': 1_000_000, 'miss': 100_000_000, 'boundary': 5_000_000}
    tval = _THRESHOLD_BY_MODE.get(mode, 1_000_000)
    for tcode in threshold_codes:
        if tcode not in expanded:
            expanded[tcode] = tval

    return expanded


# ---------------------------------------------------------------------------
# 规则级用例生成
# ---------------------------------------------------------------------------

def generate_rule_test_cases(rules, fields, functions=None):
    test_cases = []

    # v2.5: 构建函数数据链路，用于将函数输出字段码替换为函数输入字段码
    func_output_map, name_to_code = _build_func_chain(functions)
    # 补充 fields 字典中的 name→code 映射
    if isinstance(fields, dict):
        for fname, finfo in fields.items():
            if isinstance(finfo, dict) and finfo.get('code'):
                name_to_code.setdefault(fname, finfo['code'])

    # v2.5.1: 用 fields 的 name→code 映射补全函数 input/output 的 field_code
    func_output_map = _resolve_func_chain(func_output_map, name_to_code)
    if func_output_map:
        _resolved_keys = list(func_output_map.keys())
        print(f"[func_chain] 已解析 {len(_resolved_keys)} 个函数输出字段码: {_resolved_keys}", file=sys.stderr)

    for rule in rules:
        code = rule["code"]
        name = rule["name"]
        rs_code = rule["ruleSetCode"]
        hit_result = rule["hitResult"]
        expression = rule["expression"]

        if rs_code == "alertLevelJudgment":
            continue

        conditions = parse_expression_conditions(expression, rule.get("inputParamsMapped", []))

        # v2.4.2: 主解析器返回 0 条件时调用正则 fallback（修扁平架构 inputParamsMapped 不完整问题）
        if not conditions and isinstance(fields, dict):
            fb_conds = _extract_threshold_fallback(expression, fields)
            if fb_conds:
                print(f"[{code}] fallback 解析出 {len(fb_conds)} 个条件（主解析器 0）", file=sys.stderr)
                conditions = fb_conds

        # v2.5: 提取比较目标字段码（如 creditlimitoff）
        threshold_codes = _extract_threshold_codes(conditions, name_to_code)

        # 正案例
        params = {}
        for k, v in _get_common_params().items():
            params[k] = _expand_common_value(v, code)
        for cond in conditions:
            params[cond["field_code"]] = construct_param_value(cond, "hit")
        params = _expand_params_for_execution(params, "hit", func_output_map, threshold_codes)

        test_cases.append({
            "id": f"TC_{code}_HIT", "desc": f"命中验证：{name}",
            "group": "规则", "caseType": "正案例",
            "scenario": f"构造满足 {code} 全部条件的参数值，验证规则命中 {hit_result}",
            "expected": f"命中：{code}({name})[{hit_result}]",
            "params": params, "targetRuleSet": rs_code, "targetRule": code,
        })

        # 反案例
        params_miss = {}
        for k, v in _get_common_params().items():
            params_miss[k] = _expand_common_value(v, f"{code}_M")
        for cond in conditions:
            params_miss[cond["field_code"]] = construct_param_value(cond, "miss")
        params_miss = _expand_params_for_execution(params_miss, "miss", func_output_map, threshold_codes)

        test_cases.append({
            "id": f"TC_{code}_MISS", "desc": f"未命中验证：{name}",
            "group": "规则", "caseType": "反案例",
            "scenario": f"构造不满足 {code} 条件的参数值，验证规则不命中",
            "expected": f"未命中：{code}({name})",
            "params": params_miss, "targetRuleSet": rs_code, "targetRule": code,
        })

        # 边界值
        if has_threshold_condition(conditions):
            params_bound = {}
            for k, v in _get_common_params().items():
                params_bound[k] = _expand_common_value(v, f"{code}_B")
            for cond in conditions:
                params_bound[cond["field_code"]] = construct_param_value(cond, "boundary")
            params_bound = _expand_params_for_execution(params_bound, "boundary", func_output_map, threshold_codes)

            test_cases.append({
                "id": f"TC_{code}_BOUND", "desc": f"边界值验证：{name}",
                "group": "规则", "caseType": "边界案例",
                "scenario": f"使用阈值临界值测试 {code}，验证边界判定",
                "expected": f"命中：{code}({name})[{hit_result}]",
                "params": params_bound, "targetRuleSet": rs_code, "targetRule": code,
            })

        # AND 拆解（v2.4.2: 跳过有 field_code 碰撞的条件组，避免 params 被覆盖）
        if len(conditions) >= 2 and not has_or_connection(expression):
            field_codes = [c["field_code"] for c in conditions]
            has_collision = len(field_codes) != len(set(field_codes))
            if not has_collision:
                test_cases.extend(generate_and_decomposition_cases(code, name, rs_code, hit_result, conditions))
            else:
                print(f"[{code}] AND拆解跳过：{len(field_codes)-len(set(field_codes))} 组 field_code 碰撞", file=sys.stderr)

        # OR 拆解
        if has_or_connection(expression):
            or_branches = split_or_branches(expression, rule.get("inputParamsMapped", []))
            if len(or_branches) >= 2:
                test_cases.extend(generate_or_branch_cases(code, name, rs_code, hit_result, or_branches))

        # 严格边界
        test_cases.extend(generate_strict_boundary_cases(code, name, rs_code, hit_result, conditions))

        # v2.2.0: 时间窗口边界
        test_cases.extend(generate_time_boundary_cases(code, name, rs_code, hit_result, expression, conditions))

    return test_cases


# ---------------------------------------------------------------------------
# 函数级用例生成（v2.1.0: 模糊名称匹配回退）
# ---------------------------------------------------------------------------

FUNC_CASE_MAP = {
    "初始化函数": [
        {"caseType": "正案例", "scenario": "传入有效 AppKey 和 SecretKey，验证企查查接口可正常调用", "expected": "函数输出：初始化函数+企查查appKey=有效值，企查查SecretKey=有效值"},
        {"caseType": "反案例", "scenario": "传入空 AppKey，验证初始化异常处理", "expected": "函数输出：初始化函数+初始化失败"},
    ],
    "预警等级计算": [
        {"caseType": "正案例", "scenario": "高风险命中条数=1，中风险命中条数=2，低风险命中条数=3", "expected": "函数输出：预警等级计算+高风险规则命中条数=1，中风险规则命中条数=2，低风险规则命中条数=3"},
        {"caseType": "正案例", "scenario": "所有等级命中条数均为0", "expected": "函数输出：预警等级计算+极高风险规则命中条数=0，高风险规则命中条数=0，中风险规则命中条数=0，低风险规则命中条数=0"},
        {"caseType": "边界案例", "scenario": "中风险命中条数=3（触发红色预警阈值）", "expected": "函数输出：预警等级计算+中风险规则命中条数=3"},
        {"caseType": "边界案例", "scenario": "中风险命中条数=2（未达红色预警阈值，应为黄色预警）", "expected": "函数输出：预警等级计算+中风险规则命中条数=2"},
        {"caseType": "正案例", "scenario": "HIGH=4, MED=2, LOW=0, EXTREME=0 混合计数验证", "expected": "函数输出：预警等级计算+极高风险规则命中条数=0，高风险规则命中条数=4，中风险规则命中条数=2，低风险规则命中条数=0"},
        {"caseType": "正案例", "scenario": "HIGH=9, MED=7, LOW=0, EXTREME=0 大量混合计数验证", "expected": "函数输出：预警等级计算+极高风险规则命中条数=0，高风险规则命中条数=9，中风险规则命中条数=7，低风险规则命中条数=0"},
        {"caseType": "边界案例", "scenario": "空字符串输入(所有四级计数=0)", "expected": "函数输出：预警等级计算+极高风险规则命中条数=0，高风险规则命中条数=0，中风险规则命中条数=0，低风险规则命中条数=0"},
        {"caseType": "正案例", "scenario": "极高风险>0(EBNP08资质已过期触发极高风险预警)", "expected": "函数输出：预警等级计算+极高风险规则命中条数=1"},
    ],
    "股东公司循环函数": [
        {"caseType": "正案例", "scenario": "持股超20%股东公司3家，循环下标从0开始递增", "expected": "函数输出：股东公司循环函数+股东公司名称=第N家公司名，股东公司循环函数结束标识=否"},
        {"caseType": "边界案例", "scenario": "循环下标=公司列表长度，验证循环终止", "expected": "函数输出：股东公司循环函数+股东公司循环函数结束标识=是"},
        {"caseType": "反案例", "scenario": "持股超20%股东公司列表为空", "expected": "函数输出：股东公司循环函数+股东公司循环函数结束标识=是"},
        {"caseType": "正案例", "scenario": "多公司(JSON数组格式)", "expected": "函数输出：股东公司循环函数+主要股东公司keyno列表=[COMP_A,COMP_B,COMP_C]，循环索引=3"},
        {"caseType": "正案例", "scenario": "多公司(英文逗号分隔)", "expected": "函数输出：股东公司循环函数+主要股东公司keyno列表=COMP_A,COMP_B,COMP_C，循环索引=3"},
        {"caseType": "正案例", "scenario": "多公司(中文逗号分隔)", "expected": "函数输出：股东公司循环函数+主要股东公司keyno列表=COMP_A，COMP_B，COMP_C，循环索引=3"},
        {"caseType": "正案例", "scenario": "单公司(1个keyno)单次迭代后结束", "expected": "函数输出：股东公司循环函数+主要股东公司keyno列表=COMP_A，循环索引=1，结束标识=是"},
    ],
    "持股公司循环函数": [
        {"caseType": "正案例", "scenario": "对外投资持股超20%公司2家，循环下标递增", "expected": "函数输出：持股公司循环函数+持股公司名称=第N家公司名，持股公司循环函数结束标识=否"},
        {"caseType": "边界案例", "scenario": "循环下标=公司列表长度，验证循环终止", "expected": "函数输出：持股公司循环函数+持股公司循环函数结束标识=是"},
        {"caseType": "正案例", "scenario": "多公司(JSON数组格式)", "expected": "函数输出：持股公司循环函数+持股公司keyno列表=[COMP_A,COMP_B,COMP_C]，循环索引=3"},
        {"caseType": "正案例", "scenario": "多公司(英文逗号分隔)", "expected": "函数输出：持股公司循环函数+持股公司keyno列表=COMP_A,COMP_B,COMP_C，循环索引=3"},
        {"caseType": "正案例", "scenario": "多公司(中文逗号分隔)", "expected": "函数输出：持股公司循环函数+持股公司keyno列表=COMP_A，COMP_B，COMP_C，循环索引=3"},
        {"caseType": "正案例", "scenario": "单公司(1个keyno)单次迭代后结束", "expected": "函数输出：持股公司循环函数+持股公司keyno列表=[COMP_A]，循环索引=1，结束标识=是"},
        {"caseType": "正案例", "scenario": "跨迭代失信计数累加(2+3=5)和详情合并", "expected": "函数输出：持股公司循环函数+被投资公司失信记录累加=5，详情数组合并"},
    ],
    "股东公司数据合并": [
        {"caseType": "正案例", "scenario": "3家股东公司各有失信记录，验证数据合并结果", "expected": "函数输出：股东公司数据合并+合并后失信记录总数=三家之和"},
        {"caseType": "反案例", "scenario": "所有股东公司均无失信记录", "expected": "函数输出：股东公司数据合并+合并后失信记录总数=0"},
        {"caseType": "正案例", "scenario": "首次迭代初始累加(0+2=2)和详情写入", "expected": "函数输出：股东公司数据合并+失信标记=2(循环迭代2次)"},
        {"caseType": "正案例", "scenario": "跨迭代累加(2+3=5)和详情数组合并", "expected": "函数输出：股东公司数据合并+失信标记=5(循环迭代5次)"},
        {"caseType": "边界案例", "scenario": "临时字段为null/空(安全处理不崩溃)", "expected": "函数输出：股东公司数据合并+失信标记=0(null/空安全处理)"},
    ],
    "持股公司数据合并": [
        {"caseType": "正案例", "scenario": "2家持股公司各有失信记录，验证数据合并", "expected": "函数输出：持股公司数据合并+合并后失信记录总数=两家之和"},
        {"caseType": "反案例", "scenario": "持股公司列表为空", "expected": "函数输出：持股公司数据合并+合并后失信记录总数=0"},
        {"caseType": "正案例", "scenario": "首次迭代初始累加(0+1=1)和详情写入", "expected": "函数输出：持股公司数据合并+失信标记=1(循环迭代1次)"},
        {"caseType": "正案例", "scenario": "跨迭代累加(2+3=5)和详情数组合并", "expected": "函数输出：持股公司数据合并+失信标记=5(循环迭代5次)"},
        {"caseType": "边界案例", "scenario": "临时字段为null/空(安全处理不崩溃)", "expected": "函数输出：持股公司数据合并+失信标记=0(null/空安全处理)"},
    ],
    "企业信息对象取值": [
        {"caseType": "正案例", "scenario": "传入有效企业信息对象", "expected": "函数输出：企业信息对象取值+企业名称=测试企业，统一社会信用代码=91XXXXXXXX"},
        {"caseType": "反案例", "scenario": "传入空企业信息对象", "expected": "函数输出：企业信息对象取值+企业名称=空"},
        {"caseType": "边界案例", "scenario": "C_O_ENTERPRISEINFO空数组[]输入", "expected": "函数返回空(空数组输入)，企业子策略跳过"},
        {"caseType": "边界案例", "scenario": "C_O_ENTERPRISEINFO=null输入", "expected": "企业子策略跳过(null输入安全处理)"},
        {"caseType": "正案例", "scenario": "多对象数组(仅取第一个元素)", "expected": "函数输出：企业信息对象取值+企业名称=第一企业(仅取第一个元素)"},
    ],
    "个人信息对象取值": [
        {"caseType": "正案例", "scenario": "传入有效个人信息对象", "expected": "函数输出：个人信息对象取值+企业人员姓名=张三，个人角色类型=法定代表人"},
        {"caseType": "反案例", "scenario": "传入空个人信息对象", "expected": "函数输出：个人信息对象取值+企业人员姓名=空"},
        {"caseType": "边界案例", "scenario": "C_O_PERSONINFO空数组输入不崩溃", "expected": "函数返回空; 个人子策略跳过(不崩溃)"},
        {"caseType": "正案例", "scenario": "多对象数组(仅取第一个元素)", "expected": "函数输出：个人信息对象取值+企业人员姓名=张三(仅取第一个元素)"},
    ],
    "关联企业信息对象取值": [
        {"caseType": "正案例", "scenario": "传入有效关联企业信息对象", "expected": "函数输出：关联企业信息对象取值+企业名称=关联测试企业"},
        {"caseType": "反案例", "scenario": "传入空关联企业信息对象", "expected": "函数输出：关联企业信息对象取值+企业名称=空"},
        {"caseType": "边界案例", "scenario": "C_O_RELATEDCOMPANYINFO空数组输入不崩溃", "expected": "关联企业子策略跳过; 策略整体不受影响"},
        {"caseType": "正案例", "scenario": "多对象数组(仅取第一个元素)", "expected": "函数输出：关联企业信息对象取值+企业名称=关联A(仅取第一个元素)"},
    ],
    "资质等级计算函数": [
        {"caseType": "正案例", "scenario": "准入基线=特级，当前资质=一级，验证降级档位=1", "expected": "函数输出：资质等级计算函数+降级档位=1"},
        {"caseType": "正案例", "scenario": "准入基线=一级，当前资质=特级，验证降级档位=-1", "expected": "函数输出：资质等级计算函数+降级档位=-1"},
        {"caseType": "边界案例", "scenario": "当前资质证书为空（缺失），验证返回-999", "expected": "函数输出：资质等级计算函数+降级档位=-999"},
        {"caseType": "边界案例", "scenario": "准入基线=当前资质完全匹配，降级档位=0", "expected": "函数输出：资质等级计算函数+降级档位=0"},
    ],
}

FUNC_KEYWORD_MAP = {
    "初始化": "初始化函数", "预警等级": "预警等级计算",
    "股东公司循环": "股东公司循环函数", "持股公司循环": "持股公司循环函数",
    "股东公司数据合并": "股东公司数据合并", "持股公司数据合并": "持股公司数据合并",
    "企业信息对象": "企业信息对象取值", "个人信息对象": "个人信息对象取值",
    "关联企业信息": "关联企业信息对象取值", "资质等级": "资质等级计算函数",
}


def _find_func_cases(fname):
    """v2.1.0: 查找函数对应的用例列表，支持精确匹配和关键词模糊匹配。
    v2.4.2 Phase 4-2: 优先从 scenarios.yaml 查找，回退到 FUNC_CASE_MAP。"""
    # 优先查 YAML 配置
    yaml_cases = _get_func_templates(fname)
    if yaml_cases:
        return yaml_cases
    # 回退到硬编码
    if fname in FUNC_CASE_MAP:
        return FUNC_CASE_MAP[fname]
    for keyword, canonical_name in FUNC_KEYWORD_MAP.items():
        if keyword in fname:
            yaml_cases = _get_func_templates(canonical_name)
            if yaml_cases:
                return yaml_cases
            return FUNC_CASE_MAP.get(canonical_name, [])
    return []


# ---------------------------------------------------------------------------
# v2.4.2: 通用函数用例生成器 — 当 _find_func_cases 无匹配时按 logic 类型 fallback
# 解决 generate_function_test_cases 对 FUNC_CASE_MAP 的硬依赖（"架构解耦"）
# ---------------------------------------------------------------------------

def _classify_func_type(func):
    """根据函数 logic 关键词识别类型：summary / conditional / arithmetic / fetch"""
    logic = func.get("logic", "")
    name = func.get("name", "")
    if any(k in name for k in ("汇总", "综合", "综合判断")) or any(k in logic for k in ("全部通过", "部分超限", "全部超限")):
        return "summary"
    if "IF" in logic.upper() or "THEN" in logic.upper() or "ELSE" in logic.upper():
        return "conditional"
    if any(op in logic for op in ("+", "-", "*", "/")):
        return "arithmetic"
    return "fetch"


def _generate_generic_func_cases(func):
    """基于函数逻辑类型生成最小覆盖用例集。"""
    ftype = _classify_func_type(func)
    name = func.get("name", "")
    logic = func.get("logic", "")
    cases = []

    if ftype == "arithmetic":
        cases = [
            {"caseType": "正案例", "scenario": f"{name} 正常输入（各项 > 0）计算结果正确",
             "expected": f"函数输出：{name}=各项之和（按 logic 公式计算）"},
            {"caseType": "反案例", "scenario": f"{name} 所有输入项=0，验证零值计算",
             "expected": f"函数输出：{name}=0"},
            {"caseType": "边界案例", "scenario": f"{name} 部分输入项为 null/空，验证容错计算",
             "expected": f"函数输出：{name}=非空项之和（空值按 0 处理）"},
        ]
    elif ftype == "conditional":
        cases = [
            {"caseType": "正案例", "scenario": f"{name} 满足主条件分支，验证输出",
             "expected": f"函数输出：{name}=THEN 分支结果"},
            {"caseType": "反案例", "scenario": f"{name} 不满足主条件，走 ELSE 分支",
             "expected": f"函数输出：{name}=ELSE 分支结果"},
            {"caseType": "边界案例", "scenario": f"{name} 主条件临界值（刚好等于判断阈值）",
             "expected": f"函数输出：{name}=对应分支结果（临界值处理正确）"},
        ]
    elif ftype == "summary":
        cases = [
            {"caseType": "正案例", "scenario": f"{name} 所有子维度均通过",
             "expected": f"函数输出：{name}=全部通过"},
            {"caseType": "正案例", "scenario": f"{name} 部分子维度超限、部分通过",
             "expected": f"函数输出：{name}=部分超限"},
            {"caseType": "正案例", "scenario": f"{name} 所有子维度均超限",
             "expected": f"函数输出：{name}=全部超限"},
            {"caseType": "边界案例", "scenario": f"{name} 仅 1 个子维度超限",
             "expected": f"函数输出：{name}=部分超限"},
        ]
    else:  # fetch
        cases = [
            {"caseType": "正案例", "scenario": f"{name} 传入有效输入参数",
             "expected": f"函数输出：{name}=有效返回值"},
            {"caseType": "反案例", "scenario": f"{name} 传入空输入参数",
             "expected": f"函数输出：{name}=空（安全处理）"},
        ]
    return cases


def generate_function_test_cases(functions):
    test_cases = []
    tc_func_id = 0

    for func in functions:
        fname = func["name"]
        cases = _find_func_cases(fname)
        # v2.4.2: FUNC_CASE_MAP 未匹配时按 logic 类型 fallback（架构解耦）
        if not cases:
            cases = _generate_generic_func_cases(func)
        for case in cases:
            tc_func_id += 1
            test_cases.append({
                "id": f"TC_FUNC_{tc_func_id:03d}",
                "desc": f"{fname}：{case['scenario'][:30]}",
                "group": "函数", "caseType": case["caseType"],
                "scenario": case["scenario"], "expected": case["expected"],
                "params": {
                    "S_S_BIZID": f"TC_FUNC_{tc_func_id:03d}",
                    "S_S_CUSTNO": f"TC_FUNC_CUST_{tc_func_id:03d}",
                    "S_S_ORGCODE": "010117", "S_E_APIMODEL": "30",
                },
                "targetFunction": fname,
            })

    return test_cases


# ---------------------------------------------------------------------------
# 策略架构检测 (v2.4.2)
# ---------------------------------------------------------------------------

def detect_strategy_architecture(rule_sets):
    """检测策略架构类型，区分三子策略(企业/个人/关联企业)路由 vs 扁平路由"""
    if not rule_sets:
        return "unknown"
    all_routing_empty = all(
        not rs.get("bizScenarios", "") and not rs.get("enterpriseType", "")
        for rs in rule_sets
    )
    if all_routing_empty:
        return "flat"
    names = " ".join(rs.get("name", "") for rs in rule_sets)
    codes = " ".join(rs.get("code", "") for rs in rule_sets)
    has_ent = any(kw in names for kw in ("企业",)) or "Ent" in codes
    has_per = any(kw in names for kw in ("个人",)) or "per" in codes.lower()
    has_rel = any(kw in names for kw in ("关联",)) or "relate" in codes.lower()
    if has_ent and has_per and has_rel:
        return "tripartite"
    return "flat"


# ---------------------------------------------------------------------------
# 简化版分支覆盖（非三子策略架构）(v2.4.2)
# ---------------------------------------------------------------------------

def generate_simple_flow_cases(rule_sets):
    """为非三子策略架构生成简化的分支覆盖用例：每个规则集一条覆盖"""
    test_cases = []
    tc_id = 0
    for rs in rule_sets:
        if rs.get("code", "") == "alertLevelJudgment":
            continue
        tc_id += 1
        test_cases.append({
            "id": f"TC_FLOW_{tc_id:03d}",
            "desc": f"规则集覆盖：{rs.get('name', rs['code'])}",
            "group": "决策流分支覆盖", "caseType": "正案例",
            "scenario": f"验证规则集 {rs['code']} 被正确调用",
            "expected": f"规则集{rs.get('name', rs['code'])}被调用",
            "params": {
                "S_S_BIZID": f"TC_FLOW_{tc_id:03d}",
                "S_S_CUSTNO": f"TC_FLOW_CUST_{tc_id:03d}",
                "S_S_ORGCODE": "010117", "S_E_APIMODEL": "30",
            },
            "targetRuleSet": rs["code"],
        })
    return test_cases


# ---------------------------------------------------------------------------
# 简化版综合场景（非三子策略架构）(v2.4.2)
# ---------------------------------------------------------------------------

def generate_simple_combined_cases(rules, rule_sets):
    """为非三子策略架构生成简化的综合场景用例"""
    test_cases = []
    tc_id = 0
    non_alert_rs = [rs for rs in rule_sets if rs.get("code", "") != "alertLevelJudgment"]

    # 1) 每个规则集一条综合命中用例
    for rs in non_alert_rs:
        tc_id += 1
        rs_rules = [r for r in rules if r.get("ruleSetCode", "") == rs["code"]]
        # 地市级与区县级区域规则由路由条件二选一，不能构造“同时命中”。
        is_exclusive_area_set = (
            "区域" in rs.get("name", "")
            and any("地市级" in r.get("name", "") for r in rs_rules)
            and any("区县级" in r.get("name", "") for r in rs_rules)
        )
        rep_rules = rs_rules[:1] if is_exclusive_area_set else rs_rules[:2]
        rule_desc = "、".join(f"{r['code']}({r['name']})" for r in rep_rules)
        params = {
            "S_S_BIZID": f"TC_COMB_{tc_id:03d}",
            "S_S_CUSTNO": f"TC_COMB_CUST_{tc_id:03d}",
            "S_S_ORGCODE": "010117", "S_E_APIMODEL": "30",
        }
        for r in rep_rules:
            for cond in parse_expression_conditions(r["expression"], r.get("inputParamsMapped", [])):
                params[cond["field_code"]] = construct_param_value(cond, "hit")
        test_cases.append({
            "id": f"TC_COMB_{tc_id:03d}",
            "desc": f"综合场景：{rs.get('name', rs['code'])}规则命中",
            "group": "跨子策略综合", "caseType": "正案例",
            "scenario": f"验证{rs.get('name', rs['code'])}规则集正确执行",
            "expected": f"命中：{rule_desc}" if rule_desc else f"规则集{rs['code']}执行成功",
            "params": params, "isCombined": True,
            "targetRuleSet": rs["code"],
            "targetRule": rep_rules[0]["code"] if len(rep_rules) == 1 else "",
        })

    # 2) 一条全安全基线
    tc_id += 1
    rs_names = "、".join(rs.get("name", rs["code"]) for rs in non_alert_rs)
    test_cases.append({
        "id": f"TC_COMB_{tc_id:03d}",
        "desc": f"全SAFE基线：所有规则集均无命中",
        "group": "跨子策略综合", "caseType": "正案例",
        "scenario": f"所有参数安全值，验证{rs_names}均不触发",
        "expected": f"{rs_names}均无命中，最终通过",
        "params": {
            "S_S_BIZID": f"TC_COMB_{tc_id:03d}",
            "S_S_CUSTNO": f"TC_COMB_CUST_{tc_id:03d}",
            "S_S_ORGCODE": "010117", "S_E_APIMODEL": "30",
        },
        "isSafeBaseline": True,
    })

    return test_cases


# ---------------------------------------------------------------------------
# v2.4.2: 规则集联动矩阵（Phase 1-4）
# ---------------------------------------------------------------------------

def generate_ruleset_cross_matrix(rule_sets, rules, fields_dict):
    """生成 2^n 规则集命中/未命中交叉组合用例（扁平架构专用）。

    对 n 个规则集生成所有 hit/miss 组合，跳过已在单规则集覆盖和全安全基线中覆盖的组合。
    """
    from itertools import product as iter_product

    non_alert_rs = [rs for rs in rule_sets if rs.get("code", "") != "alertLevelJudgment"]
    n = len(non_alert_rs)
    if n < 2:
        return []

    # 构建 ruleSet → rule 映射（按名称推断）
    rs_to_rules = {}
    for rs in non_alert_rs:
        rs_code = rs["code"]
        rs_name = rs.get("name", "")
        matched = []
        for r in rules:
            # 按名称关键词匹配
            if "单户" in rs_name and "单户" in r.get("name", r.get("expression", "")):
                matched.append(r)
            elif "关联户" in rs_name and "关联户" in r.get("name", r.get("expression", "")):
                matched.append(r)
            elif "区域" in rs_name and "区域" in r.get("name", r.get("expression", "")):
                matched.append(r)
        if not matched:
            # fallback: 按规则编号顺序
            matched = [r for r in rules if r["code"] not in
                       sum([v2 for v2 in rs_to_rules.values()], [])]
        rs_to_rules[rs_code] = matched

    # 字段编码查找
    def _fc(name):
        """按字段名查 code，支持前缀模糊匹配。"""
        if name in fields_dict:
            return fields_dict[name].get("code")
        for k, v in fields_dict.items():
            if k.startswith(name) and len(k) > len(name):
                return v.get("code")
        return None

    # 每个维度的 hit/miss 参数模板
    dim_params = {}
    for rs in non_alert_rs:
        rs_code = rs["code"]
        rs_rules = rs_to_rules.get(rs_code, [])
        hit_p, miss_p = {}, {}

        if "单户" in rs.get("name", ""):
            fc_bal = _fc("单户合并责任余额") or "presinglemergedliability"
            fc_lim = _fc("限额_离线单户集中度") or "creditlimitoff"
            hit_p = {fc_bal: 5000000, fc_lim: 1000000}
            miss_p = {fc_bal: 100000, fc_lim: 1000000}
        elif "关联户" in rs.get("name", ""):
            fc_bal = _fc("关联户合并责任余额") or "prerelatedmergedliability"
            fc_lim = _fc("限额_离线关联户集中度") or "relatedcreditlimitoff"
            hit_p = {fc_bal: 5000000, fc_lim: 1000000}
            miss_p = {fc_bal: 100000, fc_lim: 1000000}
        elif "区域" in rs.get("name", ""):
            fc_area = _fc("区域合并已用额度") or "preareamergedusedquota"
            fc_lim = _fc("按集中度管理策略限额标准") or "conclimitstandardoff"
            fc_prov = _fc("客户区域_省") or "areaprovince"
            hit_p = {fc_area: 5000000, fc_lim: 1000000, fc_prov: "广东"}
            miss_p = {fc_area: 100000, fc_lim: 1000000, fc_prov: "广东"}

        dim_params[rs_code] = {"hit": hit_p, "miss": miss_p}

    # 生成所有 2^n 组合
    test_cases = []
    tc_id = 0
    rs_codes = [rs["code"] for rs in non_alert_rs]
    for combo in iter_product(["hit", "miss"], repeat=n):
        n_hit = sum(1 for c in combo if c == "hit")
        # 跳过已有覆盖：0 hit（全安全基线）和 1 hit（单规则集覆盖）
        if n_hit <= 1:
            continue

        tc_id += 1
        params = {
            "S_S_BIZID": f"TC_CROSS_{tc_id:03d}",
            "S_S_CUSTNO": f"TC_CROSS_CUST_{tc_id:03d}",
            "S_S_ORGCODE": "010117", "S_E_APIMODEL": "30",
        }
        hit_names, miss_names = [], []
        for i, (rs_code, state) in enumerate(zip(rs_codes, combo)):
            p = dim_params.get(rs_code, {}).get(state, {})
            params.update(p)
            rs_name = non_alert_rs[i].get("name", rs_code)
            if state == "hit":
                hit_names.append(rs_name)
            else:
                miss_names.append(rs_name)

        hit_desc = "+".join(hit_names)
        miss_desc = "+".join(miss_names) if miss_names else "无"
        combo_label = "×".join(
            f"{non_alert_rs[i].get('name', rs_codes[i])}{'命中' if c == 'hit' else '未命中'}"
            for i, c in enumerate(combo)
        )

        test_cases.append({
            "id": f"TC_CROSS_{tc_id:03d}",
            "desc": f"联动矩阵：{combo_label}",
            "group": "规则集联动矩阵", "caseType": "正案例",
            "scenario": f"规则集交叉组合：命中[{hit_desc}]，未命中[{miss_desc}]",
            "expected": f"命中：{hit_desc}；未命中：{miss_desc}",
            "params": params, "isCrossMatrix": True,
            "targetRuleSet": ",".join(rs_codes[i] for i, c in enumerate(combo) if c == "hit"),
            "targetRule": "",
        })

    return test_cases


# ---------------------------------------------------------------------------
# v2.4.2: 区域特化模板（Phase 1-5）
# ---------------------------------------------------------------------------

def generate_region_templates(rules, rule_sets, fields_dict):
    """生成区域特化模板用例：重庆 / 四川成都 / 其他省（扁平架构专用）。

    根据区域聚合层级判断函数的分支逻辑，为每个区域生成针对性测试用例。
    """
    non_alert_rs = [rs for rs in rule_sets if rs.get("code", "") != "alertLevelJudgment"]

    def _fc(name):
        if name in fields_dict:
            return fields_dict[name].get("code")
        for k, v in fields_dict.items():
            if k.startswith(name) and len(k) > len(name):
                return v.get("code")
        return None

    fc_area = _fc("区域合并已用额度") or "preareamergedusedquota"
    fc_lim_area = _fc("按集中度管理策略限额标准") or "conclimitstandardoff"
    fc_prov = _fc("客户区域_省") or "areaprovince"
    fc_city = _fc("客户区域_市") or "areacity"
    fc_single_bal = _fc("单户合并责任余额") or "presinglemergedliability"
    fc_single_lim = _fc("限额_离线单户集中度") or "creditlimitoff"
    fc_related_bal = _fc("关联户合并责任余额") or "prerelatedmergedliability"
    fc_related_lim = _fc("限额_离线关联户集中度") or "relatedcreditlimitoff"

    # 找到 areaConcPre 对应的规则集
    area_rs = next((rs for rs in non_alert_rs if "区域" in rs.get("name", "")), None)
    area_rs_code = area_rs["code"] if area_rs else "areaConcPre"

    templates = [
        {
            "name": "重庆",
            "desc": "重庆区域模板",
            "region_params": {fc_prov: "重庆", fc_city: "重庆"},
            "target_rule": "R004",
            "rule_note": "R004条件1(省=重庆)触发",
        },
        {
            "name": "四川成都",
            "desc": "四川成都区域模板",
            "region_params": {fc_prov: "四川", fc_city: "成都"},
            "target_rule": "R004",
            "rule_note": "R004条件2(省=四川且市=成都)触发",
        },
        {
            "name": "广东",
            "desc": "其他省区域模板（非重庆、非四川成都）",
            "region_params": {fc_prov: "广东", fc_city: "广州"},
            "target_rule": "R003",
            "rule_note": "R003触发（省≠重庆，省≠四川）",
        },
    ]

    test_cases = []
    tc_id = 0

    for tmpl in templates:
        # 每条区域模板生成 2 个用例：区域命中 + 区域未命中
        for area_state in ["hit", "miss"]:
            tc_id += 1
            params = {
                "S_S_BIZID": f"TC_REGION_{tc_id:03d}",
                "S_S_CUSTNO": f"TC_REGION_CUST_{tc_id:03d}",
                "S_S_ORGCODE": "010117", "S_E_APIMODEL": "30",
            }
            params.update(tmpl["region_params"])

            # 单户和关联户都设为 hit（不影响区域维度）
            params[fc_single_bal] = 5000000
            params[fc_single_lim] = 1000000
            params[fc_related_bal] = 5000000
            params[fc_related_lim] = 1000000

            if area_state == "hit":
                params[fc_area] = 5000000
                params[fc_lim_area] = 1000000
                expected_desc = f"区域集中度超限({tmpl['rule_note']})"
                case_type = "正案例"
            else:
                params[fc_area] = 100000
                params[fc_lim_area] = 1000000
                expected_desc = "区域集中度未超限（额度低于阈值）"
                case_type = "反案例"

            test_cases.append({
                "id": f"TC_REGION_{tc_id:03d}",
                "desc": f"区域模板[{tmpl['name']}]：区域{'命中' if area_state == 'hit' else '未命中'}",
                "group": "区域特化模板", "caseType": case_type,
                "scenario": f"{tmpl['desc']}，区域集中度{'超限' if area_state == 'hit' else '安全'}",
                "expected": expected_desc,
                "params": params,
                "targetRuleSet": area_rs_code,
                "isRegionTemplate": True,
            })

    return test_cases


# ---------------------------------------------------------------------------
# 决策流分支覆盖用例
# ---------------------------------------------------------------------------

def generate_flow_coverage_cases(strategies, rule_sets):
    test_cases = []
    tc_flow_id = 0

    for biz in ["借款", "债券", "委贷", "投资", "非融"]:
        for ent in ["国企", "民营"]:
            tc_flow_id += 1
            matching_rs = []
            for rs in rule_sets:
                biz_match = biz in rs["bizScenarios"] or "全部" in rs["bizScenarios"]
                ent_match = ent in rs["enterpriseType"] or "通用" in rs["enterpriseType"] or "主策略" in rs["enterpriseType"]
                if biz_match and ent_match:
                    matching_rs.append(rs["code"])

            test_cases.append({
                "id": f"TC_FLOW_{tc_flow_id:03d}",
                "desc": f"路由覆盖：{biz}×{ent}",
                "group": "决策流分支覆盖", "caseType": "正案例",
                "scenario": f"业务类型={biz}，企业类型={ent}，验证正确的规则集被触发",
                "expected": f"路由到：{', '.join(matching_rs) if matching_rs else '主策略'}",
                "params": {
                    "S_S_BIZID": f"TC_FLOW_{tc_flow_id:03d}",
                    "S_S_CUSTNO": f"TC_FLOW_CUST_{tc_flow_id:03d}",
                    "S_S_ORGCODE": "010117", "S_E_APIMODEL": "30",
                    "C_S_BIZSCENARIO": f"{biz}类", "S_S_ENTERPRISETYPE": ent,
                },
                "targetBizType": biz, "targetEntType": ent,
                "matchedRuleSets": matching_rs,
            })

    for biz in ["贷前借款", "贷前债券"]:
        tc_flow_id += 1
        test_cases.append({
            "id": f"TC_FLOW_{tc_flow_id:03d}",
            "desc": f"路由覆盖：{biz}（贷前主策略）",
            "group": "决策流分支覆盖", "caseType": "正案例",
            "scenario": f"事件类型=贷前，业务类型={biz.replace('贷前', '')}",
            "expected": "路由到：bhjcpostMainBefore",
            "params": {"S_S_BIZID": f"TC_FLOW_{tc_flow_id:03d}", "S_S_CUSTNO": f"TC_FLOW_CUST_{tc_flow_id:03d}",
                       "S_S_ORGCODE": "010117", "S_E_APIMODEL": "30"},
            "targetBizType": biz,
        })

    special_flows = [
        {"desc": "无效企业类型(外资) DEFAULT到End", "scenario": "企业类型=外资，验证企业子策略走DEFAULT分支", "expected": "企业子策略DEFAULT分支; 个人/关联企业子策略正常", "params_extra": {"S_S_ENTERPRISETYPE": "外资", "C_S_BIZSCENARIO": "借款类"}},
        {"desc": "未知业务场景走DEFAULT路径", "scenario": "C_S_BIZSCENARIO=未知类", "expected": "三个子策略均走DEFAULT", "params_extra": {"S_S_ENTERPRISETYPE": "国企", "C_S_BIZSCENARIO": "未知类"}},
        {"desc": "投资类×国企×资管类特殊分支", "scenario": "投资+国企+资管类", "expected": "企业子策略(国企投资类资管分支)被调用", "params_extra": {"S_S_ENTERPRISETYPE": "国企", "C_S_BIZSCENARIO": "投资类", "S_S_SVTYP": "资产管理类"}},
        {"desc": "投资类×民营×资管类特殊分支", "scenario": "投资+民营+资管类", "expected": "企业子策略(民营投资类资管分支)被调用", "params_extra": {"S_S_ENTERPRISETYPE": "民营", "C_S_BIZSCENARIO": "投资类", "S_S_SVTYP": "资产管理类"}},
        {"desc": "投资类×国企×非资管类", "scenario": "投资+国企+非资管类", "expected": "企业子策略(国企投资类非资管分支)被调用", "params_extra": {"S_S_ENTERPRISETYPE": "国企", "C_S_BIZSCENARIO": "投资类", "S_S_SVTYP": "融资类"}},
        {"desc": "投资类×民营×非资管类", "scenario": "投资+民营+非资管类", "expected": "企业子策略(民营投资类非资管分支)被调用", "params_extra": {"S_S_ENTERPRISETYPE": "民营", "C_S_BIZSCENARIO": "投资类", "S_S_SVTYP": "融资类"}},
        {"desc": "借款类×国企不进入PLEP", "scenario": "个人子策略：借款×国企", "expected": "不进入PLEP规则集(仅民营)", "params_extra": {"S_S_ENTERPRISETYPE": "国企", "C_S_BIZSCENARIO": "借款类"}},
        {"desc": "个人子策略DEFAULT分支", "scenario": "非标准业务场景", "expected": "个人子策略DEFAULT分支", "params_extra": {"S_S_ENTERPRISETYPE": "国企", "C_S_BIZSCENARIO": "其他类"}},
        {"desc": "委贷类×民营: 循环不触发", "scenario": "委贷+民营，无持股数据", "expected": "循环函数不触发; 其他子策略正常", "params_extra": {"S_S_ENTERPRISETYPE": "民营", "C_S_BIZSCENARIO": "委贷类"}},
    ]

    for sf in special_flows:
        tc_flow_id += 1
        params = {"S_S_BIZID": f"TC_FLOW_{tc_flow_id:03d}", "S_S_CUSTNO": f"TC_FLOW_CUST_{tc_flow_id:03d}",
                  "S_S_ORGCODE": "010117", "S_E_APIMODEL": "30"}
        params.update(sf.get("params_extra", {}))
        test_cases.append({
            "id": f"TC_FLOW_{tc_flow_id:03d}", "desc": sf["desc"],
            "group": "决策流分支覆盖", "caseType": "正案例",
            "scenario": sf["scenario"], "expected": sf["expected"], "params": params,
        })

    return test_cases


# ---------------------------------------------------------------------------
# 策略预警等级覆盖用例
# ---------------------------------------------------------------------------

def generate_alert_level_cases(alert_rules):
    test_cases = []
    level_cases = [
        {"id": "TC_MAIN01_A", "desc": "红色预警：极高风险>0", "caseType": "正案例", "scenario": "极高风险规则命中≥1条", "expected": "命中：MAIN01(命中红色预警)[红色预警]", "hitCounts": {"极高风险": 1, "高风险": 0, "中风险": 0, "低风险": 0}},
        {"id": "TC_MAIN01_B", "desc": "红色预警：高风险>0", "caseType": "正案例", "scenario": "高风险规则命中≥1条", "expected": "命中：MAIN01(命中红色预警)[红色预警]", "hitCounts": {"极高风险": 0, "高风险": 1, "中风险": 0, "低风险": 0}},
        {"id": "TC_MAIN01_C", "desc": "红色预警：中风险≥3", "caseType": "正案例", "scenario": "中风险命中3条", "expected": "命中：MAIN01(命中红色预警)[红色预警]", "hitCounts": {"极高风险": 0, "高风险": 0, "中风险": 3, "低风险": 0}},
        {"id": "TC_MAIN01_BOUND", "desc": "红色预警边界：中风险恰好3条", "caseType": "边界案例", "scenario": "中风险=3", "expected": "命中：MAIN01(命中红色预警)[红色预警]", "hitCounts": {"极高风险": 0, "高风险": 0, "中风险": 3, "低风险": 0}},
        {"id": "TC_MAIN02_A", "desc": "黄色预警：中风险=1", "caseType": "正案例", "scenario": "高风险=0，中风险=1", "expected": "命中：MAIN02(命中黄色预警)[黄色预警]", "hitCounts": {"极高风险": 0, "高风险": 0, "中风险": 1, "低风险": 0}},
        {"id": "TC_MAIN02_B", "desc": "黄色预警：中风险=2", "caseType": "正案例", "scenario": "高风险=0，中风险=2", "expected": "命中：MAIN02(命中黄色预警)[黄色预警]", "hitCounts": {"极高风险": 0, "高风险": 0, "中风险": 2, "低风险": 0}},
        {"id": "TC_MAIN02_BOUND", "desc": "黄色预警边界：中风险=2", "caseType": "边界案例", "scenario": "中风险=2", "expected": "命中：MAIN02(命中黄色预警)[黄色预警]", "hitCounts": {"极高风险": 0, "高风险": 0, "中风险": 2, "低风险": 0}},
        {"id": "TC_MAIN03_A", "desc": "蓝色预警：仅低风险>0", "caseType": "正案例", "scenario": "仅低风险命中", "expected": "命中：MAIN03(命中蓝色预警)[蓝色预警]", "hitCounts": {"极高风险": 0, "高风险": 0, "中风险": 0, "低风险": 1}},
        {"id": "TC_MAIN04_A", "desc": "绿色预警：全部=0", "caseType": "正案例", "scenario": "所有等级=0", "expected": "命中：MAIN04(命中绿色预警)[绿色预警]", "hitCounts": {"极高风险": 0, "高风险": 0, "中风险": 0, "低风险": 0}},
        {"id": "TC_MAIN_MISS", "desc": "无任何预警", "caseType": "反案例", "scenario": "所有参数安全值", "expected": "未命中：所有预警等级规则", "hitCounts": {"极高风险": 0, "高风险": 0, "中风险": 0, "低风险": 0}},
    ]

    for case in level_cases:
        test_cases.append({
            "id": case["id"], "desc": case["desc"],
            "group": "策略预警等级覆盖", "caseType": case["caseType"],
            "scenario": case["scenario"], "expected": case["expected"],
            "params": {"S_S_BIZID": case["id"], "S_S_CUSTNO": f"CUST_{case['id']}",
                       "S_S_ORGCODE": "010117", "S_E_APIMODEL": "30"},
            "targetRuleSet": "alertLevelJudgment", "hitCounts": case["hitCounts"],
        })

    return test_cases


# ---------------------------------------------------------------------------
# 跨子策略综合场景
# ---------------------------------------------------------------------------

def generate_combined_scenarios(rules, rule_sets):
    test_cases = []
    tc_comb_id = 0

    rs_rules = {}
    for r in rules:
        rsc = r["ruleSetCode"]
        if rsc == "alertLevelJudgment":
            continue
        rs_rules.setdefault(rsc, []).append(r)

    ent_rs, per_rs, rel_rs = {}, {}, {}
    for rs in rule_sets:
        code, name = rs["code"], rs.get("name", "")
        if "个人" in name or "per" in code.lower(): per_rs[code] = rs
        elif "关联" in name or "relate" in code.lower(): rel_rs[code] = rs
        elif "企业" in name or "Ent" in code: ent_rs[code] = rs

    combos = [
        {"biz": "借款", "ent": "国企", "desc": "综合场景: 借款类国企多规则同时命中"},
        {"biz": "借款", "ent": "民营", "desc": "综合场景: 借款类民营多规则同时命中"},
        {"biz": "非融", "ent": "民营", "desc": "综合场景: 非融民营资质+中标信息"},
        {"biz": "委贷", "ent": "国企", "desc": "综合场景: 委贷类国企终本记录"},
        {"biz": "投资", "ent": "民营", "desc": "综合场景: 投资类民营破产清算"},
        {"biz": "债券", "ent": "民营", "desc": "综合场景: 债券类民营多规则命中"},
    ]

    for combo in combos:
        tc_comb_id += 1
        biz, ent = combo["biz"], combo["ent"]

        matched_ent_rs = []
        for rs_code, rs in ent_rs.items():
            biz_match = biz in rs.get("bizScenarios", "") or "全部" in rs.get("bizScenarios", "")
            ent_match = ent in rs.get("enterpriseType", "") or "通用" in rs.get("enterpriseType", "")
            if biz_match and ent_match:
                matched_ent_rs.append(rs_code)

        rep_rules = []
        for rs_code in matched_ent_rs[:3]:
            rl = rs_rules.get(rs_code, [])
            if rl: rep_rules.append(rl[0])
        for rs_code in list(per_rs.keys())[:1]:
            rl = rs_rules.get(rs_code, [])
            if rl: rep_rules.append(rl[0])
        for rs_code in list(rel_rs.keys())[:1]:
            rl = rs_rules.get(rs_code, [])
            if rl: rep_rules.append(rl[0])

        rule_desc = "、".join(f"{r['code']}({r['hitResult']})" for r in rep_rules[:4])
        params = {"S_S_BIZID": f"TC_COMB_{tc_comb_id:03d}", "S_S_CUSTNO": f"TC_COMB_CUST_{tc_comb_id:03d}",
                  "S_S_ORGCODE": "010117", "S_E_APIMODEL": "30",
                  "C_S_BIZSCENARIO": f"{biz}类", "S_S_ENTERPRISETYPE": ent}

        for r in rep_rules[:4]:
            for cond in parse_expression_conditions(r["expression"], r.get("inputParamsMapped", [])):
                params[cond["field_code"]] = construct_param_value(cond, "hit")

        test_cases.append({
            "id": f"TC_COMB_{tc_comb_id:03d}", "desc": combo["desc"],
            "group": "跨子策略综合", "caseType": "正案例",
            "scenario": f"跨子策略综合：{biz}类×{ent}，同时命中{rule_desc}",
            "expected": f"多规则同时命中：{rule_desc}，验证整体预警等级",
            "params": params, "isCombined": True,
        })

    # SAFE基线 — 填充实际安全参数值
    for biz in ["借款", "债券", "委贷", "投资", "非融"]:
        for ent in ["国企", "民营"]:
            tc_comb_id += 1
            safe_params = {"S_S_BIZID": f"TC_COMB_{tc_comb_id:03d}", "S_S_CUSTNO": f"TC_COMB_CUST_{tc_comb_id:03d}",
                           "S_S_ORGCODE": "010117", "S_E_APIMODEL": "30",
                           "C_S_BIZSCENARIO": f"{biz}类", "S_S_ENTERPRISETYPE": ent}
            safe_params.update(SAFE_DEFAULTS)

            test_cases.append({
                "id": f"TC_COMB_{tc_comb_id:03d}",
                "desc": f"全SAFE基线：{biz}×{ent} - 三个子策略均无命中",
                "group": "跨子策略综合", "caseType": "正案例",
                "scenario": f"全SAFE：{biz}类×{ent}，所有参数安全值，验证三个子策略均被调用且不触发任何规则",
                "expected": "企业子策略+个人子策略+关联企业子策略均被调用，无规则命中，最终绿色预警",
                "params": safe_params, "isSafeBaseline": True,
            })

    return test_cases


# ---------------------------------------------------------------------------
# v2.5.2: 三方依赖描述（沿用 thirdPartyMock 字段以保持输出兼容）
# ---------------------------------------------------------------------------

FIELD_TO_DATASOURCE = {
    "法定代表人变更": {"code": "2003", "name": "企查查客户身份识别", "field": "ChangeList"},
    "股权变更": {"code": "2003", "name": "企查查客户身份识别", "field": "ChangeList"},
    "经营范围变更": {"code": "2003", "name": "企查查客户身份识别", "field": "ChangeList"},
    "注册资本减少": {"code": "2003", "name": "企查查客户身份识别", "field": "ChangeList"},
    "注册资本增加": {"code": "2003", "name": "企查查客户身份识别", "field": "ChangeList"},
    "注销": {"code": "2003", "name": "企查查客户身份识别", "field": "CancelInfo"},
    "失信": {"code": "740", "name": "企查查失信记录", "field": ""},
    "被执行": {"code": "741", "name": "企查查被执行人记录", "field": ""},
    "限制高消费": {"code": "742", "name": "企查查限制高消费", "field": ""},
    "终本": {"code": "761", "name": "企查查终本案件", "field": ""},
    "被保全": {"code": "887", "name": "企查查司法案件", "field": ""},
    "为被告": {"code": "887", "name": "企查查司法案件", "field": ""},
    "自诉": {"code": "887", "name": "企查查司法案件", "field": "原告"},
    "破产": {"code": "761", "name": "企查查破产案件", "field": ""},
    "欠税": {"code": "757", "name": "企查查欠税公告", "field": ""},
    "税收违法": {"code": "756", "name": "企查查税收违法", "field": ""},
    "股权冻结": {"code": "752", "name": "企查查股权冻结", "field": ""},
    "股权出质": {"code": "751", "name": "企查查股权出质", "field": ""},
    "严重违法": {"code": "748", "name": "企查查严重违法", "field": ""},
    "司法拍卖": {"code": "744", "name": "企查查司法拍卖", "field": ""},
    "行政处罚": {"code": "865", "name": "企查查行政处罚", "field": ""},
    "环保处罚": {"code": "746", "name": "企查查环保处罚", "field": ""},
    "经营异常": {"code": "739", "name": "企查查经营异常", "field": ""},
    "资质": {"code": "255", "name": "企查查资质证书", "field": ""},
    "中标": {"code": "EBNP08", "name": "中标信息查询", "field": ""},
    "实缴比例": {"code": "2003", "name": "企查查客户身份识别", "field": "PaidCapRatio"},
    "注册资本": {"code": "2003", "name": "企查查客户身份识别", "field": "RegistCapi"},
    "实缴资本": {"code": "2003", "name": "企查查客户身份识别", "field": "PaidCapi"},
    "纳税信用": {"code": "2003", "name": "企查查客户身份识别", "field": "TaxPayerLevel"},
    "成立日期": {"code": "2003", "name": "企查查客户身份识别", "field": "EstDate"},
    "股东": {"code": "2003", "name": "企查查客户身份识别", "field": "MajorShareholder"},
    "逾期借贷": {"code": "征信", "name": "征信报告", "field": ""},
    "关注类借贷": {"code": "征信", "name": "征信报告", "field": ""},
    "逾期担保": {"code": "征信", "name": "征信报告", "field": ""},
    "关注类担保": {"code": "征信", "name": "征信报告", "field": ""},
    "个人失信": {"code": "740", "name": "企查查失信记录", "field": "个人"},
    "个人被执行": {"code": "741", "name": "企查查被执行人记录", "field": "个人"},
    "个人限制高消费": {"code": "742", "name": "企查查限制高消费", "field": "个人"},
    "个人终本": {"code": "761", "name": "企查查终本案件", "field": "个人"},
    "关联注销": {"code": "2003", "name": "企查查客户身份识别", "field": "关联企业"},
    "负面舆情": {"code": "yjtxwyq", "name": "新闻舆情数据源", "field": ""},
}


def generate_third_party_mock(rule):
    """生成普通规则依赖的三方接口说明，不生成 Mock 异常用例。"""
    name = rule.get("name", "")
    expression = rule.get("expression", "")
    input_params = rule.get("inputParamsMapped", [])

    interfaces = set()
    fields = []
    hints = []

    for keyword, ds_info in FIELD_TO_DATASOURCE.items():
        if keyword in name or keyword in expression:
            interfaces.add(f"{ds_info['code']}-{ds_info['name']}")
            hint = f"需要{keyword}命中数据"
            if ds_info.get("field"):
                hint += f"({ds_info['field']})"
            hints.append(hint)

    for p in input_params:
        if p.get("code"):
            fields.append(p["code"])

    if not interfaces:
        return {"interfaces": [], "fields": fields[:10], "mockHint": "无三方数据依赖"}

    return {
        "interfaces": sorted(interfaces),
        "fields": fields[:10],
        "mockHint": "; ".join(hints[:3]),
    }


# ---------------------------------------------------------------------------
# v2.3.1: Excel 报告输出
# ---------------------------------------------------------------------------

_EXCEL_COL_NAMES = [
    '用例编号', '模块', '用例名称', '业务描述', '测试场景',
    '用例类型', '前置条件', '测试步骤', '预期结果', '实际结果',
    '测试状态', '测试时间', '测试流水号UUID', '测试数据', '三方数据', '备注'
]

_EXCEL_COL_WIDTHS = [14, 8, 28, 30, 45, 8, 30, 35, 45, 35, 10, 16, 32, 40, 50, 20]


# ── v2.5.0: V5 对齐辅助函数 ──

# 参数名 → 中文可读标签（用于前置条件和测试步骤）
_PARAM_LABEL_MAP = {
    # 系统字段编码（大写）
    'C_F_CREDITLIMITOFF': '限额_离线单户',
    'C_F_RELATEDCREDITLIMITOFF': '限额_离线关联户',
    'C_F_AREAGUARANTEEAMOUNTOFF': '在保金额_离线区域',
    'C_F_AREACREDITLIMITOFF': '限额_离线区域',
    'C_F_SINGLEMERGEDLIABILITY': '单户合并责任余额',
    'C_F_RELATEDMERGEDLIABILITY': '关联户合并责任余额',
    'C_F_AREAMERGEDUSEDQUOTA': '区域合并已用额度',
    'S_S_CUSTNAME': '客户名称',
    'S_S_CUSTNO': '客户编号',
    'S_S_BIZID': '业务流水号',
    'S_S_ORGCODE': '机构编码',
    'S_S_IDNO': '证件号码',
    'S_E_APIMODEL': '运行模式',
    'C_F_RANDOMNUM': '随机数',
    # 业务字段名（小写，天策平台实际传参名）
    'presinglemergedliability': '单户合并责任余额(保前)',
    'prerelatedmergedliability': '关联户合并责任余额(保前)',
    'preareamergedusedquota': '区域合并已用额度(保前)',
    'creditlimitoff': '限额_离线单户',
    'relatedcreditlimitoff': '限额_离线关联户',
    'conclimitstandardoff': '集中度限额标准',
    'areaprovince': '省份',
    'areacity': '城市',
    'singlemergedliability': '单户合并责任余额',
    'relatedmergedliability': '关联户合并责任余额',
    'areamergedusedquota': '区域合并已用额度',
    'areaguaranteeamountoff': '在保金额_离线区域',
    'guaranteebalance': '在保余额',
    'loanamount': '贷款金额',
    'loanbalance': '贷款余额',
    'creditratio': '信用比率',
    'risklevel': '风险等级',
    'fivetypeclassify': '五级分类',
}

# 跳过的前置条件参数（非业务参数）
_SKIP_PRECOND_KEYS = {
    'S_S_BIZID', 'S_S_CUSTNO', 'S_S_IDNO', 'C_F_RANDOMNUM',
    'S_E_APIMODEL', 'S_S_ORGCODE',
}


def _format_amount(val):
    """将数值格式化为「万」单位（如果适用）"""
    try:
        num = float(val)
        if num >= 10000 and num == int(num):
            wan = num / 10000
            if wan == int(wan):
                return f"{int(wan)}万"
            return f"{wan:.2f}万"
        return str(int(num)) if num == int(num) else str(num)
    except (ValueError, TypeError):
        return str(val)


def _build_precondition(params):
    """从 params 提取业务参数生成前置条件摘要。
    v2.4: 不再仅依赖 _PARAM_LABEL_MAP 白名单，对未映射的字段使用原始 key 名展示。
    """
    if not params:
        return ''
    parts = []
    for k, v in params.items():
        if k in _SKIP_PRECOND_KEYS:
            continue
        if v == '' or v is None:
            continue
        label = _PARAM_LABEL_MAP.get(k, k)  # 未映射时使用原始 key 名
        parts.append(f"{label}={_format_amount(v)}")
    return '; '.join(parts[:5]) if parts else ''


def _build_test_steps(params):
    """从 params 生成具体参数设置步骤。
    v2.4: 对未映射字段也展示原始 key=value，不再回退为泛化描述。
    """
    if not params:
        return '提交策略测试，验证执行结果'
    key_params = []
    for k, v in params.items():
        if k in _SKIP_PRECOND_KEYS:
            continue
        if v == '' or v is None:
            continue
        label = _PARAM_LABEL_MAP.get(k, '')
        if label:
            key_params.append(f"{k}={v}({label})")
        else:
            key_params.append(f"{k}={v}")
    if not key_params:
        return '提交策略测试，验证执行结果'
    lines = [f"步骤1：设置关键参数 {', '.join(key_params[:4])}"]
    if len(key_params) > 4:
        lines.append(f"步骤2：设置辅助参数 {', '.join(key_params[4:8])}")
    lines.append(f"步骤{'3' if len(key_params) > 4 else '2'}：构造接口请求数据并提交")
    return '\n'.join(lines)


def _build_biz_desc(tc):
    """生成 V5 风格业务描述：包含规则条件和计算逻辑"""
    expected = tc.get('expected', '')
    scenario = tc.get('scenario', '')
    rule = tc.get('targetRule', '')
    rule_set = tc.get('targetRuleSet', '')
    # 从 expected 提取规则名和命中结果
    hit_result = ''
    rule_name = ''
    m = re.match(r'(?:命中|未命中)[：:]\s*(\w+)\((.+?)\)(?:\[(.+?)\])?', expected)
    if m:
        rule_code, rule_name, hit_result = m.group(1), m.group(2), m.group(3) or ''
    if rule_name:
        if hit_result:
            return f"{rule_name}：\n\n条件：{scenario}\n\n规则触发条件：{hit_result}"
        else:
            return f"{rule_name}：\n\n条件：{scenario}"
    return scenario


def _build_scenario_text(tc):
    """生成测试场景描述。
    v2.4: 优先使用 JSON 的 scenario 字段（完整的业务场景描述），
    仅在 scenario 为空时回退到 params 构造方式。
    """
    scenario = tc.get('scenario', '').strip()
    if scenario:
        return scenario

    # ── 回退：从 params 构造（兼容旧版 JSON） ──
    params = tc.get('params', {})
    expected = tc.get('expected', '')
    desc = tc.get('desc', '')
    amounts = {}
    for k, v in params.items():
        if k not in _SKIP_PRECOND_KEYS:
            label = _PARAM_LABEL_MAP.get(k, k)
            amounts[label] = _format_amount(v)
    if '命中' in expected and '未命中' not in expected:
        scene_type = '正向'
    elif '未命中' in expected or '不命中' in expected:
        scene_type = '反向'
    else:
        scene_type = '边界'
    if amounts:
        amt_parts = [f"{k}={v}" for k, v in list(amounts.items())[:3]]
        return f"{scene_type}场景：{'; '.join(amt_parts)}"
    return desc


def _map_case_type_label(case_type):
    """映射用例类型标签：正案例→正向, 反案例→反向"""
    mapping = {'正案例': '正向', '反案例': '反向', '异常案例': '异常'}
    return mapping.get(case_type, case_type)


def _format_params_v5(params_dict, policy_code='', policy_name='',
                      policy_version='', biz_type=''):
    """将 params 字典格式化为 V5 风格完整 JSON（含接口地址和请求体）"""
    if not params_dict:
        return ''
    request_body = {
        'bizType': biz_type or 1,
        'policyCode': policy_code,
        'policyName': policy_name,
        'policyVersion': policy_version or 2,
        'params': params_dict,
    }
    return json.dumps({
        '说明': f"{policy_code}: {tc_desc}",
        '接口地址': '/noahApi/lab/policytest/create',
        '请求方法': 'POST',
        '请求体': request_body,
    }, ensure_ascii=False, indent=2) if False else json.dumps(request_body, ensure_ascii=False, indent=2)


def _format_params(params_dict):
    """将 params 字典格式化为可读文本"""
    lines = []
    for k, v in params_dict.items():
        v_str = str(v)
        if len(v_str) > 200:
            v_str = v_str[:200] + '...'
        lines.append(f'{k} = {v_str}')
    return '\n'.join(lines)


def _format_mock(mock_dict):
    """将 thirdPartyMock 格式化为可读文本"""
    if not mock_dict:
        return ''
    parts = []
    if mock_dict.get('interfaces'):
        parts.append('接口: ' + ', '.join(mock_dict['interfaces']))
    if mock_dict.get('fields'):
        parts.append('字段: ' + ', '.join(mock_dict['fields']))
    if mock_dict.get('mockHint'):
        parts.append('提示: ' + mock_dict['mockHint'])
    return '\n'.join(parts)


def _format_expected_evidence(evidence):
    if not isinstance(evidence, dict):
        return ""
    parts = []
    if evidence.get("rules"):
        parts.append("必须命中规则: " + ", ".join(evidence["rules"]))
    if evidence.get("forbiddenRules"):
        parts.append("不得命中规则: " + ", ".join(evidence["forbiddenRules"]))
    functions = []
    for requirement in evidence.get("functions", []):
        if not isinstance(requirement, dict):
            continue
        text = f"{requirement.get('nodeName', '')}.{requirement.get('field', '')}"
        if "value" in requirement:
            text += f"={requirement['value']}"
        if requirement.get("tolerance") is not None:
            text += f"(容差±{requirement['tolerance']})"
        functions.append(text)
    if functions:
        parts.append("函数证据: " + "; ".join(functions))
    nodes = []
    for requirement in evidence.get("thirdPartyNodes", []):
        if isinstance(requirement, str):
            nodes.append(requirement)
        elif isinstance(requirement, dict):
            values = ", ".join(
                f"{field}={value}"
                for field, value in (requirement.get("fieldValues", {}) or {}).items()
            )
            absent = ",".join(requirement.get("absentFields", []))
            detail = values or ",".join(requirement.get("fields", []))
            if requirement.get("fixtureRowCount", 1) > 1:
                detail = (
                    f"Fixture行数={requirement['fixtureRowCount']}; "
                    f"逐行值={requirement.get('rowFieldValues', [])}"
                )
            if absent:
                detail += f"; 不应返回={absent}"
            nodes.append(f"{requirement.get('nodeName', '')}({detail})")
    if nodes:
        parts.append("三方证据: " + "; ".join(nodes))
    return "\n".join(parts)


def _format_fixture_contract(case):
    if case.get("executionMode") == "fixture":
        return (
            f"Fixture场景={case.get('fixtureScenario', '')}; "
            f"接口={case.get('fixtureInterfaceCode', '')}"
        )
    profile = case.get("fixtureProfile")
    if isinstance(profile, dict):
        states = ", ".join(f"{key}={value}" for key, value in profile.items())
        semantic = case.get("semanticScenario")
        semantic_text = f"; 语义场景={semantic}" if semantic else ""
        return (
            f"Fixture状态: {states}; 区域路由={case.get('regionRoute', '')}"
            f"{semantic_text}"
        )
    return ""


def export_excel(output_data, excel_path):
    """v2.3.1: 将生成结果导出为 Excel 测试报告。

    Args:
        output_data: generate_all 返回的完整输出字典
        excel_path: 输出 .xlsx 路径
    """
    if not HAS_OPENPYXL:
        print("警告：未安装 openpyxl，跳过 Excel 导出。安装命令: pip install openpyxl", file=sys.stderr)
        return None

    cases = output_data['testCases']
    strategy_name = output_data.get('strategyName', '策略测试')
    strategy_code = output_data.get('strategyCode', '')
    summary = output_data.get('summary', {})
    by_module = summary.get('byModule', {})
    by_type = summary.get('byCaseType', {})

    wb = Workbook()

    # ── Sheet 1: 汇总 ──
    ws_sum = wb.active
    ws_sum.title = '汇总'

    summary_rows = [
        ('策略名称', strategy_name),
        ('策略编码', strategy_code),
        ('生成时间', output_data.get('generatedAt', '')),
        ('生成版本', f'v{VERSION}'),
        ('用例总数', summary.get('total', len(cases))),
        ('', ''),
        ('按模块分布', ''),
    ]
    for mod, cnt in by_module.items():
        summary_rows.append((mod, cnt))
    summary_rows.append(('', ''))
    summary_rows.append(('按用例类型分布', ''))
    for typ, cnt in by_type.items():
        summary_rows.append((typ, cnt))

    sum_font_bold = Font(name='微软雅黑', size=10, bold=True)
    sum_font = Font(name='微软雅黑', size=10)
    for ri, (k, v) in enumerate(summary_rows, 1):
        ws_sum.cell(row=ri, column=1, value=k).font = sum_font_bold
        ws_sum.cell(row=ri, column=2, value=v).font = sum_font
    ws_sum.column_dimensions['A'].width = 20
    ws_sum.column_dimensions['B'].width = 40

    # ── Sheet 2: 用例明细 ──
    ws = wb.create_sheet(title=strategy_name[:31])

    hdr_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
    hdr_font = Font(name='微软雅黑', size=9, color='FFFFFF', bold=True)
    hdr_align = Alignment(horizontal='center', vertical='center', wrap_text=True)
    thin = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin'),
    )
    data_font = Font(name='微软雅黑', size=9)
    data_align = Alignment(horizontal='left', vertical='top', wrap_text=True)

    # 表头
    for ci, col_name in enumerate(_EXCEL_COL_NAMES, 1):
        cell = ws.cell(row=1, column=ci, value=col_name)
        cell.fill = hdr_fill
        cell.font = hdr_font
        cell.alignment = hdr_align
        cell.border = thin

    # 列宽
    for ci, w in enumerate(_EXCEL_COL_WIDTHS, 1):
        ws.column_dimensions[get_column_letter(ci)].width = w

    # 数据行 (v2.5.0: 使用 V5 对齐辅助函数)
    policy_code = output_data.get('strategyCode', '')
    policy_name = output_data.get('strategyName', '')
    policy_version = output_data.get('policyVersion', 2)
    biz_type = output_data.get('bizType', 1)

    for ri, tc in enumerate(cases, 2):
        params = tc.get('params', {})
        row = [
            tc.get('id', ''),                                          # 用例编号
            tc.get('group', ''),                                       # 模块
            tc.get('desc', ''),                                        # 用例名称
            _build_biz_desc(tc),                                       # 业务描述 (V5)
            _build_scenario_text(tc),                                  # 测试场景 (V5)
            _map_case_type_label(tc.get('caseType', '')),              # 用例类型 (V5)
            _build_precondition(params),                               # 前置条件 (V5)
            _build_test_steps(params),                                 # 测试步骤 (V5)
            tc.get('expected', ''),                                    # 预期结果
            '待执行', '待执行', '待执行', '待执行',                       # 实际/状态/时间/UUID
            json.dumps({                                               # 测试数据 (V5 JSON)
                'policyCode': policy_code,
                'policyName': policy_name,
                'policyVersion': policy_version,
                'bizType': biz_type,
                'params': params,
            }, ensure_ascii=False, indent=2) if params else '',
            _format_expected_evidence(tc.get('expectedEvidence', {})), # 三方/函数/规则证据
            _format_fixture_contract(tc),                              # 备注
        ]
        for ci, val in enumerate(row, 1):
            cell = ws.cell(row=ri, column=ci, value=val)
            cell.font = data_font
            cell.alignment = data_align
            cell.border = thin

    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = f'A1:{get_column_letter(len(_EXCEL_COL_NAMES))}{len(cases) + 1}'

    wb.save(excel_path)
    print(f"Excel 报告已导出: {excel_path}", file=sys.stderr)
    return excel_path


# ---------------------------------------------------------------------------
# 反馈注入 (v2.4.2: --feedback 支持，闭合 Agent Loop)
# ---------------------------------------------------------------------------

def load_feedback(feedback_path):
    """加载上轮反馈 JSON，返回 actions 列表"""
    if not feedback_path or not Path(feedback_path).exists():
        return []
    try:
        data = json.loads(Path(feedback_path).read_text(encoding="utf-8"))
        return data.get("actions", [])
    except (json.JSONDecodeError, KeyError) as e:
        print(f"警告：无法加载反馈文件: {e}", file=sys.stderr)
        return []


def apply_feedback(all_cases, actions):
    """
    将反馈动作应用到用例列表。匹配优先级：targetRule > scenario 关键词 > desc 关键词。

    支持的动作类型：
      fixParams      — 修正指定字段的入参值
      adjustExpected — 替换预期结果
      removeCases    — 移除无效用例

    返回应用的反馈数量。
    """
    if not actions:
        return 0

    # 构建索引
    by_rule = {}
    by_scenario_kw = {}
    for tc in all_cases:
        rule = tc.get("targetRule", "")
        if rule:
            by_rule.setdefault(rule, []).append(tc)
        scenario = tc.get("scenario", "") + " " + tc.get("desc", "")
        for word in re.findall(r'[A-Z][A-Z0-9_]{2,}', scenario):
            by_scenario_kw.setdefault(word, []).append(tc)

    applied = 0
    for action in actions:
        atype = action.get("type", "")
        rule = action.get("rule", "")
        target = action.get("target", "")
        field = action.get("field", "")
        reason = action.get("reason", "")

        # 尝试按规则/函数代码匹配
        matches = by_rule.get(rule, [])

        # 回退：从 reason 中提取规则代码
        if not matches and not rule:
            rule_match = re.search(
                r'(ARGP\d+|EBGS\d+|EBGP\d+|EBNP\d+|EBNS\d+|ENDX\d+|ARMP\d+|'
                r'ELLP\d+|ELLS\d+|MAIN\d+|S\d{6})',
                reason
            )
            if rule_match:
                matches = by_rule.get(rule_match.group(1), [])

        # 回退：按场景关键词匹配
        if not matches:
            for word in re.findall(r'[A-Z][A-Z0-9_]{2,}', reason):
                if word in by_scenario_kw:
                    matches = by_scenario_kw[word]
                    break

        if not matches:
            continue

        tc = matches[0]
        if atype == "fixParams" and field and field != "_auto_detect":
            new_val = action.get("newValue")
            if new_val is not None:
                tc.setdefault("params", {})[field] = new_val
                applied += 1
        elif atype == "fixParams" and field == "_auto_detect":
            # 无法自动确定具体字段，标记诊断信息供下轮参考
            tc.setdefault("_feedback_pending", []).append({
                'reason': action.get('reason', ''),
                'action': action.get('action', ''),
                'rule': action.get('rule', ''),
            })
            applied += 1
        elif atype == "adjustExpected":
            new_exp = action.get("newValue")
            if new_exp:
                tc["expected"] = new_exp
                applied += 1
        elif atype == "removeCases":
            if tc in all_cases:
                all_cases.remove(tc)
                applied += 1

    return applied


# ---------------------------------------------------------------------------
# 参数分布感知（Phase 3-6）
# ---------------------------------------------------------------------------

def compute_param_distribution(history_paths):
    """读取历史测试用例文件，计算数值型参数的 P50/P95/min/max 分布统计。

    Args:
        history_paths: list[str] — 历史 testcases JSON 文件路径列表

    Returns:
        dict: {fieldName: {count, min, max, p50, p95, values_sample}} 仅含数值型字段
    """
    from collections import defaultdict
    field_values = defaultdict(list)

    for hpath in history_paths:
        try:
            with open(hpath, encoding="utf-8") as f:
                hdata = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError, OSError):
            continue

        test_cases = []
        if isinstance(hdata, dict):
            test_cases = hdata.get("testCases", hdata.get("testcases", []))
        elif isinstance(hdata, list):
            test_cases = hdata

        for tc in test_cases:
            if not isinstance(tc, dict):
                continue
            params = tc.get("params", {})
            if not isinstance(params, dict):
                continue
            for field_name, raw_val in params.items():
                try:
                    num_val = float(raw_val)
                    field_values[field_name].append(num_val)
                except (ValueError, TypeError):
                    pass

    distribution = {}
    for field_name, values in sorted(field_values.items()):
        if len(values) < 2:
            continue
        values_sorted = sorted(values)
        n = len(values_sorted)
        p50_idx = int(n * 0.5)
        p95_idx = min(int(n * 0.95), n - 1)
        distribution[field_name] = {
            "count": n,
            "min": values_sorted[0],
            "max": values_sorted[-1],
            "p50": values_sorted[p50_idx],
            "p95": values_sorted[p95_idx],
            "mean": round(sum(values_sorted) / n, 4),
        }

    return distribution


# ---------------------------------------------------------------------------
# 策略版本 diff（Phase 3-5）
# ---------------------------------------------------------------------------

def diff_strategy_versions(old_path, new_path):
    """对比两版 parsed_strategy.json，输出变更摘要。
    返回 dict 包含 added/removed/modified rules, ruleSets, functions, fields 等。
    """
    with open(old_path, encoding="utf-8") as f:
        old_data = json.load(f)
    with open(new_path, encoding="utf-8") as f:
        new_data = json.load(f)

    diff = {"rules": {}, "ruleSets": {}, "functions": {}, "fields": {}, "thirdParty": {}}

    # --- rules diff ---
    old_rules = {r.get("code") or r.get("name", ""): r for r in old_data.get("rules", [])}
    new_rules = {r.get("code") or r.get("name", ""): r for r in new_data.get("rules", [])}
    diff["rules"]["added"] = sorted(set(new_rules.keys()) - set(old_rules.keys()))
    diff["rules"]["removed"] = sorted(set(old_rules.keys()) - set(new_rules.keys()))
    modified = []
    for key in set(old_rules.keys()) & set(new_rules.keys()):
        o = old_rules[key]
        n = new_rules[key]
        changes = []
        if o.get("expression") != n.get("expression"):
            changes.append("expression")
        if o.get("hitResult") != n.get("hitResult"):
            changes.append("hitResult")
        if o.get("name") != n.get("name"):
            changes.append("name")
        if o.get("ruleSetCode") != n.get("ruleSetCode"):
            changes.append("ruleSetCode")
        if changes:
            modified.append({"key": key, "changes": changes})
    diff["rules"]["modified"] = modified

    # --- ruleSets diff ---
    old_rs = {r.get("code") or r.get("name", ""): r for r in old_data.get("ruleSets", [])}
    new_rs = {r.get("code") or r.get("name", ""): r for r in new_data.get("ruleSets", [])}
    diff["ruleSets"]["added"] = sorted(set(new_rs.keys()) - set(old_rs.keys()))
    diff["ruleSets"]["removed"] = sorted(set(old_rs.keys()) - set(new_rs.keys()))

    # --- functions diff ---
    old_fn = {f.get("name", ""): f for f in old_data.get("functions", [])}
    new_fn = {f.get("name", ""): f for f in new_data.get("functions", [])}
    diff["functions"]["added"] = sorted(set(new_fn.keys()) - set(old_fn.keys()))
    diff["functions"]["removed"] = sorted(set(old_fn.keys()) - set(new_fn.keys()))

    # --- fields diff ---
    # fields 可能是 dict(key=中文名, value={code,type,...}) 或 list([{code,name,...}])
    raw_old_fields = old_data.get("fields", [])
    raw_new_fields = new_data.get("fields", [])
    if isinstance(raw_old_fields, dict):
        old_fields = {k: v for k, v in raw_old_fields.items()}
    else:
        old_fields = {f.get("code") or f.get("name", ""): f for f in raw_old_fields}
    if isinstance(raw_new_fields, dict):
        new_fields = {k: v for k, v in raw_new_fields.items()}
    else:
        new_fields = {f.get("code") or f.get("name", ""): f for f in raw_new_fields}
    diff["fields"]["added"] = sorted(set(new_fields.keys()) - set(old_fields.keys()))
    diff["fields"]["removed"] = sorted(set(old_fields.keys()) - set(new_fields.keys()))

    # --- thirdParty diff ---
    old_tp = set(t.get("name", "") for t in old_data.get("thirdPartyInterfaces", []))
    new_tp = set(t.get("name", "") for t in new_data.get("thirdPartyInterfaces", []))
    diff["thirdParty"]["added"] = sorted(new_tp - old_tp)
    diff["thirdParty"]["removed"] = sorted(old_tp - new_tp)

    # --- summary ---
    total_changes = (
        len(diff["rules"]["added"]) + len(diff["rules"]["removed"]) + len(diff["rules"]["modified"])
        + len(diff["ruleSets"]["added"]) + len(diff["ruleSets"]["removed"])
        + len(diff["functions"]["added"]) + len(diff["functions"]["removed"])
        + len(diff["fields"]["added"]) + len(diff["fields"]["removed"])
        + len(diff["thirdParty"]["added"]) + len(diff["thirdParty"]["removed"])
    )
    diff["summary"] = {
        "totalChanges": total_changes,
        "rulesChanged": len(diff["rules"]["added"]) + len(diff["rules"]["removed"]) + len(diff["rules"]["modified"]),
        "ruleSetsChanged": len(diff["ruleSets"]["added"]) + len(diff["ruleSets"]["removed"]),
        "functionsChanged": len(diff["functions"]["added"]) + len(diff["functions"]["removed"]),
        "fieldsChanged": len(diff["fields"]["added"]) + len(diff["fields"]["removed"]),
        "thirdPartyChanged": len(diff["thirdParty"]["added"]) + len(diff["thirdParty"]["removed"]),
    }

    return diff


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

def _fixture_capable_interface(interface):
    """仅数据库查询接口可在无 mock 环境用隔离数据稳定构造返回。"""
    protocol = str(interface.get("protocol", "")).lower()
    url = str(interface.get("url", "")).lower()
    return "mysql" in protocol or url.startswith("jdbc:mysql:")


def _interface_query_inputs(interface):
    return [item.strip() for item in str(interface.get("inputs", "")).splitlines()
            if item.strip() and "sql" not in item.lower()]


CONCENTRATION_RULE_DIMENSIONS = {
    "R001": "single",
    "R002": "related",
    "R003": "area",
    "R004": "area",
}

CONCENTRATION_RULE_NAMES = {
    "R001": "保前单户集中度判断",
    "R002": "保前关联户集中度判断",
    "R003": "保前区域集中度判断_地市级",
    "R004": "保前区域集中度判断_区县级",
}

CONCENTRATION_FUNCTIONS = {
    "single": ("保前单户合并责任余额", "C_F_PRESINGLEMERGEDLIABILITY"),
    "related": ("保前关联户合并责任余额", "C_F_PRERELATEDMERGEDLIABILITY"),
    "area": ("保前区域合并已用额度", "C_F_PREAREAMERGEDUSEDQUOTA"),
    "route": ("区域聚合层级判断", "C_S_AREAAGGLEVEL"),
    "summary": ("保前集中度综合判断结果汇总", "C_S_PRECONCOVERALLRESULT"),
}

CONCENTRATION_SEMANTIC_TAGS = {
    "region_full_name_normalization",
    "sichuan_non_chengdu_route",
    "single_decimal_precision",
    "single_realtime_only",
    "single_offline_only",
    "related_decimal_precision",
    "related_realtime_only",
    "related_offline_only",
    "area_decimal_precision",
    "area_realtime_only",
    "area_offline_only",
    "area_multi_row_aggregation",
}

CONCENTRATION_DIMENSION_INTERFACES = {
    "single": ("dhjzdsearch", "dhjzdoffsearch"),
    "related": ("glhjzdsearch", "glhjzdoffsearch"),
    "area": ("sjqyjzdsearch", "sjqyjzdoffsearch"),
}

CONCENTRATION_NODES = {
    "single_realtime": ("单户集中度表查询_实时", ["C_F_GUARANTEEBALANCE", "C_F_LIABILITYBALANCE", "C_F_QUOTAREALTIMESINGLECONC", "C_F_RESERVEAMOUNT"]),
    "single_batch": ("单户集中度表查询_离线", ["C_F_GUARANTEEBALANCEOFF", "C_F_LIABILITYBALANCEOFF", "C_F_CREDITLIMITOFF", "C_F_RESERVEAMOUNTOFF"]),
    "related_realtime": ("关联户集中度表查询_实时", ["C_F_RELATEDGUARANTEEBALANCE", "C_F_RELATEDLIABILITYBALANCE", "C_F_QUOTAREALTIMERELATEDCONC", "C_F_RELATEDRESERVEAMOUNT"]),
    "related_batch": ("关联户集中度表查询_离线", ["C_F_RELATEDGUARANTEEBALANCEOFF", "C_F_RELATEDLIABILITYBALANCEOFF", "C_F_RELATEDCREDITLIMITOFF", "C_F_RELATEDRESERVEAMOUNTOFF"]),
    "city_realtime": ("市级区域集中度表查询_实时", ["C_F_AREAGUARANTEEAMOUNT", "C_F_AREARESERVEAMOUNT", "C_F_DISTRICTUSEDQUOTA"]),
    "city_batch": ("市级区域集中度表查询_离线", ["C_F_AREAGUARANTEEAMOUNTOFF", "C_F_AREARESERVEAMOUNTOFF", "C_F_DISTRICTUSEDQUOTAOFF", "C_F_CONCLIMITSTANDARDOFF"]),
    "district_realtime": ("区级区域集中度表查询_实时", ["C_F_AREAGUARANTEEAMOUNT", "C_F_AREARESERVEAMOUNT", "C_F_DISTRICTUSEDQUOTA"]),
    "district_batch": ("区级区域集中度表查询_离线", ["C_F_AREAGUARANTEEAMOUNTOFF", "C_F_AREARESERVEAMOUNTOFF", "C_F_DISTRICTUSEDQUOTAOFF", "C_F_CONCLIMITSTANDARDOFF"]),
}

CONCENTRATION_NODE_SOURCES = {
    "single_realtime": {
        "C_F_GUARANTEEBALANCE": "in_guar_bal",
        "C_F_LIABILITYBALANCE": "duty_bal",
        "C_F_QUOTAREALTIMESINGLECONC": "quota",
        "C_F_RESERVEAMOUNT": "reserve_amount",
    },
    "single_batch": {
        "C_F_GUARANTEEBALANCEOFF": "in_guar_bal",
        "C_F_LIABILITYBALANCEOFF": "duty_bal",
        "C_F_CREDITLIMITOFF": "quota",
        "C_F_RESERVEAMOUNTOFF": "reserve_amount",
    },
    "related_realtime": {
        "C_F_RELATEDGUARANTEEBALANCE": "in_guar_bal",
        "C_F_RELATEDLIABILITYBALANCE": "duty_bal",
        "C_F_QUOTAREALTIMERELATEDCONC": "quota",
        "C_F_RELATEDRESERVEAMOUNT": "reserve_amount",
    },
    "related_batch": {
        "C_F_RELATEDGUARANTEEBALANCEOFF": "in_guar_bal",
        "C_F_RELATEDLIABILITYBALANCEOFF": "duty_bal",
        "C_F_RELATEDCREDITLIMITOFF": "quota",
        "C_F_RELATEDRESERVEAMOUNTOFF": "reserve_amount",
    },
    "city_realtime": {
        "C_F_AREAGUARANTEEAMOUNT": "in_guar_bal",
        "C_F_AREARESERVEAMOUNT": "reserve_amount",
        "C_F_DISTRICTUSEDQUOTA": "area_used_quota",
    },
    "city_batch": {
        "C_F_AREAGUARANTEEAMOUNTOFF": "in_guar_bal",
        "C_F_AREARESERVEAMOUNTOFF": "reserve_amount",
        "C_F_DISTRICTUSEDQUOTAOFF": "area_used_quota",
        "C_F_CONCLIMITSTANDARDOFF": "area_quota",
    },
}
CONCENTRATION_NODE_SOURCES["district_realtime"] = CONCENTRATION_NODE_SOURCES["city_realtime"]
CONCENTRATION_NODE_SOURCES["district_batch"] = CONCENTRATION_NODE_SOURCES["city_batch"]

CONCENTRATION_STATE_VALUES = {
    "hit": {
        "in_guar_bal": 10_000_000,
        "duty_bal": 10_000_000,
        "reserve_amount": 10_000_000,
        "quota": 1_000_000,
        "area_used_quota": 10_000_000,
        "area_quota": 1_000_000,
    },
    "boundary": {
        "in_guar_bal": 250_000,
        "duty_bal": 250_000,
        "reserve_amount": 250_000,
        "quota": 1_000_000,
        "area_used_quota": 250_000,
        "area_quota": 1_000_000,
    },
    "miss": {
        "in_guar_bal": 0,
        "duty_bal": 0,
        "reserve_amount": 0,
        "quota": 100_000_000,
        "area_used_quota": 0,
        "area_quota": 100_000_000,
    },
}


def _is_concentration_strategy(strategy_code, strategy_name):
    return "CONC" in str(strategy_code).upper() or "集中度" in str(strategy_name)


def _supports_concentration_fixture_model(data):
    if not _is_concentration_strategy(
        data.get("strategies", [{}])[0].get("code", ""),
        data.get("strategies", [{}])[0].get("name", ""),
    ):
        return False
    rule_codes = {rule.get("code") for rule in data.get("rules", [])}
    interface_codes = {
        interface.get("code") for interface in data.get("thirdPartyInterfaces", [])
    }
    required_interfaces = {
        "dhjzdsearch", "dhjzdoffsearch", "glhjzdsearch", "glhjzdoffsearch",
        "sjqyjzdsearch", "sjqyjzdoffsearch", "qjqyjzdsearch", "qjqyjzdoffsearch",
    }
    return set(CONCENTRATION_RULE_DIMENSIONS).issubset(rule_codes) and required_interfaces.issubset(interface_codes)


def _record_semantic_text(record):
    if not isinstance(record, dict):
        return ""
    return "\n".join(
        str(record.get(key) or "")
        for key in (
            "name", "description", "logic", "inputs", "outputs", "expression",
        )
    )


def _field_items(fields):
    if isinstance(fields, dict):
        return fields.items()
    return (
        (field.get("name") or field.get("code") or "", field)
        for field in fields or [] if isinstance(field, dict)
    )


def _function_has_decimal_inputs(function, fields):
    function_text = _record_semantic_text(function).lower()
    if "小数" in function_text or "decimal" in function_text:
        return True
    for field_name, metadata in _field_items(fields):
        field_type = str(metadata.get("type") or "").lower()
        if not re.search(r"小数|浮点|decimal|double|float", field_type):
            continue
        aliases = {
            str(field_name).lower(),
            str(metadata.get("name") or "").lower(),
            str(metadata.get("code") or "").lower(),
        }
        if any(alias and alias in function_text for alias in aliases):
            return True
    return False


def _function_accepts_multi_row_input(function, fields):
    """Require an explicit function input cardinality contract.

    SUM/汇总/分组 may describe aggregation already completed by the data
    source. They do not prove that the function itself accepts collections.
    """
    function_text = _record_semantic_text(function)
    explicit_contract = re.search(
        r"(?:函数|入参|输入|接收|处理|返回).{0,30}"
        r"(?:数组|列表|集合|多行|多条记录|一对多)"
        r"|(?:同一查询键|同键).{0,30}(?:多行|多条记录)",
        function_text,
        re.IGNORECASE,
    )
    if explicit_contract:
        return True

    lowered_text = function_text.lower()
    for field_name, metadata in _field_items(fields):
        field_type = str(metadata.get("type") or "").lower()
        if not re.search(r"数组|列表|集合|array|list|collection", field_type):
            continue
        aliases = {
            str(field_name).lower(),
            str(metadata.get("name") or "").lower(),
            str(metadata.get("code") or "").lower(),
        }
        if any(alias and alias in lowered_text for alias in aliases):
            return True
    return False


def _concentration_semantic_applicability(data):
    """Infer optional semantic regressions from the actual strategy template."""
    functions = {
        function.get("name", ""): function
        for function in data.get("functions", [])
        if isinstance(function, dict)
    }
    rules = {
        rule.get("code", ""): rule
        for rule in data.get("rules", [])
        if isinstance(rule, dict)
    }
    interfaces = {
        interface.get("code", ""): interface
        for interface in data.get("thirdPartyInterfaces", [])
        if isinstance(interface, dict)
    }
    fields = data.get("fields", {})
    applicable = set()
    reasons = {}

    route_function = functions.get(CONCENTRATION_FUNCTIONS["route"][0], {})
    route_text = "\n".join([
        _record_semantic_text(route_function),
        _record_semantic_text(rules.get("R003", {})),
        _record_semantic_text(rules.get("R004", {})),
    ])
    has_region_fields = any(
        token in route_text
        for token in ("客户区域_省", "客户区域_市", "省份", "省=", "市=")
    )
    has_full_and_short_sichuan = (
        ("四川省" in route_text and re.search(r"四川(?!省)", route_text))
        or ("成都市" in route_text and re.search(r"成都(?!市)", route_text))
    )
    if has_region_fields and has_full_and_short_sichuan:
        applicable.add("region_full_name_normalization")
        reasons["region_full_name_normalization"] = (
            "区域路由同时出现四川/四川省或成都/成都市表达"
        )

    r003_text = _record_semantic_text(rules.get("R003", {}))
    if (
        "四川" in r003_text
        and "成都" in r003_text
        and re.search(r"或|\|\|", r003_text)
    ):
        applicable.add("sichuan_non_chengdu_route")
        reasons["sichuan_non_chengdu_route"] = "R003含四川/成都的OR路由分支"

    for dimension in ("single", "related", "area"):
        function_name = CONCENTRATION_FUNCTIONS[dimension][0]
        function = functions.get(function_name, {})
        function_text = _record_semantic_text(function)
        realtime_code, offline_code = CONCENTRATION_DIMENSION_INTERFACES[dimension]
        has_dual_sources = (
            "实时" in function_text
            and "离线" in function_text
            and realtime_code in interfaces
            and offline_code in interfaces
            and _fixture_capable_interface(interfaces[realtime_code])
            and _fixture_capable_interface(interfaces[offline_code])
        )

        decimal_tag = f"{dimension}_decimal_precision"
        if function and _function_has_decimal_inputs(function, fields):
            applicable.add(decimal_tag)
            reasons[decimal_tag] = f"{function_name}包含小数型输入"

        if has_dual_sources:
            for source_kind in ("realtime_only", "offline_only"):
                tag = f"{dimension}_{source_kind}"
                applicable.add(tag)
                reasons[tag] = f"{function_name}同时依赖实时和离线MySQL来源"

    area_function = functions.get(CONCENTRATION_FUNCTIONS["area"][0], {})
    if area_function and _function_accepts_multi_row_input(area_function, fields):
        applicable.add("area_multi_row_aggregation")
        reasons["area_multi_row_aggregation"] = "区域函数模板明确声明接收多行或集合入参"

    return {
        "applicableTags": applicable,
        "notApplicableTags": CONCENTRATION_SEMANTIC_TAGS - applicable,
        "reasons": reasons,
    }


def _concentration_rule_for_profile(profile, route):
    rules = []
    if profile["single"] in {"hit", "boundary"}:
        rules.append("R001")
    if profile["related"] in {"hit", "boundary"}:
        rules.append("R002")
    if profile["area"] in {"hit", "boundary"}:
        rules.append("R004" if route == "district" else "R003")
    return rules


def _concentration_amount(state):
    return {"hit": 40_000_000, "miss": 0, "boundary": 1_000_000}[state]


def _concentration_node_rows(node_key, state, fixture_overrides=None):
    """Return normalized logical rows for evidence and Fixture generation."""
    sources = set(CONCENTRATION_NODE_SOURCES[node_key].values())
    base = {
        source: CONCENTRATION_STATE_VALUES[state][source]
        for source in sources
    }
    override = (fixture_overrides or {}).get(node_key, {}) or {}
    if override.get("absent"):
        return []
    raw_rows = override.get("rows")
    if raw_rows is None:
        raw_rows = [{
            key: value for key, value in override.items()
            if key not in {"absent", "rows"}
        }]
    return [{**base, **row} for row in raw_rows]


def _normalized_number(value):
    decimal_value = value if isinstance(value, Decimal) else Decimal(str(value))
    if decimal_value == decimal_value.to_integral_value():
        return int(decimal_value)
    return float(decimal_value)


def _sum_node_sources(rows, sources):
    return _normalized_number(sum(
        (Decimal(str(row.get(source, 0) or 0)) for row in rows for source in sources),
        Decimal("0"),
    ))


def _concentration_node_requirement(node_key, state, fixture_overrides=None):
    node_name, fields = CONCENTRATION_NODES[node_key]
    rows = _concentration_node_rows(node_key, state, fixture_overrides)
    if not rows:
        return {
            "nodeName": node_name,
            "fields": ["S_S_THIRDRESCODE"],
            "fieldValues": {"S_S_THIRDRESCODE": "10000"},
            "absentFields": list(fields),
            "fixtureRowCount": 0,
        }

    row_field_values = [{
        field: row[source]
        for field, source in CONCENTRATION_NODE_SOURCES[node_key].items()
    } for row in rows]
    if len(row_field_values) == 1:
        return {
            "nodeName": node_name,
            "fields": list(row_field_values[0]),
            "fieldValues": row_field_values[0],
            "fixtureRowCount": 1,
        }
    return {
        "nodeName": node_name,
        "fields": [],
        "fixtureRowCount": len(row_field_values),
        "rowFieldValues": row_field_values,
        "evidenceMode": "function_aggregate",
    }


def _concentration_metrics(profile, route, fixture_overrides=None):
    rows = {
        key: _concentration_node_rows(
            key,
            profile[
                "single" if key.startswith("single_")
                else "related" if key.startswith("related_")
                else "area"
            ],
            fixture_overrides,
        )
        for key in (
            "single_realtime", "single_batch",
            "related_realtime", "related_batch",
            ("district_realtime" if route == "district" else "city_realtime"),
            ("district_batch" if route == "district" else "city_batch"),
        )
    }
    area_realtime = "district_realtime" if route == "district" else "city_realtime"
    area_batch = "district_batch" if route == "district" else "city_batch"
    totals = {
        "single": _sum_node_sources(
            rows["single_realtime"] + rows["single_batch"],
            ("duty_bal", "reserve_amount"),
        ),
        "related": _sum_node_sources(
            rows["related_realtime"] + rows["related_batch"],
            ("duty_bal", "reserve_amount"),
        ),
        "area": _sum_node_sources(
            rows[area_realtime] + rows[area_batch],
            ("in_guar_bal", "reserve_amount"),
        ),
    }
    limits = {
        "single": rows["single_batch"][0].get("quota") if rows["single_batch"] else None,
        "related": rows["related_batch"][0].get("quota") if rows["related_batch"] else None,
        "area": rows[area_batch][0].get("area_quota") if rows[area_batch] else None,
    }
    hit_rules = []
    for dimension, rule_code in (
        ("single", "R001"),
        ("related", "R002"),
        ("area", "R004" if route == "district" else "R003"),
    ):
        limit = limits[dimension]
        if limit is not None and Decimal(str(totals[dimension])) >= Decimal(str(limit)):
            hit_rules.append(rule_code)
    return rows, totals, limits, hit_rules


def _concentration_evidence(profile, route, fixture_overrides=None):
    _, totals, _, hit_rules = _concentration_metrics(
        profile, route, fixture_overrides)
    overall = (
        "全部通过" if not hit_rules
        else "全部超限" if len(hit_rules) == 3
        else "部分超限"
    )
    functions = []
    for dimension in ("single", "related", "area"):
        node_name, field = CONCENTRATION_FUNCTIONS[dimension]
        requirement = {
            "nodeName": node_name,
            "field": field,
            "value": totals[dimension],
        }
        if isinstance(totals[dimension], float):
            requirement["tolerance"] = 0.01
        functions.append(requirement)
    route_name, route_field = CONCENTRATION_FUNCTIONS["route"]
    functions.append({
        "nodeName": route_name,
        "field": route_field,
        "value": "区县" if route == "district" else "地级市",
    })
    summary_name, summary_field = CONCENTRATION_FUNCTIONS["summary"]
    functions.append({
        "nodeName": summary_name,
        "field": summary_field,
        "value": overall,
    })

    node_keys = ["single_realtime", "single_batch", "related_realtime", "related_batch"]
    node_keys.extend(
        ["district_realtime", "district_batch"]
        if route == "district"
        else ["city_realtime", "city_batch"]
    )
    third_party = []
    for key in node_keys:
        if key.startswith("single_"):
            state = profile["single"]
        elif key.startswith("related_"):
            state = profile["related"]
        else:
            state = profile["area"]
        third_party.append(_concentration_node_requirement(
            key, state, fixture_overrides))
    return {
        "rules": hit_rules,
        "forbiddenRules": sorted(set(CONCENTRATION_RULE_DIMENSIONS) - set(hit_rules)),
        "functions": functions,
        "thirdPartyNodes": third_party,
    }, overall


def generate_concentration_executable_cases(data):
    """Generate unique, fixture-driven cases for concentration strategies.

    Database results overwrite calculated C_F inputs, so every emitted case is
    described as a real database state instead of a synthetic request payload.
    Function behavior is asserted from the same execution evidence.
    """
    rules_by_code = {rule.get("code"): rule for rule in data.get("rules", [])}
    semantic_applicability = _concentration_semantic_applicability(data)
    applicable_semantics = semantic_applicability["applicableTags"]
    cases = []

    def add_case(code, state, route="city", route_label=None):
        rule = rules_by_code.get(code, {})
        profile = {"single": "miss", "related": "miss", "area": "miss"}
        profile[CONCENTRATION_RULE_DIMENSIONS[code]] = state
        evidence, overall = _concentration_evidence(profile, route)
        is_hit = state in {"hit", "boundary"}
        state_label = {"hit": "命中", "miss": "未命中", "boundary": "等值边界"}[state]
        route_text = f"，路由={route_label}" if route_label else ""
        name = rule.get("name") or CONCENTRATION_RULE_NAMES[code]
        cases.append({
            "id": f"CONC_{code}_{state}_{len(cases) + 1}",
            "desc": f"{code} {state_label}{route_text}",
            "group": "规则",
            "caseType": "正案例" if is_hit else "反案例",
            "scenario": f"以隔离 MySQL 数据构造{name}{state_label}{route_text}",
            "expected": (
                f"命中：{code}({name})[{rule.get('hitResult', '集中度超限')}]"
                if is_hit else f"未命中：{code}({name})"
            ),
            "params": {},
            "targetRuleSet": rule.get("ruleSetCode", ""),
            "targetRule": code,
            "fixtureProfile": profile,
            "regionRoute": route,
            "regionVariant": route_label or ("广东广州" if route == "city" else "四川成都"),
            "boundaryKind": "threshold_equal" if state == "boundary" else "",
            "expectedEvidence": evidence,
            "expectedOverallResult": overall,
            "executable": True,
        })

    for code in ("R001", "R002", "R003"):
        for state in ("hit", "miss", "boundary"):
            add_case(code, state, route="city")
    add_case("R004", "hit", route="district", route_label="重庆")
    add_case("R004", "hit", route="district", route_label="四川成都")
    add_case("R004", "miss", route="district", route_label="四川成都")
    add_case("R004", "boundary", route="district", route_label="四川成都")

    from itertools import product as iter_product
    for combo in iter_product(("hit", "miss"), repeat=3):
        if sum(state == "hit" for state in combo) < 2:
            continue
        profile = dict(zip(("single", "related", "area"), combo))
        evidence, overall = _concentration_evidence(profile, "city")
        hit_rules = evidence["rules"]
        cases.append({
            "id": f"CONC_MATRIX_{len(cases) + 1}",
            "desc": "三维联动：" + "/".join(combo),
            "group": "决策流分支覆盖",
            "caseType": "正案例",
            "scenario": "单户/关联户/区域联动状态=" + "/".join(combo),
            "expected": "命中：" + "、".join(hit_rules) + f"；综合结果={overall}",
            "params": {},
            "targetRuleSet": "singleConcPre,relatedConcPre,areaConcPre",
            "targetRule": "",
            "fixtureProfile": profile,
            "regionRoute": "city",
            "isCrossMatrix": True,
            "expectedEvidence": evidence,
            "expectedOverallResult": overall,
            "executable": True,
        })

    def add_semantic_case(desc, scenario, coverage_tags, profile=None,
                          route="city", route_label=None,
                          fixture_overrides=None, target_rule=""):
        profile = profile or {"single": "miss", "related": "miss", "area": "miss"}
        fixture_overrides = fixture_overrides or {}
        evidence, overall = _concentration_evidence(
            profile, route, fixture_overrides)
        hit_rules = evidence["rules"]
        expected = (
            "命中：" + "、".join(hit_rules) + f"；综合结果={overall}"
            if hit_rules else f"不得命中规则；综合结果={overall}"
        )
        cases.append({
            "id": f"CONC_SEMANTIC_{len(cases) + 1}",
            "desc": desc,
            "group": "决策流分支覆盖",
            "caseType": "正案例",
            "scenario": scenario,
            "expected": expected,
            "params": {},
            "targetRuleSet": (
                rules_by_code.get(target_rule, {}).get("ruleSetCode", "")
                if target_rule else "singleConcPre,relatedConcPre,areaConcPre"
            ),
            "targetRule": target_rule,
            "fixtureProfile": profile,
            "fixtureOverrides": fixture_overrides,
            "regionRoute": route,
            "regionVariant": route_label or ("广东广州" if route == "city" else "四川成都"),
            "semanticScenario": coverage_tags[0],
            "coverageTags": coverage_tags,
            "expectedEvidence": evidence,
            "expectedOverallResult": overall,
            "executable": True,
        })

    if "region_full_name_normalization" in applicable_semantics:
        add_semantic_case(
            "区域名称全称兼容：四川省/成都市",
            "使用四川省、成都市全称验证区县级路由与简称规则兼容",
            ["region_full_name_normalization"],
            profile={"single": "miss", "related": "miss", "area": "hit"},
            route="district",
            route_label="四川省成都市",
            target_rule="R004",
        )
    if "sichuan_non_chengdu_route" in applicable_semantics:
        add_semantic_case(
            "四川非成都路由：四川乐山",
            "省=四川且市!=成都时验证R003的OR分支并路由到地级市",
            ["sichuan_non_chengdu_route"],
            profile={"single": "miss", "related": "miss", "area": "hit"},
            route="city",
            route_label="四川乐山",
            target_rule="R003",
        )

    dimension_specs = {
        "single": {
            "label": "单户",
            "realtime": "single_realtime",
            "batch": "single_batch",
            "amountFields": ("duty_bal", "reserve_amount"),
            "limitField": "quota",
            "rule": "R001",
        },
        "related": {
            "label": "关联户",
            "realtime": "related_realtime",
            "batch": "related_batch",
            "amountFields": ("duty_bal", "reserve_amount"),
            "limitField": "quota",
            "rule": "R002",
        },
        "area": {
            "label": "区域",
            "realtime": "city_realtime",
            "batch": "city_batch",
            "amountFields": ("in_guar_bal", "reserve_amount"),
            "limitField": "area_quota",
            "rule": "R003",
        },
    }
    for dimension, spec in dimension_specs.items():
        amount_a, amount_b = spec["amountFields"]
        decimal_overrides = {
            spec["realtime"]: {
                amount_a: 123_456.78,
                amount_b: 45_678.90,
            },
            spec["batch"]: {
                amount_a: 234_567.89,
                amount_b: 34_567.89,
                spec["limitField"]: 400_000,
            },
        }
        decimal_tag = f"{dimension}_decimal_precision"
        if decimal_tag in applicable_semantics:
            add_semantic_case(
                f"{spec['label']}合并金额小数精度",
                "验证123456.78+45678.90+234567.89+34567.89=438271.46，允许0.01数值容差",
                [decimal_tag, "decimal_precision"],
                fixture_overrides=decimal_overrides,
                target_rule=spec["rule"],
            )

        realtime_only = {
            spec["realtime"]: {amount_a: 600_000, amount_b: 400_000},
            spec["batch"]: {"absent": True},
        }
        realtime_tag = f"{dimension}_realtime_only"
        if realtime_tag in applicable_semantics:
            add_semantic_case(
                f"{spec['label']}仅实时数据",
                f"{spec['label']}离线查询为空，仅实时金额参与合并，预期函数输出1000000",
                [realtime_tag, "realtime_only"],
                fixture_overrides=realtime_only,
                target_rule=spec["rule"],
            )

        offline_only = {
            spec["realtime"]: {"absent": True},
            spec["batch"]: {
                amount_a: 600_000,
                amount_b: 400_000,
                spec["limitField"]: 1_000_000,
            },
        }
        offline_tag = f"{dimension}_offline_only"
        if offline_tag in applicable_semantics:
            add_semantic_case(
                f"{spec['label']}仅离线数据",
                f"{spec['label']}实时查询为空，仅离线金额参与合并，预期函数输出1000000",
                [offline_tag, "offline_only"],
                fixture_overrides=offline_only,
                target_rule=spec["rule"],
            )

    if "area_multi_row_aggregation" in applicable_semantics:
        add_semantic_case(
            "区域查询多行聚合",
            "市级实时/离线查询各返回2行，验证函数按4行合计为1000000且不按首行误判",
            ["area_multi_row_aggregation", "multi_row_aggregation"],
            fixture_overrides={
                "city_realtime": {"rows": [
                    {"in_guar_bal": 200_000, "reserve_amount": 100_000},
                    {"in_guar_bal": 300_000, "reserve_amount": 100_000},
                ]},
                "city_batch": {"rows": [
                    {"in_guar_bal": 100_000, "reserve_amount": 50_000, "area_quota": 1_000_000},
                    {"in_guar_bal": 100_000, "reserve_amount": 50_000, "area_quota": 1_000_000},
                ]},
            },
            target_rule="R003",
        )
    return cases


def _decorate_concentration_third_party_case(case):
    interface_code = case.get("fixtureInterfaceCode", "")
    district = interface_code.startswith("qjqy")
    node_keys = ["single_realtime", "single_batch", "related_realtime", "related_batch"]
    node_keys.extend(
        ["district_realtime", "district_batch"]
        if district else ["city_realtime", "city_batch"]
    )
    interface_nodes = {
        "dhjzdsearch": "single_realtime",
        "dhjzdoffsearch": "single_batch",
        "glhjzdsearch": "related_realtime",
        "glhjzdoffsearch": "related_batch",
        "sjqyjzdsearch": "city_realtime",
        "sjqyjzdoffsearch": "city_batch",
        "qjqyjzdsearch": "district_realtime",
        "qjqyjzdoffsearch": "district_batch",
    }
    numeric_values = {
        "in_guar_bal": -1,
        "duty_bal": -1,
        "quota": 0,
        "reserve_amount": None,
        "area_used_quota": -1,
        "area_quota": 0,
    }
    requirements = []
    for key in node_keys:
        field_values = {"S_S_THIRDRESCODE": "10000"}
        absent_fields = list(CONCENTRATION_NODES[key][1])
        if (
            case.get("fixtureScenario") == "numeric_boundary"
            and key == interface_nodes.get(interface_code)
        ):
            field_values.update({
                field: numeric_values[source]
                for field, source in CONCENTRATION_NODE_SOURCES[key].items()
                if numeric_values[source] is not None
            })
            absent_fields = [
                field for field, source in CONCENTRATION_NODE_SOURCES[key].items()
                if numeric_values[source] is None
            ]
        requirements.append({
            "nodeName": CONCENTRATION_NODES[key][0],
            "fields": list(field_values),
            "fieldValues": field_values,
            "absentFields": absent_fields,
        })

    functions = [{
        "nodeName": CONCENTRATION_FUNCTIONS["route"][0],
        "field": CONCENTRATION_FUNCTIONS["route"][1],
        "value": "区县" if district else "地级市",
    }, {
        "nodeName": CONCENTRATION_FUNCTIONS["summary"][0],
        "field": CONCENTRATION_FUNCTIONS["summary"][1],
        "value": "全部通过",
    }]
    if case.get("fixtureScenario") == "numeric_boundary":
        dimension = (
            "single" if interface_code.startswith("dhjzd")
            else "related" if interface_code.startswith("glhjzd")
            else "area"
        )
        node_name, field = CONCENTRATION_FUNCTIONS[dimension]
        functions.insert(0, {"nodeName": node_name, "field": field, "value": -1})

    case["expectedEvidence"] = {
        "rules": [],
        "forbiddenRules": sorted(CONCENTRATION_RULE_DIMENSIONS),
        "functions": functions,
        "thirdPartyNodes": requirements,
    }


def generate_third_party_fixture_cases(data, fields_dict, execution_profile="no-mock"):
    """生成当前环境可执行的三方数据用例。

    仅生成可由唯一查询键或隔离 MySQL Fixture 实现的空返回、数值边界。
    超时、错误码和类型错误等依赖 Mock 环境的异常场景不再生成。
    """
    if execution_profile != "no-mock":
        raise ValueError(
            "仅支持 no-mock；超时、错误码和字段类型错误等 Mock 异常用例已停用"
        )

    tp_interfaces = data.get("thirdPartyInterfaces", [])
    if not isinstance(tp_interfaces, list) or not tp_interfaces:
        return []

    cases = []
    counter = [1]  # mutable counter for closure

    def next_id():
        n = counter[0]
        counter[0] += 1
        return f"TP_FIX_{n:03d}"

    common_params = {
        "S_S_BIZID": "{tc_id}_BIZ",
        "S_S_CUSTNO": "{tc_id}_CUST",
        "S_S_ORGCODE": "sxdb",
        "S_E_APIMODEL": "30",
        "S_E_CUSTTYPE": "1",
        "S_S_IDNO": "500102199001011234",
        "S_F_LOANBALANCE": 100000,
        "C_F_RANDOMNUM": 0.5,
    }

    for iface in tp_interfaces:
        iface_name = iface.get("name", "未知接口")
        iface_code = iface.get("code", "")
        iface_desc = f"{iface_code}({iface_name})" if iface_code else iface_name

        query_inputs = _interface_query_inputs(iface)
        if _fixture_capable_interface(iface):
            # 空返回时本就没有输出字段；这里只要求目标三方节点真实执行。
            evidence_node = iface_name
            cases.extend([
                {
                    "id": next_id(),
                    "desc": f"三方空结果分支验证: {iface_desc}",
                    "group": "决策流分支覆盖",
                    "caseType": "反案例",
                    "scenario": f"使用唯一查询键且目标表不插入记录，使{iface_desc}返回空结果，验证策略安全降级",
                    "expected": "全部通过",
                    "params": dict(common_params),
                    "targetRuleSet": "",
                    "targetRule": "",
                    "executionMode": "fixture",
                    "fixtureScenario": "empty_result",
                    "fixtureInterfaceCode": iface_code,
                    "fixtureRequirements": {
                        "protocol": iface.get("protocol", ""),
                        "interfaceCode": iface_code,
                        "queryInputs": query_inputs,
                        "setup": "使用唯一查询键，目标表不插入记录",
                    },
                    "expectedEvidence": {
                        "rules": [],
                        "forbiddenRules": sorted(CONCENTRATION_RULE_DIMENSIONS),
                        "functions": [{
                            "nodeName": CONCENTRATION_FUNCTIONS["summary"][0],
                            "field": CONCENTRATION_FUNCTIONS["summary"][1],
                            "value": "全部通过",
                        }],
                        "thirdPartyNodes": [{
                            "nodeName": evidence_node,
                            "fields": ["S_S_THIRDRESCODE"],
                        }],
                    },
                    "executable": True,
                },
                {
                    "id": next_id(),
                    "desc": f"三方数值边界验证: {iface_desc}",
                    "group": "决策流分支覆盖",
                    "caseType": "反案例",
                    "scenario": f"通过隔离 MySQL Fixture 为{iface_desc}写入负数/NULL数值，验证策略不误判且流程完成",
                    "expected": "全部通过",
                    "params": dict(common_params),
                    "targetRuleSet": "",
                    "targetRule": "",
                    "executionMode": "fixture",
                    "fixtureScenario": "numeric_boundary",
                    "fixtureInterfaceCode": iface_code,
                    "fixtureRequirements": {
                        "protocol": iface.get("protocol", ""),
                        "interfaceCode": iface_code,
                        "queryInputs": query_inputs,
                        "numericValues": {"negative": -1, "null": None},
                        "setup": "按唯一查询键插入隔离数据，完成后按同键清理",
                    },
                    "expectedEvidence": {
                        "rules": [],
                        "forbiddenRules": sorted(CONCENTRATION_RULE_DIMENSIONS),
                        "functions": [{
                            "nodeName": CONCENTRATION_FUNCTIONS["summary"][0],
                            "field": CONCENTRATION_FUNCTIONS["summary"][1],
                            "value": "全部通过",
                        }],
                        "thirdPartyNodes": [{
                            "nodeName": evidence_node,
                            "fields": ["S_S_THIRDRESCODE"],
                        }],
                    },
                    "executable": True,
                },
            ])

    if cases:
        print(f"[三方数据/fixture] 为 {len(tp_interfaces)} 个接口生成 {len(cases)} 条用例",
              file=sys.stderr)
    return cases


def _has_executable_contract(case):
    params = case.get("params", {})
    required = {"S_S_BIZID", "S_S_CUSTNO", "S_S_ORGCODE", "S_S_IDNO", "C_F_RANDOMNUM"}
    if case.get("executable") is False or not required.issubset(params):
        return False
    if not isinstance(case.get("expectedEvidence"), dict):
        return False
    if case.get("executionMode") == "fixture":
        return bool(case.get("fixtureScenario") and case.get("fixtureInterfaceCode"))
    profile = case.get("fixtureProfile")
    return isinstance(profile, dict) and set(profile.values()).issubset({"hit", "miss", "boundary"})


def _system_field_code(field):
    code = str(field.get("code") or "")
    if not code:
        return ""
    if code.startswith(("C_", "S_")):
        return code.upper()
    field_type = str(field.get("type") or "")
    prefix = "C_F_" if any(
        token in field_type for token in ("小数", "整数", "数值", "金额")
    ) else "C_S_"
    return prefix + code.upper()


def compute_coverage_pre_report(all_cases, rules, rule_sets, functions, fields_dict, data):
    """计算预期覆盖率报告（v2.4.2 Phase 3-1）。

    返回结构化 dict，包含 7 个维度的覆盖率分析，供 policy-test 实际执行后做 diff。
    """
    executable_cases = [case for case in all_cases if _has_executable_contract(case)]
    report = {
        "dimensions": {},
        "executableCases": len(executable_cases),
        "excludedFromCoverage": len(all_cases) - len(executable_cases),
    }

    # --- 1. 规则覆盖率 ---
    rule_cases = [c for c in executable_cases if c.get("group") == "规则"]
    rule_detail = {}
    for r in rules:
        if r.get("ruleSetCode") == "alertLevelJudgment":
            continue
        code, name = r["code"], r["name"]
        rc = [c for c in rule_cases if c.get("targetRule") == code]
        dimension = CONCENTRATION_RULE_DIMENSIONS.get(code)
        if dimension:
            has_hit = any(c.get("fixtureProfile", {}).get(dimension) == "hit" for c in rc)
            has_miss = any(c.get("fixtureProfile", {}).get(dimension) == "miss" for c in rc)
            has_boundary = any(c.get("fixtureProfile", {}).get(dimension) == "boundary" for c in rc)
        else:
            has_hit = any(c.get("caseType") == "正案例" for c in rc)
            has_miss = any(c.get("caseType") == "反案例" for c in rc)
            has_boundary = any("边界" in c.get("desc", "") for c in rc)
        covered = sum([has_hit, has_miss, has_boundary])
        rule_detail[code] = {
            "name": name, "ruleSet": r.get("ruleSetCode", ""),
            "hasHit": has_hit, "hasMiss": has_miss, "hasBoundary": has_boundary,
            "cases": len(rc), "score": f"{covered}/3",
        }
    total_rules = len(rule_detail)
    fully_covered = sum(
        1 for v in rule_detail.values()
        if v["hasHit"] and v["hasMiss"] and v["hasBoundary"]
    )
    report["dimensions"]["rules"] = {
        "total": total_rules, "fullyCovered": fully_covered,
        "percent": round(fully_covered / max(total_rules, 1) * 100, 1),
        "detail": rule_detail,
    }

    # --- 2. 规则集覆盖率 ---
    non_alert_rs = [rs for rs in rule_sets if rs.get("code") != "alertLevelJudgment"]
    rs_detail = {}
    for rs in non_alert_rs:
        rs_code = rs["code"]
        rs_rules = [r for r in rules if r.get("ruleSetCode") == rs_code]
        rs_cases = [c for c in executable_cases if c.get("targetRuleSet", "").find(rs_code) >= 0]
        rules_tested = len(set(c.get("targetRule") for c in rs_cases if c.get("targetRule")))
        rs_detail[rs_code] = {
            "name": rs.get("name", ""),
            "totalRules": len(rs_rules), "rulesTested": rules_tested,
            "cases": len(rs_cases),
            "percent": round(rules_tested / max(len(rs_rules), 1) * 100, 1),
        }
    report["dimensions"]["ruleSets"] = {
        "total": len(non_alert_rs), "detail": rs_detail,
    }

    # --- 3. 函数覆盖率 ---
    func_detail = {}
    for f in functions:
        fname = f.get("name", "")
        fc = [
            case for case in executable_cases
            if any(
                isinstance(requirement, dict)
                and (requirement.get("nodeName") or requirement.get("name")) == fname
                for requirement in case.get("expectedEvidence", {}).get("functions", [])
            )
        ]
        func_detail[fname] = {
            "type": f.get("type", ""), "cases": len(fc),
            "evidenceAsserted": bool(fc),
        }
    total_funcs = len(func_detail)
    funcs_tested = sum(1 for v in func_detail.values() if v["cases"] > 0)
    report["dimensions"]["functions"] = {
        "total": total_funcs, "tested": funcs_tested,
        "percent": round(funcs_tested / max(total_funcs, 1) * 100, 1),
        "detail": func_detail,
    }

    if _supports_concentration_fixture_model(data):
        applicability = _concentration_semantic_applicability(data)
        applicable_semantics = applicability["applicableTags"]
        covered_semantics = {
            tag
            for case in executable_cases
            for tag in case.get("coverageTags", [])
        }
        missing_semantics = sorted(applicable_semantics - covered_semantics)
        covered_applicable = applicable_semantics & covered_semantics
        report["dimensions"]["semanticScenarios"] = {
            "catalogTotal": len(CONCENTRATION_SEMANTIC_TAGS),
            "applicable": len(applicable_semantics),
            "covered": len(covered_applicable),
            "percent": (
                100.0 if not applicable_semantics
                else round(
                    len(covered_applicable) / len(applicable_semantics) * 100,
                    1,
                )
            ),
            "applicableTags": sorted(applicable_semantics),
            "notApplicableTags": sorted(applicability["notApplicableTags"]),
            "coveredTags": sorted(covered_applicable),
            "missingTags": missing_semantics,
            "applicabilityReasons": applicability["reasons"],
        }

    # --- 4. 字段覆盖率 ---
    all_field_codes = set()
    for v in fields_dict.values():
        code = _system_field_code(v)
        if code:
            all_field_codes.add(code)
    used_fields = set()
    for c in executable_cases:
        used_fields.update(str(code).upper() for code in c.get("params", {}))
        evidence = c.get("expectedEvidence", {})
        for requirement in evidence.get("functions", []):
            if isinstance(requirement, dict) and requirement.get("field"):
                used_fields.add(str(requirement["field"]).upper())
        for requirement in evidence.get("thirdPartyNodes", []):
            if isinstance(requirement, dict):
                used_fields.update(str(code).upper() for code in requirement.get("fields", []))
    # 排除非策略字段（通用参数）
    common_fields = {"S_S_BIZID", "S_S_CUSTNO", "S_S_ORGCODE", "S_E_APIMODEL",
                     "S_S_IDNO", "C_F_RANDOMNUM", "C_S_BIZSCENARIO", "S_S_ENTERPRISETYPE"}
    strategy_used = used_fields - common_fields
    strategy_all = all_field_codes - common_fields
    report["dimensions"]["fields"] = {
        "totalInStrategy": len(strategy_all),
        "usedInTestCases": len(strategy_used & strategy_all),
        "percent": round(len(strategy_used & strategy_all) / max(len(strategy_all), 1) * 100, 1),
        "unused": sorted(strategy_all - strategy_used),
    }

    # --- 5. 三方接口覆盖率 ---
    tp_interfaces = set()
    for c in all_cases:
        mock = c.get("thirdPartyMock", {})
        if isinstance(mock, dict):
            for iface in mock.get("interfaces", []):
                tp_interfaces.add(iface)
        evidence = c.get("expectedEvidence", {})
        for node in evidence.get("thirdPartyNodes", []):
            if isinstance(node, str):
                tp_interfaces.add(node)
            elif isinstance(node, dict) and node.get("nodeName"):
                tp_interfaces.add(node["nodeName"])
    strategy_tp = data.get("thirdPartyInterfaces", [])
    strategy_tp_names = set(t.get("name", "") for t in strategy_tp) if isinstance(strategy_tp, list) else set()
    report["dimensions"]["thirdParty"] = {
        "referenced": sorted(tp_interfaces),
        "totalInStrategy": len(strategy_tp_names),
        "referencedCount": len(tp_interfaces),
    }

    # --- 6. 交叉矩阵覆盖率 ---
    cross_cases = [c for c in executable_cases if c.get("isCrossMatrix")]
    n_rs = len(non_alert_rs)
    total_combos = (2 ** n_rs) - n_rs - 1  # 减去0-hit和1-hit
    report["dimensions"]["crossMatrix"] = {
        "ruleSets": n_rs,
        "possibleCombinations": max(total_combos, 0),
        "testedCombinations": len(cross_cases),
        "percent": round(len(cross_cases) / max(total_combos, 1) * 100, 1),
    }

    # --- 7. 决策流分支覆盖率 ---
    flow_cases = [c for c in executable_cases if c.get("group") == "决策流分支覆盖"]
    combined_cases = [c for c in executable_cases if c.get("group") == "跨子策略综合"]
    report["dimensions"]["branches"] = {
        "flowCases": len(flow_cases),
        "combinedCases": len(combined_cases),
        "total": len(flow_cases) + len(combined_cases),
    }

    return report


def _apply_concentration_fixture_contract(tc, strategy_code, fixture_run_id=None):
    """Bind deterministic concentration cases to their real MySQL query keys."""
    if tc.get("executionMode") == "fixture":
        return

    expected = str(tc.get("expected", ""))
    scenario = str(tc.get("scenario", ""))
    target_rule = str(tc.get("targetRule", ""))
    profile = tc.get("fixtureProfile")

    if profile is None and target_rule in {"R001", "R002", "R003", "R004"}:
        target_state = "miss" if any(
            marker in expected for marker in ("未命中", "不命中", "不触发")
        ) else ("boundary" if tc.get("boundaryKind") else "hit")
        profile = {"single": "miss", "related": "miss", "area": "miss"}
        dimension = {
            "R001": "single",
            "R002": "related",
            "R003": "area",
            "R004": "area",
        }[target_rule]
        profile[dimension] = target_state
    elif profile is None and (tc.get("isSafeBaseline") or "所有子维度均通过" in scenario or "=全部通过" in expected):
        profile = {"single": "miss", "related": "miss", "area": "miss"}
    elif profile is None and ("所有子维度均超限" in scenario or "=全部超限" in expected):
        profile = {"single": "hit", "related": "hit", "area": "hit"}
    elif profile is None and ("部分子维度超限" in scenario or "仅 1 个子维度超限" in scenario):
        profile = {"single": "hit", "related": "miss", "area": "miss"}

    if profile is None:
        return

    params = tc.setdefault("params", {})
    suffix = str(tc.get("id", "CASE")).replace("TC_", "")
    run_marker = f"_{fixture_run_id}" if fixture_run_id else ""
    key_prefix = f"{strategy_code}_{tc.get('id', suffix)}"
    params.setdefault("S_S_BIZID", f"{key_prefix}_BIZ")
    params.setdefault("S_S_CUSTNO", f"{key_prefix}_CUST")
    params.setdefault("S_S_ORGCODE", "sxdb")
    params.setdefault("S_E_APIMODEL", "30")
    params.setdefault("S_E_CUSTTYPE", "1")
    params.setdefault("S_F_LOANBALANCE", 100000)
    params["S_S_CUSTNAME"] = f"{key_prefix}{run_marker}"

    district_route = (
        tc.get("regionRoute") == "district"
        or target_rule == "R004"
        or "R004(" in expected
    )
    if district_route:
        if tc.get("regionVariant") == "重庆":
            params.update({
                "C_S_AREAPROVINCE": "重庆",
                "C_S_AREACITY": "重庆",
                "C_S_AREADISTRICT": "渝中",
                "C_S_AREAPROVINCECODE": "500000",
                "C_S_AREACITYCODE": "500100",
                "C_S_AREADISTRICTCODE": f"508{suffix}{run_marker}",
            })
        elif tc.get("regionVariant") == "四川省成都市":
            params.update({
                "C_S_AREAPROVINCE": "四川省",
                "C_S_AREACITY": "成都市",
                "C_S_AREADISTRICT": "锦江区",
                "C_S_AREAPROVINCECODE": "510000",
                "C_S_AREACITYCODE": "510100",
                "C_S_AREADISTRICTCODE": f"518{suffix}{run_marker}",
            })
        else:
            params.update({
                "C_S_AREAPROVINCE": "四川",
                "C_S_AREACITY": "成都",
                "C_S_AREADISTRICT": "锦江",
                "C_S_AREAPROVINCECODE": "510000",
                "C_S_AREACITYCODE": "510100",
                "C_S_AREADISTRICTCODE": f"518{suffix}{run_marker}",
            })
        area_key = "district"
    else:
        if tc.get("regionVariant") == "四川乐山":
            params.update({
                "C_S_AREAPROVINCE": "四川",
                "C_S_AREACITY": "乐山",
                "C_S_AREADISTRICT": "市中",
                "C_S_AREAPROVINCECODE": "510000",
                "C_S_AREACITYCODE": f"5111{suffix}{run_marker}",
                "C_S_AREADISTRICTCODE": f"5110{suffix}{run_marker}",
            })
        else:
            params.update({
                "C_S_AREAPROVINCE": "广东",
                "C_S_AREACITY": "广州",
                "C_S_AREADISTRICT": "海珠",
                "C_S_AREAPROVINCECODE": "440000",
                "C_S_AREACITYCODE": f"449{suffix}{run_marker}",
                "C_S_AREADISTRICTCODE": f"448{suffix}{run_marker}",
            })
        area_key = "city"

    tc["requiresIsolatedThirdPartyData"] = True
    tc["fixtureProfile"] = profile
    tc["fixtureQueryKeys"] = {
        "customerName": params["S_S_CUSTNAME"],
        "areaKey": area_key,
        "cityCode": params["C_S_AREACITYCODE"],
        "districtCode": params["C_S_AREADISTRICTCODE"],
    }


def generate_all(parsed_json_path, output_path, feedback_path=None,
                 execution_profile="no-mock", org_code=None,
                 fixture_run_id=None):
    """生成全部测试用例。feedback_path 可选，用于注入上轮 Agent Loop 反馈。"""
    path = Path(parsed_json_path)
    if not path.exists():
        print(f"错误：输入文件不存在: {parsed_json_path}", file=sys.stderr)
        sys.exit(1)

    try:
        raw_text = path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, PermissionError) as e:
        print(f"错误：无法读取文件: {e}", file=sys.stderr)
        sys.exit(1)

    try:
        data = json.loads(raw_text)
    except json.JSONDecodeError as e:
        print(f"错误：JSON 解析失败: {e}", file=sys.stderr)
        sys.exit(1)

    required_keys = ["rules", "fields", "functions", "strategies", "ruleSets"]
    missing = [k for k in required_keys if k not in data]
    if missing:
        print(f"错误：parsed JSON 缺少必要字段: {', '.join(missing)}", file=sys.stderr)
        sys.exit(1)

    rules = data["rules"]
    functions = data["functions"]
    strategies = data["strategies"]
    rule_sets = data["ruleSets"]

    strategy_code = data.get("strategies", [{}])[0].get("code", "unknown")
    strategy_name = data.get("strategies", [{}])[0].get("name", "未知策略")
    field_system_codes = {}
    raw_fields = data.get("fields", {})
    field_items = raw_fields.values() if isinstance(raw_fields, dict) else raw_fields
    for field in field_items:
        if not isinstance(field, dict):
            continue
        code = field.get("code")
        if not code or str(code).startswith(("C_", "S_")):
            continue
        field_type = str(field.get("type") or "")
        prefix = "C_F_" if any(
            token in field_type for token in ("小数", "整数", "数值", "金额")
        ) else "C_S_"
        field_system_codes[str(code)] = f"{prefix}{str(code).upper()}"

    # v2.4.2: 自动推导缺失的 ruleSetCode（修 parsed_strategy.json 数据层面问题）
    _infer_ruleset_codes(rules, rule_sets)

    alert_rules = [r for r in rules if r["ruleSetCode"] == "alertLevelJudgment"]
    concentration_model = _supports_concentration_fixture_model(data)
    concentration_cases = (
        generate_concentration_executable_cases(data)
        if concentration_model else []
    )
    rule_cases = (
        [case for case in concentration_cases if case["group"] == "规则"]
        if concentration_model
        else generate_rule_test_cases(rules, data["fields"], functions)
    )

    # v2.3.1 BUG-3 fix: 规则级用例注入路由参数（C_S_BIZSCENARIO / S_S_ENTERPRISETYPE）
    # 天策策略的子策略分支依赖这两个参数路由到正确的规则集，缺失则用例无法命中目标规则
    # v2.4.2: 仅对 tripartite 架构注入；扁平架构的规则集没有 bizScenarios×enterpriseType 路由维度
    arch = detect_strategy_architecture(rule_sets)
    if arch == "tripartite":
        rs_routing = {}
        for rs in rule_sets:
            rsc = rs["code"]
            biz_list = rs.get("bizScenarios", "")
            ent_list = rs.get("enterpriseType", "")
            biz_val = biz_list.split(",")[0].strip() if biz_list and biz_list != "全部" else ""
            if ent_list:
                ent_parts = [e.strip() for e in ent_list.split(",")]
                ent_val = ent_parts[0]
                for preferred in ("国企", "民营"):
                    if preferred in ent_parts:
                        ent_val = preferred
                        break
            else:
                ent_val = ""
            if ent_val in ("通用", "主策略"):
                ent_val = "国企"
            rs_routing[rsc] = (biz_val, ent_val)

        injected_count = 0
        for tc in rule_cases:
            rs_code = tc.get("targetRuleSet", "")
            if rs_code in rs_routing:
                biz_val, ent_val = rs_routing[rs_code]
                params = tc.get("params", {})
                if biz_val and "C_S_BIZSCENARIO" not in params:
                    params["C_S_BIZSCENARIO"] = f"{biz_val}类"
                if ent_val and "S_S_ENTERPRISETYPE" not in params:
                    params["S_S_ENTERPRISETYPE"] = ent_val
                tc["params"] = params
                injected_count += 1
        if injected_count:
            print(f"已为 {injected_count} 条规则级用例注入路由参数", file=sys.stderr)
    else:
        print(f"扁平架构({arch})：跳过 C_S_BIZSCENARIO/S_S_ENTERPRISETYPE 路由参数注入", file=sys.stderr)

    # v2.4.2 Phase 4-3: 自动检测策略类型并加载 cases_library 模板
    _st_type = _detect_strategy_type(strategy_code, strategy_name)
    _st_lib = _load_cases_library(_st_type) if _st_type else None
    if _st_lib:
        _rule_pats = len(_st_lib.get("rule_patterns", {}))
        _func_pats = len(_st_lib.get("function_patterns", {}))
        print(f"cases_library 命中: {_st_type} ({_rule_pats} 规则模板, {_func_pats} 函数模板)",
              file=sys.stderr)
    elif _st_type:
        print(f"cases_library: 检测到 {_st_type} 但模板文件未找到", file=sys.stderr)

    func_cases = [] if concentration_model else generate_function_test_cases(functions)

    # v2.4.2: 策略架构检测 — 根据架构类型选择生成逻辑
    arch = detect_strategy_architecture(rule_sets)
    if concentration_model:
        flow_cases = [
            case for case in concentration_cases
            if case["group"] == "决策流分支覆盖"
        ]
        alert_cases = []
        combined_cases = []
        cross_cases = []
        region_cases = []
        print(
            f"集中度可执行模型：生成 {len(concentration_cases)} 条唯一 Fixture 状态用例；"
            "函数覆盖合并到执行证据",
            file=sys.stderr,
        )
    elif arch == "tripartite":
        flow_cases = generate_flow_coverage_cases(strategies, rule_sets)
        alert_cases = generate_alert_level_cases(alert_rules)
        combined_cases = generate_combined_scenarios(rules, rule_sets)
        cross_cases = []
        region_cases = []
    else:
        print(f"检测到扁平架构({arch})，使用简化生成器（跳过保后检查专用模板）", file=sys.stderr)
        flow_cases = generate_simple_flow_cases(rule_sets)
        alert_cases = []
        combined_cases = generate_simple_combined_cases(rules, rule_sets)
        # v2.4.2 Phase 1-4: 规则集联动矩阵
        cross_cases = generate_ruleset_cross_matrix(rule_sets, rules, data["fields"])
        if cross_cases:
            print(f"已生成 {len(cross_cases)} 条规则集联动矩阵用例 (v2.4.2)", file=sys.stderr)
        # v2.4.2 Phase 1-5: 区域特化模板
        region_cases = generate_region_templates(rules, rule_sets, data["fields"])
        if region_cases:
            print(f"已生成 {len(region_cases)} 条区域特化模板用例 (v2.4.2)", file=sys.stderr)

    # v2.6.0: 仅生成当前环境可执行的三方 Fixture 用例
    tp_fixture_cases = generate_third_party_fixture_cases(
        data, data["fields"], execution_profile=execution_profile)

    all_cases = rule_cases + func_cases + flow_cases + alert_cases + combined_cases + cross_cases + region_cases + tp_fixture_cases

    # v2.4.2 Phase 1-6: 动态字段自检 — 确保所有用例包含 API 必传字段
    api_required = ["S_S_IDNO", "C_F_RANDOMNUM"]
    strategy_meta = data.get("strategies", [{}])[0]
    extra_required = strategy_meta.get("apiRequiredFields", [])
    if extra_required:
        api_required = list(set(api_required + extra_required))
    injected_count = 0
    for tc in all_cases:
        params = tc.get("params", {})
        for field in api_required:
            if field not in params:
                if field == "S_S_IDNO":
                    params[field] = "500102199001011234"
                elif field == "C_F_RANDOMNUM":
                    params[field] = "0.5"
                else:
                    params[field] = ""
                injected_count += 1
    if injected_count:
        print(f"已注入 {injected_count} 个 API 必传字段 (v2.4.2)", file=sys.stderr)

    # v2.4.2: 注入上轮 Agent Loop 反馈（fixParams / adjustExpected / removeCases）
    if feedback_path:
        fb_actions = load_feedback(feedback_path)
        if fb_actions:
            fb_applied = apply_feedback(all_cases, fb_actions)
            print(f"已应用 {fb_applied}/{len(fb_actions)} 条反馈动作 (v2.4.2)", file=sys.stderr)

    # v2.3.1: 边界用例归入正/反案例（按预期结果判定：命中→正案例，未命中→反案例）
    boundary_count = 0
    for tc in all_cases:
        if tc.get("caseType") == "边界案例":
            expected = tc.get("expected", "")
            if "未命中" in expected or "不命中" in expected or "不触发" in expected:
                tc["caseType"] = "反案例"
            else:
                tc["caseType"] = "正案例"
            boundary_count += 1
    if boundary_count:
        print(f"已将 {boundary_count} 条边界用例归入正/反案例", file=sys.stderr)

    for i, tc in enumerate(all_cases, start=1):
        if tc.get("group") in {"跨子策略综合", "规则集联动矩阵", "区域特化模板"}:
            tc["group"] = "决策流分支覆盖"
        tc["id"] = f"TC_{i:03d}"
        params = tc.setdefault("params", {})
        for field, value in list(params.items()):
            system_code = field_system_codes.get(field)
            if system_code:
                params.setdefault(system_code, value)
                del params[field]
        params["CASE_ID"] = tc["id"]
        if org_code:
            params["S_S_ORGCODE"] = org_code

        if "CONC" in strategy_code.upper() or "集中度" in strategy_name:
            _apply_concentration_fixture_contract(
                tc,
                strategy_code,
                fixture_run_id=fixture_run_id,
            )

        # v2.5.0: 无 mock 数据韧性用例必须使用唯一业务键/查询键，避免缓存和串数据。
        if tc.get("executionMode") == "fixture":
            suffix = f"{i:03d}"
            run_marker = f"_{fixture_run_id}" if fixture_run_id else ""
            interface_code = str(
                tc.get("fixtureRequirements", {}).get("interfaceCode", "")
            )
            district_route = interface_code.startswith("qjqy")
            params.update({
                "CASE_ID": tc["id"],
                "S_S_BIZID": f"{strategy_code}_NM_BIZ_{suffix}",
                "S_S_CUSTNO": f"{strategy_code}_NM_CUST_{suffix}",
                "S_S_CUSTNAME": f"{strategy_code}_NM_{suffix}{run_marker}",
                "S_S_ORGCODE": org_code or "sxdb",
                "S_E_APIMODEL": "30",
                "S_E_CUSTTYPE": "1",
                "S_S_IDNO": f"50010219900101{suffix[-4:].zfill(4)}",
                "S_F_LOANBALANCE": 100000,
                "C_F_RANDOMNUM": 0.5,
                "C_S_AREAPROVINCECODE": "500000" if district_route else "320000",
                "C_S_AREACITYCODE": "500100" if district_route else f"329{suffix}{run_marker}",
                "C_S_AREADISTRICTCODE": f"328{suffix}{run_marker}",
                "C_S_AREAPROVINCE": "重庆市" if district_route else "江苏省",
                "C_S_AREACITY": "重庆市" if district_route else "无锡市",
                "C_S_AREADISTRICT": "渝中区" if district_route else "江阴市",
            })
            if _supports_concentration_fixture_model(data):
                _decorate_concentration_third_party_case(tc)

    for tc in all_cases:
        if tc.get("targetRule") and not concentration_model:
            for r in rules:
                if r["code"] == tc["targetRule"]:
                    tc["thirdPartyMock"] = generate_third_party_mock(r)
                    break

    by_module = {}
    by_type = {}
    for tc in all_cases:
        by_module[tc["group"]] = by_module.get(tc["group"], 0) + 1
        by_type[tc["caseType"]] = by_type.get(tc["caseType"], 0) + 1

    output = {
        "strategyCode": strategy_code, "strategyName": strategy_name,
        "generatedAt": datetime.now().isoformat(),
        "executionProfile": execution_profile,
        "excludedScenarios": [],
        "summary": {"total": len(all_cases), "byModule": by_module, "byCaseType": by_type},
        "testCases": all_cases,
    }

    # v2.4.2 Phase 3-1: 输出预期覆盖率报告
    cov_report = compute_coverage_pre_report(
        all_cases, rules, rule_sets, functions, data["fields"], data)
    cov_report["strategyCode"] = strategy_code
    cov_report["strategyName"] = strategy_name
    cov_report["generatedAt"] = output["generatedAt"]
    cov_report["totalCases"] = len(all_cases)
    cov_path = str(Path(output_path).parent / "coverage_pre_report.json")
    Path(cov_path).write_text(json.dumps(cov_report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"覆盖率预期报告: {cov_path}", file=sys.stderr)

    # v2.4.2 Phase 4-1: 自动生成覆盖率热力图 Dashboard
    try:
        _dashboard_dir = Path(__file__).resolve().parent
        sys.path.insert(0, str(_dashboard_dir))
        from generate_coverage_dashboard import generate_dashboard as _gen_dash
        _dash_path = str(Path(output_path).parent / "coverage_dashboard.html")
        _gen_dash(cov_report, output_path=_dash_path)
        print(f"覆盖率热力图: {_dash_path}", file=sys.stderr)
    except Exception as _e:
        print(f"热力图生成跳过: {_e}", file=sys.stderr)

    Path(output_path).write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"生成完成！共 {len(all_cases)} 条测试用例 (v{VERSION}, {execution_profile})", file=sys.stderr)
    for mod, cnt in by_module.items():
        print(f"  {mod}: {cnt}", file=sys.stderr)
    print(f"  ---", file=sys.stderr)
    for typ, cnt in by_type.items():
        print(f"  {typ}: {cnt}", file=sys.stderr)
    print(f"输出到: {output_path}", file=sys.stderr)

    # v2.3.1: 同时导出 Excel 报告
    excel_path = str(Path(output_path).with_suffix('.xlsx'))
    export_excel(output, excel_path)

    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description=f"天策策略测试用例生成引擎 v{VERSION}",
        epilog="示例: python3 generate_testcases.py parsed.json output.json --feedback feedback.json",
    )
    parser.add_argument("parsed_json", help="策略解析 JSON 文件路径 (parsed_strategy.json)")
    parser.add_argument("output_json", help="输出测试用例 JSON 文件路径")
    parser.add_argument("--feedback", "-f", default=None,
                        help="上轮 Agent Loop 反馈 JSON (feedback.json)，用于自动修正用例")
    parser.add_argument("--scenarios", default=None,
                        help="scenarios.yaml 配置路径，数据驱动模式：外部化规则/函数模板与通用参数")
    parser.add_argument("--diff-old", default=None,
                        help="旧版 parsed_strategy.json 路径，用于增量回归：对比两版策略差异")
    parser.add_argument("--history", nargs="+", default=None,
                        help="历史 testcases JSON 文件路径（可多个），用于计算参数值 P50/P95 分布")
    parser.add_argument("--excel-output", default=None,
                        help="Excel 报告输出路径（默认与 output_json 同目录同名 .xlsx）")
    parser.add_argument("--execution-profile", choices=["no-mock"],
                        default="no-mock",
                        help="仅支持 no-mock，只生成当前可执行的 Fixture 用例")
    parser.add_argument("--org-code", default=None,
                        help="覆盖所有用例的机构编码，确保与当前登录机构一致")
    parser.add_argument("--fixture-run-id", default=None,
                        help="追加到 fixture 查询键的本轮标识，便于隔离和清理")
    args = parser.parse_args()

    # v2.4.2 Phase 4-2: 数据驱动 — 加载外部 scenarios.yaml 配置
    if args.scenarios:
        _load_scenarios(args.scenarios)
        _scen_count = len(_scenarios_config.get("function_templates", {}))
        _cp_count = len(_scenarios_config.get("common_params", {}))
        print(f"scenarios.yaml 已加载: {_scen_count} 函数模板, {_cp_count} 通用参数覆盖",
              file=sys.stderr)

    # v2.4.2 Phase 3-5: 策略版本 diff — 先输出变更摘要再生成用例
    if args.diff_old:
        diff_result = diff_strategy_versions(args.diff_old, args.parsed_json)
        diff_out_path = str(Path(args.output_json).parent / "strategy_diff.json")
        Path(diff_out_path).write_text(
            json.dumps(diff_result, ensure_ascii=False, indent=2), encoding="utf-8")
        summary = diff_result["summary"]
        print(f"策略版本 diff: {summary['totalChanges']} 处变更 "
              f"(规则{summary['rulesChanged']} 规则集{summary['ruleSetsChanged']} "
              f"函数{summary['functionsChanged']} 字段{summary['fieldsChanged']} "
              f"三方{summary['thirdPartyChanged']})", file=sys.stderr)
        print(f"diff 输出: {diff_out_path}", file=sys.stderr)

    # v2.4.2 Phase 3-6: 参数分布感知 — 从历史用例计算 P50/P95
    if args.history:
        dist = compute_param_distribution(args.history)
        dist_out_path = str(Path(args.output_json).parent / "param_distribution.json")
        Path(dist_out_path).write_text(
            json.dumps(dist, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"参数分布: {len(dist)} 个数值型字段有 P50/P95 统计", file=sys.stderr)
        for fname, stats in list(dist.items())[:5]:
            print(f"  {fname}: P50={stats['p50']} P95={stats['p95']} "
                  f"[{stats['min']}~{stats['max']}]", file=sys.stderr)
        print(f"分布输出: {dist_out_path}", file=sys.stderr)

    result = generate_all(args.parsed_json, args.output_json,
                          feedback_path=args.feedback,
                          execution_profile=args.execution_profile,
                          org_code=args.org_code,
                          fixture_run_id=args.fixture_run_id)

    # 如果指定了 --excel-output，覆盖默认的 Excel 路径
    if args.excel_output and result:
        from shutil import copy2
        default_xlsx = str(Path(args.output_json).with_suffix('.xlsx'))
        if Path(default_xlsx).exists():
            if Path(default_xlsx).resolve() != Path(args.excel_output).resolve():
                copy2(default_xlsx, args.excel_output)
                print(f"Excel 报告已复制到: {args.excel_output}", file=sys.stderr)
            else:
                print(f"Excel 报告已生成: {args.excel_output}", file=sys.stderr)
