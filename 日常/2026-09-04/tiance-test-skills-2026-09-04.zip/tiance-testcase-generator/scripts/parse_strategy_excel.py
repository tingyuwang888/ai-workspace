#!/usr/bin/env python3
"""
策略部署落地方案 Excel 解析器

从落地方案 Excel 中提取生成测试用例所需的全部结构化数据：
  - 策略列表（场景策略）
  - 规则集（含业务类型/企业类型路由）
  - 规则（含表达式、命中结果、入参）
  - 函数（含入参/出参/计算逻辑）
  - 字段映射（中文名 → 系统编码）
  - 风险决策类型
  - 三方数据接口

输出: JSON 格式，供 AI 分析后生成测试用例
"""
import json
import sys
import argparse
from pathlib import Path

try:
    import pandas as pd
except ImportError:
    print("ERROR: 需要 pandas 和 openpyxl: pip install pandas openpyxl", file=sys.stderr)
    sys.exit(1)


def read_sheet_safe(xls, name, header_keywords=None):
    """安全读取 sheet，自动检测表头行位置，不存在时返回 None。
    header_keywords: 用于定位表头行的关键字列表，默认用 ['序号']
    """
    if name not in xls.sheet_names:
        return None
    df = pd.read_excel(xls, sheet_name=name, header=None)
    if df.empty:
        return None
    # 自动检测表头行
    if header_keywords is None:
        header_keywords = ['序号', '规则编号', '字段显示名', '接口名称', '函数类型']
    header_row = 0
    for i in range(min(5, len(df))):
        row_vals = [str(v).strip() for v in df.iloc[i].values if pd.notna(v)]
        if any(kw in rv for kw in header_keywords for rv in row_vals):
            header_row = i
            break
    df.columns = df.iloc[header_row]
    return df.iloc[header_row + 1:].reset_index(drop=True)


def parse_strategies(df):
    if df is None:
        return []
    strategies = []
    for _, row in df.iterrows():
        code = row.get('决策流编码')
        if pd.isna(code):
            continue
        strategies.append({
            "code": str(code).strip(),
            "name": str(row.get('决策流名称', '')).strip(),
            "org": str(row.get('机构', '')).strip(),
            "channel": str(row.get('渠道', '')).strip(),
            "eventType": str(row.get('事件类型', '')).strip(),
            "bizType": str(row.get('业务类型', '')).strip(),
            "mode": str(row.get('执行模式', '')).strip(),
        })
    return strategies


def parse_rule_sets(df):
    if df is None:
        return []
    rule_sets = []
    for _, row in df.iterrows():
        code = row.get('规则集标识')
        if pd.isna(code):
            continue
        rule_sets.append({
            "code": str(code).strip(),
            "name": str(row.get('规则集名称', '')).strip(),
            "riskTag": str(row.get('风险标签', '')).strip(),
            "execMode": str(row.get('规则集执行模式', '')).strip(),
            "bizScenarios": str(row.get('适用业务场景', '')).strip(),
            "enterpriseType": str(row.get('适用企业类型', '')).strip(),
            "ruleCount": int(row.get('规则数', 0)) if pd.notna(row.get('规则数')) else 0,
            "sharedNote": str(row.get('共用说明', '')).strip() if pd.notna(row.get('共用说明')) else '',
        })
    return rule_sets


def parse_rules(df):
    if df is None:
        return []
    rules = []
    for _, row in df.iterrows():
        code = row.get('规则编号')
        if pd.isna(code):
            continue
        rule = {
            "code": str(code).strip(),
            "name": str(row.get('规则名称', '')).strip(),
            "ruleSet": str(row.get('所属规则集', '')).strip(),
            "ruleSetCode": str(row.get('规则集标识', '')).strip() if pd.notna(row.get('规则集标识')) else '',
            "expression": str(row.get('规则表达式', '')).strip(),
            "description": str(row.get('规则描述', '')).strip() if pd.notna(row.get('规则描述')) else '',
            "hitResult": str(row.get('命中结果', '')).strip(),
            "hitAssignment": str(row.get('命中后赋值', '')).strip() if pd.notna(row.get('命中后赋值')) else '',
            "inputParams": str(row.get('规则入参', '')).strip() if pd.notna(row.get('规则入参')) else '',
            "ruleType": str(row.get('规则类型', '')).strip() if pd.notna(row.get('规则类型')) else '自定义规则',
            "dataSource": str(row.get('数据源/接口', '')).strip() if pd.notna(row.get('数据源/接口')) else '',
        }
        rules.append(rule)
    return rules


def parse_functions(df):
    if df is None:
        return []
    functions = []
    for _, row in df.iterrows():
        name = row.get('名称')
        if pd.isna(name):
            continue
        functions.append({
            "type": str(row.get('函数类型', '')).strip(),
            "name": str(name).strip(),
            "logic": str(row.get('计算逻辑', '')).strip() if pd.notna(row.get('计算逻辑')) else '',
            "inputs": str(row.get('入参', '')).strip() if pd.notna(row.get('入参')) else '',
            "outputs": str(row.get('出参', '')).strip() if pd.notna(row.get('出参')) else '',
            "description": str(row.get('描述', '')).strip() if pd.notna(row.get('描述')) else '',
        })
    return functions


def parse_fields(df):
    if df is None:
        return {}
    fields = {}
    for _, row in df.iterrows():
        display_name = row.get('字段显示名')
        field_code = row.get('字段标识')
        if pd.isna(display_name) or pd.isna(field_code):
            continue
        name = str(display_name).strip()
        code = str(field_code).strip()
        fields[name] = {
            "code": code,
            "type": str(row.get('字段类型', '')).strip() if pd.notna(row.get('字段类型')) else '',
            "group": str(row.get('所属分组', '')).strip() if pd.notna(row.get('所属分组')) else '',
            "description": str(row.get('描述', '')).strip() if pd.notna(row.get('描述')) else '',
        }
    return fields


def parse_risk_decisions(df):
    if df is None:
        return []
    decisions = []
    for _, row in df.iterrows():
        code = row.get('风险决策标识')
        if pd.isna(code):
            continue
        decisions.append({
            "name": str(row.get('风险决策名称', '')).strip(),
            "code": str(code).strip(),
            "level": int(row.get('风险决策等级', 0)) if pd.notna(row.get('风险决策等级')) else 0,
            "color": str(row.get('颜色值', '')).strip() if pd.notna(row.get('颜色值')) else '',
            "signalLevel": str(row.get('信号等级', '')).strip() if pd.notna(row.get('信号等级')) else '',
            "bizCategory": str(row.get('业务分类', '')).strip() if pd.notna(row.get('业务分类')) else '',
        })
    return decisions


def parse_third_party_data(df):
    if df is None:
        return []
    interfaces = []
    for _, row in df.iterrows():
        name = row.get('接口名称')
        if pd.isna(name):
            continue
        interfaces.append({
            "name": str(name).strip(),
            "code": str(row.get('接口标识', '')).strip() if pd.notna(row.get('接口标识')) else '',
            "protocol": str(row.get('协议', '')).strip() if pd.notna(row.get('协议')) else '',
            "url": str(row.get('接口/url地址', '')).strip() if pd.notna(row.get('接口/url地址')) else '',
            "inputs": str(row.get('接口入参', '')).strip() if pd.notna(row.get('接口入参')) else '',
            "outputs": str(row.get('接口出参', '')).strip() if pd.notna(row.get('接口出参')) else '',
            "preETL": str(row.get('前置ETL处理逻辑', '')).strip() if pd.notna(row.get('前置ETL处理逻辑')) else '',
            "postETL": str(row.get('后置ETL处理逻辑', '')).strip() if pd.notna(row.get('后置ETL处理逻辑')) else '',
            "partner": str(row.get('合作方名称', '')).strip() if pd.notna(row.get('合作方名称')) else '',
            "isPaged": str(row.get('是否分页接口', '')).strip() if pd.notna(row.get('是否分页接口')) else '否',
            "timeout": int(row.get('超时时间', 30000)) if pd.notna(row.get('超时时间')) else 30000,
        })
    return interfaces


def build_rule_set_routing(rule_sets):
    routing = {}
    for rs in rule_sets:
        key = f"{rs['bizScenarios']}×{rs['enterpriseType']}"
        if key not in routing:
            routing[key] = []
        routing[key].append(rs['code'])
    return routing


def enrich_rules_with_field_codes(rules, fields):
    for rule in rules:
        params = rule.get('inputParams', '')
        if not params:
            rule["inputParamsMapped"] = []
            continue
        param_list = [p.strip() for p in params.replace('，', '、').split('、') if p.strip()]
        mapped = []
        for p in param_list:
            if p in fields:
                mapped.append({"name": p, "code": fields[p]["code"], "type": fields[p]["type"]})
            else:
                matched = None
                for fname, finfo in fields.items():
                    if fname in p or p in fname:
                        matched = {"name": p, "code": finfo["code"], "type": finfo["type"], "fuzzyMatch": fname}
                        break
                mapped.append(matched if matched else {"name": p, "code": None})
        rule["inputParamsMapped"] = mapped
    return rules


def parse_all(excel_path, output_path=None):
    xls = pd.ExcelFile(excel_path)

    strategies = parse_strategies(read_sheet_safe(xls, '场景策略'))
    rule_sets = parse_rule_sets(read_sheet_safe(xls, '规则集'))
    rules = parse_rules(read_sheet_safe(xls, '规则'))
    functions = parse_functions(read_sheet_safe(xls, '函数'))
    fields = parse_fields(read_sheet_safe(xls, '字段管理'))
    risk_decisions = parse_risk_decisions(read_sheet_safe(xls, '风险决策配置'))
    third_party = parse_third_party_data(read_sheet_safe(xls, '三方数据'))

    rules = enrich_rules_with_field_codes(rules, fields)
    routing = build_rule_set_routing(rule_sets)

    result = {
        "source": str(excel_path),
        "summary": {
            "strategyCount": len(strategies),
            "ruleSetCount": len(rule_sets),
            "ruleCount": len(rules),
            "functionCount": len(functions),
            "fieldCount": len(fields),
            "riskDecisionCount": len(risk_decisions),
            "thirdPartyInterfaceCount": len(third_party),
        },
        "strategies": strategies,
        "ruleSets": rule_sets,
        "rules": rules,
        "functions": functions,
        "fields": fields,
        "riskDecisions": risk_decisions,
        "thirdPartyInterfaces": third_party,
        "ruleSetRouting": routing,
    }

    json_str = json.dumps(result, ensure_ascii=False, indent=2)

    if output_path:
        Path(output_path).write_text(json_str, encoding='utf-8')
        print(f"已输出到: {output_path}", file=sys.stderr)
    else:
        print(json_str)

    return result


def main():
    parser = argparse.ArgumentParser(description='策略部署落地方案 Excel 解析器')
    parser.add_argument('excel', help='落地方案 Excel 文件路径')
    parser.add_argument('-o', '--output', help='输出 JSON 文件路径（默认输出到 stdout）')
    args = parser.parse_args()

    if not Path(args.excel).exists():
        print(f"ERROR: 文件不存在: {args.excel}", file=sys.stderr)
        sys.exit(1)

    parse_all(args.excel, args.output)


if __name__ == '__main__':
    main()
