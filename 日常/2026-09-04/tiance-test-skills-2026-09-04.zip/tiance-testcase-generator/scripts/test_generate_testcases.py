#!/usr/bin/env python3
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path


SCRIPT_PATH = Path(__file__).with_name("generate_testcases.py")
SPEC = importlib.util.spec_from_file_location("generate_testcases", SCRIPT_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class ThirdPartyFixtureGenerationTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.parsed = Path(
            "/Users/td/.qoderwork/skills/tiance-policy-test/loop_workspace/"
            "DF_PRE_CONC_001/iteration_1/parsed_strategy.json"
        )

    def test_no_mock_profile_only_emits_fixture_cases(self):
        data = json.loads(self.parsed.read_text(encoding="utf-8"))
        cases = MODULE.generate_third_party_fixture_cases(
            data, data["fields"], execution_profile="no-mock")

        self.assertEqual(len(cases), 16)
        self.assertEqual({case["executionMode"] for case in cases}, {"fixture"})
        self.assertEqual({case["fixtureScenario"] for case in cases},
                         {"empty_result", "numeric_boundary"})
        self.assertEqual({case["group"] for case in cases},
                         {"决策流分支覆盖"})
        self.assertEqual({case["caseType"] for case in cases}, {"反案例"})
        self.assertFalse(any("mockScenario" in case for case in cases))

    def test_mock_profile_is_rejected(self):
        data = json.loads(self.parsed.read_text(encoding="utf-8"))
        with self.assertRaisesRegex(ValueError, "Mock 异常用例已停用"):
            MODULE.generate_third_party_fixture_cases(
                data, data["fields"], execution_profile="mock")

    def test_scenario_libraries_do_not_define_mock_only_cases(self):
        scenarios = MODULE._load_scenarios()
        self.assertNotIn("third_party_exception_patterns", scenarios)
        self.assertEqual(
            {item["type"] for item in scenarios["third_party_fixture_patterns"]},
            {"empty_result", "numeric_boundary"},
        )

        library = MODULE._load_cases_library("concentration_check")
        self.assertNotIn("third_party_exception_patterns", library)
        self.assertEqual(
            {
                item["type"]
                for pattern in library["third_party_fixture_patterns"]
                for item in pattern["fixtures"]
            },
            {"empty_result", "numeric_boundary"},
        )
        serialized = json.dumps(library, ensure_ascii=False).lower()
        self.assertNotIn("mock_config", serialized)
        self.assertNotIn('"timeout"', serialized)
        self.assertNotIn('"invalid_data"', serialized)

    def test_full_generation_has_unique_executable_fixture_keys(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "cases.json"
            result = MODULE.generate_all(
                self.parsed, output, execution_profile="no-mock")
            excel_version = None
            excel_evidence = None
            excel_fixture = None
            excel_evidence_header = None
            excel_uuid_header = None
            if MODULE.HAS_OPENPYXL:
                from openpyxl import load_workbook
                workbook = load_workbook(output.with_suffix(".xlsx"), read_only=True)
                excel_version = workbook["汇总"]["B4"].value
                detail_sheet = workbook[workbook.sheetnames[1]]
                excel_uuid_header = detail_sheet["M1"].value
                excel_evidence_header = detail_sheet["O1"].value
                excel_evidence = detail_sheet["O2"].value
                excel_fixture = detail_sheet["P2"].value
                workbook.close()

        fixture_cases = [case for case in result["testCases"]
                         if case.get("executionMode") == "fixture"]
        self.assertEqual(len(fixture_cases), 16)
        self.assertEqual(len(result["testCases"]), 44)
        self.assertEqual(len({case["params"]["CASE_ID"] for case in fixture_cases}), 16)
        self.assertEqual(len({case["params"]["S_S_BIZID"] for case in fixture_cases}), 16)
        self.assertEqual(len({case["params"]["S_S_CUSTNO"] for case in fixture_cases}), 16)
        self.assertTrue(all(isinstance(case["params"]["C_F_RANDOMNUM"], float)
                            for case in fixture_cases))
        self.assertFalse(any(case["group"] not in {
            "规则", "函数", "决策流分支覆盖", "策略预警等级覆盖"
        } for case in result["testCases"]))
        self.assertEqual(result["executionProfile"], "no-mock")
        if MODULE.HAS_OPENPYXL:
            self.assertEqual(excel_version, f"v{MODULE.VERSION}")
            self.assertEqual(excel_uuid_header, "测试流水号UUID")
            self.assertEqual(excel_evidence_header, "三方数据")
            self.assertIn("函数证据", excel_evidence)
            self.assertIn("C_F_LIABILITYBALANCE=10000000", excel_evidence)
            self.assertIn("Fixture状态", excel_fixture)
        self.assertEqual(result["excludedScenarios"], [])
        self.assertFalse(any(
            case.get("executionMode") == "mock"
            or case.get("mockScenario")
            or case.get("thirdPartyMock")
            for case in result["testCases"]
        ))
        generated_text = json.dumps(result["testCases"], ensure_ascii=False).lower()
        for forbidden in ("接口超时", "错误码", "字段类型错误", "invalid_data", '"timeout"'):
            self.assertNotIn(forbidden, generated_text)
        self.assertFalse(any(case["group"] == "函数" for case in result["testCases"]))
        self.assertTrue(all(case.get("expectedEvidence") for case in result["testCases"]))
        self.assertTrue(all(case.get("executable") is True for case in result["testCases"]))
        self.assertTrue(all(
            requirement.get("fieldValues")
            or requirement.get("evidenceMode") == "function_aggregate"
            for case in result["testCases"]
            for requirement in case["expectedEvidence"].get("thirdPartyNodes", [])
        ))

        tc001 = result["testCases"][0]
        single_realtime = next(
            item for item in tc001["expectedEvidence"]["thirdPartyNodes"]
            if item["nodeName"] == "单户集中度表查询_实时"
        )
        self.assertEqual(single_realtime["fieldValues"], {
            "C_F_GUARANTEEBALANCE": 10_000_000,
            "C_F_LIABILITYBALANCE": 10_000_000,
            "C_F_QUOTAREALTIMESINGLECONC": 1_000_000,
            "C_F_RESERVEAMOUNT": 10_000_000,
        })

        numeric = next(
            case for case in fixture_cases
            if case["fixtureInterfaceCode"] == "dhjzdsearch"
            and case["fixtureScenario"] == "numeric_boundary"
        )
        numeric_node = next(
            item for item in numeric["expectedEvidence"]["thirdPartyNodes"]
            if item["nodeName"] == "单户集中度表查询_实时"
        )
        self.assertEqual(numeric_node["fieldValues"]["C_F_LIABILITYBALANCE"], -1)
        self.assertIn("C_F_RESERVEAMOUNT", numeric_node["absentFields"])

    def test_concentration_cases_bind_real_query_keys_and_exclusive_routes(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "cases.json"
            result = MODULE.generate_all(
                self.parsed,
                output,
                execution_profile="no-mock",
                org_code="sxdb",
                fixture_run_id="RUN123",
            )

        deterministic = [
            case for case in result["testCases"]
            if case.get("requiresIsolatedThirdPartyData")
        ]
        self.assertTrue(deterministic)
        self.assertEqual(
            len({case["params"]["S_S_CUSTNAME"] for case in deterministic}),
            len(deterministic),
        )
        self.assertTrue(all(
            case["params"]["S_S_CUSTNAME"].endswith("_RUN123")
            for case in deterministic
        ))

        for case in deterministic:
            if case.get("targetRule") == "R003":
                if case.get("regionVariant") == "四川乐山":
                    self.assertEqual(case["params"]["C_S_AREAPROVINCE"], "四川")
                    self.assertEqual(case["params"]["C_S_AREACITY"], "乐山")
                    self.assertEqual(case["params"]["C_S_AREAPROVINCECODE"], "510000")
                else:
                    self.assertEqual(case["params"]["C_S_AREAPROVINCE"], "广东")
                    self.assertEqual(case["params"]["C_S_AREAPROVINCECODE"], "440000")
                self.assertEqual(case["fixtureQueryKeys"]["areaKey"], "city")
            elif case.get("targetRule") == "R004":
                if case.get("regionVariant") == "重庆":
                    self.assertEqual(case["params"]["C_S_AREAPROVINCE"], "重庆")
                    self.assertEqual(case["params"]["C_S_AREAPROVINCECODE"], "500000")
                elif case.get("regionVariant") == "四川省成都市":
                    self.assertEqual(case["params"]["C_S_AREAPROVINCE"], "四川省")
                    self.assertEqual(case["params"]["C_S_AREACITY"], "成都市")
                    self.assertEqual(case["params"]["C_S_AREAPROVINCECODE"], "510000")
                else:
                    self.assertEqual(case["params"]["C_S_AREAPROVINCE"], "四川")
                    self.assertEqual(case["params"]["C_S_AREACITY"], "成都")
                    self.assertEqual(case["params"]["C_S_AREAPROVINCECODE"], "510000")
                    self.assertEqual(case["params"]["C_S_AREACITYCODE"], "510100")
                self.assertEqual(case["fixtureQueryKeys"]["areaKey"], "district")

        r004_hit = [
            case for case in deterministic
            if case.get("targetRule") == "R004"
            and case.get("group") == "规则"
            and case["fixtureProfile"]["area"] == "hit"
        ]
        self.assertEqual({case["regionVariant"] for case in r004_hit}, {"重庆", "四川成都"})

        boundary_cases = [case for case in deterministic if case.get("boundaryKind")]
        self.assertEqual(len(boundary_cases), 4)
        self.assertTrue(all("boundary" in case["fixtureProfile"].values()
                            for case in boundary_cases))

        cross_cases = [case for case in deterministic if case.get("isCrossMatrix")]
        self.assertEqual(len(cross_cases), 4)
        self.assertEqual(
            len({tuple(sorted(case["fixtureProfile"].items())) for case in cross_cases}),
            4,
        )

    def test_concentration_semantic_regressions_are_fixture_driven(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "cases.json"
            result = MODULE.generate_all(
                self.parsed,
                output,
                execution_profile="no-mock",
                fixture_run_id="RUN123",
            )
            coverage = json.loads((Path(tmp) / "coverage_pre_report.json").read_text())

        semantic_cases = [
            case for case in result["testCases"] if case.get("semanticScenario")
        ]
        self.assertEqual(len(semantic_cases), 11)
        covered_tags = {
            tag for case in semantic_cases for tag in case.get("coverageTags", [])
        }
        expected_tags = MODULE.CONCENTRATION_SEMANTIC_TAGS - {
            "area_multi_row_aggregation"
        }
        self.assertTrue(expected_tags <= covered_tags)
        semantic_coverage = coverage["dimensions"]["semanticScenarios"]
        self.assertEqual(semantic_coverage["catalogTotal"], 12)
        self.assertEqual(semantic_coverage["applicable"], 11)
        self.assertEqual(
            set(semantic_coverage["applicableTags"]),
            expected_tags,
        )
        self.assertEqual(
            semantic_coverage["notApplicableTags"],
            ["area_multi_row_aggregation"],
        )
        self.assertEqual(
            semantic_coverage["percent"], 100.0)
        self.assertEqual(
            semantic_coverage["missingTags"], [])

        full_name = next(
            case for case in semantic_cases
            if case["semanticScenario"] == "region_full_name_normalization"
        )
        self.assertEqual(full_name["params"]["C_S_AREAPROVINCE"], "四川省")
        self.assertEqual(full_name["params"]["C_S_AREACITY"], "成都市")

        decimal_cases = [
            case for case in semantic_cases
            if "decimal_precision" in case.get("coverageTags", [])
        ]
        self.assertEqual(len(decimal_cases), 3)
        self.assertTrue(all(
            any(item.get("tolerance") == 0.01
                for item in case["expectedEvidence"]["functions"])
            for case in decimal_cases
        ))

    def test_multi_row_requires_explicit_function_input_contract(self):
        data = json.loads(self.parsed.read_text(encoding="utf-8"))
        area_function = next(
            function for function in data["functions"]
            if function.get("name") == "保前区域合并已用额度"
        )
        area_function["description"] = (
            "函数接收同一查询键返回的多条记录数组，并逐行汇总金额"
        )

        applicability = MODULE._concentration_semantic_applicability(data)
        self.assertIn(
            "area_multi_row_aggregation",
            applicability["applicableTags"],
        )

        with tempfile.TemporaryDirectory() as tmp:
            parsed = Path(tmp) / "parsed.json"
            output = Path(tmp) / "cases.json"
            parsed.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            result = MODULE.generate_all(
                parsed,
                output,
                execution_profile="no-mock",
                fixture_run_id="RUN123",
            )

        multi_row = next(
            case for case in result["testCases"]
            if case.get("semanticScenario") == "area_multi_row_aggregation"
        )
        area_nodes = [
            item for item in multi_row["expectedEvidence"]["thirdPartyNodes"]
            if item.get("fixtureRowCount") == 2
        ]
        self.assertEqual(len(area_nodes), 2)

    def test_semantic_regressions_are_not_required_when_template_does_not_support_them(self):
        data = json.loads(self.parsed.read_text(encoding="utf-8"))
        for metadata in data["fields"].values():
            if metadata.get("type") == "小数型":
                metadata["type"] = "整数型"

        function_overrides = {
            "保前单户合并责任余额": ("责任余额_实时单户集中度", "取实时单户数据计算"),
            "保前关联户合并责任余额": ("责任余额_实时关联户集中度", "取实时关联户数据计算"),
            "保前区域合并已用额度": ("在保金额_实时区域集中度", "返回第一条实时区域数据"),
            "区域聚合层级判断": ("客户区域_省", "按省代码选择路由"),
        }
        for function in data["functions"]:
            override = function_overrides.get(function.get("name"))
            if not override:
                continue
            function["inputs"], function["logic"] = override
            function["description"] = override[1]

        for rule in data["rules"]:
            if rule.get("code") == "R003":
                rule["expression"] = "客户区域_省 <> 重庆 且 区域合并已用额度 >= 限额"
            elif rule.get("code") == "R004":
                rule["expression"] = "客户区域_省 = 重庆 且 区域合并已用额度 >= 限额"

        applicability = MODULE._concentration_semantic_applicability(data)
        self.assertEqual(applicability["applicableTags"], set())
        self.assertEqual(
            applicability["notApplicableTags"],
            MODULE.CONCENTRATION_SEMANTIC_TAGS,
        )

        with tempfile.TemporaryDirectory() as tmp:
            parsed = Path(tmp) / "parsed.json"
            output = Path(tmp) / "cases.json"
            parsed.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            result = MODULE.generate_all(
                parsed,
                output,
                execution_profile="no-mock",
                fixture_run_id="RUN123",
            )
            coverage = json.loads((Path(tmp) / "coverage_pre_report.json").read_text())

        self.assertFalse(any(
            case.get("semanticScenario") for case in result["testCases"]
        ))
        self.assertEqual(len(result["testCases"]), 33)
        semantic_coverage = coverage["dimensions"]["semanticScenarios"]
        self.assertEqual(semantic_coverage["applicable"], 0)
        self.assertEqual(semantic_coverage["covered"], 0)
        self.assertEqual(semantic_coverage["percent"], 100.0)
        self.assertEqual(semantic_coverage["applicableTags"], [])
        self.assertEqual(
            set(semantic_coverage["notApplicableTags"]),
            MODULE.CONCENTRATION_SEMANTIC_TAGS,
        )
        self.assertEqual(semantic_coverage["missingTags"], [])

    def test_coverage_counts_only_real_fixture_and_evidence_contracts(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "cases.json"
            result = MODULE.generate_all(
                self.parsed, output, fixture_run_id="RUN123")
            coverage = json.loads((Path(tmp) / "coverage_pre_report.json").read_text())

        self.assertEqual(coverage["executableCases"], len(result["testCases"]))
        self.assertEqual(coverage["excludedFromCoverage"], 0)
        self.assertEqual(coverage["dimensions"]["rules"]["percent"], 100.0)
        self.assertEqual(coverage["dimensions"]["functions"]["percent"], 100.0)
        self.assertEqual(coverage["dimensions"]["crossMatrix"]["testedCombinations"], 4)
        self.assertEqual(coverage["dimensions"]["semanticScenarios"]["percent"], 100.0)


if __name__ == "__main__":
    unittest.main()
