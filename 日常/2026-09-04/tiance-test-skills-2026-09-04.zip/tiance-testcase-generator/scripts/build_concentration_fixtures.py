#!/usr/bin/env python3
"""Build isolated MySQL fixtures for deterministic concentration cases."""

import argparse
import json
import re
from pathlib import Path


RUN_ID_PLACEHOLDER = "${RUN_ID}"
RUN_ID_RE = re.compile(r"^[A-Za-z0-9_-]+$")


CUSTOMER_TABLES = (
    ("single_realtime", "ads_icr_sgl_cust_conc_realtime"),
    ("single_batch", "ads_icr_sgl_cust_conc_bacth"),
    ("related_realtime", "ads_icr_rel_cust_conc_realtime"),
    ("related_batch", "ads_icr_rel_cust_conc_batch"),
)

INTERFACE_TABLES = {
    "dhjzdsearch": ("ads_icr_sgl_cust_conc_realtime", "cust_name", "customer"),
    "dhjzdoffsearch": ("ads_icr_sgl_cust_conc_bacth", "cust_name", "customer"),
    "glhjzdsearch": ("ads_icr_rel_cust_conc_realtime", "cust_name", "customer"),
    "glhjzdoffsearch": ("ads_icr_rel_cust_conc_batch", "cust_name", "customer"),
    "sjqyjzdsearch": ("ads_icr_area_conc_realtime", "rgst_addr_city_cd", "area"),
    "sjqyjzdoffsearch": ("ads_icr_area_conc_batch", "rgst_addr_city_cd", "area"),
    "qjqyjzdsearch": ("ads_icr_area_conc_realtime", "rgst_addr_area_cd", "area"),
    "qjqyjzdoffsearch": ("ads_icr_area_conc_batch", "rgst_addr_area_cd", "area"),
}


def _template_key(value, run_id):
    value = str(value)
    marker = f"_{run_id}"
    if marker not in value:
        raise ValueError(f"隔离查询键未包含本轮标识 {marker}: {value}")
    return value.replace(marker, f"_{RUN_ID_PLACEHOLDER}")


def _customer_row(customer_name, state):
    if state == "hit":
        values = {
            "in_guar_bal": 10_000_000,
            "duty_bal": 10_000_000,
            "reserve_amount": 10_000_000,
            "quota": 1_000_000,
        }
    elif state == "boundary":
        values = {
            "in_guar_bal": 250_000,
            "duty_bal": 250_000,
            "reserve_amount": 250_000,
            "quota": 1_000_000,
        }
    elif state == "miss":
        values = {
            "in_guar_bal": 0,
            "duty_bal": 0,
            "reserve_amount": 0,
            "quota": 100_000_000,
        }
    else:
        raise ValueError(f"不支持的客户 Fixture 状态: {state}")
    return {
        "cust_name": customer_name,
        **values,
        "data_op_type": "CODEX_FIXTURE",
    }


def _area_row(params, state, key_column, key_value, offline=False):
    if state == "hit":
        amounts = {
            "in_guar_bal": 10_000_000,
            "duty_bal": 10_000_000,
            "reserve_amount": 10_000_000,
            "area_used_quota": 10_000_000,
        }
        area_quota = 1_000_000
    elif state == "boundary":
        amounts = {
            "in_guar_bal": 250_000,
            "duty_bal": 250_000,
            "reserve_amount": 250_000,
            "area_used_quota": 250_000,
        }
        area_quota = 1_000_000
    elif state == "miss":
        amounts = {
            "in_guar_bal": 0,
            "duty_bal": 0,
            "reserve_amount": 0,
            "area_used_quota": 0,
        }
        area_quota = 100_000_000
    else:
        raise ValueError(f"不支持的区域 Fixture 状态: {state}")

    row = {
        "rgst_addr_prov_cd": params["C_S_AREAPROVINCECODE"],
        "rgst_addr_city_cd": params["C_S_AREACITYCODE"],
        "rgst_addr_area_cd": params["C_S_AREADISTRICTCODE"],
        **amounts,
        "data_op_type": "CODEX_FIXTURE",
    }
    row[key_column] = key_value
    if offline:
        row["area_quota"] = area_quota
    return row


def _rows_with_override(base_row, override, distinct_area_rows=False):
    override = override or {}
    if override.get("absent"):
        return []
    raw_rows = override.get("rows")
    if raw_rows is None:
        raw_rows = [{
            key: value for key, value in override.items()
            if key not in {"absent", "rows"}
        }]
    rows = [{**base_row, **row} for row in raw_rows]
    if distinct_area_rows and len(rows) > 1:
        for index, row in enumerate(rows, 1):
            row["rgst_addr_area_cd"] = (
                f"{base_row['rgst_addr_area_cd']}_ROW{index}"
            )
    return rows


def _absence_check(case_id, node_key, table, key_column, key_value):
    return {
        "id": f"{case_id}_{node_key}_absent",
        "table": table,
        "keyColumns": [key_column],
        "row": {key_column: key_value},
    }


def _case_query_values(case, run_id):
    params = case["params"]
    def optional_template(value):
        marker = f"_{run_id}"
        return _template_key(value, run_id) if marker in str(value) else str(value)

    return {
        "cust_name": _template_key(params["S_S_CUSTNAME"], run_id),
        "rgst_addr_city_cd": optional_template(params["C_S_AREACITYCODE"]),
        "rgst_addr_area_cd": optional_template(params["C_S_AREADISTRICTCODE"]),
    }


def _numeric_row(case, run_id, interface_code):
    table, key_column, kind = INTERFACE_TABLES[interface_code]
    params = case["params"]
    key_value = _case_query_values(case, run_id)[key_column]
    if kind == "customer":
        row = {
            "cust_name": key_value,
            "in_guar_bal": -1,
            "duty_bal": -1,
            "quota": 0,
            "reserve_amount": None,
            "data_op_type": "CODEX_FIXTURE",
        }
    else:
        row = {
            "rgst_addr_prov_cd": params["C_S_AREAPROVINCECODE"],
            "in_guar_bal": -1,
            "reserve_amount": None,
            "area_used_quota": -1,
            "data_op_type": "CODEX_FIXTURE",
        }
        row[key_column] = key_value
        if key_column == "rgst_addr_area_cd":
            row["rgst_addr_city_cd"] = _case_query_values(case, run_id)["rgst_addr_city_cd"]
        if table.endswith("_batch"):
            row["area_quota"] = 0
    return table, key_column, row


def _absence_checks(case, run_id, excluded_interface=None):
    params = case["params"]
    query_values = _case_query_values(case, run_id)
    district = str(case.get("fixtureInterfaceCode", "")).startswith("qjqy")
    interface_codes = [
        "dhjzdsearch", "dhjzdoffsearch", "glhjzdsearch", "glhjzdoffsearch",
        "qjqyjzdsearch" if district else "sjqyjzdsearch",
        "qjqyjzdoffsearch" if district else "sjqyjzdoffsearch",
    ]
    checks = []
    for interface_code in interface_codes:
        if interface_code == excluded_interface:
            continue
        table, key_column, _ = INTERFACE_TABLES[interface_code]
        checks.append({
            "id": f"{case['id']}_{interface_code}_absent",
            "table": table,
            "keyColumns": [key_column],
            "row": {key_column: query_values[key_column]},
        })
    return checks


def build_manifest(testcases, run_id, case_ids=None):
    if not RUN_ID_RE.fullmatch(run_id):
        raise ValueError("run-id 只能包含字母、数字、下划线和连字符")

    cases = testcases.get("testCases", testcases)
    selected_ids = set(case_ids or [])
    selected = [
        case for case in cases
        if (case.get("requiresIsolatedThirdPartyData") or case.get("executionMode") == "fixture")
        and (not selected_ids or case.get("id") in selected_ids)
    ]
    found_ids = {case.get("id") for case in selected}
    missing = selected_ids - found_ids
    if missing:
        raise ValueError(f"用例不存在或未声明隔离数据合同: {', '.join(sorted(missing))}")
    if not selected:
        raise ValueError("没有可生成 Fixture 的集中度用例")

    fixtures = []
    absence_checks = []
    for case in selected:
        case_id = case["id"]
        if case.get("executionMode") == "fixture":
            interface_code = case.get("fixtureInterfaceCode")
            if interface_code not in INTERFACE_TABLES:
                raise ValueError(f"{case_id} 缺少受支持的 fixtureInterfaceCode")
            if case.get("fixtureScenario") == "empty_result":
                absence_checks.extend(_absence_checks(case, run_id))
            elif case.get("fixtureScenario") == "numeric_boundary":
                table, key_column, row = _numeric_row(case, run_id, interface_code)
                fixtures.append({
                    "id": f"{case_id}_{interface_code}_numeric",
                    "table": table,
                    "keyColumns": [key_column],
                    "rows": [row],
                })
                absence_checks.extend(
                    _absence_checks(case, run_id, excluded_interface=interface_code)
                )
            else:
                raise ValueError(f"{case_id} 不支持的 fixtureScenario")
            continue

        params = case["params"]
        profile = case["fixtureProfile"]
        fixture_overrides = case.get("fixtureOverrides", {}) or {}
        customer_name = _template_key(params["S_S_CUSTNAME"], run_id)

        for dimension, table in CUSTOMER_TABLES:
            state_key = "single" if dimension.startswith("single") else "related"
            rows = _rows_with_override(
                _customer_row(customer_name, profile[state_key]),
                fixture_overrides.get(dimension),
            )
            if rows:
                fixtures.append({
                    "id": f"{case_id}_{dimension}",
                    "table": table,
                    "keyColumns": ["cust_name"],
                    "rows": rows,
                })
            else:
                absence_checks.append(_absence_check(
                    case_id, dimension, table, "cust_name", customer_name,
                ))

        area_key = case["fixtureQueryKeys"]["areaKey"]
        if area_key == "district":
            key_column = "rgst_addr_area_cd"
            key_value = _template_key(params["C_S_AREADISTRICTCODE"], run_id)
        else:
            key_column = "rgst_addr_city_cd"
            key_value = _template_key(params["C_S_AREACITYCODE"], run_id)

        for suffix, offline in (("realtime", False), ("batch", True)):
            node_key = f"{area_key}_{suffix}"
            # Generator evidence uses city_*/district_* while table fixtures
            # use area_* IDs. Keep the node key for override lookup only.
            rows = _rows_with_override(
                _area_row(
                    params,
                    profile["area"],
                    key_column,
                    key_value,
                    offline=offline,
                ),
                fixture_overrides.get(node_key),
                distinct_area_rows=area_key == "city",
            )
            table = (
                "ads_icr_area_conc_batch" if offline
                else "ads_icr_area_conc_realtime"
            )
            if rows:
                fixtures.append({
                    "id": f"{case_id}_area_{suffix}",
                    "table": table,
                    "keyColumns": [key_column],
                    "rows": rows,
                })
            else:
                absence_checks.append(_absence_check(
                    case_id, node_key, table, key_column, key_value,
                ))

    return {
        "policyCode": testcases.get("strategyCode", ""),
        "description": "deterministic concentration fixtures",
        "caseIds": [case["id"] for case in selected],
        "fixtures": fixtures,
        "absenceChecks": absence_checks,
    }


def main():
    parser = argparse.ArgumentParser(
        description="为集中度正常用例生成隔离 MySQL Fixture 清单"
    )
    parser.add_argument("testcases", help="生成后的 testcases.json")
    parser.add_argument("output", help="Fixture manifest 输出路径")
    parser.add_argument("--run-id", required=True, help="生成用例时使用的 fixture-run-id")
    parser.add_argument("--case-id", action="append", default=[], help="仅生成指定用例，可重复")
    args = parser.parse_args()

    source = json.loads(Path(args.testcases).read_text(encoding="utf-8"))
    manifest = build_manifest(source, args.run_id, args.case_id)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps({
        "ok": True,
        "cases": len(manifest["caseIds"]),
        "fixtures": len(manifest["fixtures"]),
        "absenceChecks": len(manifest["absenceChecks"]),
        "output": str(output),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
