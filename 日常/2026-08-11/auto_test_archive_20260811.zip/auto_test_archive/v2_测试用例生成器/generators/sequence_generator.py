"""
进件序列生成器 - 调用LLM生成满足测试场景的进件序列
"""

import json
import hashlib
import random
import string
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field

from llm.client import LLMClient
from llm.prompts import build_sequence_generation_prompt, build_system_prompt
from loaders.metadata_loader import MetadataManager
from utils.logger import get_logger
from templates import TemplateRegistry


@dataclass
class TestEvent:
    """测试进件"""
    sequence: int                           # 序号
    purpose: str                            # 目的说明
    expected_metric_values: Dict[str, Dict] # 预期指标值变化
    expected_condition_hit: bool            # 预期是否命中条件
    data: Dict[str, Any]                    # 进件数据


@dataclass
class TestCase:
    """测试用例"""
    case_id: str                            # 用例ID
    case_name: str                          # 用例名称
    scenario_name: str                      # 场景名称
    condition_states: Dict[str, bool]       # 条件状态
    expected_rule_hit: bool                 # 预期规则是否触发
    events: List[TestEvent]                 # 进件序列
    analysis: Dict[str, str] = field(default_factory=dict)  # LLM分析


class SequenceGenerator:
    """进件序列生成器"""
    
    def __init__(
        self,
        llm_client: Optional[LLMClient] = None,
        metadata_manager: Optional[MetadataManager] = None,
        dry_run: bool = False
    ):
        """
        初始化生成器
        
        Args:
            llm_client: LLM客户端
            metadata_manager: 元数据管理器
            dry_run: 是否为模拟运行模式
        """
        self.dry_run = dry_run
        self.llm_client = llm_client if llm_client is not None else (None if dry_run else LLMClient())
        self.metadata = metadata_manager or MetadataManager()
        self.logger = get_logger()
    
    def pre_validate_rule(
        self,
        rule_info: Dict[str, Any],
        common_fields: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        规则级别预校验：在场景生成前检查事件类型等匹配性。
        避免同一规则下所有场景逐个重复报相同的错误。
        
        Args:
            rule_info: 规则信息
            common_fields: 公共字段配置
        
        Returns:
            {'valid': bool, 'message': str}
        """
        # 提取相关指标元数据
        related_metrics = self._extract_related_metrics(rule_info)
        
        # 提取场景条件信息
        scene_conditions = self._extract_scene_conditions(related_metrics)
        
        # 复用已有的场景条件验证逻辑
        return self._validate_scene_conditions(
            scene_conditions, common_fields, related_metrics, rule_info
        )
    
    def generate_test_case(
        self,
        rule_info: Dict[str, Any],
        scenario: Any,
        case_index: int = 1
    ) -> Optional[TestCase]:
        """
        为单个场景生成测试用例
        
        Args:
            rule_info: 规则信息
            scenario: 测试场景
            case_index: 用例序号
        
        Returns:
            TestCase对象，失败返回None
        """
        # 获取场景信息
        scenario_dict = self._scenario_to_dict(scenario)
        
        self.logger.debug(f"生成场景: {scenario_dict['scenario_name']}")
        
        # 提取相关指标元数据
        related_metrics = self._extract_related_metrics(rule_info)
        
        # 提取相关字段元数据（包含规则条件中的字段）
        try:
            related_fields = self._extract_related_fields(related_metrics, rule_info)
        except ValueError as e:
            self.logger.error(f"字段映射错误: {e}")
            return self._build_empty_test_case(scenario_dict, case_index, str(e))
        
        # 提取场景条件信息
        scene_conditions = self._extract_scene_conditions(related_metrics)
        
        # 提取字段条件信息（fieldCondition）
        field_conditions = self._extract_field_conditions(related_metrics)
        
        # 获取公共字段配置
        common_fields = rule_info.get('common_fields', {})
        
        # 本地验证场景条件匹配性
        validation_result = self._validate_scene_conditions(
            scene_conditions, common_fields, related_metrics, rule_info
        )
        if not validation_result['valid']:
            self.logger.error(f"场景条件验证失败: {validation_result['message']}")
            # 返回空测试用例但带有错误信息
            return self._build_empty_test_case(scenario_dict, case_index, validation_result['message'])
        
        # 构建Prompt
        prompt = build_sequence_generation_prompt(
            rule_info=rule_info,
            scenario=scenario_dict,
            metrics_metadata=related_metrics,
            field_metadata=related_fields,
            common_fields=common_fields,
            mapping_config=self.metadata.mapping_config,
            scene_conditions=scene_conditions,
            field_conditions=field_conditions
        )
        
        self.logger.debug(f"Prompt长度: {len(prompt)} 字符")
        
        scenario_name = scenario_dict.get('scenario_name', f'场景{case_index}')
        rule_name = rule_info.get('rule_name', 'unknown')
        
        # dry-run模式返回模拟数据
        if self.dry_run or self.llm_client is None:
            self.logger.warning(f"  [{scenario_name}] DRY RUN: 生成模拟测试用例")
            return self._build_mock_test_case(scenario_dict, case_index)
        
        # 设置LLM调用上下文（用于日志记录）
        self.llm_client.set_context(
            rule_name=rule_name,
            scenario_name=scenario_name,
            call_type="generate_sequence"
        )
        
        # 调用LLM（带JSON解析重试机制，使用详细版本获取原始响应）
        system_prompt = build_system_prompt()
        response, last_raw_response = self.llm_client.call_with_json_retry_detailed(
            prompt, system_prompt=system_prompt, max_retries=2
        )
        
        if not response:
            self.logger.warning(f"  - LLM响应为空或解析失败（已重试），返回空测试用例")
            # 返回一个带有空events的测试用例，同时保存最后一次原始响应
            return self._build_empty_test_case(
                scenario_dict, case_index, 
                error_message="LLM响应解析失败",
                raw_response=last_raw_response
            )
        
        # 检查response中是否有events字段，或是否标记为不可达场景
        analysis = response.get('analysis', {})
        is_skipped = analysis.get('skipped', False)
        has_events = 'events' in response
        
        if has_events:
            # 标准格式
            pass
        elif is_skipped:
            # 不可达场景，允许没有events
            pass
        else:
            # 缺少必要字段，尝试一次补救重试
            self.logger.warning(f"  - LLM响应缺少'events'字段且未标记为不可达")
            self.logger.info(f"  - 尝试补救重试...")
            
            retry_prompt = self._build_missing_fields_retry_prompt(response)
            response, last_raw_response = self.llm_client.call_with_json_retry_detailed(
                retry_prompt, system_prompt=system_prompt, max_retries=1
            )
            
            if not response:
                self.logger.warning(f"  - 补救重试失败，返回空测试用例")
                return self._build_empty_test_case(
                    scenario_dict, case_index,
                    error_message="补救重试后仍无法解析LLM响应",
                    raw_response=last_raw_response
                )
            
            # 再次检查格式
            if 'events' not in response and not response.get('analysis', {}).get('skipped', False):
                self.logger.warning(f"  - 补救重试后仍缺少'events'字段，返回空测试用例")
                return self._build_empty_test_case(
                    scenario_dict, case_index,
                    error_message="补救重试后响应仍缺少events字段",
                    raw_response=last_raw_response
                )
        
        if not response.get('events') and not response.get('analysis', {}).get('skipped', False):
            self.logger.warning(f"  - LLM返回的events为空数组")
        
        # 解析响应构建TestCase（传入prompt用于不可达场景二次确认）
        return self._build_test_case(response, scenario_dict, case_index, rule_info, prompt, related_metrics)
    
    def generate_all_test_cases(
        self,
        rule_info: Dict[str, Any],
        scenarios: List[Any]
    ) -> List[TestCase]:
        """
        为所有场景生成测试用例（串行版本）
        
        Args:
            rule_info: 规则信息
            scenarios: 测试场景列表
        
        Returns:
            TestCase列表
        """
        # 打印规则输入信息（只打印一次）
        self._print_rule_inputs_once(rule_info)
        
        test_cases = []
        
        for i, scenario in enumerate(scenarios, 1):
            scenario_name = scenario.scenario_name if hasattr(scenario, 'scenario_name') else scenario.get('scenario_name', '')
            
            self.logger.debug(f"处理场景 {i}/{len(scenarios)}: {scenario_name}")
            
            test_case = self.generate_test_case(rule_info, scenario, case_index=i)
            
            if test_case:
                test_cases.append(test_case)
                self.logger.event_generated(scenario_name, len(test_case.events))
            else:
                self.logger.warning(f"场景 '{scenario_name}' 生成失败")
        
        return test_cases
    
    def generate_all_test_cases_parallel(
        self,
        rule_info: Dict[str, Any],
        scenarios: List[Any],
        max_workers: int = 5,
        timeout: int = 120,
        retry_times: int = 1
    ) -> List[TestCase]:
        """
        为所有场景并行生成测试用例（线程池版本）
        
        Args:
            rule_info: 规则信息
            scenarios: 测试场景列表
            max_workers: 最大并发线程数（默认5）
            timeout: 单个场景超时时间（秒，默认120）
            retry_times: 失败重试次数（默认1）
        
        Returns:
            TestCase列表
        """
        if not scenarios:
            return []
        
        # 单场景直接串行处理
        if len(scenarios) == 1:
            return self.generate_all_test_cases(rule_info, scenarios)
        
        # 打印规则输入信息（只打印一次）
        self._print_rule_inputs_once(rule_info)
        
        self.logger.info(f"启动并行生成: {len(scenarios)} 个场景, {max_workers} 线程")
        start_time = time.time()
        
        # 线程锁保护日志
        log_lock = threading.Lock()
        # 使用列表作为可变计数器（线程安全）
        counters = {'completed': 0, 'failed': 0}
        
        def generate_single(args: Tuple[int, Any, int]) -> Tuple[int, Optional[TestCase], Optional[str]]:
            """
            生成单个场景的包装函数
            
            Args:
                args: (index, scenario, retry_count)
            
            Returns:
                (index, test_case, error_message)
            """
            index, scenario, retry_left = args
            scenario_name = scenario.scenario_name if hasattr(scenario, 'scenario_name') else scenario.get('scenario_name', f'场景{index}')
            thread_name = threading.current_thread().name
            start_ts = time.time()
            
            try:
                test_case = self.generate_test_case(rule_info, scenario, case_index=index)
                elapsed = time.time() - start_ts
                
                if test_case:
                    event_count = len(test_case.events)
                    hit_status = "✓触发" if test_case.expected_rule_hit else "✗未触发"
                    with log_lock:
                        counters['completed'] += 1
                        progress = counters['completed'] + counters['failed']
                        self.logger.info(
                            f"[{thread_name}] {scenario_name} ({index}/{len(scenarios)}): "
                            f"LLM完成 | 进件:{event_count} | 规则:{hit_status} | "
                            f"耗时:{elapsed:.1f}s | 进度:{progress}/{len(scenarios)}"
                        )
                    return index, test_case, None
                else:
                    # 生成失败，尝试重试
                    if retry_left > 0:
                        with log_lock:
                            self.logger.warning(f"[{thread_name}] {scenario_name}: 失败，{retry_left}次重试机会")
                        time.sleep(1)
                        return generate_single((index, scenario, retry_left - 1))
                    else:
                        with log_lock:
                            counters['failed'] += 1
                            self.logger.error(f"[{thread_name}] {scenario_name}: 失败，重试已用尽")
                        return index, None, f"场景 {index} ({scenario_name}) 生成失败"
                        
            except Exception as e:
                error_msg = str(e)
                elapsed = time.time() - start_ts
                # 发生异常，尝试重试
                if retry_left > 0:
                    with log_lock:
                        self.logger.warning(f"[{thread_name}] {scenario_name}: 异常{elapsed:.1f}s，{retry_left}次重试")
                    time.sleep(1)
                    return generate_single((index, scenario, retry_left - 1))
                else:
                    with log_lock:
                        counters['failed'] += 1
                        self.logger.error(f"[{thread_name}] {scenario_name}: 异常，重试已用尽")
                    return index, None, f"场景 {index} ({scenario_name}) 异常: {error_msg}"
        
        # 使用线程池并行执行
        results = []
        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="LLMWorker") as executor:
            # 提交所有任务（携带重试次数）
            future_to_index = {}
            for i, scenario in enumerate(scenarios, 1):
                future = executor.submit(generate_single, (i, scenario, retry_times))
                future_to_index[future] = i
            
            # 收集结果（带超时控制）
            for future in as_completed(future_to_index):
                index = future_to_index[future]
                try:
                    idx, test_case, error = future.result(timeout=timeout)
                    if error:
                        with log_lock:
                            self.logger.error(f"{error}")
                    elif test_case:
                        results.append((idx, test_case))
                except TimeoutError:
                    with log_lock:
                        counters['failed'] += 1
                        self.logger.error(f"场景 {index} 生成超时（>{timeout}秒）")
                except Exception as e:
                    with log_lock:
                        counters['failed'] += 1
                        self.logger.error(f"场景 {index} 处理异常: {e}")
        
        # 按原始顺序排序
        results.sort(key=lambda x: x[0])
        test_cases = [tc for _, tc in results]
        
        elapsed = time.time() - start_time
        total_events = sum(len(tc.events) for tc in test_cases)
        avg_time = elapsed / len(scenarios) if scenarios else 0
        
        # 详细的汇总日志
        self.logger.info("=" * 60)
        self.logger.info("并行生成汇总:")
        self.logger.info(f"  总场景数: {len(scenarios)}")
        self.logger.info(f"  成功: {counters['completed']} | 失败: {counters['failed']}")
        self.logger.info(f"  生成用例: {len(test_cases)} 个")
        self.logger.info(f"  总进件数: {total_events} 笔")
        self.logger.info(f"  总耗时: {elapsed:.1f}秒")
        self.logger.info(f"  平均每场景: {avg_time:.1f}秒")
        self.logger.info(f"  并发效率: {len(scenarios) * avg_time / elapsed:.1f}x")
        self.logger.info("=" * 60)
        
        return test_cases
    
    def _scenario_to_dict(self, scenario: Any) -> Dict[str, Any]:
        """将场景对象转换为字典"""
        if isinstance(scenario, dict):
            return scenario
        
        return {
            'scenario_id': scenario.scenario_id,
            'scenario_name': scenario.scenario_name,
            'condition_states': scenario.condition_states,
            'expected_rule_hit': scenario.expected_rule_hit,
            'constraint_notes': scenario.constraint_notes
        }
    
    def _extract_related_metrics(self, rule_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        提取规则相关的指标元数据
        
        对于 FORMULA 类型指标，会自动展开其公式中引用的依赖指标。
        """
        related_metrics = {}
        
        # 从条件中提取指标名称
        for cond in rule_info.get('conditions', []):
            if hasattr(cond, 'left_operand'):
                metric_name = cond.left_operand.metric_name
            else:
                metric_name = cond.get('left_operand', {}).get('metric_name')
            
            if metric_name:
                metric_def = self.metadata.get_metric(metric_name)
                if metric_def:
                    related_metrics[metric_name] = metric_def
        
        # 也从metrics列表中提取
        for metric_name in rule_info.get('metrics', []):
            if metric_name and metric_name not in related_metrics:
                metric_def = self.metadata.get_metric(metric_name)
                if metric_def:
                    related_metrics[metric_name] = metric_def
        
        # 展开 FORMULA 指标的依赖（将引用的指标也加入 related_metrics）
        related_metrics = self._expand_formula_dependencies(related_metrics)
        
        return related_metrics
    
    def _expand_formula_dependencies(
        self,
        metrics: Dict[str, Any],
        max_depth: int = 3
    ) -> Dict[str, Any]:
        """
        展开 FORMULA 指标的依赖指标
        
        递归解析 FORMULA 公式中 @metricCode 引用的其他指标，
        将它们也加入 related_metrics，使下游的场景条件、字段条件等能正确提取。
        
        Args:
            metrics: 已知的指标元数据字典
            max_depth: 最大递归深度（防止循环引用）
        
        Returns:
            展开后的指标元数据字典
        """
        from templates.formula_template import FormulaTemplateStrategy
        
        expanded = dict(metrics)
        all_metrics_context = self.metadata.metric_metadata
        fields_context = self.metadata.field_metadata
        
        # 构建 metricCode -> metricName 映射
        code_to_name = {}
        for name, mdef in all_metrics_context.items():
            code = mdef.get('metricCode', '')
            if code:
                code_to_name[code] = name
        
        # 迭代展开（BFS方式，限制深度）
        to_expand = list(expanded.keys())
        for _ in range(max_depth):
            new_metrics = {}
            for metric_name in to_expand:
                metric_def = expanded.get(metric_name)
                if not metric_def or metric_def.get('templateCode') != 'FORMULA':
                    continue
                
                # 创建 FORMULA 策略并设置上下文
                strategy = FormulaTemplateStrategy(metric_def)
                strategy.set_formula_context(all_metrics_context, fields_context)
                
                # 获取引用的指标代码
                ref_codes = strategy.get_referenced_metric_codes()
                for ref_code in ref_codes:
                    ref_name = code_to_name.get(ref_code)
                    if ref_name and ref_name not in expanded and ref_name not in new_metrics:
                        ref_def = self.metadata.get_metric(ref_name)
                        if ref_def:
                            new_metrics[ref_name] = ref_def
                            self.logger.debug(
                                f"FORMULA 依赖展开: {metric_name} -> "
                                f"@{ref_code} = {ref_name}"
                            )
            
            if not new_metrics:
                break  # 没有新指标需要展开
            
            expanded.update(new_metrics)
            to_expand = list(new_metrics.keys())
        
        return expanded
    
    def _extract_related_fields(self, metrics: Dict[str, Any], rule_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        提取字段元数据（从Excel的公共字段和规则集参数列）
        
        Args:
            metrics: 指标元数据字典（仅用于提取指标所需字段）
            rule_info: 规则信息，包含公共字段和规则集参数
        
        Returns:
            字段元数据字典
        
        Raises:
            ValueError: 如果字段在 field_metadata.json 中找不到映射关系
        """
        related_fields = {}
        
        # 1. 从公共字段中提取（Excel中的公共字段列）
        common_fields = rule_info.get('common_fields', {})
        for field_name in common_fields.keys():
            # 尝试通过displayName查找fieldCode
            field_def = self.metadata.get_field_by_display_name(field_name)
            if field_def:
                related_fields[field_def['fieldCode']] = field_def
        
        # 2. 从规则集参数中提取（Excel中的规则集参数列）
        ruleset_params = rule_info.get('ruleset_params', [])
        for field_display_name in ruleset_params:
            field_def = self.metadata.get_field_by_display_name(field_display_name)
            if field_def:
                related_fields[field_def['fieldCode']] = field_def
                
                # 如果是动态计算字段，需要将依赖字段也加入
                if field_def.get('script'):
                    from loaders.metadata_loader import parse_script_dependencies
                    dependencies = parse_script_dependencies(field_def.get('script', ''))
                    for dep_code in dependencies:
                        if dep_code not in related_fields:
                            dep_def = self.metadata.get_field_def(dep_code)
                            if dep_def:
                                related_fields[dep_code] = dep_def
            else:
                # 字段在元数据中找不到，报错
                raise ValueError(
                    f"字段 '{field_display_name}' 在 field_metadata.json 中未找到映射关系。"
                    f"请确保该字段已配置在元数据中，或检查Excel中的字段名称是否正确。"
                )
        
        # 3. 从指标中提取必需的字段（如deviceid, accountlogin等）
        for metric_name, metric_def in metrics.items():
            field_codes = self.metadata.get_metric_required_fields(metric_name)
            for field_code in field_codes:
                if field_code not in related_fields:
                    field_def = self.metadata.get_field_def(field_code)
                    if field_def:
                        related_fields[field_code] = field_def
        
        return related_fields
    
    def _find_field_in_dict(self, field_code: str, fields: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        在字段字典中查找字段定义
        
        Args:
            field_code: 字段代码或显示名称
            fields: 字段字典
        
        Returns:
            字段定义，如果未找到则返回None
        """
        if not field_code:
            return None
        
        # 首先尝试直接查找
        if field_code in fields:
            return fields[field_code]
        
        # 尝试通过 displayName 查找
        for fc, fd in fields.items():
            if fd.get('displayName') == field_code:
                return fd
        
        return None
    
    def _print_rule_inputs_once(self, rule_info: Dict[str, Any]):
        """
        打印规则输入信息（只打印一次）
        
        Args:
            rule_info: 规则信息
        """
        # 提取相关指标元数据
        related_metrics = self._extract_related_metrics(rule_info)
        
        # 提取相关字段元数据
        try:
            related_fields = self._extract_related_fields(related_metrics, rule_info)
        except ValueError as e:
            self.logger.error(f"字段映射错误: {e}")
            return
        
        # 获取公共字段配置
        common_fields = rule_info.get('common_fields', {})
        
        # 打印规则输入信息
        self._log_rule_inputs(rule_info, related_metrics, related_fields, common_fields)
    
    def _log_rule_inputs(
        self,
        rule_info: Dict[str, Any],
        metrics: Dict[str, Any],
        fields: Dict[str, Any],
        common_fields: Dict[str, str]
    ):
        """
        打印规则输入信息（来自Excel的描述）
        """
        self.logger.info("  [规则输入信息]")
        
        # 打印公共字段（来自Excel）
        if common_fields:
            self.logger.info("  - 公共字段（Excel固定值）:")
            for field_name, field_value in common_fields.items():
                self.logger.info(f"    • {field_name}: {field_value}")
        
        # 打印规则集参数（从Excel的"规则集参数"列获取）
        ruleset_params = rule_info.get('ruleset_params', [])
        if ruleset_params:
            self.logger.info("  - 规则集参数（Excel指定，需生成）:")
            for field_display_name in ruleset_params:
                field_def = self._find_field_in_dict(field_display_name, fields)
                if field_def:
                    service_param = field_def.get('serviceParam', '')
                    display_name = field_def.get('displayName', field_display_name)
                    self.logger.info(f"    • {display_name} -> {service_param}")
                else:
                    self.logger.info(f"    • {field_display_name} -> [未找到映射]")
        
        # 打印涉及的指标
        if metrics:
            self.logger.info("  - 涉及指标:")
            for metric_name, metric_def in metrics.items():
                template_code = metric_def.get('templateCode', 'UNKNOWN')
                template_config = metric_def.get('templateConfig', {})
                time_slice = template_config.get('timeSlice', {})
                self_included = time_slice.get('selfIncluded', 'unknown')
                self_str = "含当前" if self_included else "不含当前"
                
                # 根据模板类型显示特定信息
                if template_code == 'SET':
                    set_field = template_config.get('setFieldCode', '')
                    self.logger.info(f"    • {metric_name} ({template_code}, {self_str}, 集合字段:{set_field})")
                elif template_code == 'COUNT':
                    aggregate_by_day = template_config.get('aggregateByDay', False)
                    calc_type = "按天聚合" if aggregate_by_day else "按次计数"
                    self.logger.info(f"    • {metric_name} ({template_code}, {self_str}, {calc_type})")
                elif template_code == 'HISTORY_VALUE':
                    value_method = template_config.get('valueTakenMethod', 'LATEST')
                    value_field = template_config.get('valueTakenFieldCode', '')
                    method_desc = "首笔" if value_method == 'EARLIEST' else "最近一笔"
                    self.logger.info(f"    • {metric_name} ({template_code}, {self_str}, {method_desc}, 取值字段:{value_field})")
                elif template_code == 'FORMULA':
                    formula = template_config.get('formula', '')
                    return_type = template_config.get('returnType', 'DOUBLE')
                    # 提取 @引用 简要展示
                    import re as _re
                    refs = _re.findall(r'@(\w+)', formula)
                    refs_str = ', '.join(f'@{r}' for r in refs[:3])
                    if len(refs) > 3:
                        refs_str += f' 等{len(refs)}个引用'
                    self.logger.info(f"    • {metric_name} ({template_code}, 返回:{return_type}, 引用:{refs_str})")
                elif template_code == 'TIME_GAP':
                    time_calc = template_config.get('timeCalcMethod', 'INTERVAL')
                    time_unit = template_config.get('timeUnit', 'SECOND')
                    unit_map = {'SECOND': '秒', 'MINUTE': '分钟', 'HOUR': '小时', 'DAY': '天'}
                    unit_cn = unit_map.get(time_unit, time_unit)
                    if time_calc == 'INTERVAL':
                        calc = template_config.get('calcMethod', 'AVG')
                        self.logger.info(f"    • {metric_name} ({template_code}, {self_str}, {time_calc}/{calc}, 单位:{unit_cn})")
                    else:
                        taken = template_config.get('valueTakenMethod', 'LATEST')
                        self.logger.info(f"    • {metric_name} ({template_code}, {time_calc}/{taken}, 单位:{unit_cn})")
                elif template_code == 'CONSECUTIVE':
                    calc_method = template_config.get('calcMethod', 'MAX_CONSECUTIVE_COUNT')
                    condition = template_config.get('condition', {})
                    cond_field = condition.get('displayName', condition.get('fieldCode', ''))
                    cond_logic = condition.get('logic', '')
                    cond_ref = condition.get('refValue', '')
                    accumulate = condition.get('accumulateMethod', '')
                    calc_short = 'MAX_COUNT' if calc_method == 'MAX_CONSECUTIVE_COUNT' else 'MAX_ACCUM'
                    extra = f", {accumulate}" if accumulate else ""
                    self.logger.info(f"    • {metric_name} ({template_code}, {self_str}, {calc_short}, {cond_field} {cond_logic} {cond_ref}{extra})")
                elif template_code == 'TREND':
                    calc_method = template_config.get('calcMethod', 'MAX_CONSECUTIVE_COUNT')
                    trend = template_config.get('trend', 'ASC')
                    calc_field = template_config.get('calcFieldCode', '')
                    compare = template_config.get('compareMethod', 'GREATER_THAN')
                    scale = template_config.get('scale', '0')
                    measurement = template_config.get('measurement', 'ABSOLUTE')
                    trend_map = {'ASC': '上升', 'DESC': '下降', 'FLUCTUATION': '波动'}
                    trend_cn = trend_map.get(trend, trend)
                    self.logger.info(f"    • {metric_name} ({template_code}, {self_str}, {calc_method}, {trend_cn}, {calc_field} {compare} {scale} [{measurement}])")
                elif template_code == 'MOVEMENT':
                    calc_method = template_config.get('calcMethod', 'DISTANCE')
                    lng_field = template_config.get('longitudeFieldCode', '')
                    lat_field = template_config.get('latitudeFieldCode', '')
                    calc_map = {'DISTANCE': '移动距离(米)', 'SPEED': '移动速度(米/时)'}
                    calc_cn = calc_map.get(calc_method, calc_method)
                    self.logger.info(f"    • {metric_name} ({template_code}, {self_str}, {calc_cn}, 经度:{lng_field}, 纬度:{lat_field})")
                else:
                    self.logger.info(f"    • {metric_name} ({template_code}, {self_str})")
    
    def _extract_scene_conditions(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        提取指标的场景条件信息
        
        Args:
            metrics: 指标元数据字典
        
        Returns:
            场景条件汇总信息，包含事件类型、渠道、策略等
        """
        scene_conditions = {
            'event_types': set(),      # 事件类型集合
            'app_codes': set(),        # 渠道编码集合
            'policy_codes': set(),     # 策略编码集合
            'scene_field_mapping': {}  # 指标名 -> 场景条件
        }
        
        for metric_name, metric_def in metrics.items():
            scene_cond = metric_def.get('sceneCondition', {})
            if not scene_cond:
                continue
            
            scene_field = scene_cond.get('sceneFieldCode', '')
            scene_type = scene_cond.get('sceneType', '')
            scene_list = scene_cond.get('sceneList', [])
            
            scene_conditions['scene_field_mapping'][metric_name] = {
                'sceneFieldCode': scene_field,
                'sceneType': scene_type,
                'sceneList': scene_list,
                'sceneLogic': scene_cond.get('sceneLogic', 'EQ')
            }
            
            # 根据场景字段类型分类
            if scene_field == 'S_S_EVENTTYPE':
                scene_conditions['event_types'].update(scene_list)
            elif scene_field == 'S_S_APPCODE':
                scene_conditions['app_codes'].update(scene_list)
            elif scene_field == 'S_S_POLICYCODE':
                scene_conditions['policy_codes'].update(scene_list)
        
        # 将集合转换为列表以便序列化
        scene_conditions['event_types'] = list(scene_conditions['event_types'])
        scene_conditions['app_codes'] = list(scene_conditions['app_codes'])
        scene_conditions['policy_codes'] = list(scene_conditions['policy_codes'])
        
        return scene_conditions
    
    def _validate_scene_conditions(
        self,
        scene_conditions: Dict[str, Any],
        common_fields: Dict[str, str],
        metrics: Dict[str, Any],
        rule_info: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        本地验证场景条件匹配性
        
        在调用LLM前，预先检查当前规则配置是否能满足指标的场景条件要求。
        如果当前进件的事件类型/渠道/策略不在指标允许的列表中，则提前告警。
        
        Args:
            scene_conditions: 提取的场景条件信息
            common_fields: 公共字段配置（包含策略事件类型、渠道标识等）
            metrics: 指标元数据
            rule_info: 规则信息（可选，用于从 non_input_fields / event_type 获取策略事件类型）
        
        Returns:
            验证结果 {'valid': bool, 'message': str}
        """
        # 获取当前规则的事件类型
        # 优先级: rule_info['event_type'] > non_input_fields['策略事件类型'] > common_fields['策略事件类型']
        current_event_type_name = ''
        if rule_info:
            current_event_type_name = rule_info.get('event_type', '')
            if not current_event_type_name:
                non_input = rule_info.get('non_input_fields', {})
                current_event_type_name = non_input.get('策略事件类型', '')
        if not current_event_type_name:
            current_event_type_name = common_fields.get('策略事件类型', '')
        
        # 获取当前规则的渠道（从"渠道标识"映射）
        current_channel_name = common_fields.get('渠道标识', '')
        current_app_code = None
        if current_channel_name:
            app_mapping = self.metadata.get_app_mapping(current_channel_name)
            if app_mapping:
                current_app_code = app_mapping.get('appCode')
        
        # 获取当前规则的策略编码（从公共字段或规则信息）
        current_policy_code = common_fields.get('策略编码', '')
        
        # 检查每个指标的场景条件
        for metric_name, scene_cond in scene_conditions.get('scene_field_mapping', {}).items():
            scene_field = scene_cond.get('sceneFieldCode', '')
            scene_list = scene_cond.get('sceneList', [])
            scene_logic = scene_cond.get('sceneLogic', 'EQ')
            
            # 只处理EQ逻辑（目前所有场景条件都是EQ）
            if scene_logic != 'EQ':
                continue
            
            if scene_field == 'S_S_EVENTTYPE' and current_event_type_name:
                # 将中文事件类型名称映射为代码
                event_mapping = self.metadata.get_eventtype_mapping(current_event_type_name)
                if event_mapping:
                    current_event_code = event_mapping.get('name')
                    if current_event_code and current_event_code not in scene_list:
                        return {
                            'valid': False,
                            'message': (f"指标'{metric_name}'要求事件类型为{scene_list}，"
                                      f"但当前规则的事件类型'{current_event_type_name}'"
                                      f"(代码:{current_event_code})不在允许列表中")
                        }
                else:
                    # 如果找不到映射，尝试直接匹配（可能是代码直接传入）
                    if current_event_type_name not in scene_list:
                        # 给警告但不阻止，因为可能是新的事件类型
                        self.logger.warning(
                            f"事件类型'{current_event_type_name}'未在映射表中找到，"
                            f"请确认是否为有效的事件类型代码"
                        )
            
            elif scene_field == 'S_S_APPCODE' and current_app_code:
                if current_app_code not in scene_list:
                    return {
                        'valid': False,
                        'message': (f"指标'{metric_name}'要求渠道编码为{scene_list}，"
                                  f"但当前规则的渠道'{current_channel_name}'"
                                  f"映射为'{current_app_code}'不在允许列表中")
                    }
            
            elif scene_field == 'S_S_POLICYCODE' and current_policy_code:
                if current_policy_code not in scene_list:
                    return {
                        'valid': False,
                        'message': (f"指标'{metric_name}'要求策略编码为{scene_list}，"
                                  f"但当前规则的策略编码'{current_policy_code}'不在允许列表中")
                    }
        
        return {'valid': True, 'message': '场景条件验证通过'}
    
    def _extract_field_conditions(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        提取指标的字段条件(fieldCondition)信息
        
        将复杂的fieldCondition结构转换为易于使用的约束列表，
        用于指导LLM生成满足字段条件的进件序列。
        
        Args:
            metrics: 指标元数据字典
        
        Returns:
            字段条件汇总信息，包含约束列表和原始条件
        """
        field_conditions = {
            'constraints': [],           # 扁平化的约束列表
            'grouped_conditions': {},    # 按指标分组的原始条件
            'all_field_codes': set()     # 所有涉及的字段编码
        }
        
        for metric_name, metric_def in metrics.items():
            field_cond = metric_def.get('fieldCondition', {})
            if not field_cond:
                continue
            
            filter_logic = field_cond.get('filterLogic', 'ALL')
            conditions = field_cond.get('conditions', [])
            
            metric_constraints = []
            
            for cond in conditions:
                # 处理分组条件（groupLogic不为空）
                if cond.get('groupLogic'):
                    group_logic = cond.get('groupLogic', 'AND')
                    sub_conditions = cond.get('conditions', [])
                    
                    group_constraints = []
                    for sub_cond in sub_conditions:
                        constraint = self._parse_field_constraint(sub_cond)
                        if constraint:
                            group_constraints.append(constraint)
                            field_conditions['all_field_codes'].add(constraint['field_code'])
                    
                    if group_constraints:
                        metric_constraints.append({
                            'type': 'group',
                            'logic': group_logic,
                            'constraints': group_constraints
                        })
                
                # 处理叶子条件
                else:
                    constraint = self._parse_field_constraint(cond)
                    if constraint:
                        metric_constraints.append({
                            'type': 'single',
                            'constraint': constraint
                        })
                        field_conditions['all_field_codes'].add(constraint['field_code'])
            
            if metric_constraints:
                field_conditions['grouped_conditions'][metric_name] = {
                    'filterLogic': filter_logic,
                    'constraints': metric_constraints
                }
                field_conditions['constraints'].extend(metric_constraints)
        
        # 将集合转换为列表
        field_conditions['all_field_codes'] = list(field_conditions['all_field_codes'])
        
        return field_conditions
    
    def _parse_field_constraint(self, cond: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        解析单个字段条件为约束对象
        
        Args:
            cond: 原始条件字典
        
        Returns:
            解析后的约束对象，解析失败返回None
        """
        field_code = cond.get('fieldCode', '')
        logic = cond.get('logic', '')
        ref_type = cond.get('refType', '')
        ref_value = cond.get('refValue', '')
        data_type = cond.get('dataType', 'STRING')
        
        if not field_code or not logic:
            return None
        
        # 获取字段的serviceParam（实际API字段名）
        field_def = self.metadata.get_field(field_code)
        service_param = field_def.get('serviceParam', field_code.lower()) if field_def else field_code.lower()
        
        # 转换logic为可读形式
        logic_map = {
            'EQUAL': '等于',
            'NOT_EQUAL': '不等于',
            'GREATER_THAN': '大于',
            'LESS_THAN': '小于',
            'GREATER_THAN_OR_EQUAL': '大于等于',
            'LESS_THAN_OR_EQUAL': '小于等于',
            'IN': '在...中',
            'NOT_IN': '不在...中',
            'IS_NULL': '为空',
            'NOT_NULL': '不为空',
            'CONTAINS': '包含',
            'NOT_CONTAINS': '不包含'
        }
        
        return {
            'field_code': field_code,
            'field_name': service_param,  # 实际使用的字段名
            'logic': logic,
            'logic_desc': logic_map.get(logic, logic),
            'ref_type': ref_type,
            'ref_value': ref_value,
            'data_type': data_type
        }
    
    def _build_missing_fields_retry_prompt(self, failed_response: Dict[str, Any]) -> str:
        """
        构建字段缺失时的补救重试提示
        
        Args:
            failed_response: 缺少字段的响应
        
        Returns:
            重试提示词
        """
        response_preview = json.dumps(failed_response, ensure_ascii=False)[:800]
        
        retry_prompt = f"""你之前的JSON响应缺少必要字段，请补充后重新输出。

**你之前的响应**:
```
{response_preview}
```

**问题**: 响应缺少 `events` 字段，且未标记为不可达场景。

**修正要求**:
1. 如果场景可达，必须返回包含 `events` 数组的JSON：
   {{"analysis": {{"strategy": "...", "event_count": "..."}}, "events": [{{...}}]}}

2. 如果场景确实不可达，必须明确标记：
   {{"analysis": {{"skipped": true, "skip_reason": "详细说明为什么不可达"}}}}

3. 不要只返回 analysis 而忘记 events

请直接输出修正后的完整JSON："""
        
        return retry_prompt
    
    def _retry_fill_missing_fields(
        self,
        events_data: List[Dict[str, Any]],
        missing_fields: List[str],
        param_to_display: Dict[str, str],
        scenario_name: str
    ) -> Optional[List[Dict[str, Any]]]:
        """
        当LLM生成的进件缺少必需业务字段时，构造补全提示让LLM补充缺失字段
        
        Args:
            events_data: 原始LLM生成的进件列表
            missing_fields: 缺失的 serviceParam 列表
            param_to_display: serviceParam -> displayName 映射
            scenario_name: 场景名称
        
        Returns:
            补全后的进件列表，失败返回None
        """
        self.logger.info(f"  - 正在尝试 LLM 补全缺失字段...")
        
        # 构造简洁的进件摘要
        events_summary = json.dumps(events_data, ensure_ascii=False)
        if len(events_summary) > 3000:
            events_summary = events_summary[:3000] + "...(截断)"
        
        missing_desc = ", ".join(
            f"{sp}（{param_to_display.get(sp, sp)}）" for sp in missing_fields
        )
        
        retry_prompt = f"""你生成的测试用例进件数据缺少以下必需的业务字段：{missing_desc}

**你之前生成的进件**：
```json
{events_summary}
```

**修正要求**：
请在每笔进件的 `data` 中补充上述缺失字段，确保：
1. 每笔进件都必须包含这些字段
2. 字段值要符合该场景的测试目的和各条件要求
3. 保持原有字段和结构不变，仅补充缺失字段
4. 直接输出完整的 events JSON 数组

请直接输出修正后的JSON：
{{"events": [...]}}"""
        
        try:
            system_prompt = build_system_prompt()
            response = self.llm_client.call_with_json_retry(
                retry_prompt, system_prompt=system_prompt, max_retries=1
            )
            if response and response.get('events'):
                return response['events']
            else:
                self.logger.warning(f"  - 字段补全重试未返回有效events")
                return None
        except Exception as e:
            self.logger.warning(f"  - 字段补全重试失败: {e}")
            return None
    
    def _confirm_unreachable_scenario(
        self,
        original_prompt: str,
        scenario_name: str,
        skip_reason: str
    ) -> bool:
        """
        二次确认场景是否真的不可达
        
        Args:
            original_prompt: 原始提示词
            scenario_name: 场景名称
            skip_reason: LLM给出的跳过原因
        
        Returns:
            True: 确认不可达
            False: 认为可达，需要重新生成
        """
        confirm_prompt = f"""你之前判断场景 "{scenario_name}" 为不可达，理由是：
"{skip_reason}"

请重新审视这个判断。首先需要区分条件类型：

## 条件类型判断

### 类型A：字段判断型条件（直接比较当前进件字段值）
示例：`BlacklistRuleset Result == Accept`、`payerFirstName != payeeFirstName`
特征：直接判断当前进件的某个字段是否等于/不等于某个值

### 类型B：指标统计型条件（基于历史数据统计）
示例：`30天内交易次数 > 5`、`历史平均金额 >= 1000`
特征：需要统计历史进件数据，有 fieldCondition 过滤条件

## 判断规则

### 对于字段判断型条件的矛盾
**如果两个条件检查的是同一个入参字段（如条件A="字段X == 值1"，条件B="字段X == 值1"），且场景要求它们状态不同（一个true一个false），则确实不可达。**

原因：同一笔进件中，字段X只能有一个值，无法同时满足和不满足相同条件。多笔进件策略对此无效——历史进件无法改变当前进件的字段值。

### 对于指标统计型条件
如果之前误判原因是混淆了 fieldCondition（筛选历史进件）与当前进件字段约束，则可能可达：
- fieldCondition 只限制被统计的历史进件
- 当前验证进件的字段值不受 fieldCondition 限制
- 可以通过多笔进件策略累积指标后再验证

## 请判断

分析你之前给出的跳过原因：
1. 涉及的条件是「字段判断型」还是「指标统计型」？
2. 如果是两个字段判断型条件检查同一字段却要求不同状态，则确实不可达
3. 如果是指标统计型条件，检查是否可以通过多笔进件策略实现

请回答 JSON:
- 确实不可达: {{"confirmed": true, "reason": "确认理由"}}
- 可能可达: {{"confirmed": false, "reason": "之前误判的原因，现在认为可达的理由"}}
"""
        
        # 设置LLM调用上下文
        self.llm_client.set_context(
            scenario_name=scenario_name,
            call_type="confirm_unreachable"
        )
        
        system_prompt = build_system_prompt()
        response = self.llm_client.call_and_parse_json(confirm_prompt, system_prompt=system_prompt)
        
        if not response:
            # 无法解析，保守起见认为可达（重新尝试生成）
            self.logger.warning(f"    二次确认响应解析失败，将尝试重新生成")
            return False
        
        confirmed = response.get('confirmed', False)
        reason = response.get('reason', '')
        
        if confirmed:
            self.logger.info(f"    二次确认结果: 确实不可达 - {reason}")
        else:
            self.logger.info(f"    二次确认结果: 可能可达 - {reason}")
        
        return confirmed
    
    def _build_test_case(
        self,
        response: Dict[str, Any],
        scenario: Dict[str, Any],
        case_index: int,
        rule_info: Dict[str, Any] = None,
        original_prompt: str = None,
        related_metrics: Dict[str, Any] = None
    ) -> Optional[TestCase]:
        """从LLM响应构建TestCase"""
        try:
            # 提取分析
            analysis = response.get('analysis', {})
            
            # 检查是否为不可达场景（LLM判断跳过）
            if analysis.get('skipped', False):
                skip_reason = analysis.get('skip_reason', analysis.get('strategy', '未知原因'))
                self.logger.warning(f"  - 场景 '{scenario['scenario_name']}' 被LLM判定为不可达")
                self.logger.info(f"    跳过原因: {skip_reason}")
                
                # 二次确认：将判断理由反馈给LLM，要求重新审视
                if original_prompt and self.llm_client:
                    self.logger.info(f"  - 正在进行不可达场景二次确认...")
                    confirmed = self._confirm_unreachable_scenario(
                        original_prompt, scenario['scenario_name'], skip_reason
                    )
                    if not confirmed:
                        # 二次确认后认为可达，重新生成
                        self.logger.info(f"  - 二次确认后认为场景可达，重新生成测试用例...")
                        retry_response = self.llm_client.call_with_json_retry(
                            original_prompt, system_prompt=build_system_prompt(), max_retries=1
                        )
                        if retry_response and retry_response.get('events'):
                            # 递归调用，传入 original_prompt=None 避免无限循环
                            # 如果重新生成的结果仍然是 skipped=True，将直接跳过，不再二次确认
                            return self._build_test_case(retry_response, scenario, case_index, rule_info, None)
                        else:
                            self.logger.warning(f"  - 二次确认后重新生成失败或无events")
                    else:
                        self.logger.info(f"  - 二次确认：场景确实不可达")
                
                # 返回一个标记为跳过的TestCase（events为空）
                return TestCase(
                    case_id=f"TC_{case_index:03d}",
                    case_name=f"[跳过] {scenario['scenario_name']}",
                    scenario_name=scenario['scenario_name'],
                    condition_states=scenario['condition_states'],
                    expected_rule_hit=scenario['expected_rule_hit'],
                    events=[],
                    analysis={'skipped': True, 'skip_reason': skip_reason}
                )
            
            # 提取事件列表
            events_data = response.get('events', [])
            
            # 检查可达场景但events为空（这是异常情况）
            if not events_data or len(events_data) == 0:
                self.logger.error(f"  ⚠️ 场景 '{scenario['scenario_name']}' 为可达场景但events为空！")
                return TestCase(
                    case_id=f"TC_{case_index:03d}",
                    case_name=f"[失败] {scenario['scenario_name']}",
                    scenario_name=scenario['scenario_name'],
                    condition_states=scenario['condition_states'],
                    expected_rule_hit=scenario['expected_rule_hit'],
                    events=[],
                    analysis={
                        'failed': True, 
                        'fail_reason': '可达场景但LLM未生成任何进件',
                        'error': '可达场景但LLM未生成任何进件'
                    }
                )
            
            # 调试：检查 rule_info
            if rule_info is None:
                self.logger.warning(f"  [调试] rule_info is None")
            else:
                business_fields = rule_info.get('input_fields_business', rule_info.get('ruleset_params', []))
                self.logger.debug(f"  [调试] input_fields_business: {business_fields}")
            
            # 生成本地配置字段（入参字段-配置，固定值，不通过LLM）
            config_fields_data = self._generate_common_fields_local(rule_info)
            
            # 生成场景唯一的维度字段值（确保场景隔离）
            dim_field_values = self._generate_unique_dim_values(scenario, rule_info, related_metrics)
            
            # 获取非入参字段列表（这些字段不应出现在 data 中）
            non_input_fields = rule_info.get('non_input_fields', {}) if rule_info else {}
            non_input_service_params = set()
            for field_name in non_input_fields.keys():
                field_def = self.metadata.get_field_by_display_name(field_name)
                if field_def:
                    non_input_service_params.add(field_def.get('serviceParam', field_name))
                else:
                    non_input_service_params.add(field_name)
            
            # 预先构建白名单和计算字段集合（在循环外只做一次）
            business_fields = rule_info.get('input_fields_business', []) if rule_info else []
            if not business_fields:
                business_fields = rule_info.get('ruleset_params', []) if rule_info else []
            
            allowed_params = set()
            computed_fields = set()  # 动态计算字段（需要排除）
            # required_business_params: LLM应当生成的业务字段（排除配置字段和维度字段）
            required_business_params = set()
            # 记录 serviceParam -> displayName 的映射，用于日志
            param_to_display = {}
            
            for param in business_fields:
                field_def = self.metadata.get_field_by_display_name(param)
                if field_def:
                    service_param = field_def.get('serviceParam', param)
                    param_to_display[service_param] = param
                    
                    # 检查是否为动态计算字段
                    if field_def.get('script'):
                        computed_fields.add(service_param)
                        # 将依赖字段加入白名单
                        from loaders.metadata_loader import parse_script_dependencies
                        dependencies = parse_script_dependencies(field_def.get('script', ''))
                        for dep_code in dependencies:
                            dep_def = self.metadata.get_field_def(dep_code)
                            if dep_def:
                                dep_sp = dep_def.get('serviceParam', dep_code.lower())
                                allowed_params.add(dep_sp)
                                required_business_params.add(dep_sp)
                                param_to_display[dep_sp] = dep_def.get('displayName', dep_code)
                    else:
                        allowed_params.add(service_param)
                        required_business_params.add(service_param)
                else:
                    allowed_params.add(param)
                    required_business_params.add(param)
                    param_to_display[param] = param
            
            # 从 required 中排除配置字段和维度字段（这些由本地生成，不需要LLM提供）
            config_param_keys = set(config_fields_data.keys())
            dim_param_keys = set(dim_field_values.keys())
            required_from_llm = required_business_params - config_param_keys - dim_param_keys
            
            events = []
            for event_data in events_data:
                # 获取LLM生成的数据
                llm_data = event_data.get('data', {})
                
                # 过滤LLM数据：
                # 1. 只保留业务字段及动态字段的依赖字段
                # 2. 排除动态计算字段（即使LLM错误生成了）
                # 3. 排除非入参字段（如策略事件类型）
                filtered_llm_data = {
                    k: v for k, v in llm_data.items() 
                    if k in allowed_params 
                    and k not in computed_fields
                    and k not in non_input_service_params
                }
                
                # 合并顺序：LLM数据 → 配置字段覆盖 → 维度字段强制覆盖
                event_data_merged = filtered_llm_data.copy()
                event_data_merged.update(config_fields_data)
                event_data_merged.update(dim_field_values)  # 强制覆盖维度字段
                
                event = TestEvent(
                    sequence=event_data.get('sequence', len(events) + 1),
                    purpose=event_data.get('purpose', ''),
                    expected_metric_values=event_data.get('expected_metric_values', {}),
                    expected_condition_hit=event_data.get('expected_condition_hit', False),
                    data=event_data_merged
                )
                events.append(event)
            
            # ====== 字段完整性校验 ======
            # 检查每笔进件是否包含所有必需的业务字段
            field_validation_failed = False
            field_validation_detail = ""
            
            if required_from_llm and events:
                missing_report = []  # [(event_seq, missing_fields)]
                for ev in events:
                    present_keys = set(ev.data.keys())
                    missing = required_from_llm - present_keys
                    if missing:
                        missing_display = [f"{p}({param_to_display.get(p, p)})" for p in sorted(missing)]
                        missing_report.append((ev.sequence, missing))
                
                if missing_report:
                    # 汇总缺失字段
                    all_missing = set()
                    for _, ms in missing_report:
                        all_missing |= ms
                    missing_display = [f"{p}({param_to_display.get(p, p)})" for p in sorted(all_missing)]
                    affected_seqs = [str(seq) for seq, _ in missing_report]
                    
                    self.logger.warning(
                        f"  ⚠️ 场景'{scenario['scenario_name']}' 进件[{','.join(affected_seqs)}]缺少业务字段: "
                        f"{', '.join(missing_display)}"
                    )
                    
                    # 尝试一次补全重试
                    retry_succeeded = False
                    if self.llm_client and original_prompt:
                        retry_events = self._retry_fill_missing_fields(
                            events_data, sorted(all_missing), param_to_display,
                            scenario['scenario_name']
                        )
                        if retry_events is not None:
                            # 用补全后的 events_data 重建 events 列表
                            events = []
                            for event_data in retry_events:
                                llm_data = event_data.get('data', {})
                                filtered_llm_data = {
                                    k: v for k, v in llm_data.items()
                                    if k in allowed_params
                                    and k not in computed_fields
                                    and k not in non_input_service_params
                                }
                                event_data_merged = filtered_llm_data.copy()
                                event_data_merged.update(config_fields_data)
                                event_data_merged.update(dim_field_values)
                                
                                event = TestEvent(
                                    sequence=event_data.get('sequence', len(events) + 1),
                                    purpose=event_data.get('purpose', ''),
                                    expected_metric_values=event_data.get('expected_metric_values', {}),
                                    expected_condition_hit=event_data.get('expected_condition_hit', False),
                                    data=event_data_merged
                                )
                                events.append(event)
                            
                            # 验证补全后是否仍有缺失
                            still_missing_report = []
                            for ev in events:
                                still_missing = required_from_llm - set(ev.data.keys())
                                if still_missing:
                                    still_missing_report.append((ev.sequence, still_missing))
                            
                            if still_missing_report:
                                # 补全后仍有缺失，汇总详情
                                still_all_missing = set()
                                for _, ms in still_missing_report:
                                    still_all_missing |= ms
                                still_missing_display = [
                                    f"{p}({param_to_display.get(p, p)})" for p in sorted(still_all_missing)
                                ]
                                still_affected_seqs = [str(seq) for seq, _ in still_missing_report]
                                
                                field_validation_failed = True
                                field_validation_detail = (
                                    f"补全重试后进件[{','.join(still_affected_seqs)}]仍缺少字段: "
                                    f"{', '.join(still_missing_display)}"
                                )
                                self.logger.error(
                                    f"  ❌ 场景'{scenario['scenario_name']}' {field_validation_detail}"
                                )
                            else:
                                retry_succeeded = True
                                self.logger.info(f"  ✅ 字段补全成功")
                    
                    if not retry_succeeded and not field_validation_failed:
                        # 没有尝试补全或补全未返回有效数据，直接标记失败
                        field_validation_failed = True
                        field_validation_detail = (
                            f"进件[{','.join(affected_seqs)}]缺少业务字段: "
                            f"{', '.join(missing_display)}"
                        )
                        self.logger.error(
                            f"  ❌ 场景'{scenario['scenario_name']}' 字段缺失且无法补全: "
                            f"{', '.join(missing_display)}"
                        )
            
            # 检查每笔进件 data 是否为空（灾难性失败）
            if events:
                empty_data_seqs = [str(ev.sequence) for ev in events if not ev.data]
                if empty_data_seqs:
                    field_validation_failed = True
                    field_validation_detail = f"进件[{','.join(empty_data_seqs)}]的 data 完全为空"
                    self.logger.error(
                        f"  ❌ 场景'{scenario['scenario_name']}' {field_validation_detail}"
                    )
            
            # 根据校验结果构建 TestCase
            if field_validation_failed:
                # 标记为失败的测试用例，保留已生成的 events 以便排查
                analysis['failed'] = True
                analysis['fail_reason'] = f"字段完整性校验失败: {field_validation_detail}"
                
                return TestCase(
                    case_id=f"TC_{case_index:03d}",
                    case_name=f"[字段缺失] {scenario['scenario_name']}",
                    scenario_name=scenario['scenario_name'],
                    condition_states=scenario['condition_states'],
                    expected_rule_hit=scenario['expected_rule_hit'],
                    events=events,
                    analysis=analysis
                )
            
            return TestCase(
                case_id=f"TC_{case_index:03d}",
                case_name=f"{scenario['scenario_name']}",
                scenario_name=scenario['scenario_name'],
                condition_states=scenario['condition_states'],
                expected_rule_hit=scenario['expected_rule_hit'],
                events=events,
                analysis=analysis
            )
            
        except Exception as e:
            self.logger.error(f"构建TestCase失败: {e}")
            return None
    
    def _generate_common_fields_local(self, rule_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        本地生成配置字段（入参字段-配置，固定值，不通过LLM）
        
        Args:
            rule_info: 规则信息
        
        Returns:
            配置字段字典，key为serviceParam，value为映射后的值
        """
        result = {}
        
        # 优先使用新结构（input_fields_config），兼容旧结构（common_fields）
        config_fields = rule_info.get('input_fields_config', {}) if rule_info else {}
        if not config_fields:
            config_fields = rule_info.get('common_fields', {}) if rule_info else {}
        
        # 非入参字段不应出现在进件中（已在新 Excel 结构中分离）
        # 但为兼容旧结构，仍排除可能混入的非入参字段
        non_input_fields = rule_info.get('non_input_fields', {}) if rule_info else {}
        excluded_field_names = set(non_input_fields.keys())
        excluded_field_names.add('策略事件类型')  # 兼容旧结构
        
        for field_name, field_value in config_fields.items():
            # 跳过非入参字段
            if field_name in excluded_field_names:
                continue
            
            # 尝试通过 displayName 查找字段定义
            field_def = self.metadata.get_field_by_display_name(field_name)
            
            if field_def:
                service_param = field_def.get('serviceParam', field_name)
                mapped_value = field_value
                
                # 特殊字段映射处理：渠道标识、机构编号
                if field_name == '渠道标识':
                    app_mapping = self.metadata.get_app_mapping(field_value)
                    if app_mapping:
                        mapped_value = app_mapping.get('appCode', field_value)
                        self.logger.debug(f"渠道映射: {field_value} -> {mapped_value}")
                    else:
                        self.logger.warning(f"渠道标识 '{field_value}' 在 mapping_config.json 中未找到映射")
                elif field_name == '机构编号':
                    org_mapping = self.metadata.get_org_mapping(field_value)
                    if org_mapping:
                        mapped_value = org_mapping.get('orgCode', field_value)
                        self.logger.debug(f"机构映射: {field_value} -> {mapped_value}")
                    else:
                        self.logger.warning(f"机构编号 '{field_value}' 在 mapping_config.json 中未找到映射")
                # 如果是 ENUM 类型，映射值
                elif field_def.get('enumValues', {}) and field_value in field_def.get('enumValues', {}):
                    mapped_value = field_def['enumValues'][field_value]
                
                result[service_param] = mapped_value
            else:
                # 如果找不到映射，使用原字段名
                result[field_name] = field_value
        
        return result
    
    def _generate_unique_dim_values(
        self,
        scenario: Dict[str, Any],
        rule_info: Dict[str, Any],
        related_metrics: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        为场景生成唯一的维度字段值（确保场景隔离）
        
        根据字段的业务含义生成符合格式的唯一值：
        - 手机号：11位数字
        - 银行卡号：16位数字
        - 身份证号：18位符合规则的号码
        - IP地址：合法的IPv4地址
        - 省份/城市：中文名称
        - 其他字符串：字母数字组合
        
        Args:
            scenario: 场景信息
            rule_info: 规则信息
            related_metrics: 展开后的相关指标元数据（包含 FORMULA 依赖指标）
        
        Returns:
            维度字段字典，key为serviceParam，value为唯一值
        """
        result = {}
        dim_fields = set()
        
        # 优先使用展开后的 related_metrics（包含 FORMULA 依赖指标的 dimFieldCode）
        if related_metrics:
            for metric_name, metric_def in related_metrics.items():
                template_config = metric_def.get('templateConfig', {})
                dim_field = template_config.get('dimFieldCode')
                if dim_field:
                    dim_fields.add(dim_field)
        
        # 兜底：从 rule_info['metrics'] 列表提取（兼容未传 related_metrics 的旧调用）
        if not dim_fields:
            metrics = rule_info.get('metrics', []) if rule_info else []
            for metric_name in metrics:
                metric_def = self.metadata.get_metric(metric_name)
                if metric_def:
                    template_config = metric_def.get('templateConfig', {})
                    dim_field = template_config.get('dimFieldCode')
                    if dim_field:
                        dim_fields.add(dim_field)
        
        if not dim_fields:
            return result
        
        # 生成场景唯一标识：场景名 + UUID + 时间戳，确保跨运行绝不碰撞
        scenario_name = scenario.get('scenario_name', 'unknown')
        unique_seed = f"{scenario_name}_{uuid.uuid4().hex}_{time.time_ns()}"
        scenario_hash = hashlib.md5(unique_seed.encode()).hexdigest()
        
        # 为每个维度字段生成符合业务含义的唯一值
        for dim_field in dim_fields:
            field_def = self.metadata.get_field_def(dim_field)
            if field_def:
                service_param = field_def.get('serviceParam', dim_field.lower())
                display_name = field_def.get('displayName', '')
                field_code = field_def.get('fieldCode', dim_field)
                
                # 根据字段特征生成合适格式的唯一值
                unique_value = self._generate_field_value_by_type(
                    service_param, display_name, field_code, scenario_hash
                )
                result[service_param] = unique_value
                self.logger.debug(f"场景'{scenario_name}' 维度字段 {service_param}={unique_value}")
        
        return result
    
    def _generate_field_value_by_type(
        self,
        service_param: str,
        display_name: str,
        field_code: str,
        scenario_hash: str
    ) -> str:
        """
        根据字段类型和业务含义生成符合格式的唯一值
        
        Args:
            service_param: 服务参数名
            display_name: 显示名称
            field_code: 字段编码
            scenario_hash: 场景哈希（UUID+时间戳派生，每次调用都不同）
        
        Returns:
            符合业务含义的唯一值
        """
        # 从场景哈希中提取数字和字母部分
        hash_digits = ''.join(c for c in scenario_hash if c.isdigit())
        if len(hash_digits) < 14:
            hash_digits = hash_digits + ''.join(random.choices(string.digits, k=14 - len(hash_digits)))
        
        # 综合判断字段类型的关键词
        key = (service_param + display_name + field_code).lower()
        
        # 手机号类字段（11位数字）
        if any(kw in key for kw in ['phone', 'mobile', '手机', 'mobino']):
            return f"1{random.choice('3456789')}{hash_digits[:9]}"
        
        # 银行卡号类字段（16-19位数字）
        if any(kw in key for kw in ['cardno', 'bankcard', '银行卡', '卡号']):
            return f"62{hash_digits[:14]}"  # 16位，62开头（银联）
        
        # 身份证号类字段（18位）
        if any(kw in key for kw in ['certid', 'idno', 'idcard', '身份证', '证件号']):
            area_codes = ['110101', '310101', '440106', '510104', '330102', '420106', '320102', '500103']
            area = area_codes[int(hash_digits[0]) % len(area_codes)]
            birth_year = 1970 + int(hash_digits[1:3]) % 35
            birth_month = 1 + int(hash_digits[3:5]) % 12
            birth_day = 1 + int(hash_digits[5:7]) % 28
            seq = hash_digits[7:10]
            check = random.choice('0123456789X')
            return f"{area}{birth_year}{birth_month:02d}{birth_day:02d}{seq}{check}"
        
        # IP地址类字段
        if any(kw in key for kw in ['ipaddr', 'ip地址', 'ipaddress']):
            return f"10.{int(hash_digits[:3]) % 254 + 1}.{int(hash_digits[3:6]) % 254 + 1}.{int(hash_digits[6:9]) % 254 + 1}"
        
        # 省份类字段
        if any(kw in key for kw in ['prov', '省份', '省']):
            provinces = ['北京', '上海', '广东', '浙江', '江苏', '四川', '湖北', '山东']
            return provinces[int(hash_digits[0]) % len(provinces)]
        
        # 城市类字段
        if any(kw in key for kw in ['city', '城市', '市']):
            cities = ['北京市', '上海市', '广州市', '深圳市', '杭州市', '成都市', '武汉市', '南京市']
            return cities[int(hash_digits[0]) % len(cities)]
        
        # 邮箱类字段
        if any(kw in key for kw in ['email', 'mail', '邮箱']):
            return f"u{hash_digits[:8]}@test.com"
        
        # 设备ID类字段（字母数字组合）
        if any(kw in key for kw in ['deviceid', 'device', '设备']):
            return f"DEV{scenario_hash[:12].upper()}"
        
        # 账号/用户类字段
        if any(kw in key for kw in ['account', 'login', 'user', '账号', '用户']):
            return f"user_{scenario_hash[:10]}"
        
        # 订单/流水号类字段
        if any(kw in key for kw in ['order', 'bizid', 'transid', '订单', '流水']):
            return f"ORD{scenario_hash[:12].upper()}"
        
        # 默认：字母数字组合（适用于大多数STRING类型）
        return f"{scenario_hash[:12]}"
    
    def _build_empty_test_case(
        self,
        scenario: Dict[str, Any],
        case_index: int,
        error_message: str = "",
        raw_response: str = ""
    ) -> TestCase:
        """构建空测试用例（当LLM调用失败或验证失败时使用）
        
        标记为 failed=true，表示生成失败（非不可达场景）
        保存最后一次LLM原始响应以便排查问题
        """
        default_error = "LLM未能生成进件序列，请检查API配置或Prompt"
        fail_reason = error_message if error_message else default_error
        analysis = {
            "failed": True,
            "fail_reason": fail_reason,
            "error": fail_reason  # 保持兼容
        }
        
        # 保存原始响应（如果存在）
        if raw_response:
            # 截断过长的响应，避免JSON过大
            max_raw_length = 5000
            if len(raw_response) > max_raw_length:
                analysis["raw_response"] = raw_response[:max_raw_length] + "... [截断]"
                analysis["raw_response_truncated"] = True
            else:
                analysis["raw_response"] = raw_response
        
        return TestCase(
            case_id=f"TC_{case_index:03d}",
            case_name=f"[失败] {scenario['scenario_name']}",
            scenario_name=scenario['scenario_name'],
            condition_states=scenario['condition_states'],
            expected_rule_hit=scenario['expected_rule_hit'],
            events=[],
            analysis=analysis
        )
    
    def _build_mock_test_case(
        self,
        scenario: Dict[str, Any],
        case_index: int
    ) -> TestCase:
        """构建模拟测试用例（dry-run模式）"""
        # 根据场景生成模拟进件
        mock_events = [
            TestEvent(
                sequence=1,
                purpose="[MOCK] 模拟进件1 - 初始化指标",
                expected_metric_values={"指标": {"before": 0, "after": 1}},
                expected_condition_hit=False,
                data={
                    "bizid": "mock_biz_001",
                    "apimodel": 20,
                    "biztime": "2026-01-01 10:00:00",
                    "deviceid": "mock_device_001"
                }
            ),
            TestEvent(
                sequence=2,
                purpose="[MOCK] 模拟进件2 - 触发条件",
                expected_metric_values={"指标": {"before": 1, "after": 2}},
                expected_condition_hit=True,
                data={
                    "bizid": "mock_biz_002",
                    "apimodel": 20,
                    "biztime": "2026-01-01 10:01:00",
                    "deviceid": "mock_device_001"
                }
            )
        ]
        
        return TestCase(
            case_id=f"TC_{case_index:03d}",
            case_name=f"[MOCK] {scenario['scenario_name']}",
            scenario_name=scenario['scenario_name'],
            condition_states=scenario['condition_states'],
            expected_rule_hit=scenario['expected_rule_hit'],
            events=mock_events,
            analysis={"note": "这是DRY RUN模式生成的模拟数据"}
        )


def test_cases_to_dict(test_cases: List[TestCase]) -> List[Dict[str, Any]]:
    """将TestCase列表转换为字典列表"""
    result = []
    
    for tc in test_cases:
        tc_dict = {
            'case_id': tc.case_id,
            'case_name': tc.case_name,
            'scenario': {
                'scenario_name': tc.scenario_name,
                'condition_states': tc.condition_states,
                'expected_rule_hit': tc.expected_rule_hit
            },
            'analysis': tc.analysis,
            'events': [
                {
                    'sequence': e.sequence,
                    'purpose': e.purpose,
                    'expected_metric_values': e.expected_metric_values,
                    'expected_condition_hit': e.expected_condition_hit,
                    'data': e.data
                }
                for e in tc.events
            ]
        }
        result.append(tc_dict)
    
    return result


if __name__ == "__main__":
    # 测试生成器
    print("=" * 60)
    print("进件序列生成器测试")
    print("=" * 60)
    
    generator = SequenceGenerator()
    
    print(f"\n元数据已加载:")
    generator.metadata.print_summary()
    
    # 模拟规则信息
    test_rule = {
        'rule_name': '短时间内，同一设备ID注册成功账户数过多',
        'trigger_logic': '条件1 or 条件2',
        'metrics': [
            '注册_24小时内同一设备ID关联注册成功登录账号个数',
            '注册_60分钟内同一设备ID关联注册成功登录账号个数'
        ],
        'conditions': [],
        'common_fields': {
            '调用类型': '准实时',
            '策略编码': 'test_rule_policy',
            '渠道标识': '测试渠道'
        }
    }
    
    # 提取相关指标
    related_metrics = generator._extract_related_metrics(test_rule)
    print(f"\n相关指标: {list(related_metrics.keys())}")
    
    # 提取相关字段
    related_fields = generator._extract_related_fields(related_metrics)
    print(f"相关字段: {list(related_fields.keys())}")
