"""
LLM通信日志模块 - 记录每次与LLM的交互

日志格式：JSON Lines (.jsonl)
存储位置：logs/llm_calls/
"""

import json
import os
import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List
from threading import Lock
from dataclasses import dataclass, field, asdict


@dataclass
class LLMCallRecord:
    """LLM调用记录"""
    # 基础信息
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    model: str = ""
    
    # 上下文信息（业务场景）
    context: Dict[str, Any] = field(default_factory=dict)
    
    # 请求信息
    system_prompt: str = ""
    user_prompt: str = ""
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    
    # 响应信息
    response_content: str = ""
    tokens_prompt: int = 0
    tokens_completion: int = 0
    tokens_total: int = 0
    finish_reason: str = ""
    
    # 运行指标
    duration_ms: int = 0
    retries: int = 0
    success: bool = True
    
    # 错误信息
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "model": self.model,
            "context": self.context,
            "request": {
                "system_prompt": self.system_prompt,
                "user_prompt": self.user_prompt,
                "temperature": self.temperature,
                "max_tokens": self.max_tokens
            },
            "response": {
                "content": self.response_content,
                "tokens": {
                    "prompt": self.tokens_prompt,
                    "completion": self.tokens_completion,
                    "total": self.tokens_total
                },
                "finish_reason": self.finish_reason
            },
            "metrics": {
                "duration_ms": self.duration_ms,
                "retries": self.retries,
                "success": self.success
            },
            "error": self.error
        }
    
    def to_json(self) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(), ensure_ascii=False)


class LLMLogger:
    """
    LLM通信日志记录器
    
    使用方式：
        logger = LLMLogger(output_dir="output/task_1")
        
        # 开始记录
        record = logger.start_call(model="qwen-plus", context={"rule": "xxx"})
        record.system_prompt = "..."
        record.user_prompt = "..."
        
        # 调用结束后
        logger.end_call(record, response="...", tokens={...})
    """
    
    def __init__(self, output_dir: str = "logs/llm_calls", task_id: Optional[str] = None):
        """
        初始化LLM日志记录器
        
        Args:
            output_dir: 日志输出目录
            task_id: 任务ID，用于日志文件命名，不传则使用时间戳
        """
        self.output_dir = output_dir
        self.task_id = task_id or datetime.now().strftime("%Y%m%d_%H%M%S")
        self._lock = Lock()
        self._call_count = 0
        self._total_tokens = 0
        self._total_duration_ms = 0
        
        # 确保目录存在
        os.makedirs(output_dir, exist_ok=True)
        
        # 日志文件路径
        self.log_file = os.path.join(output_dir, f"llm_calls_{self.task_id}.jsonl")
        
        # 写入会话开始标记
        self._write_session_start()
    
    def _write_session_start(self):
        """写入会话开始标记"""
        session_info = {
            "type": "session_start",
            "task_id": self.task_id,
            "started_at": datetime.now().isoformat()
        }
        self._append_line(json.dumps(session_info, ensure_ascii=False))
    
    def _append_line(self, line: str):
        """线程安全地追加一行到日志文件"""
        with self._lock:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(line + '\n')
    
    def start_call(
        self,
        model: str = "",
        context: Optional[Dict[str, Any]] = None
    ) -> LLMCallRecord:
        """
        开始一次LLM调用记录
        
        Args:
            model: 模型名称
            context: 业务上下文（规则名、场景名等）
        
        Returns:
            LLMCallRecord 对象，调用者需要填充请求信息
        """
        self._call_count += 1
        record = LLMCallRecord(
            model=model,
            context=context or {}
        )
        return record
    
    def end_call(
        self,
        record: LLMCallRecord,
        response: str = "",
        tokens: Optional[Dict[str, int]] = None,
        duration_ms: int = 0,
        retries: int = 0,
        success: bool = True,
        error: Optional[str] = None,
        finish_reason: str = ""
    ):
        """
        结束一次LLM调用记录并写入日志
        
        Args:
            record: 调用记录
            response: LLM响应内容
            tokens: Token使用量 {"prompt": x, "completion": y, "total": z}
            duration_ms: 调用耗时（毫秒）
            retries: 重试次数
            success: 是否成功
            error: 错误信息
            finish_reason: 结束原因
        """
        record.response_content = response
        record.duration_ms = duration_ms
        record.retries = retries
        record.success = success
        record.error = error
        record.finish_reason = finish_reason
        
        if tokens:
            record.tokens_prompt = tokens.get('prompt', 0)
            record.tokens_completion = tokens.get('completion', 0)
            record.tokens_total = tokens.get('total', 0)
        
        # 更新统计
        self._total_tokens += record.tokens_total
        self._total_duration_ms += duration_ms
        
        # 写入日志
        self._append_line(record.to_json())
    
    def log_call(
        self,
        model: str,
        system_prompt: str,
        user_prompt: str,
        response: str,
        tokens: Optional[Dict[str, int]] = None,
        duration_ms: int = 0,
        retries: int = 0,
        success: bool = True,
        error: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        finish_reason: str = ""
    ):
        """
        一次性记录完整的LLM调用（简化API）
        
        适用于已有调用结果后的记录场景
        """
        record = self.start_call(model=model, context=context)
        record.system_prompt = system_prompt
        record.user_prompt = user_prompt
        record.temperature = temperature
        record.max_tokens = max_tokens
        
        self.end_call(
            record=record,
            response=response,
            tokens=tokens,
            duration_ms=duration_ms,
            retries=retries,
            success=success,
            error=error,
            finish_reason=finish_reason
        )
    
    def write_session_end(self):
        """写入会话结束标记和统计信息"""
        session_summary = {
            "type": "session_end",
            "task_id": self.task_id,
            "ended_at": datetime.now().isoformat(),
            "summary": {
                "total_calls": self._call_count,
                "total_tokens": self._total_tokens,
                "total_duration_ms": self._total_duration_ms,
                "avg_duration_ms": round(self._total_duration_ms / self._call_count, 1) if self._call_count > 0 else 0
            }
        }
        self._append_line(json.dumps(session_summary, ensure_ascii=False))
    
    def get_stats(self) -> Dict[str, Any]:
        """获取当前统计信息"""
        return {
            "call_count": self._call_count,
            "total_tokens": self._total_tokens,
            "total_duration_ms": self._total_duration_ms,
            "log_file": self.log_file
        }


# 全局LLM日志实例
_llm_logger: Optional[LLMLogger] = None


def setup_llm_logger(output_dir: str, task_id: Optional[str] = None) -> LLMLogger:
    """设置并初始化全局LLM日志实例"""
    global _llm_logger
    _llm_logger = LLMLogger(output_dir=output_dir, task_id=task_id)
    return _llm_logger


def get_llm_logger() -> Optional[LLMLogger]:
    """获取全局LLM日志实例"""
    return _llm_logger


if __name__ == "__main__":
    # 测试日志记录
    print("=" * 60)
    print("LLM日志模块测试")
    print("=" * 60)
    
    # 创建日志记录器
    logger = LLMLogger(output_dir="logs/llm_calls", task_id="test_001")
    print(f"日志文件: {logger.log_file}")
    
    # 模拟调用1
    record = logger.start_call(
        model="qwen-plus",
        context={"rule_name": "测试规则", "scenario": "场景1"}
    )
    record.system_prompt = "你是一个风控测试专家。"
    record.user_prompt = "请分析以下规则..."
    record.temperature = 0.7
    
    # 模拟响应
    logger.end_call(
        record=record,
        response='{"analysis": "...", "events": [...]}',
        tokens={"prompt": 100, "completion": 200, "total": 300},
        duration_ms=1500,
        success=True,
        finish_reason="stop"
    )
    
    # 模拟调用2（失败）
    logger.log_call(
        model="qwen-plus",
        system_prompt="你是一个风控测试专家。",
        user_prompt="请生成测试用例...",
        response="",
        error="API超时",
        duration_ms=30000,
        success=False,
        context={"rule_name": "测试规则", "scenario": "场景2"}
    )
    
    # 写入会话结束
    logger.write_session_end()
    
    # 打印统计
    stats = logger.get_stats()
    print(f"\n统计信息:")
    print(f"  - 调用次数: {stats['call_count']}")
    print(f"  - Token总量: {stats['total_tokens']}")
    print(f"  - 总耗时: {stats['total_duration_ms']}ms")
    
    # 读取并显示日志内容
    print(f"\n日志文件内容:")
    with open(logger.log_file, 'r', encoding='utf-8') as f:
        for line in f:
            data = json.loads(line)
            if data.get('type') == 'session_start':
                print(f"  [会话开始] {data['started_at']}")
            elif data.get('type') == 'session_end':
                print(f"  [会话结束] 共{data['summary']['total_calls']}次调用")
            else:
                print(f"  [调用] {data['id']} | {data['context']} | 成功:{data['metrics']['success']}")
