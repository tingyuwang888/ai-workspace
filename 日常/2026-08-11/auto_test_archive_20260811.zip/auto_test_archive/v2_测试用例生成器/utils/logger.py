"""
日志和控制台打印工具 - 提供彩色输出、进度提示、详细日志
"""

import sys
from datetime import datetime
from typing import Optional, Any
from enum import Enum


class Color(Enum):
    """终端颜色代码"""
    RESET = '\033[0m'
    BOLD = '\033[1m'
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    GRAY = '\033[90m'


class Logger:
    """日志和控制台打印工具"""
    
    VERSION = "1.0"
    
    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self.step_count = 0
        self.total_steps = 0
    
    def _color(self, text: str, color: Color) -> str:
        """为文本添加颜色"""
        return f"{color.value}{text}{Color.RESET.value}"
    
    def _bold(self, text: str) -> str:
        """加粗文本"""
        return f"{Color.BOLD.value}{text}{Color.RESET.value}"
    
    # ======================== 分隔线和标题 ========================
    
    def separator(self, char: str = "=", length: int = 80):
        """打印分隔线"""
        print(char * length)
    
    def title(self, text: str, char: str = "=", length: int = 80):
        """打印居中标题"""
        self.separator(char, length)
        padding = (length - len(text)) // 2
        print(" " * padding + self._bold(text))
        self.separator(char, length)
    
    def section(self, text: str, char: str = "-", length: int = 60):
        """打印章节标题"""
        print()
        print(self._color(char * length, Color.GRAY))
        print(self._bold(self._color(text, Color.CYAN)))
        print(self._color(char * length, Color.GRAY))
    
    # ======================== 进度提示 ========================
    
    def set_total_steps(self, total: int):
        """设置总步骤数"""
        self.total_steps = total
        self.step_count = 0
    
    def step(self, current_or_desc, total: Optional[int] = None, description: Optional[str] = None):
        """
        打印步骤进度
        
        支持两种调用方式：
        - step("描述") - 自动递增步骤
        - step(1, 6, "描述") - 指定步骤号
        """
        if total is not None and description is not None:
            # step(1, 6, "描述") 方式
            step_text = f"[{current_or_desc}/{total}]"
            desc = description
        else:
            # step("描述") 方式
            self.step_count += 1
            step_text = f"[{self.step_count}/{self.total_steps}]" if self.total_steps > 0 else f"[{self.step_count}]"
            desc = current_or_desc
        print(f"\n{self._color(step_text, Color.BLUE)} {self._bold(desc)}")
    
    def substep(self, description: str, indent: int = 2):
        """打印子步骤"""
        prefix = " " * indent + "- "
        print(f"{prefix}{description}")
    
    def progress(self, current: int, total: int, description: str = ""):
        """打印进度条"""
        percent = (current / total) * 100 if total > 0 else 0
        bar_length = 30
        filled = int(bar_length * current / total) if total > 0 else 0
        bar = "█" * filled + "░" * (bar_length - filled)
        desc = f" {description}" if description else ""
        print(f"\r  [{bar}] {percent:5.1f}%{desc}", end="", flush=True)
        if current >= total:
            print()  # 换行
    
    # ======================== 状态消息 ========================
    
    def info(self, message: str, indent: int = 0):
        """信息消息"""
        prefix = " " * indent
        print(f"{prefix}{self._color('ℹ', Color.BLUE)} {message}")
    
    def success(self, message: str, indent: int = 0):
        """成功消息"""
        prefix = " " * indent
        print(f"{prefix}{self._color('✓', Color.GREEN)} {message}")
    
    def warning(self, message: str, indent: int = 0):
        """警告消息"""
        prefix = " " * indent
        print(f"{prefix}{self._color('⚠', Color.YELLOW)} {message}")
    
    def error(self, message: str, indent: int = 0):
        """错误消息"""
        prefix = " " * indent
        print(f"{prefix}{self._color('✗', Color.RED)} {message}")
    
    def debug(self, message: str, indent: int = 0):
        """调试消息（仅verbose模式）"""
        if self.verbose:
            prefix = " " * indent
            print(f"{prefix}{self._color('→', Color.GRAY)} {message}")
    
    # ======================== 数据展示 ========================
    
    def key_value(self, key: str, value: Any, indent: int = 2):
        """打印键值对"""
        prefix = " " * indent
        print(f"{prefix}{self._color(key, Color.CYAN)}: {value}")
    
    def list_item(self, item: str, index: Optional[int] = None, indent: int = 2):
        """打印列表项"""
        prefix = " " * indent
        if index is not None:
            print(f"{prefix}{self._color(f'{index}.', Color.GRAY)} {item}")
        else:
            print(f"{prefix}{self._color('•', Color.GRAY)} {item}")
    
    def json_preview(self, data: dict, max_lines: int = 10, indent: int = 2):
        """预览JSON数据"""
        import json
        lines = json.dumps(data, ensure_ascii=False, indent=2).split('\n')
        prefix = " " * indent
        for i, line in enumerate(lines[:max_lines]):
            print(f"{prefix}{self._color(line, Color.GRAY)}")
        if len(lines) > max_lines:
            print(f"{prefix}{self._color(f'... (共 {len(lines)} 行)', Color.GRAY)}")
    
    # ======================== 规则相关 ========================
    
    def rule_header(self, rule_index: int, total_rules: int, rule_name: str):
        """打印规则处理头部"""
        print()
        self.separator("=", 80)
        header = f"处理规则 {rule_index}/{total_rules}: {rule_name}"
        print(self._bold(self._color(header, Color.MAGENTA)))
        self.separator("=", 80)
    
    def condition(self, condition_id: str, condition_text: str, condition_type: str, indent: int = 2):
        """打印条件信息"""
        prefix = " " * indent
        # 根据条件类型选择颜色 - 所有指标类型都显示绿色
        metric_types = {
            "聚合指标型", "关联类指标型", "次数类指标型", "求和类指标型",
            "平均类指标型", "最大类指标型", "最小类指标型", "历史取值类指标型",
            "时间差类指标型", "连续类指标型", "趋势类指标型", "公式类指标型",
            "地理位置类指标型", "链式类指标型"
        }
        type_color = Color.GREEN if condition_type in metric_types else Color.YELLOW
        print(f"{prefix}{self._color(condition_id, Color.CYAN)}: {condition_text} "
              f"[{self._color(condition_type, type_color)}]")
    
    def scenario(self, scenario_index: int, scenario_name: str, expected_result: bool, indent: int = 2):
        """打印场景信息"""
        prefix = " " * indent
        result_text = "规则触发" if expected_result else "规则不触发"
        result_color = Color.GREEN if expected_result else Color.RED
        print(f"{prefix}场景{scenario_index}: {scenario_name} -> {self._color(result_text, result_color)}")
    
    def dependency(self, description: str, indent: int = 2):
        """打印依赖关系"""
        prefix = " " * indent
        print(f"{prefix}{self._color('⊂', Color.YELLOW)} {description}")
    
    def event_generated(self, scenario_name: str, event_count: int, indent: int = 2):
        """打印事件生成结果"""
        prefix = " " * indent
        print(f"{prefix}{scenario_name}: 生成 {self._color(str(event_count), Color.CYAN)} 笔进件 "
              f"{self._color('✓', Color.GREEN)}")
    
    # ======================== 启动和完成 ========================
    
    def banner(self, title: Optional[str] = None):
        """打印启动横幅"""
        self.separator("=", 80)
        print()
        display_title = title if title else "风控规则测试用例生成器"
        version = f"v{self.VERSION}"
        padding = (80 - len(display_title) - len(version) - 4) // 2
        print(" " * padding + self._bold(self._color(display_title, Color.CYAN)) + 
              "  " + self._color(version, Color.GRAY))
        print()
        self.separator("=", 80)
    
    def section_header(self, text: str):
        """打印章节标题（居中）"""
        print()
        self.separator("=", 80)
        padding = (80 - len(text)) // 2
        print(" " * padding + self._bold(self._color(text, Color.GREEN)))
        self.separator("=", 80)
    
    def divider(self):
        """打印分隔线"""
        self.separator("=", 80)
    
    def summary(self, output_file: str, case_count: int, event_count: int):
        """打印完成摘要"""
        print()
        self.separator("=", 80)
        print(self._bold(self._color("                              生成完成", Color.GREEN)))
        self.separator("=", 80)
        self.key_value("输出文件", output_file)
        self.key_value("测试用例", f"{case_count} 个")
        self.key_value("总进件数", f"{event_count} 笔")
        self.separator("=", 80)
    
    def timestamp(self) -> str:
        """获取当前时间戳"""
        return datetime.now().strftime("%Y%m%d_%H%M%S")


# 全局日志实例
_logger: Optional[Logger] = None


def setup_logger(verbose: bool = True) -> Logger:
    """设置并初始化全局日志实例"""
    global _logger
    _logger = Logger(verbose=verbose)
    return _logger


def get_logger(verbose: bool = True) -> Logger:
    """获取全局日志实例"""
    global _logger
    if _logger is None:
        _logger = Logger(verbose=verbose)
    return _logger


if __name__ == "__main__":
    # 测试日志输出
    logger = get_logger()
    
    logger.banner()
    
    logger.set_total_steps(6)
    
    logger.step("加载元数据")
    logger.substep("字段元数据: 124 个字段")
    logger.substep("指标元数据: 3 个指标")
    logger.substep("映射配置: app_mapping(1), org_mapping(1)")
    
    logger.step("读取Excel规则文件")
    logger.key_value("文件", "资产环境1测试用例.xlsx")
    logger.key_value("规则数量", "1 条")
    
    logger.rule_header(1, 1, "短时间内，同一设备ID注册成功账户数过多")
    
    logger.step("解析规则描述")
    logger.condition("条件1", "注册_24小时内同一设备ID关联注册成功登录账号个数>=5", "聚合指标型")
    logger.condition("条件2", "注册_60分钟内同一设备ID关联注册成功登录账号个数>=3", "聚合指标型")
    logger.substep("触发逻辑: 条件1 or 条件2")
    
    logger.step("枚举测试场景")
    logger.scenario(1, "仅条件1触发", True)
    logger.scenario(2, "仅条件2触发", True)
    logger.scenario(3, "都触发", True)
    logger.scenario(4, "都不触发", False)
    logger.substep("共 4 个场景")
    
    logger.step("分析指标依赖")
    logger.dependency("发现依赖: 60分钟 ⊂ 24小时（时间窗口包含）")
    logger.substep("场景1约束: 需要将进件分散到60分钟外但24小时内")
    
    logger.step("生成进件序列")
    logger.event_generated("场景1", 6)
    logger.event_generated("场景2", 4)
    logger.event_generated("场景3", 6)
    logger.event_generated("场景4", 2)
    
    logger.summary("output/test_cases_20260305_140000.json", 4, 18)
