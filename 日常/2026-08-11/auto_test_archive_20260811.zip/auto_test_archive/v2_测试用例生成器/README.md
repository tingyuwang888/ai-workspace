# 风控规则测试用例生成器 v2.0

> 基于大模型的智能测试用例生成工具，支持指标累积触发机制的自动化测试。

## 项目概述

本项目将原有单文件架构重构为模块化分层架构，实现了从Excel规则文件到标准化测试用例（JSON格式）的全自动转换。核心能力包括规则解析、场景枚举、指标依赖分析和LLM驱动的进件序列生成。

## 核心特性

- **指标累积触发机制**：通过有序进件序列累积触发指标，非直接设置值
- **双指标型条件支持**：左右操作数均可为指标（如 A > B）
- **指标依赖分析**：自动识别时间窗口包含关系（如60分钟 ⊂ 24小时）
- **全量模板类型识别**：支持Salaxy平台10种指标模板
- **场景条件过滤**：本地验证事件类型、渠道、策略匹配性
- **字段条件约束**：自动提取并应用fieldCondition进件约束
- **OpenAI兼容API**：支持多模型、多地域部署

## 技术架构

```
auto_test_v2/
├── config/              # 配置管理
│   ├── settings.py      # 项目配置（路径、API、元数据）
│   └── .env             # 环境变量（API密钥、模型配置）
├── loaders/             # 数据加载层
│   ├── excel_loader.py      # Excel规则文件解析
│   ├── metadata_loader.py   # 指标/字段元数据加载
│   └── rule_parser.py       # 规则描述解析（支持10种模板类型）
├── analyzers/           # 规则分析层
│   ├── scenario_enumerator.py   # 测试场景枚举
│   └── dependency_analyzer.py   # 指标依赖分析与可行性筛选
├── llm/                 # 大模型交互层
│   ├── client.py        # OpenAI兼容API客户端
│   └── prompts.py       # Prompt模板管理
├── generators/          # 测试用例生成层
│   └── sequence_generator.py    # 进件序列生成器
├── output/              # 输出层
│   └── json_writer.py   # JSON格式化输出
├── utils/               # 工具层
│   └── logger.py        # 彩色日志输出
├── base_info/           # 元数据目录
│   ├── filed_metadata.json      # 字段元数据（124个字段定义）
│   ├── salaxy_metadata.json     # 指标元数据（10个指标定义）
│   └── mapping_config.json      # 映射配置（事件类型、渠道等）
└── main.py              # CLI入口
```

## 执行流程

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         风控规则测试用例生成流程                               │
└─────────────────────────────────────────────────────────────────────────────┘

[步骤1] 加载元数据
    ├── 字段元数据 (filed_metadata.json) - 124个字段定义
    ├── 指标元数据 (salaxy_metadata.json) - 10个指标定义
    └── 映射配置 (mapping_config.json) - 事件类型、渠道映射

[步骤2] 读取Excel规则
    └── 解析规则文件，提取规则名称、描述、公共字段等

[步骤3] 解析规则描述
    ├── 识别条件表达式（如：指标A >= 5）
    ├── 解析操作数类型（指标型/字段型/常量型）
    ├── 识别指标模板类型（SET/COUNT/SUM等10种）
    └── 提取触发逻辑（AND/OR组合）

[步骤4] 枚举测试场景
    ├── 基于条件数量生成2^n种状态组合
    ├── 计算每种组合的规则触发结果
    └── 生成场景名称（如："都触发"、"仅条件1触发"）

[步骤5] 分析指标依赖
    ├── 提取条件涉及的指标
    ├── 分析时间窗口包含关系（如60分钟 ⊂ 24小时）
    ├── 构建条件-指标映射
    └── 筛选可行场景（剔除有冲突的组合）

[步骤6] 生成进件序列
    ├── 提取相关指标元数据
    ├── 提取场景条件（sceneCondition）
    │   └── 本地验证：事件类型、渠道、策略匹配性
    ├── 提取字段条件（fieldCondition）
    │   └── 如：transstat=1, amount>40000
    ├── 构建Prompt（含场景条件+字段条件约束）
    ├── 调用LLM生成进件序列
    └── 解析响应构建TestCase

[输出] JSON格式测试用例
    ├── 规则元数据
    ├── 测试用例列表（每个场景一个用例）
    ├── 进件序列（每笔进件的字段值）
    └── 统计摘要
```

### 核心处理逻辑

#### 1. 规则解析
将自然语言规则描述解析为结构化数据：
```
输入: "注册_24小时内同一设备ID关联注册成功登录账号个数>=5"
输出: {
    left_operand: {type: "关联类指标", metric_name: "注册_24小时内..."},
    operator: ">=",
    right_operand: {type: "常量型", value: "5"}
}
```

#### 2. 场景枚举
基于触发逻辑枚举所有可能的条件状态组合：
```
条件: [条件1, 条件2]
触发逻辑: "条件1 or 条件2"

枚举结果:
- 都触发 (T, T) -> 规则触发
- 仅条件1触发 (T, F) -> 规则触发
- 仅条件2触发 (F, T) -> 规则触发
- 都不触发 (F, F) -> 规则不触发
```

#### 3. 指标依赖分析
识别指标间的时间窗口包含关系，筛选可行场景：
```
指标A: 60分钟内... (时间窗口: 60分钟)
指标B: 24小时内... (时间窗口: 24小时)

依赖关系: 指标A ⊂ 指标B (60分钟窗口被24小时窗口包含)

可行性判断:
- "仅A触发"场景可行（A触发时B一定触发）
- "仅B触发"场景不可行（B触发时A可能不触发）
```

#### 4. 场景条件验证
本地验证规则配置与指标要求的匹配性：
```
指标要求: eventtype = "Register"
规则配置: 策略事件类型 = "登录事件" (对应Login)

验证结果: ❌ 不匹配，提前告警不调用LLM
```

#### 5. 字段条件约束
提取并应用指标的fieldCondition约束：
```
指标: 注册_24小时内...
字段条件: transstat EQUAL 1

Prompt约束:
"每笔进件的transstat字段必须等于1"
```

## 支持的指标模板类型

| 模板代码 | 中文名称 | 典型场景 |
|---------|---------|---------|
| SET | 关联类指标 | 同一设备关联的登录账号个数（去重计数） |
| COUNT | 次数类指标 | 登录次数、交易次数 |
| STATISTICS (SUM/AVG/MAX/MIN) | 统计类指标 | 累计金额、平均值、最大/最小值 |
| LATEST / HISTORY_VALUE | 历史取值类 | 最近一笔交易金额 |
| TIME_GAP / TIME_DIFF | 时间差类 | 两次登录间隔 |
| CONSECUTIVE / CONTINUOUS | 连续类 | 连续失败次数 |
| TREND | 趋势类 | 金额连续递增/递减 |
| FORMULA | 公式类 | 自定义公式计算 |
| GEO | 地理位置类 | 登录位置移动距离 |
| CHAIN | 链式类 | 多阶段行为链（开户→试探→大额出账） |

## 快速开始

### 1. 环境准备

```bash
# 创建虚拟环境
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
# 或 .venv\Scripts\activate  # Windows

# 安装依赖
pip install -r requirements.txt
```

### 2. 配置环境变量

创建 `.env` 文件：

```env
# DashScope API配置
DASHSCOPE_API_KEY=your_api_key_here
LLM_MODEL=qwen-plus
LLM_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
```

### 3. 准备元数据

确保 `base_info/` 目录包含：
- `filed_metadata.json` - 字段元数据
- `salaxy_metadata.json` - 指标元数据
- `mapping_config.json` - 映射配置

### 4. 运行测试用例生成

```bash
python main.py --input 规则文件.xlsx --output ./output
```

**参数说明：**
- `-i, --input`：Excel规则文件路径（必需）
- `-o, --output`：输出目录（默认：./output）
- `-v, --verbose`：输出详细日志
- `--dry-run`：模拟运行，不调用LLM

## 输入格式

Excel规则文件需包含以下列：

| 列名 | 说明 | 示例 |
|-----|------|------|
| 策略名称 | 策略标识 | test_ruleset |
| 策略标识 | 策略编码 | test_ruleset |
| **策略事件类型** | **事件类型（用于场景条件验证）** | **注册事件** |
| 规则集名称 | 规则集名称 | 规则集命中测试 |
| 规则编号 | 规则编号 | AD120526 |
| 规则名称 | 规则名称 | 短时间内，同一设备ID注册成功账户数过多 |
| 规则描述 | 条件描述 | 条件1：注册_24小时内...>=5\n条件2：... |
| 指标 | 涉及的指标 | 注册_24小时内...\n注册_60分钟内... |
| 规则集参数 | 参数列表 | 业务流水号\n业务发生时间... |
| 公共字段 | 通用字段 | 调用类型=准实时\n策略编码=... |

### 场景条件验证

系统会根据"策略事件类型"列的值进行本地验证：

```
指标要求: eventtype = "Register" (注册事件)
Excel配置: 策略事件类型 = "注册事件"

验证流程:
1. 从 mapping_config.json 查找 "注册事件" -> "Register"
2. 检查 "Register" 是否在指标允许的 sceneList 中
3. 匹配通过则继续，不匹配则提前告警
```

支持的事件类型映射：
- 注册事件 -> Register
- 登录事件 -> Login
- 转账事件 -> Transfer
- ... (详见 mapping_config.json 中的 eventtypes_mapping)

## 输出格式

生成的JSON文件包含以下结构：

```json
{
  "metadata": {
    "version": "2.0.0",
    "generated_at": "2026-03-06T10:06:27",
    "rule_name": "短时间内，同一设备ID注册成功账户数过多"
  },
  "rule_info": {
    "rule_name": "...",
    "trigger_logic": "条件1 or 条件2",
    "conditions": [...]
  },
  "test_cases": [
    {
      "case_id": "TC_001",
      "case_name": "都触发",
      "scenario": "条件1=True, 条件2=True",
      "expected_rule_hit": true,
      "analysis": {...},
      "events": [
        {
          "sequence": 1,
          "purpose": "...",
          "expected_condition_hit": {...},
          "data": {...}
        }
      ]
    }
  ],
  "summary": {
    "total_test_cases": 4,
    "total_events": 20,
    "rule_hit_cases": 3,
    "rule_not_hit_cases": 1
  }
}
```

## 运行示例

```bash
$ python main.py --input 资产环境1测试用例.xlsx --output ./output

================================================================================
                           风控规则测试用例生成器 v2.0.0
================================================================================
[1/6] 加载元数据...
  - 字段元数据: 124 个字段
  - 指标元数据: 10 个指标
  - 映射配置: app_mapping(1), org_mapping(1)
[2/6] 读取Excel规则文件...
  - 文件: 资产环境1测试用例.xlsx
  - 规则数量: 1 条
[3/6] 解析规则描述...
  - 条件1: 注册_24小时内...>=5...
    类型: 左=关联类指标, 右=常量型
  - 条件2: 注册_60分钟内...>=3...
    类型: 左=关联类指标, 右=常量型
[4/6] 枚举测试场景...
  - 都触发 -> 规则触发
  - 仅条件1触发 -> 规则触发
  - 仅条件2触发 -> 规则触发
  - 都不触发 -> 规则不触发
[5/6] 分析指标依赖...
  - 可行场景: 4/4 个
[6/6] 生成进件序列...
  都触发: 生成 6 笔进件 ✓
  仅条件1触发: 生成 6 笔进件 ✓
  仅条件2触发: 生成 4 笔进件 ✓
  都不触发: 生成 4 笔进件 ✓

✓ 测试用例已写入: ./output/test_cases_..._20260306_100627.json

================================================================================
                                      全部完成
================================================================================
  - 处理规则: 1/1 条
  - 生成用例: 4 个
  - 总进件数: 20 笔
  - 输出目录: ./output
```

## 项目状态

- **当前版本：** v2.0.0
- **开发状态：** 核心功能完成，已投入实际使用
- **已实现功能：**
  - ✅ 10种指标模板类型识别
  - ✅ 双指标型条件支持（A > B）
  - ✅ 指标依赖分析（时间窗口包含关系）
  - ✅ 场景条件本地验证（eventtype/appcode/policycode）
  - ✅ 字段条件约束（fieldCondition）
  - ✅ OpenAI兼容API支持
- **测试覆盖：** 已通过真实业务规则验证

## 后续规划

1. **功能扩展**
   - [ ] 支持更复杂的规则嵌套和混合逻辑
   - [ ] 支持自定义指标模板扩展

2. **性能优化**
   - [ ] LLM调用并发化
   - [ ] 响应缓存机制
   - [ ] 批量规则并行处理

3. **工程化**
   - [ ] 单元测试覆盖（当前0%）
   - [ ] 异常处理增强
   - [ ] 代码质量优化（格式化、重构）

4. **平台对接**
   - [ ] 与测试平台集成
   - [ ] 实现一键导入测试用例
   - [ ] 测试结果回传

## 依赖说明

| 依赖包 | 版本 | 用途 |
|-------|------|------|
| pandas | >=2.0.0 | Excel文件处理 |
| openpyxl | >=3.1.0 | Excel格式支持 |
| openai | >=1.0.0 | OpenAI兼容API调用 |
| python-dotenv | >=1.0.0 | 环境变量管理 |
| requests | >=2.31.0 | HTTP请求（备用） |

## 许可证

内部工具，仅供公司内部使用。

---

## 附录

### 指标元数据结构

```json
{
  "metrics": {
    "指标名称": {
      "template": "SET/COUNT/SUM/...",
      "dimFieldCode": "维度字段",
      "setFieldCode": "集合字段（SET模板）",
      "timeSlice": "时间窗口（如24h）",
      "sceneCondition": {
        "sceneFieldCode": "S_S_EVENTTYPE/S_S_APPCODE/S_S_POLICYCODE",
        "sceneType": "事件类型/渠道/策略",
        "sceneLogic": "EQ",
        "sceneList": ["Register", "Login"]
      },
      "fieldCondition": {
        "filterLogic": "ALL/ANY/NOT_ANY",
        "conditions": [
          {
            "fieldCode": "字段编码",
            "logic": "EQUAL/NOT_EQUAL/GREATER_THAN/...",
            "refType": "CONSTANT/VARIABLE",
            "refValue": "参考值",
            "dataType": "STRING/NUMBER/BOOLEAN"
          }
        ]
      }
    }
  }
}
```

### 字段元数据结构

```json
{
  "字段编码": {
    "fieldName": "字段名称",
    "serviceParam": "API参数名（小写无前缀）",
    "dataType": "数据类型",
    "enumValues": ["枚举值1", "枚举值2"]
  }
}
```

### 映射配置结构

```json
{
  "eventtypes_mapping": [
    {"name": "Register", "dName": "注册事件", "enDName": "Register Event"}
  ],
  "app_mapping": {
    "测试渠道": {"appCode": "TEST_APP", "appName": "测试渠道"}
  },
  "org_mapping": {
    "测试机构": {"orgCode": "TEST_ORG", "orgName": "测试机构"}
  }
}
```

---

**维护者：** 风控研发团队  
**最后更新：** 2026年3月6日
