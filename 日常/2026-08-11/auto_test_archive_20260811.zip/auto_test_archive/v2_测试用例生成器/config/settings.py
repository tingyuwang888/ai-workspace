"""
配置管理 - 项目路径、API配置、元数据文件路径
"""

import os
import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Settings:
    """项目配置类"""
    
    # 项目根目录
    project_root: Path = field(default_factory=lambda: Path(__file__).parent.parent)
    
    # 自定义 base_info 目录（None 表示使用默认路径）
    _custom_base_info_dir: Optional[Path] = field(default=None, repr=False)
    
    # 加载.env文件（如果存在）
    def __post_init__(self):
        """初始化后加载环境变量"""
        try:
            from dotenv import load_dotenv
            env_path = self.project_root / '.env'
            if env_path.exists():
                load_dotenv(env_path)
        except ImportError:
            pass  # python-dotenv未安装时跳过
    
    def set_base_info_dir(self, path: str):
        """
        设置自定义 base_info 目录
        
        Args:
            path: base_info 目录路径（如 base_info/RCBC）
        """
        p = Path(path)
        if not p.is_absolute():
            p = self.project_root / p
        self._custom_base_info_dir = p
    
    # 元数据文件路径
    @property
    def base_info_dir(self) -> Path:
        if self._custom_base_info_dir is not None:
            return self._custom_base_info_dir
        return self.project_root / "base_info"
    
    @property
    def BASE_INFO_DIR(self) -> Path:
        """兼容大写调用"""
        return self.base_info_dir
    
    @property
    def field_metadata_path(self) -> Path:
        return self.base_info_dir / "filed_metadata.json"
    
    @property
    def metric_metadata_path(self) -> Path:
        return self.base_info_dir / "salaxy_metadata.json"
    
    @property
    def mapping_config_path(self) -> Path:
        return self.base_info_dir / "mapping_config.json"
    
    # DashScope配置（从上级目录读取）
    @property
    def dashscope_config_path(self) -> Path:
        return self.project_root.parent / "dashscope_config.json"
    
    # 输出目录
    @property
    def output_dir(self) -> Path:
        output_path = self.project_root / "output"
        output_path.mkdir(exist_ok=True)
        return output_path
    
    # API配置（OpenAI兼容模式）
    _api_key: Optional[str] = None
    _base_url: Optional[str] = None
    _model: Optional[str] = None
    
    @property
    def api_key(self) -> str:
        """API Key（优先从环境变量读取）"""
        if self._api_key is None:
            self._api_key = os.getenv('DASHSCOPE_API_KEY', '')
        return self._api_key
    
    @property
    def base_url(self) -> str:
        """API基础URL（优先从环境变量读取）"""
        if self._base_url is None:
            self._base_url = os.getenv('LLM_BASE_URL', '')
        return self._base_url
    
    @property
    def model(self) -> str:
        """模型名称（优先从环境变量读取）"""
        if self._model is None:
            self._model = os.getenv('LLM_MODEL', 'qwen-plus')
        return self._model
    
    # 并发配置
    @property
    def max_workers(self) -> int:
        """最大并发线程数（默认5）"""
        return int(os.getenv('LLM_MAX_WORKERS', '5'))
    
    @property
    def timeout(self) -> int:
        """单个LLM调用超时时间（秒，默认120）"""
        return int(os.getenv('LLM_TIMEOUT', '120'))
    
    @property
    def retry_times(self) -> int:
        """失败重试次数（默认1）"""
        return int(os.getenv('LLM_RETRY_TIMES', '1'))
    
    # 保持向后兼容
    @property
    def app_id(self) -> str:
        """兼容旧代码的app_id属性"""
        return os.getenv('LLM_APP_ID', '')
    
    def validate(self) -> bool:
        """验证配置完整性"""
        errors = []
        
        if not self.field_metadata_path.exists():
            errors.append(f"字段元数据文件不存在: {self.field_metadata_path}")
        
        if not self.metric_metadata_path.exists():
            errors.append(f"指标元数据文件不存在: {self.metric_metadata_path}")
        
        if not self.mapping_config_path.exists():
            errors.append(f"映射配置文件不存在: {self.mapping_config_path}")
        
        if not self.api_key:
            errors.append("API Key未配置 (请设置 DASHSCOPE_API_KEY 环境变量)")
        
        if not self.model:
            errors.append("模型未配置 (请设置 LLM_MODEL 环境变量，默认: qwen-plus)")
        
        if errors:
            print("[配置验证失败]")
            for err in errors:
                print(f"  - {err}")
            return False
        
        return True
    
    def print_config(self):
        """打印当前配置信息"""
        print("=" * 60)
        print("                    配置信息")
        print("=" * 60)
        print(f"  项目根目录: {self.project_root}")
        print(f"  字段元数据: {self.field_metadata_path}")
        print(f"  指标元数据: {self.metric_metadata_path}")
        print(f"  映射配置: {self.mapping_config_path}")
        print(f"  输出目录: {self.output_dir}")
        print(f"  API Key: {'*' * 10}...{self.api_key[-4:] if self.api_key else 'N/A'}")
        print(f"  Base URL: {self.base_url or '默认'}")
        print(f"  模型: {self.model}")
        print("=" * 60)


# 全局配置实例
_settings: Optional[Settings] = None


def get_settings(base_info_dir: Optional[str] = None) -> Settings:
    """
    获取全局配置实例
    
    Args:
        base_info_dir: 自定义 base_info 目录路径（首次调用时设置）
    """
    global _settings
    if _settings is None:
        _settings = Settings()
    if base_info_dir is not None:
        _settings.set_base_info_dir(base_info_dir)
    return _settings


if __name__ == "__main__":
    # 测试配置
    settings = get_settings()
    settings.print_config()
    print(f"\n配置验证: {'通过' if settings.validate() else '失败'}")
