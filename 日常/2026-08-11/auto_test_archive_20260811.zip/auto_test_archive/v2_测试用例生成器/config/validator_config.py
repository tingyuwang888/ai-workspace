"""
验证器配置 - 从.env文件读取配置
"""

import os
from dataclasses import dataclass
from typing import Optional
from dotenv import load_dotenv

# 加载.env文件
load_dotenv()


@dataclass
class ValidatorConfig:
    """验证器配置类"""
    
    # API配置（基础地址，不含服务标识）
    api_base_url: str = "http://localhost:8080/riskService/trade/riskDecision"
    timeout: int = 30
    retry_times: int = 2
    retry_delay: float = 1.0  # 退避重试的基础延迟（秒）
    
    # 报告配置
    report_output_dir: str = "./validation_reports"
    
    def get_api_url(self, service_id: str = "") -> str:
        """
        根据服务标识拼接完整的API地址
        
        Args:
            service_id: 服务标识（从Excel或测试用例JSON中读取）
        
        Returns:
            完整的API地址
        """
        base = self.api_base_url.rstrip('/')
        if service_id:
            return f"{base}/{service_id}"
        return base
    
    @classmethod
    def from_env(cls) -> 'ValidatorConfig':
        """从环境变量加载配置"""
        # 兼容旧配置：如果存在 VALIDATOR_API_URL 则从中提取 base_url
        old_api_url = os.getenv('VALIDATOR_API_URL', '')
        base_url = os.getenv('VALIDATOR_API_BASE_URL', '')
        
        if base_url:
            resolved_base = base_url
        elif old_api_url:
            # 兼容旧配置：从完整URL中截取base部分（去掉最后一段路径）
            resolved_base = old_api_url.rsplit('/', 1)[0]
        else:
            resolved_base = cls.api_base_url
        
        return cls(
            api_base_url=resolved_base,
            timeout=int(os.getenv('VALIDATOR_TIMEOUT', cls.timeout)),
            retry_times=int(os.getenv('VALIDATOR_RETRY_TIMES', cls.retry_times)),
            retry_delay=float(os.getenv('VALIDATOR_RETRY_DELAY', cls.retry_delay)),
            report_output_dir=os.getenv('VALIDATOR_REPORT_DIR', cls.report_output_dir)
        )
