"""
OpenAI兼容模式LLM客户端 - 支持DashScope等OpenAI兼容API
"""

import json
import os
import re
import time
from typing import Optional, Dict, Any, List, Tuple
import httpx
from openai import OpenAI
from config.settings import get_settings
from utils.logger import get_logger
from utils.llm_logger import LLMLogger, get_llm_logger

# 默认超时时间（秒）
DEFAULT_TIMEOUT = 120
DEFAULT_CONNECT_TIMEOUT = 30


class LLMClient:
    """
    OpenAI兼容模式LLM客户端
    
    支持:
    - 阿里云DashScope (北京/新加坡)
    - OpenAI
    - 其他OpenAI兼容API
    """
    
    # 预设的base_url配置
    BASE_URLS = {
        'dashscope-beijing': 'https://dashscope.aliyuncs.com/compatible-mode/v1',
        'dashscope-singapore': 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1',
        'openai': 'https://api.openai.com/v1',
    }
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: Optional[str] = None,
        llm_logger: Optional[LLMLogger] = None
    ):
        """
        初始化客户端
        
        Args:
            api_key: API Key，不传则从环境变量DASHSCOPE_API_KEY读取
            base_url: API基础URL，不传则从环境变量或配置读取
            model: 模型名称，不传则从环境变量LLM_MODEL读取
            llm_logger: LLM通信日志记录器，不传则尝试使用全局实例
        """
        settings = get_settings()
        self.logger = get_logger()
        self.llm_logger = llm_logger or get_llm_logger()
        
        # 调用上下文（规则名、场景名等，由调用方设置）
        self._call_context: Dict[str, Any] = {}
        
        # 读取配置（优先级：参数 > 环境变量 > 配置）
        self.api_key = api_key or os.getenv('DASHSCOPE_API_KEY') or settings.api_key
        self.base_url = base_url or os.getenv('LLM_BASE_URL') or settings.base_url
        self.model = model or os.getenv('LLM_MODEL') or settings.model or 'qwen-plus'
        
        # 如果没有base_url，使用默认的DashScope北京地域
        if not self.base_url:
            self.base_url = self.BASE_URLS['dashscope-beijing']
            self.logger.debug(f"使用默认base_url: {self.base_url}")
        
        # 初始化OpenAI客户端
        if self.api_key:
            # 从settings读取超时配置（支持LLM_TIMEOUT环境变量）
            read_timeout = settings.timeout  # 默认120s，可通过LLM_TIMEOUT环境变量覆盖
            timeout = httpx.Timeout(read_timeout, connect=DEFAULT_CONNECT_TIMEOUT)
            self.client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
                timeout=timeout
            )
            self.logger.debug(f"LLM客户端初始化成功: {self.base_url}, 模型: {self.model}, 超时: {read_timeout}s")
        else:
            self.client = None
            self.logger.warning("API Key未配置，LLM客户端不可用")
    
    def set_context(self, **kwargs):
        """
        设置调用上下文（规则名、场景名等）
        
        这些信息会被记录到LLM日志中，便于追踪和调试。
        
        Args:
            **kwargs: 上下文键值对，如 rule_name="xxx", scenario_name="yyy"
        """
        self._call_context.update(kwargs)
    
    def clear_context(self):
        """清除调用上下文"""
        self._call_context.clear()
    
    def call(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        max_retries: int = 3
    ) -> str:
        """
        调用LLM API
        
        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词
            temperature: 温度参数
            max_tokens: 最大token数
            max_retries: 最大重试次数
        
        Returns:
            模型响应文本
        """
        if not self.client:
            self.logger.error("LLM客户端未初始化")
            return ""
        
        # 构建消息列表
        messages: List[Dict[str, str]] = []
        if system_prompt:
            messages.append({'role': 'system', 'content': system_prompt})
        messages.append({'role': 'user', 'content': prompt})
        
        self.logger.debug(f"调用LLM API: {self.base_url}")
        self.logger.debug(f"模型: {self.model}")
        self.logger.debug(f"Prompt长度: {len(prompt)} 字符")
        
        # 开始计时
        start_time = time.time()
        response_text = ""
        tokens_info = None
        finish_reason = ""
        last_error = None
        actual_retries = 0
        
        for attempt in range(max_retries):
            try:
                completion = self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens
                )
                
                response_text = completion.choices[0].message.content or ""
                finish_reason = completion.choices[0].finish_reason or ""
                
                # 提取Token使用量
                if hasattr(completion, 'usage') and completion.usage:
                    tokens_info = {
                        'prompt': completion.usage.prompt_tokens or 0,
                        'completion': completion.usage.completion_tokens or 0,
                        'total': completion.usage.total_tokens or 0
                    }
                
                if response_text:
                    self.logger.debug(f"API响应成功，长度: {len(response_text)} 字符")
                    break
                else:
                    self.logger.warning(f"API响应为空")
                    last_error = "API响应为空"
                    
            except Exception as e:
                actual_retries = attempt + 1
                last_error = str(e)
                self.logger.warning(f"API调用异常 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt == max_retries - 1:
                    self.logger.error(f"API调用失败，已重试 {max_retries} 次")
        
        # 计算耗时
        duration_ms = int((time.time() - start_time) * 1000)
        
        # 记录到LLM日志
        if self.llm_logger:
            self.llm_logger.log_call(
                model=self.model,
                system_prompt=system_prompt or "",
                user_prompt=prompt,
                response=response_text,
                tokens=tokens_info,
                duration_ms=duration_ms,
                retries=actual_retries,
                success=bool(response_text),
                error=last_error if not response_text else None,
                context=self._call_context.copy(),
                temperature=temperature,
                max_tokens=max_tokens,
                finish_reason=finish_reason
            )
        
        return response_text
    
    def call_and_parse_json(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7
    ) -> Optional[Dict[str, Any]]:
        """
        调用API并解析JSON响应（无重试，保持向后兼容）
        
        Args:
            prompt: 提示词
            system_prompt: 系统提示词
            temperature: 温度参数
        
        Returns:
            解析后的JSON对象，失败返回None
        """
        response_text = self.call(prompt, system_prompt, temperature)
        
        if not response_text:
            self.logger.warning("API返回空响应")
            return None
        
        self.logger.debug(f"API原始响应: {response_text[:500]}...")
        
        result = self.parse_json_response(response_text)
        
        if result is None:
            self.logger.warning(f"无法解析JSON响应: {response_text[:300]}...")
        else:
            self.logger.debug(f"JSON解析成功，包含字段: {list(result.keys())}")
        
        return result
    
    def call_with_json_retry(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_retries: int = 2,
        required_fields: Optional[List[str]] = None
    ) -> Optional[Dict[str, Any]]:
        """
        调用API并解析JSON响应，带错误反馈重试机制（向后兼容版本）
        
        当JSON解析失败或缺少必要字段时，将错误信息反馈给LLM，让它修正输出。
        
        Args:
            prompt: 提示词
            system_prompt: 系统提示词
            temperature: 温度参数
            max_retries: JSON解析失败时的最大重试次数（默认2次）
            required_fields: 必须包含的字段列表，如 ['events']，缺失时也会触发重试
        
        Returns:
            解析后的JSON对象，失败返回None
        """
        result, _ = self.call_with_json_retry_detailed(
            prompt, system_prompt, temperature, max_retries, required_fields
        )
        return result
    
    def call_with_json_retry_detailed(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_retries: int = 2,
        required_fields: Optional[List[str]] = None
    ) -> Tuple[Optional[Dict[str, Any]], str]:
        """
        调用API并解析JSON响应，带错误反馈重试机制（详细版本）
        
        当JSON解析失败或缺少必要字段时，将错误信息反馈给LLM，让它修正输出。
        
        Args:
            prompt: 提示词
            system_prompt: 系统提示词
            temperature: 温度参数
            max_retries: JSON解析失败时的最大重试次数（默认2次）
            required_fields: 必须包含的字段列表，如 ['events']，缺失时也会触发重试
        
        Returns:
            (解析后的JSON对象, 最后一次原始响应文本)
            - 成功时: (result_dict, "")
            - 失败时: (None, last_response_text)
        """
        current_prompt = prompt
        last_response = ""
        last_error = ""
        
        for attempt in range(max_retries + 1):
            # 调用API
            response_text = self.call(current_prompt, system_prompt, temperature)
            
            if not response_text:
                self.logger.warning(f"JSON重试 [{attempt + 1}/{max_retries + 1}]: API返回空响应")
                last_error = "API返回空响应"
                continue
            
            last_response = response_text
            self.logger.debug(f"JSON重试 [{attempt + 1}/{max_retries + 1}]: 响应长度 {len(response_text)} 字符")
            
            # 尝试解析JSON
            result, error_msg = self._try_parse_json_with_error(response_text)
            
            if result is not None:
                # JSON格式正确，检查是否缺少必要字段
                if required_fields:
                    missing_fields = [f for f in required_fields if f not in result]
                    if missing_fields:
                        error_msg = f"JSON缺少必要字段: {missing_fields}"
                        self.logger.warning(f"JSON重试 [{attempt + 1}/{max_retries + 1}]: {error_msg}")
                        
                        # 如果还有重试机会，构建字段缺失的错误反馈
                        if attempt < max_retries:
                            current_prompt = self._build_field_missing_retry_prompt(
                                prompt, response_text, missing_fields
                            )
                            self.logger.info(f"将字段缺失信息反馈给LLM，准备第 {attempt + 2} 次尝试...")
                            continue
                        else:
                            self.logger.error(f"JSON缺少必要字段 {missing_fields}，已重试 {max_retries} 次")
                            return None, last_response
                
                # 格式正确且字段完整
                if attempt > 0:
                    self.logger.info(f"JSON解析在第 {attempt + 1} 次尝试后成功")
                else:
                    self.logger.debug(f"JSON解析成功，包含字段: {list(result.keys())}")
                return result, ""
            
            last_error = error_msg
            self.logger.warning(f"JSON重试 [{attempt + 1}/{max_retries + 1}]: {error_msg}")
            
            # 如果还有重试机会，构建错误反馈提示
            if attempt < max_retries:
                current_prompt = self._build_retry_prompt(prompt, response_text, error_msg)
                self.logger.info(f"将错误反馈给LLM，准备第 {attempt + 2} 次尝试...")
        
        self.logger.error(f"JSON解析失败，已重试 {max_retries} 次")
        return None, last_response
    
    def _try_parse_json_with_error(self, text: str) -> tuple:
        """
        尝试解析JSON并返回详细错误信息
        
        Returns:
            (解析结果, 错误信息)
        """
        # 尝试直接解析
        try:
            return json.loads(text), ""
        except json.JSONDecodeError as e:
            direct_error = f"直接解析失败: {str(e)}"
        
        # 尝试提取```json...```代码块
        json_match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', text)
        if json_match:
            try:
                return json.loads(json_match.group(1)), ""
            except json.JSONDecodeError as e:
                code_block_error = f"代码块解析失败: {str(e)}"
        
        # 尝试提取{...}或[...]
        json_match = re.search(r'(\{[\s\S]*\}|\[[\s\S]*\])', text)
        if json_match:
            try:
                return json.loads(json_match.group(1)), ""
            except json.JSONDecodeError as e:
                bracket_error = f"括号提取解析失败: {str(e)}"
                return None, bracket_error
        
        # 完全无法提取JSON
        return None, f"无法在响应中找到有效的JSON内容。{direct_error}"
    
    def _build_retry_prompt(self, original_prompt: str, failed_response: str, error_msg: str) -> str:
        """
        构建带错误反馈的重试提示，精确定位错误位置
        
        Args:
            original_prompt: 原始提示词
            failed_response: 失败的响应
            error_msg: 错误信息
        
        Returns:
            重试提示词
        """
        # 尝试从错误信息中提取位置信息
        error_location = self._extract_error_location(error_msg, failed_response)
        
        retry_prompt = f"""你之前的响应存在JSON格式错误，请仔细分析错误位置并修正。

**错误信息**: {error_msg}

{error_location}

**修正要求**:
1. **必须修正上述指出的具体错误位置**
2. 确保所有字符串使用双引号（检查是否有中文引号""或''）
3. 确保所有括号 {{}} [] 正确配对
4. 确保字符串中没有未转义的换行符
5. 确保没有尾随逗号（如 {{"a": 1,}} 是错误的）
6. **不要只重复原内容，必须修正错误**

**常见JSON错误及修正方法**:
- 错误: `{{"key": "value with "quotes" inside"}}` 
  修正: `{{"key": "value with \\"quotes\\" inside"}}` （引号前加反斜杠）
- 错误: `{{"a": 1,}}` 
  修正: `{{"a": 1}}` （删除尾随逗号）
- 错误: `{{"a": 1\n"b": 2}}` 
  修正: `{{"a": 1,\n"b": 2}}` （添加逗号）

请输出**修正后**的完整JSON："""
        
        return retry_prompt
    
    def _extract_error_location(self, error_msg: str, response: str) -> str:
        """
        从错误信息中提取并标记错误位置
        
        Returns:
            带有错误位置标记的文本
        """
        import re
        
        # 尝试匹配 "line X column Y (char Z)" 格式的错误
        match = re.search(r'line (\d+) column (\d+) \(char (\d+)\)', error_msg)
        if not match:
            # 尝试匹配 "char X" 格式
            match = re.search(r'char (\d+)', error_msg)
            if match:
                char_pos = int(match.group(1))
                line_num = response[:char_pos].count('\n') + 1
                col_num = char_pos - response[:char_pos].rfind('\n')
            else:
                # 无法提取位置，返回完整响应
                preview = response[:1500] if len(response) > 1500 else response
                return f"**你的响应（前1500字符）**:\n```\n{preview}\n```"
        else:
            line_num = int(match.group(1))
            col_num = int(match.group(2))
            char_pos = int(match.group(3))
        
        # 提取错误行及其上下文
        lines = response.split('\n')
        error_line_idx = line_num - 1
        
        # 确保错误行索引有效
        if error_line_idx >= len(lines):
            error_line_idx = len(lines) - 1
        
        error_line = lines[error_line_idx] if error_line_idx >= 0 else ""
        
        # 获取上下文（前后2行）
        start_idx = max(0, error_line_idx - 2)
        end_idx = min(len(lines), error_line_idx + 3)
        
        context_lines = []
        for i in range(start_idx, end_idx):
            line = lines[i]
            line_no = i + 1
            if i == error_line_idx:
                # 标记错误行
                context_lines.append(f">>> {line_no:3d}| {line}")
                # 标记错误列（限制长度避免溢出）
                if col_num <= len(line):
                    marker = " " * (6 + col_num - 1) + "↑ 错误在这里"
                    context_lines.append(marker)
            else:
                context_lines.append(f"    {line_no:3d}| {line}")
        
        context_str = '\n'.join(context_lines)
        
        # 对于单行长JSON，额外显示错误点附近的内容
        if len(lines) == 1 and len(error_line) > 100:
            # 提取错误点周围的上下文
            start_pos = max(0, col_num - 50)
            end_pos = min(len(error_line), col_num + 50)
            snippet = error_line[start_pos:end_pos]
            snippet_col = col_num - start_pos
            snippet_marker = " " * (snippet_col - 1) + "↑"
            
            context_str += f"\n\n**错误点附近（第{col_num}列前后）**:\n```\n{snippet}\n{snippet_marker}\n```"
        
        return f"**错误位置（第{line_num}行，第{col_num}列）**:\n```\n{context_str}\n```"
    
    def _build_field_missing_retry_prompt(
        self,
        original_prompt: str,
        failed_response: str,
        missing_fields: List[str]
    ) -> str:
        """
        构建字段缺失时的重试提示
        
        Args:
            original_prompt: 原始提示词
            failed_response: 失败的响应
            missing_fields: 缺失的字段列表
        
        Returns:
            重试提示词
        """
        # 截取失败响应的部分内容
        response_preview = failed_response[:800] if len(failed_response) > 800 else failed_response
        
        retry_prompt = f"""你之前的JSON响应缺少必要字段，请补充后重新输出。

**缺少的字段**: {missing_fields}

**你之前的响应**:
```
{response_preview}
```

**修正要求**:
1. 必须包含以下字段: {missing_fields}
2. 如果场景不可达，应返回 {{"analysis": {{"skipped": true, "skip_reason": "原因"}}}}
3. 如果场景可达，应返回 {{"analysis": {{...}}, "events": [...]}}
4. 不要添加任何JSON之外的文字说明

请直接输出修正后的完整JSON："""
        
        return retry_prompt
    
    def parse_json_response(self, text: str) -> Optional[Dict[str, Any]]:
        """
        解析响应文本中的JSON
        
        Args:
            text: 响应文本
        
        Returns:
            解析后的JSON对象
        """
        # 尝试直接解析
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
        
        # 尝试提取```json...```代码块
        json_match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', text)
        if json_match:
            try:
                return json.loads(json_match.group(1))
            except json.JSONDecodeError:
                pass
        
        # 尝试提取{...}或[...]
        json_match = re.search(r'(\{[\s\S]*\}|\[[\s\S]*\])', text)
        if json_match:
            try:
                return json.loads(json_match.group(1))
            except json.JSONDecodeError:
                pass
        
        self.logger.warning(f"无法解析JSON响应: {text[:200]}...")
        return None


# 保持向后兼容的别名
BailianClient = LLMClient


if __name__ == "__main__":
    # 测试客户端
    print("=" * 60)
    print("LLM客户端测试 (OpenAI兼容模式)")
    print("=" * 60)
    
    client = LLMClient()
    
    print(f"\nAPI Key: {'*' * 10}...{client.api_key[-4:] if client.api_key else 'N/A'}")
    print(f"Base URL: {client.base_url}")
    print(f"模型: {client.model}")
    
    if client.client:
        # 简单测试
        test_prompt = "请用一句话介绍什么是风控规则测试。"
        print(f"\n测试Prompt: {test_prompt}")
        
        response = client.call(test_prompt)
        print(f"\n响应: {response[:200] if response else '无响应'}...")
    else:
        print("\n客户端未初始化，跳过测试")
        print("请设置环境变量: export DASHSCOPE_API_KEY=your_api_key")
