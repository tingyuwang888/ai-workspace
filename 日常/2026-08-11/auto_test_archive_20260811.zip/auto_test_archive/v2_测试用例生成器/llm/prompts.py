"""
Prompt模板 - 用于生成进件序列
"""

import json
import hashlib
import random
import string
from typing import Dict, List, Any, Optional

from loaders.metadata_loader import parse_script_dependencies, generate_compute_description
from templates import TemplateRegistry


def _generate_prompt_dim_value(service_param: str, display_name: str, field_code: str, scenario_hash: str) -> str:
    """
    根据字段类型生成符合业务含义的示例值（用于Prompt展示）
    
    Args:
        service_param: 服务参数名
        display_name: 显示名称
        field_code: 字段编码
        scenario_hash: 场景哈希
    
    Returns:
        符合业务含义的示例值
    """
    # 综合判断字段类型的关键词
    key = (service_param + display_name + field_code).lower()
    hash_short = scenario_hash[:8]
    
    # 手机号类字段
    if any(kw in key for kw in ['phone', 'mobile', '手机', 'mobino']):
        return f"138{hash_short[:8]}"  # 11位手机号示例
    
    # 银行卡号类字段
    if any(kw in key for kw in ['cardno', 'bankcard', '银行卡', '卡号']):
        return f"6222{hash_short}0000"  # 16位银行卡示例
    
    # 身份证号类字段
    if any(kw in key for kw in ['certid', 'idno', 'idcard', '身份证', '证件号']):
        return f"110101199001{hash_short[:4]}1X"  # 18位身份证示例
    
    # IP地址类字段
    if any(kw in key for kw in ['ipaddr', 'ip地址', 'ipaddress']):
        return "192.168.1.100"
    
    # 省份类字段
    if any(kw in key for kw in ['prov', '省份', '省']):
        return "北京"
    
    # 城市类字段
    if any(kw in key for kw in ['city', '城市', '市']):
        return "北京市"
    
    # 设备ID类字段
    if any(kw in key for kw in ['deviceid', 'device', '设备']):
        return f"DEV{hash_short.upper()}"
    
    # 账号/用户类字段
    if any(kw in key for kw in ['account', 'login', 'user', '账号', '用户']):
        return f"user_{hash_short[:6]}"
    
    # 默认
    return f"{hash_short}"


def _format_field_constraint(constraint: Dict[str, Any], prefix: str = "") -> str:
    """
    格式化字段约束为可读文本
    
    Args:
        constraint: 约束字典
        prefix: 前缀编号
    
    Returns:
        格式化的约束描述
    """
    field_name = constraint.get('field_name', constraint.get('field_code', ''))
    logic_desc = constraint.get('logic_desc', constraint.get('logic', ''))
    ref_value = constraint.get('ref_value', '')
    data_type = constraint.get('data_type', 'STRING')
    
    # 特殊处理空值判断
    logic = constraint.get('logic', '')
    if logic in ['IS_NULL', 'NOT_NULL']:
        return f"{prefix}. {field_name} {logic_desc}\n"
    
    # 处理 VARIABLE 类型引用（字段与字段的动态比较）
    ref_type = constraint.get('ref_type', 'CONSTANT')
    if ref_type == 'VARIABLE':
        ref_field = constraint.get('ref_value', '')
        return f"{prefix}. {field_name} {logic_desc} 字段[{ref_field}]的值（动态比较：两个字段的值进行比较）\n"
    
    # 格式化参考值
    if data_type == 'NUMBER':
        value_str = str(ref_value)
    elif data_type == 'BOOLEAN':
        value_str = str(ref_value)
    else:
        value_str = f"'{ref_value}'"
    
    return f"{prefix}. {field_name} {logic_desc} {value_str}\n"


def build_system_prompt() -> str:
    """
    构建LLM系统提示词（system prompt）
    
    明确角色定位和输出规范，提高指令稳定性，防止输出语言漂移。
    
    Returns:
        系统提示词文本
    """
    return """你是一位专业的金融风控测试工程师，专精于设计风控策略规则的测试用例。

## 核心职责
- 根据给定的规则信息和测试场景要求，生成准确、完整的测试进件序列
- 确保生成的数据逻辑正确，能精确验证指标计算和条件触发

## 输出规范（必须严格遵守）
1. **语言要求**：所有输出内容必须使用中文，包括但不限于：
   - analysis.strategy（分析策略说明）
   - analysis.event_count（进件数量说明）
   - analysis.skip_reason（跳过原因说明）
   - events[].purpose（每笔进件的目的说明）
   - 即使输入中包含英文的规则名称、字段名或指标名，你的分析说明和目的描述也必须使用中文
   - 英文的字段名（如 serviceParam）和指标名只在引用时保持原样，描述文字一律用中文

2. **格式要求**：只输出合法的 JSON，不要包含任何 JSON 之外的文字说明、注释或 markdown 标记

3. **完整性要求**：
   - 每笔进件的 data 必须包含所有必需的业务字段
   - expected_metric_values 必须包含所有相关指标
   - 不得遗漏任何必需字段"""


def build_sequence_generation_prompt(
    rule_info: Dict[str, Any],
    scenario: Dict[str, Any],
    metrics_metadata: Dict[str, Any],
    field_metadata: Dict[str, Any],
    common_fields: Dict[str, str],
    mapping_config: Dict[str, Any],
    scene_conditions: Optional[Dict[str, Any]] = None,
    field_conditions: Optional[Dict[str, Any]] = None
) -> str:
    """
    构建进件序列生成的Prompt
    
    Args:
        rule_info: 规则信息
        scenario: 测试场景
        metrics_metadata: 相关指标元数据
        field_metadata: 相关字段元数据
        common_fields: 公共字段配置
        mapping_config: 映射配置
        scene_conditions: 场景条件信息（事件类型、渠道、策略等）
        field_conditions: 字段条件信息（fieldCondition约束）
    
    Returns:
        完整的Prompt文本
    """
    
    # 提取条件和指标的对应关系
    conditions_info = []
    for cond in rule_info.get('conditions', []):
        cond_id = cond.condition_id if hasattr(cond, 'condition_id') else cond.get('condition_id')
        raw_text = cond.raw_text if hasattr(cond, 'raw_text') else cond.get('raw_text')
        
        # 获取操作数信息
        if hasattr(cond, 'left_operand'):
            left_metric = cond.left_operand.metric_name
            operator = cond.operator
            right_value = cond.right_operand.value
        else:
            left_metric = cond.get('left_operand', {}).get('metric_name')
            operator = cond.get('operator')
            right_value = cond.get('right_operand', {}).get('value')
        
        conditions_info.append({
            'id': cond_id,
            'text': raw_text,
            'metric_name': left_metric,
            'operator': operator,
            'threshold': right_value
        })
    
    # 构建Prompt
    prompt = f"""# 任务：生成风控规则测试用例的进件序列

## 规则信息
- 规则名称：{rule_info.get('rule_name', '')}
- 触发逻辑：{rule_info.get('trigger_logic', '')}

### 条件详情
"""
    
    for cond_info in conditions_info:
        prompt += f"- {cond_info['id']}：{cond_info['text']}\n"
        if cond_info['metric_name']:
            prompt += f"  - 关联指标：{cond_info['metric_name']}\n"
            prompt += f"  - 操作符：{cond_info['operator']}\n"
            prompt += f"  - 阈值：{cond_info['threshold']}\n"
    
    prompt += f"""
## 测试场景要求
- 场景名称：{scenario.get('scenario_name', '')}
- 条件状态：{json.dumps(scenario.get('condition_states', {}), ensure_ascii=False)}
- 预期规则结果：{"触发" if scenario.get('expected_rule_hit') else "不触发"}
"""
    
    if scenario.get('constraint_notes'):
        prompt += f"- 约束说明：{'; '.join(scenario.get('constraint_notes', []))}\n"
    
    # 格式化指标元数据，提取关键信息（使用模板策略）
    formatted_metrics = []
    template_descriptions = []  # 收集各模板的详细描述
    
    for metric_name, metric_def in metrics_metadata.items():
        template_config = metric_def.get('templateConfig', {})
        time_slice = template_config.get('timeSlice', {})
        template_code = metric_def.get('templateCode', 'UNKNOWN')
        
        # 获取模板策略
        strategy = TemplateRegistry.get_strategy(metric_def)
        
        # 基本信息
        metric_info = {
            'metricName': metric_name,
            'templateCode': template_code,
            'dimFieldCode': template_config.get('dimFieldCode'),
            'timeSlice': {
                'count': time_slice.get('count'),
                'timeUnit': time_slice.get('timeUnit'),
                'selfIncluded': time_slice.get('selfIncluded') if time_slice.get('selfIncluded') is not None else False
            }
        }
        
        # 根据模板类型添加特定字段
        if template_code == 'SET':
            metric_info['setFieldCode'] = template_config.get('setFieldCode')
        elif template_code == 'COUNT':
            metric_info['aggregateByDay'] = template_config.get('aggregateByDay', False)
            metric_info['calcMethod'] = template_config.get('calcMethod', 'COUNT')
        elif template_code == 'STATISTICS':
            metric_info['calcMethod'] = template_config.get('calcMethod', 'SUM')
            metric_info['calcFieldCode'] = template_config.get('calcFieldCode', '')
        elif template_code == 'HISTORY_VALUE':
            metric_info['valueTakenMethod'] = template_config.get('valueTakenMethod', 'LATEST')
            metric_info['valueTakenFieldCode'] = template_config.get('valueTakenFieldCode', '')
            metric_info['metricDataType'] = metric_def.get('metricDataType', 'STRING')
        elif template_code == 'FORMULA':
            metric_info['formulaType'] = template_config.get('formulaType', 'DSL')
            metric_info['formula'] = template_config.get('formula', '')
            metric_info['returnType'] = template_config.get('returnType', 'DOUBLE')
            # FORMULA 没有自己的 dimFieldCode 和 timeSlice
            metric_info['dimFieldCode'] = None
            metric_info['timeSlice'] = None
        elif template_code == 'TIME_GAP':
            time_calc_method = template_config.get('timeCalcMethod', 'INTERVAL')
            metric_info['timeCalcMethod'] = time_calc_method
            metric_info['timeUnit'] = template_config.get('timeUnit', 'SECOND')
            if time_calc_method == 'INTERVAL':
                metric_info['calcMethod'] = template_config.get('calcMethod', 'AVG')
                metric_info['timeFieldCode'] = template_config.get('timeFieldCode', '')
            else:  # EVENT_INTERVAL
                metric_info['valueTakenMethod'] = template_config.get('valueTakenMethod', 'LATEST')
                metric_info['eventType'] = template_config.get('eventType', '')
                metric_info['eventTypeFieldCode'] = template_config.get('eventTypeFieldCode', '')
        elif template_code == 'CONSECUTIVE':
            condition = template_config.get('condition', {})
            metric_info['calcMethod'] = template_config.get('calcMethod', 'MAX_CONSECUTIVE_COUNT')
            metric_info['conditionFieldCode'] = condition.get('fieldCode', '')
            metric_info['conditionLogic'] = condition.get('logic', 'EQUAL')
            metric_info['conditionRefValue'] = condition.get('refValue', '')
            accumulate_method = condition.get('accumulateMethod')
            if accumulate_method:
                metric_info['accumulateMethod'] = accumulate_method
        elif template_code == 'TREND':
            metric_info['calcMethod'] = template_config.get('calcMethod', 'MAX_CONSECUTIVE_COUNT')
            metric_info['trend'] = template_config.get('trend', 'ASC')
            metric_info['calcFieldCode'] = template_config.get('calcFieldCode', '')
            metric_info['compareMethod'] = template_config.get('compareMethod', 'GREATER_THAN')
            metric_info['scale'] = template_config.get('scale', '0')
            metric_info['measurement'] = template_config.get('measurement', 'ABSOLUTE')
            sub_dim_fields = template_config.get('subDimFields', [])
            if sub_dim_fields:
                metric_info['subDimFields'] = [f.get('dimFieldCode', '') for f in sub_dim_fields]
        elif template_code == 'MOVEMENT':
            metric_info['calcMethod'] = template_config.get('calcMethod', 'DISTANCE')
            metric_info['longitudeFieldCode'] = template_config.get('longitudeFieldCode', '')
            metric_info['latitudeFieldCode'] = template_config.get('latitudeFieldCode', '')
        
        formatted_metrics.append(metric_info)
        
        # 收集模板详细描述
        if strategy:
            # 对 FORMULA 策略设置上下文，使其能解析 @引用
            if template_code == 'FORMULA' and hasattr(strategy, 'set_formula_context'):
                strategy.set_formula_context(metrics_metadata, field_metadata)
            template_descriptions.append(f"### {metric_name}\n{strategy.get_prompt_description()}")
        else:
            template_descriptions.append(
                f"### {metric_name}\n"
                f"**警告**：模板类型 `{template_code}` 暂未支持，请参考指标定义理解计算逻辑。"
            )
    
    prompt += f"""
## 指标元数据（关键信息）
```json
{json.dumps(formatted_metrics, ensure_ascii=False, indent=2)}
```

**重要提示**：
- `dimFieldCode`：维度字段，用于区分不同主体的指标值（如设备ID、账号等）
- `selfIncluded=true`：查询时**包含**当前进件（先更新再查询）
- `selfIncluded=false`（包括原始值为null的情况）：查询时**不包含**当前进件（先查询再更新）

**⚠️ selfIncluded 计算规则（关键！）**：
```
SET/COUNT 模板（整数型）：
selfIncluded=true:
  - query_value = 历史进件数 + 1（查询时已包含当前进件）
  - after_update = query_value（与query_value相同）
  - 第一笔进件：query_value = 1（不是0！）

selfIncluded=false:
  - query_value = 历史进件数（查询时不包含当前进件）
  - after_update = query_value + 1（处理后才计入）
  - 第一笔进件：query_value = 0

STATISTICS 模板（金额累加，浮点型）：
selfIncluded=true:
  - query_value = 历史累计金额 + 当前笔金额（查询时已包含当前进件金额）
  - after_update = query_value
  - 第一笔进件（金额=A1）：query_value = A1

selfIncluded=false:
  - query_value = 历史累计金额（查询时不包含当前进件金额）
  - after_update = query_value + 当前笔金额
  - 第一笔进件（金额=A1）：query_value = 0, after_update = A1

HISTORY_VALUE 模板（历史取值，返回原始值）：
selfIncluded=false（默认）:
  - query_value = 窗口内满足条件的历史进件中，按取值方式(EARLIEST/LATEST)取 valueTakenFieldCode 的值
  - 无满足条件的历史进件时，query_value = null
  - 第1笔进件：query_value = null（无历史）
  - 第2笔进件：query_value = 第1笔的取值字段值（若第1笔满足条件）
  - 常用于比较：如"历史IP省份 != 当前IP省份"

FORMULA 模板（公式计算，返回指定类型）：
  - query_value = 将公式中引用的指标 query_value 和字段值代入公式计算的结果
  - after_update = 将公式中引用的指标 after_update 和字段值代入公式计算的结果
  - 公式指标本身无 selfIncluded 概念，其值完全由引用的指标和字段实时计算
  - 公式中 @metricCode 取对应指标的 query_value，@fieldCode 取当前进件的字段值
  - 示例：formula = return #nvl(@metric1,0)+#nvl(@S_F_AMOUNT,0);
    → query_value = nvl(metric1.query_value, 0) + nvl(当前交易金额, 0)

TIME_GAP 模板（时间差，返回小数型，默认 null）：
  INTERVAL（时间间隔，selfIncluded=false 默认）：
  - 对窗口内历史事件（不含当前）按时间字段排序，计算相邻事件的时间差
  - 对所有时间差取聚合（AVG/MIN/MAX）作为 query_value
  - 历史事件不足 2 笔时 query_value = null（无法计算间隔）
  - 示例：4笔进件间隔分别 3s、2s、3s（selfIncluded=false）
    → e1: null, e2: null, e3: AVG([3])=3, e4: AVG([3,2])=2.5

  EVENT_INTERVAL（事件时间间隔，始终不含当前事件）：
  - 在窗口内查找满足条件的最近/最早一笔匹配事件
  - query_value = 匹配事件时间到当前事件时间的差值（按 timeUnit 换算）
  - 无匹配事件时 query_value = null
  - 当前事件始终不会匹配到自身

CONSECUTIVE 模板（连续类，返回整数型，默认 0）：
  MAX_CONSECUTIVE_COUNT（最大连续次数，selfIncluded=false 默认）：
  - 在窗口内按时间排序事件，逐笔检查是否满足 condition 条件
  - 找出满足条件的最长连续子序列长度作为 query_value
  - 示例：5笔进件状态 [失败,失败,成功,失败,失败,失败]（selfIncluded=false）
    → e1: 0, e2: 1, e3: 2, e4: 0, e5: 1, e6: 2（第6笔查询时看前5笔历史最大连续=3→不对）
    → 实际: e1:0, e2:1, e3:1(成功打断), e4:1, e5:1, e6:2

  MAX_CONSECUTIVE_ACCUMULATED_COUNT（最大连续累计个数）：
  - 按天(BY_DAY)或按小时(BY_HOUR)将事件分组
  - 每组累计 condition 字段值，判断是否满足阈值条件
  - 找出连续满足条件的最大组数作为 query_value
  - 示例：3天每天累计金额 [10000, 5000, 12000]，条件>=9000
    → 满足: [T, F, T] → 最大连续天数=1

TREND 模板（趋势类，返回整数型，默认 0）：
  MAX_CONSECUTIVE_COUNT（最大连续次数，selfIncluded=false 默认）：
  - 在窗口内按时间排序事件，对相邻两笔事件的 calcFieldCode 值进行比较
  - 上升(ASC)趋势：diff = 后一笔 - 前一笔，判断 diff compareMethod scale
  - 下降(DESC)趋势：diff = 前一笔 - 后一笔，判断 diff compareMethod scale
  - 找出连续满足趋势条件的最大对数作为 query_value
  - 示例：trend=DESC, compareMethod=GREATER_THAN, scale=0
    5笔历史金额 [1000, 800, 600, 900, 700]
    → diff(前-后): [200, 200, -300, 200]
    → 满足>0: [T, T, F, T]
    → 最大连续=2
  - fieldCondition 过滤：只有通过 fieldCondition 的事件才参与趋势计算

MOVEMENT 模板（移动类，返回小数型，默认 null）：
  DISTANCE（移动距离，单位：米）：
  - 在窗口内按时间排序事件，提取每笔的经度和纬度
  - 使用 Haversine 公式计算相邻两笔事件间的地球表面距离
  - 累加所有相邻事件对的距离，得到总移动距离
  - 窗口内不足2个有效坐标点时，返回 null
  - selfIncluded=true: 当前进件参与距离计算
    第1笔: query_value = null（仅1个点）
    第2笔: query_value = 两点距离
  - selfIncluded=false: 当前进件不参与距离计算
    第1笔: query_value = null（无历史）
    第2笔: query_value = null（1笔历史，仅1个点）
    第3笔: query_value = 两点距离（2笔历史）
  - ⚠️ query_value 对于不足2点时设为 null，其余也设为 null（系统自动计算距离）
  SPEED（移动速度，单位：米/小时）：
  - 累计距离 / 时间跨度（小时），不足2点或时间跨度为0时返回 null
```

## ⚠️ 场景隔离要求（必须遵守）
**每个测试场景必须使用唯一的 dimFieldCode 值，确保指标查询互不影响！**

涉及的维度字段：
"""
    
    # 提取所有 dimFieldCode
    dim_fields = set()
    for metric_name, metric_def in metrics_metadata.items():
        template_config = metric_def.get('templateConfig', {})
        dim_field = template_config.get('dimFieldCode')
        if dim_field:
            dim_fields.add(dim_field)
    
    # 为当前场景生成唯一的维度字段值（符合业务含义）
    scenario_name = scenario.get('scenario_name', 'unknown')
    scenario_hash = hashlib.md5(scenario_name.encode()).hexdigest()
    
    # 生成各维度字段的必须使用的值
    dim_field_values = {}
    for dim_field in dim_fields:
        if dim_field in field_metadata:
            field_def = field_metadata[dim_field]
            service_param = field_def.get('serviceParam', dim_field.lower())
            display_name = field_def.get('displayName', dim_field)
            field_code = field_def.get('fieldCode', dim_field)
            
            # 根据字段类型生成符合业务含义的示例值
            dim_value = _generate_prompt_dim_value(service_param, display_name, field_code, scenario_hash)
            dim_field_values[service_param] = dim_value
            prompt += f"- `{service_param}` ({display_name}): 示例格式 `{dim_value}`\n"
        else:
            prompt += f"- `{dim_field}`: [未找到映射]\n"
    
    prompt += f"""
**⚠️ 维度字段规则**：
1. 维度字段值将由系统自动生成并强制覆盖，LLM无需特别关注
2. 同一场景内所有进件的维度字段值相同
3. 系统会根据字段类型生成符合业务含义的值（如手机号11位、银行卡16位等）

## 场景条件（指标定义时的固定筛选条件）
以下场景条件是指标定义时就确定的固定属性，**不是进件的入参字段**。这些条件用于筛选哪些进件会被纳入指标计算：
"""
    
    # 添加场景条件信息
    if scene_conditions:
        event_types = scene_conditions.get('event_types', [])
        app_codes = scene_conditions.get('app_codes', [])
        policy_codes = scene_conditions.get('policy_codes', [])
        scene_mapping = scene_conditions.get('scene_field_mapping', {})
        
        if event_types:
            prompt += f"""
### 事件类型（eventtype）- 指标筛选条件
- **指标要求的事件类型**：{', '.join(event_types)}
- **说明**：eventtype是指标定义时的固定筛选条件，**不是进件入参**。当前规则配置的事件类型已验证通过，无需在进件中设置此字段。
"""
        
        if app_codes:
            prompt += f"""
### 渠道编码（appcode）- 进件入参
- **要求值**：{', '.join(app_codes)}
- **来源**：Excel"渠道标识"列映射
- **说明**：appcode是进件入参，所有进件的appcode字段必须设置为上述值
"""
        
        if policy_codes:
            prompt += f"""
### 策略编码（policycode）- 进件入参
- **要求值**：{', '.join(policy_codes)}
- **来源**：Excel"策略编码"列
- **说明**：policycode是进件入参，所有进件的policycode字段必须设置为上述值
"""
    
    # 添加字段条件约束（fieldCondition）
    if field_conditions and field_conditions.get('grouped_conditions'):
        prompt += """
## 字段条件约束（需生成）
指标计算时，每笔进件必须满足以下字段条件（fieldCondition）。**你需要根据这些约束生成进件字段值**：
"""
        
        grouped = field_conditions.get('grouped_conditions', {})
        for metric_name, cond_info in grouped.items():
            filter_logic = cond_info.get('filterLogic', 'ALL')
            constraints = cond_info.get('constraints', [])
            
            prompt += f"""
### {metric_name}
过滤逻辑：{filter_logic}（{'全部满足' if filter_logic == 'ALL' else '任一满足' if filter_logic == 'ANY' else '全部不满足'}）
"""
            for i, constraint in enumerate(constraints, 1):
                if constraint.get('type') == 'group':
                    # 分组条件
                    group_logic = constraint.get('logic', 'AND')
                    sub_constraints = constraint.get('constraints', [])
                    prompt += f"  条件组{i}（{group_logic}逻辑）：\n"
                    for j, sub in enumerate(sub_constraints, 1):
                        prompt += _format_field_constraint(sub, f"    {i}.{j}")
                else:
                    # 单个条件
                    sub = constraint.get('constraint', {})
                    prompt += _format_field_constraint(sub, f"  {i}")
        
        prompt += """
**重要提示**：生成的每笔进件必须严格满足上述字段条件，否则指标计算结果将不正确。
"""
    
    prompt += """
## 指标计算规则（重要）

### 通用规则
1. **selfIncluded字段**：决定本次进件是否计入本次判断
   - **selfIncluded=false**：先查询（不含当前）→ 规则判断 → 再更新（含当前）
     * query_value = 历史进件数
     * after_update = query_value + 1
     * 第一笔：query_value=0, after_update=1
   - **selfIncluded=true**：先更新（含当前）→ 再查询（已含当前）
     * query_value = 历史进件数 + 1
     * after_update = query_value
     * 第一笔：query_value=1, after_update=1（不是0！）

2. **时间窗口计算规则**：
   - **滑动窗口**：每笔进件的查询时刻，窗口是动态计算的 `(biztime - duration, biztime]`
   - **窗口为左开右闭区间**：恰好在边界上的进件**不包含**在内（如10:00不在(09:00, 10:00]的窗口中？不对——右端点包含，左端点不包含）
   - **关键**：窗口 `(T-D, T]` 意味着 `T-D` 时刻的进件**不在**窗口内，而 `T` 时刻的进件**在**窗口内
   
   **计算示例1**：60分钟窗口，进件时间为 10:00, 10:01, 10:02, 10:03, 10:04
   - 第5笔 (10:04) 查询时，窗口为 (09:04, 10:04]，包含前4笔（间隔仅4分钟，全部在窗口内）
   
   **计算示例2**：30分钟窗口，进件在 09:00, 09:02, 09:31
   - 第3笔 (09:31) 查询时，窗口为 (09:01, 09:31]
   - 09:00 **不在**窗口内（09:00 ≤ 09:01 的开边界）！只有 09:02 在窗口内
   
   **⚠️ 安全时间间距规则（必须遵守！）**：
   - 当需要让历史进件落在时间窗口**内**时，确保时间间距远小于窗口大小
     * 例：30分钟窗口→历史进件与验证进件间隔不超过 **25分钟**（留5分钟余量）
     * 例：60分钟窗口→间隔不超过 **55分钟**
     * 例：24小时窗口→间隔不超过 **23小时**
   - 当需要让历史进件落在时间窗口**外**时，确保间距明显超过窗口大小
     * 例：60分钟窗口→间隔至少 **65分钟**（留5分钟余量）
   - **绝对禁止**将进件时间设在窗口边界附近（±1分钟内）

### ⚠️ 多时间窗口场景的时间间隔策略（关键！）

当规则包含**多个不同时间窗口**的指标（如同时有 24小时 和 60分钟 两个窗口）时，
"仅条件X触发"场景需要**精确控制事件间距**，使指标仅在目标窗口内累积：

**场景A："仅大窗口条件触发"（如仅24h触发，60min不触发）**
- 历史进件之间的间距必须 **大于** 小窗口时长+余量（如60min窗口→间隔至少70分钟）
- 这样在最终验证进件的小窗口内，最多只能看到0~1笔历史进件，不会达到小窗口阈值
- 示例（24h>=5, 60min>=3）：5笔进件分别在 09:00, 11:10, 13:20, 15:30, 17:40
  → 每笔间隔130分钟 > 60分钟，第5笔的60min窗口内仅有自身（qv=0，selfIncluded=false）
  → 但24h窗口包含全部5笔 → 仅24h条件满足

**场景B："仅小窗口条件触发"（如仅60min触发，24h不触发）**
- 历史进件集中在小窗口范围内（如间隔5-10分钟），确保小窗口指标累积
- 但总的去重数量必须低于大窗口阈值
- 示例（24h>=5, 60min>=3）：3笔进件在 10:00, 10:10, 10:20
  → 第3笔的60min qv=2（selfIncluded=false）→ 还不够
  → 需要4笔：10:00, 10:10, 10:20, 10:30 → 第4笔60min qv=3 ≥ 3 ✓
  → 同时24h qv=3 < 5 ✓ → 仅60min条件满足

"""
    
    # 添加各指标的模板详细描述
    prompt += "### 各指标模板详细计算规则\n\n"
    prompt += "\n\n".join(template_descriptions)
    
    prompt += """

## 字段说明

### 一、入参字段（最终出现在进件 data 中）

#### 1.1 系统字段（自动生成，无需 LLM 处理）
- bizid: 系统自动生成唯一流水号
- biztime: 系统自动生成时间

#### 1.2 配置字段（自动填充，无需 LLM 处理）
以下字段由系统根据 Excel 配置自动填充：
"""
    
    # 收集白名单字段
    allowed_fields_list = ['bizid', 'biztime']  # 系统字段默认加入
    
    # 显示配置字段（入参字段-配置）
    input_fields_config = rule_info.get('input_fields_config', {}) if rule_info else {}
    # 兼容旧结构
    if not input_fields_config:
        input_fields_config = common_fields
    
    for field_name, field_value in input_fields_config.items():
        # 尝试将中文名映射到 serviceParam
        field_def = None
        for fc, fd in field_metadata.items():
            if fd.get('displayName') == field_name:
                field_def = fd
                break
        
        if field_def:
            service_param = field_def.get('serviceParam', field_name)
            enum_values = field_def.get('enumValues', {})
            actual_value = enum_values.get(field_value, field_value) if enum_values else field_value
            prompt += f"- {service_param}: {actual_value}\n"
            allowed_fields_list.append(service_param)
        else:
            prompt += f"- {field_name}: {field_value}\n"
            allowed_fields_list.append(field_name)
    
    prompt += """
#### 1.3 业务字段（LLM 必须生成）
以下字段需要 LLM 根据场景动态生成，**必须在每笔进件的 data 中包含**：
"""
    
    # 收集动态计算字段信息（将移到非入参字段部分）
    computed_fields_info = []
    
    # 从入参字段-业务中获取（Excel定义）
    input_fields_business = rule_info.get('input_fields_business', []) if rule_info else []
    # 兼容旧结构
    if not input_fields_business:
        input_fields_business = rule_info.get('ruleset_params', []) if rule_info else []
    
    for param_name in input_fields_business:
        field_def = None
        for fc, fd in field_metadata.items():
            if fd.get('displayName') == param_name:
                field_def = fd
                break
        
        if field_def:
            service_param = field_def.get('serviceParam', param_name)
            display_name = field_def.get('displayName', param_name)
            data_type = field_def.get('dataType', 'STRING')
            script = field_def.get('script')
            
            # 检查是否为脚本计算的动态字段
            if script:
                # 动态字段：收集信息，稍后在"非入参字段"部分展示
                dependencies = parse_script_dependencies(script)
                compute_desc = generate_compute_description(field_def, field_metadata)
                
                computed_fields_info.append({
                    'field_code': field_def.get('fieldCode'),
                    'service_param': service_param,
                    'display_name': display_name,
                    'dependencies': dependencies,
                    'compute_description': compute_desc
                })
                
                # 将依赖字段加入白名单（动态字段本身不加入）
                for dep_code in dependencies:
                    dep_def = field_metadata.get(dep_code, {})
                    dep_service_param = dep_def.get('serviceParam', dep_code.lower())
                    if dep_service_param not in allowed_fields_list:
                        allowed_fields_list.append(dep_service_param)
                        # 同时显示依赖字段的说明
                        dep_dn = dep_def.get('displayName', dep_code)
                        dep_type = dep_def.get('dataType', 'STRING')
                        prompt += f"- {dep_service_param} ({dep_dn}): 类型={dep_type} [为计算 {display_name} 所需]\n"
            else:
                # 普通业务字段
                prompt += f"- {service_param} ({display_name}): 类型={data_type}\n"
                allowed_fields_list.append(service_param)
                if field_def.get('enumValues'):
                    prompt += f"  可选值: {json.dumps(field_def['enumValues'], ensure_ascii=False)}\n"
        else:
            prompt += f"- {param_name}: [未找到映射]\n"
            allowed_fields_list.append(param_name)
    
    prompt += """
### 二、非入参字段（不出现在进件 data 中）
以下字段不是进件入参，LLM **不要**在 data 中包含这些字段：
"""
    
    # 从 Excel 的非入参字段中获取
    non_input_fields = rule_info.get('non_input_fields', {}) if rule_info else {}
    
    # 显示非入参字段
    if non_input_fields:
        prompt += "\n#### 2.1 元信息字段（指标筛选条件，非入参）\n"
        for field_name, field_value in non_input_fields.items():
            prompt += f"- {field_name}: {field_value}（仅用于指标筛选，不是进件入参）\n"
    
    # 显示动态计算字段
    if computed_fields_info:
        prompt += "\n#### 2.2 计算字段（由系统根据脚本计算，非入参）\n"
        for cf in computed_fields_info:
            prompt += f"""
**{cf['display_name']}** (`{cf['service_param']}`)：
- 计算方式：{cf['compute_description']}
- 依赖字段：{', '.join(cf['dependencies'])}
- **LLM 不要生成此字段**，只需生成上述依赖字段即可
"""
    
    # 去重
    allowed_fields_list = list(set(allowed_fields_list))
    
    prompt += f"""
## ⚠️ 字段白名单（严格执行）
**LLM 只能在 data 中包含以下字段：**
```
{', '.join(sorted(allowed_fields_list))}
```

**重要规则**：
- 配置字段由系统自动填充，LLM 不要生成
- LLM 只需生成业务字段（见上方 1.3 节）
- 非入参字段（策略事件类型、计算字段等）**绝对不要**出现在 data 中
- 禁止添加任何未在白名单中的字段

## 配置字段参考
```json
{json.dumps(input_fields_config, ensure_ascii=False, indent=2)}
```

## 映射配置
- 渠道映射：{json.dumps(mapping_config.get('app_mapping', {}), ensure_ascii=False)}
- 机构映射：{json.dumps(mapping_config.get('org_mapping', {}), ensure_ascii=False)}

## 生成要求
1. **使用 serviceParam 作为 JSON 的 key**（如 deviceid 而非 S_S_DEVICEID）
2. **时间安排**：所有进件的 biztime 应在相关时间窗口内，且间隔合理
   - **关键**：对每笔进件，必须验算其 `(biztime - 窗口时长, biztime]` 区间内包含哪些历史进件
   - **多窗口场景**：若规则涉及多个不同时长的窗口，先参考上方"多时间窗口场景的时间间隔策略"，选择正确的间隔
   - **禁止**将进件时间设在窗口边界附近（如窗口30分钟，两笔进件间隔恰好30分钟）
   - 推荐：需要在窗口内的进件间隔控制在窗口时长的 1/3 以内
   - **⚠️ 绝对禁止 biztime 重复**：每笔进件的 biztime 必须互不相同，严禁两笔进件使用相同的时间戳
   - **⚠️ biztime 必须严格递增**：后一笔进件的 biztime 必须晚于前一笔，且至少间隔1分钟
3. **维度字段**：同一测试用例中，维度字段值应保持一致
4. **模板特定规则**：
   - **SET 模板**：集合字段（setFieldCode）每笔进件应不同（用于去重计数）
   - **COUNT 模板**：每笔进件都必须满足 fieldCondition 约束才会被计入次数
   - **COUNT 模板（按天聚合）**：若 aggregateByDay=true，同一天多笔只算1天
   - **STATISTICS 模板**：统计字段（calcFieldCode，通常为交易金额）的值会被累加（SUM），每笔进件金额可以不同
     * 合理分配每笔进件的金额值，使累计金额恰好达到或不达到阈值
     * 推荐使用整数金额（如 10000、15000），便于验证
     * **STATISTICS 的 query_value 是浮点数**，不是整数
5. **字段条件**：每笔进件都应满足指标的 fieldCondition 约束（不满足条件的进件不参与统计）
   - 当 fieldCondition 中有 **refType=VARIABLE** 的条件时，表示两个字段之间的动态比较
   - 例如 `custname NOT_EQUAL payeeacctname` 表示"客户名称不等于收款方名称"（非同名）
   - 需要在进件中同时设置这两个字段的值，使其满足比较关系
6. **ENUM 字段**：使用 enumValues 中的实际值（如 transstat 用 1 而非 "成功"）
7. **字段分类处理**：
    - **配置字段**：使用上方"1.2 配置字段"中给定的固定值（来自 Excel）
    - **业务字段**：根据场景条件动态生成（见上方"1.3 业务字段"）
    - **非入参字段**：不要出现在 data 中（见上方"二、非入参字段"）
8. **业务字段生成规则**：
    - 根据 scenario.condition_states 中的条件状态设置字段值
    - 必须使用 serviceParam 作为 key（如字段定义中的 serviceParam 值）
    - **禁止添加任何未在白名单中的字段**

## ⚠️ 不可达场景判断（重要）

在生成测试用例前，请先判断当前场景是否**物理可实现**：

### 不可达场景的典型情况
1. **时间字段逻辑矛盾**：如"事件发生小时>=0"要求为false，但合法时间的小时值恒为0-23，无法为负
2. **数值范围矛盾**：如要求某字段同时满足">=10"和"<5"
3. **枚举值矛盾**：如要求交易状态同时为"成功"和"失败"
4. **依赖字段缺失**：条件依赖的字段不在入参字段白名单中且无法通过其他字段计算

### ⚠️ 重要：关于指标型条件的可达性判断

**指标型条件（如"某指标>=5"）的可达性判断需要特别注意：**

1. **区分统计条件 vs 当前进件字段**
   - 指标的 `fieldCondition` 只限制**被统计的历史进件**的筛选条件
   - 最终验证进件的字段值**不受 fieldCondition 限制**
   - 可以通过**多笔进件**实现指标累积

2. **多笔进件策略**
   - 先构造满足 `fieldCondition` 的进件来累积指标值
   - 最后构造验证进件来验证场景状态
   - 只要历史上有满足条件的进件，指标就会累积

3. **常见误区（避免）**
   - ❌ 错误：认为 fieldCondition 限制了所有进件的字段值
   - ✅ 正确：fieldCondition 只筛选统计范围，当前进件可以有不同的字段值

**示例**：指标"IP归属国家不等于中国的登录次数"要求 fieldCondition 中 `ipcountry≠中国`，但这只限制被统计的进件。可以通过先构造 ipcountry=美国/日本 的进件累积指标，再构造 ipcountry=中国 的进件进行验证。

### 判断流程
1. 检查 scenario.condition_states 中每个条件的状态要求
2. 对照字段的数据类型和取值范围（如 biztime 的 HH 只能是 00-23）
3. **对于指标型条件**：判断是否可以通过多笔进件实现（先累积指标，再验证场景）
4. 若存在物理上无法满足的条件状态组合，则判定为**不可达场景**

### 不可达场景的处理
若判定当前场景不可达，请按以下格式返回（跳过该场景）：
```json
{{
  "analysis": {{
    "strategy": "不可达场景：[说明具体原因，如'条件2要求事件发生小时<0，但合法时间的小时值恒为0-23']",
    "event_count": 0,
    "skipped": true,
    "skip_reason": "详细说明为什么该场景物理上无法实现"
  }},
  "events": []
}}
```

## 输出格式
请严格按照以下JSON格式输出：

### 格式A：正常场景（可达）
```json
{{
  "analysis": {{
    "strategy": "简要说明进件序列的生成策略",
    "event_count": "预计需要的进件数量及原因"
  }},
  "events": [
    {{
      "sequence": 1,
      "purpose": "该笔进件的目的说明",
      "expected_metric_values": {{
        "指标名称": {{
          "query_value": 0,
          "after_update": 1,
          "self_included": false
        }}
      }},
      "expected_condition_hit": false,
      "data": {{
        "apimodel": 20,
        "bizid": "唯一业务流水号",
        "biztime": "YYYY-MM-DD HH:MM:SS格式",
        "policycode": "策略编码",
        "appcode": "渠道编码",
        "kratos": "合作方",
        "orgcode": "机构编码"
      }}
    }}
  ]
}}
```

**注意**：
1. `expected_metric_values` 必须包含所有指标（下方示例展示两个指标）
2. data中必须包含：
   - 公共字段配置中的所有字段（policycode, appcode, kratos, orgcode等）
   - 规则中的字段判断型条件对应的字段（根据上方"1.3 业务字段"中的 serviceParam 填写）
   - **重要**：必须使用 serviceParam 作为 key（见上方各字段的 serviceParam 定义）

### 格式A示例（多指标）：
```json
{{
  "expected_metric_values": {{
    "指标名称1": {{
      "query_value": 0,
      "after_update": 1,
      "self_included": false
    }},
    "指标名称2": {{
      "query_value": 0,
      "after_update": 0,
      "self_included": false
    }}
  }}
}}
```

### 格式B：不可达场景（跳过）
```json
{{
  "analysis": {{
    "strategy": "不可达场景：[具体原因]",
    "event_count": 0,
    "skipped": true,
    "skip_reason": "详细说明"
  }},
  "events": []
}}
```

### 指标值字段说明
`expected_metric_values` 中每个指标包含三个字段：
- **query_value**: 本次进件查询时的指标值（用于规则判断的值）
  - selfIncluded=false: 不包含当前进件（查询历史）
  - selfIncluded=true: 包含当前进件
- **after_update**: 本次进件处理后的指标值（更新后的值）
- **self_included**: 当前进件是否计入query_value，必须与指标元数据中的timeSlice.selfIncluded一致

**⚠️ 重要：每个进件必须包含所有指标的预期值！**
- `expected_metric_values` 必须包含上方"指标元数据"中列出的**所有指标**
- 即使某指标在该进件的场景中不直接相关，也必须计算并填写其预期值
- 缺少任何指标的预期值将导致验证失败

**计算规则（务必正确！）**：
```
selfIncluded=false（如60分钟指标）:
  - query_value = 历史进件数（查询时不含当前）
  - after_update = query_value + 1（处理后+1）
  - 第一笔：query_value=0, after_update=1
  - 第N笔：query_value=N-1, after_update=N

selfIncluded=true（如24小时指标）:
  - query_value = 历史进件数 + 1（查询时已含当前）
  - after_update = query_value（与query_value相同）
  - 第一笔：query_value=1, after_update=1（不是0！）
  - 第N笔：query_value=N, after_update=N
```

**验证方法**：检查每笔进件的query_value是否符合上述公式，特别是第一笔！

**⚠️ expected_condition_hit 判定规则（极其重要，必须严格执行！）**：
```
expected_condition_hit 的值取决于 query_value 是否满足条件阈值：
- 判定公式：将 query_value 代入条件表达式（如 query_value >= 3）
- ✅ 正确：query_value=3, 条件>=3 → expected_condition_hit=True
- ❌ 错误：query_value=2, 条件>=3 → expected_condition_hit=True（2<3，不满足！）

严禁使用 after_update 判断条件！after_update 仅表示更新后的值，不参与规则判定。

自查步骤（每笔进件必须执行）：
1. 计算该进件的 query_value
2. 将 query_value 代入每个条件的表达式
3. 根据触发逻辑（AND/OR）判断规则是否整体命中
4. 设置 expected_condition_hit
```

**⚠️ 语言要求（必须遵守）**：
- 所有输出文本必须使用**中文**，包括 purpose、strategy、event_count、skip_reason 等字段
- 英文字段名和指标名引用时保持原样，但描述说明一律用中文

**⚠️ purpose字段格式要求（重要！业务人员需要能看懂）**：
purpose字段需要让业务人员清晰理解每笔进件的作用，必须包含以下要素：

1. **进件类型**：明确是「铺垫进件」还是「验证进件」
   - 铺垫进件：用于构造历史数据，为后续验证做准备
   - 验证进件：最终触发/不触发规则的那笔进件

2. **业务目的**：用业务语言说明这笔交易要达成什么效果
   - ❌ 错误示例："累积30天窗口指标"（太技术化）
   - ✅ 正确示例："构造一笔5000元的跨行转账，使30天内转账次数达到3次"

3. **条件影响**：说明这笔进件会影响哪个条件的状态
   - ❌ 错误示例："时间在90天排除近3天窗口外"（难以理解）
   - ✅ 正确示例："交易时间设为3天前，使本笔计入'90天内转账次数'统计"

**purpose字段示例**：
- 「铺垫进件1」构造一笔1000元转账，使'30天内转账次数'从0变为1，为条件2(转账次数>=3)做铺垫
- 「铺垫进件2」构造一笔2000元转账，使'30天内转账金额'累计达到3000元
- 「验证进件」金额5000元，转账次数已达阈值3次，本笔触发条件1(金额>=5000)和条件2(次数>=3)，规则命中

请生成满足上述要求的进件序列。只输出JSON，不要其他解释。
"""
    
    return prompt


def build_simple_prompt(
    scenario_name: str,
    condition_states: Dict[str, bool],
    expected_result: bool,
    conditions_text: List[str],
    constraint_notes: List[str]
) -> str:
    """
    构建简化版Prompt（用于测试）
    
    Args:
        scenario_name: 场景名称
        condition_states: 条件状态
        expected_result: 预期结果
        conditions_text: 条件文本列表
        constraint_notes: 约束说明
    
    Returns:
        Prompt文本
    """
    prompt = f"""生成测试进件序列：

场景：{scenario_name}
条件状态：{json.dumps(condition_states, ensure_ascii=False)}
预期：{"规则触发" if expected_result else "规则不触发"}

条件：
"""
    for cond in conditions_text:
        prompt += f"- {cond}\n"
    
    if constraint_notes:
        prompt += f"\n约束：{'; '.join(constraint_notes)}\n"
    
    prompt += "\n请生成满足条件的进件序列JSON。"
    
    return prompt


if __name__ == "__main__":
    # 测试Prompt生成
    test_rule_info = {
        'rule_name': '短时间内，同一设备ID注册成功账户数过多',
        'trigger_logic': '条件1 or 条件2',
        'conditions': [
            {
                'condition_id': '条件1',
                'raw_text': '注册_24小时内同一设备ID关联注册成功登录账号个数>=5',
                'left_operand': {'metric_name': '注册_24小时内同一设备ID关联注册成功登录账号个数'},
                'operator': '>=',
                'right_operand': {'value': '5'}
            }
        ]
    }
    
    test_scenario = {
        'scenario_name': '仅条件2触发',
        'condition_states': {'条件1': False, '条件2': True},
        'expected_rule_hit': True,
        'constraint_notes': []
    }
    
    test_metrics = {
        "注册_60分钟内同一设备ID关联注册成功登录账号个数": {
            "templateCode": "SET",
            "templateConfig": {
                "dimFieldCode": "S_S_DEVICEID",
                "setFieldCode": "S_S_ACCOUNTLOGIN",
                "timeSlice": {"count": 60, "timeUnit": "MINUTE"}
            },
            "sceneCondition": {
                "sceneFieldCode": "S_S_EVENTTYPE",
                "sceneList": ["Register"]
            },
            "fieldCondition": {
                "conditions": [{"fieldCode": "S_E_TRANSSTAT", "logic": "EQUAL", "refValue": "1"}]
            }
        }
    }
    
    test_fields = {
        "S_S_DEVICEID": {"serviceParam": "deviceid"},
        "S_S_ACCOUNTLOGIN": {"serviceParam": "accountlogin"},
        "S_E_TRANSSTAT": {"serviceParam": "transstat", "enumValues": {"成功": "1", "失败": "0"}}
    }
    
    test_common = {"调用类型": "准实时", "策略编码": "test_rule_policy"}
    test_mapping = {"app_mapping": {"测试渠道": {"appCode": "test_app"}}}
    
    prompt = build_sequence_generation_prompt(
        test_rule_info, test_scenario, test_metrics, test_fields, test_common, test_mapping
    )
    
    print("=" * 60)
    print("Prompt生成测试")
    print("=" * 60)
    print(f"\nPrompt长度: {len(prompt)} 字符")
    print(f"\n前1000字符:\n{prompt[:1000]}...")
