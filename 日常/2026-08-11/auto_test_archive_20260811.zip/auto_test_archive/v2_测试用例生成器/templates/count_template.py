"""
COUNT 模板策略 - 次数类模板

计算逻辑：一段时间内某属性某行为发生的次数或累计的天数
- 默认值：0
- 结果类型：整数型

特殊配置：
- aggregateByDay=false（默认）：统计满足条件的进件次数
- aggregateByDay=true：统计满足条件的进件发生的天数
- recentExcluded=true：排除近期N天/小时等的进件（用于"历史行为排除近期"场景）
- subDimFields：子维度字段（多维度联合分组）

示例：
- "1天内同一银行卡号单笔交易金额大于40000出入账成功次数"
- dimFieldCode: S_S_CARDNO（维度字段，用于分组）
- fieldCondition: 定义了筛选条件（金额>40000 且 交易状态=成功）
- "90天排除近1天内同一设备ID同一登录账号登录成功次数"
- recentExcluded=true, recentCount=1：排除最近1天的数据
- subDimFields: [S_S_ACCOUNTLOGIN]：联合维度（设备ID + 登录账号）
"""

from typing import Dict, List, Any, Optional
from templates.base import TemplateStrategy


class CountTemplateStrategy(TemplateStrategy):
    """
    COUNT 模板策略实现
    
    次数类模板：统计满足条件的进件次数或天数
    - aggregateByDay=false: 计算次数
    - aggregateByDay=true: 计算天数（同一天多笔只算1天）
    - recentExcluded=true: 排除近期数据（窗口变为 [T-total, T-recent]）
    - subDimFields: 子维度字段，与主维度联合分组
    """
    
    TEMPLATE_CODE = "COUNT"
    TEMPLATE_NAME = "次数类模板"
    TEMPLATE_DESCRIPTION = "一段时间内某属性某行为发生的次数或累计的天数"
    
    def __init__(self, metric_def: Dict[str, Any]):
        super().__init__(metric_def)
        self.calc_method = self.template_config.get('calcMethod', 'COUNT')
        self.aggregate_by_day = self.template_config.get('aggregateByDay', False)
        self.read_current_field = self.template_config.get('readCurrentField', False)
        
        # 近期排除配置
        self.recent_excluded = self.time_slice.get('recentExcluded', False) or False
        self.recent_count = self.time_slice.get('recentCount') or 0
        
        # 子维度字段（联合分组）
        self.sub_dim_fields = self.template_config.get('subDimFields', []) or []
        
        # 提取 fieldCondition（筛选条件）
        self.field_condition = metric_def.get('fieldCondition', {})
    
    def get_prompt_description(self) -> str:
        """获取用于 Prompt 的模板计算规则描述"""
        time_desc = self.get_time_slice_description()
        self_included_desc = self.get_self_included_description()
        
        # 根据 aggregateByDay 确定计算方式描述
        if self.aggregate_by_day:
            calc_desc = "统计满足条件的进件发生的**天数**（同一天多笔只算1天）"
            count_unit = "天数"
        else:
            calc_desc = "统计满足条件的进件**次数**（每笔进件计1次）"
            count_unit = "次数"
        
        description = f"""**模板类型**: {self.TEMPLATE_NAME}（{self.TEMPLATE_CODE}）
**计算方式**: {calc_desc}
**时间窗口**: {time_desc}
**selfIncluded**: {self.self_included}（{self_included_desc}）
**按天聚合**: {self.aggregate_by_day}
"""

        # 添加近期排除配置说明
        if self.recent_excluded and self.recent_count:
            recent_unit = self._get_recent_unit_description()
            description += f"""**近期排除**: 排除最近 {self.recent_count}{recent_unit} 的数据（recentExcluded=true）
"""

        # 添加子维度字段说明
        if self.sub_dim_fields:
            sub_dim_codes = [f.get('dimFieldCode', '') for f in self.sub_dim_fields if isinstance(f, dict)]
            if sub_dim_codes:
                description += f"""**子维度字段**: {', '.join(sub_dim_codes)}（与主维度联合分组）
"""

        description += f"""
**计算规则详解**：
- 维度字段（dimFieldCode）: `{self.dim_field_code}` - 用于分组聚合
"""
        # 子维度说明
        if self.sub_dim_fields:
            sub_dim_codes = [f.get('dimFieldCode', '') for f in self.sub_dim_fields if isinstance(f, dict)]
            description += f"- 子维度字段（subDimFields）: {', '.join(f'`{c}`' for c in sub_dim_codes)} - 与主维度联合分组\n"
            description += f"- 联合分组含义：只统计**主维度字段和所有子维度字段都相同**的进件\n"

        description += f"- 筛选条件（fieldCondition）: 每笔进件必须满足指标定义的字段条件才会被计入\n"
        description += f"- 结果 = 时间窗口内，维度字段相同且**满足筛选条件**的进件{count_unit}\n"

        # 近期排除的详细说明
        if self.recent_excluded and self.recent_count:
            recent_unit = self._get_recent_unit_description()
            description += f"""
**⚠️ 近期排除逻辑（recentExcluded）**：
- 总时间窗口: {time_desc}
- 排除最近: {self.recent_count}{recent_unit}
- **有效统计范围**: `(biztime - {time_desc}, biztime - {self.recent_count}{recent_unit}]`
- 即：只统计时间窗口内、但**不在最近 {self.recent_count}{recent_unit} 内**的历史进件
- 示例：90天排除近1天，当前时间 3月13日
  - 有效范围：(12月13日, 3月12日]（左开右闭）
  - 12月13日的进件**不在**范围内（左开边界排除）
  - 3月12日的进件**在**范围内
  - 3月13日的进件**不在**范围内（近1天排除区间）
  - **近期排除区间** = (3月12日, 3月13日]，此区间内的进件不被统计
- **对测试用例的影响**：
  - 要让指标值>0：历史进件时间必须在有效范围内（不能太近也不能太远）
  - 要让指标值=0：确保有效范围内没有满足条件的进件（可以全部放在近期排除区间内）
- **⚠️ 常见错误（必须避免！）**：
  - ❌ 错误：将历史进件设在与验证进件同一天，期望进入有效范围（实际在排除区间内）
  - ❌ 错误：期望某进件不在有效范围内，但实际该进件日期落在 (T-total, T-recent] 区间中
  - ✅ 正确：先计算验证进件的有效范围边界，再逐一检查每笔历史进件是否在此范围内
"""

        # 添加 aggregateByDay 的具体说明
        if self.aggregate_by_day:
            description += """
**按天聚合逻辑**：
- 将进件按日期分组，每个日期只计1次
- 例如：3笔进件分别在 Day1、Day1、Day2，则计数=2（2天）
"""
        else:
            description += """
**次数计算逻辑**：
- 每笔满足条件的进件计1次
- 例如：3笔进件都满足条件，则计数=3（3次）
"""

        description += f"""
**selfIncluded 影响**：
"""
        if self.self_included:
            description += f"""- `selfIncluded=true`: 当前进件**先计入**再查询
  - 第1笔（满足条件）：query_value=1（已含自己）
  - 第2笔（满足条件）：query_value=2
  - 第N笔（满足条件）：query_value=N
  - 注意：不满足 fieldCondition 的进件不会增加{count_unit}"""
        else:
            description += f"""- `selfIncluded=false`: 先查询历史，**再**将当前进件计入
  - 第1笔（满足条件）：query_value=0（不含自己）
  - 第2笔（满足条件）：query_value=1
  - 第N笔（满足条件）：query_value=N-1
  - 注意：不满足 fieldCondition 的进件不会增加{count_unit}"""

        description += f"""

**进件生成要点**：
1. 所有进件的维度字段 `{self.dim_field_code}` 必须相同（用于聚合）
"""
        # 子维度字段要点
        if self.sub_dim_fields:
            sub_dim_codes = [f.get('dimFieldCode', '') for f in self.sub_dim_fields if isinstance(f, dict)]
            for i, code in enumerate(sub_dim_codes):
                description += f"   - 子维度字段 `{code}` 也必须与主维度一起保持一致（联合分组）\n"
        
        description += f"""2. **每笔进件必须满足 fieldCondition 中定义的筛选条件**（否则不计入{count_unit}）
3. 所有进件时间必须在 {time_desc} 的滑动窗口内
"""

        if self.recent_excluded and self.recent_count:
            recent_unit = self._get_recent_unit_description()
            description += f"4. **近期排除**：要被统计的进件时间不能在最近 {self.recent_count}{recent_unit} 内\n"

        if self.aggregate_by_day:
            next_num = 5 if (self.recent_excluded and self.recent_count) else 4
            description += f"""{next_num}. 若需要增加天数计数，进件应在**不同日期**（同一天多笔只算1天）
"""
        
        return description
    
    def _get_recent_unit_description(self) -> str:
        """获取近期排除的时间单位描述"""
        time_unit = self.time_slice.get('timeUnit', 'DAY')
        unit_map = {
            'SECOND': '秒',
            'MINUTE': '分钟',
            'HOUR': '小时',
            'DAY': '天',
            'WEEK': '周',
            'MONTH': '月'
        }
        return unit_map.get(time_unit, time_unit)
    
    def get_required_fields(self) -> List[str]:
        """获取该模板必需的字段代码列表"""
        fields = []
        if self.dim_field_code:
            fields.append(self.dim_field_code)
        
        # 添加子维度字段
        for sub_dim in self.sub_dim_fields:
            if isinstance(sub_dim, dict):
                sub_code = sub_dim.get('dimFieldCode', '')
                if sub_code:
                    fields.append(sub_code)
            elif isinstance(sub_dim, str):
                fields.append(sub_dim)
        
        # 从 fieldCondition 中提取涉及的字段
        conditions = self.field_condition.get('conditions', [])
        for cond in conditions:
            field_code = cond.get('fieldCode')
            if field_code:
                fields.append(field_code)
            
            # 处理分组条件
            sub_conditions = cond.get('conditions', [])
            for sub_cond in sub_conditions:
                sub_field_code = sub_cond.get('fieldCode')
                if sub_field_code:
                    fields.append(sub_field_code)
        
        return list(set(fields))
    
    def calculate_expected_value(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        计算当前进件的预期指标值
        
        COUNT 模板计算满足条件的进件数量或天数。
        """
        if self.aggregate_by_day:
            # 按天聚合：统计天数
            return self._calculate_by_day(history_events, current_event)
        else:
            # 普通计数：统计次数
            return self._calculate_by_count(history_events, current_event)
    
    def _calculate_by_count(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """按次数计算"""
        # 统计历史进件中满足条件的数量
        # 注意：这里简化处理，假设传入的 history_events 都满足条件
        history_count = len(history_events)
        
        if self.self_included:
            # selfIncluded=true: 先更新再查询
            query_value = history_count + 1
            after_update = query_value
        else:
            # selfIncluded=false: 先查询再更新
            query_value = history_count
            after_update = history_count + 1
        
        return {
            'query_value': query_value,
            'after_update': after_update,
            'self_included': self.self_included
        }
    
    def _calculate_by_day(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """按天数计算（同一天只算1天）"""
        # 提取历史进件的日期（去重）
        history_days = set()
        for event in history_events:
            biztime = event.get('data', {}).get('biztime', '')
            if biztime:
                # 提取日期部分（YYYY-MM-DD）
                day = biztime.split(' ')[0] if ' ' in biztime else biztime[:10]
                history_days.add(day)
        
        # 当前进件的日期
        current_biztime = current_event.get('data', {}).get('biztime', '')
        current_day = None
        if current_biztime:
            current_day = current_biztime.split(' ')[0] if ' ' in current_biztime else current_biztime[:10]
        
        if self.self_included:
            # selfIncluded=true: 先更新再查询
            if current_day:
                history_days.add(current_day)
            query_value = len(history_days)
            after_update = query_value
        else:
            # selfIncluded=false: 先查询再更新
            query_value = len(history_days)
            if current_day:
                history_days.add(current_day)
            after_update = len(history_days)
        
        return {
            'query_value': query_value,
            'after_update': after_update,
            'self_included': self.self_included
        }
    
    def get_event_generation_hint(self, threshold: int, operator: str) -> str:
        """获取进件生成提示"""
        count_unit = "天" if self.aggregate_by_day else "笔"
        
        if self.self_included:
            if operator in ['>=', '>']:
                needed = threshold if operator == '>=' else threshold + 1
                hint = f"需要生成 {needed} {count_unit}的进件（每{count_unit}进件都必须满足 fieldCondition）。"
                if self.aggregate_by_day:
                    hint += f"若需 {needed} 天，进件应分布在 {needed} 个不同日期。"
                hint += f"第 {needed} {count_unit}进件的 query_value={needed}，满足条件 {operator}{threshold}。"
                return hint
        else:
            if operator in ['>=', '>']:
                needed = threshold + 1 if operator == '>=' else threshold + 2
                hint = f"需要生成 {needed} {count_unit}的进件（每{count_unit}进件都必须满足 fieldCondition）。"
                if self.aggregate_by_day:
                    hint += f"若需 {needed} 天，进件应分布在 {needed} 个不同日期。"
                hint += f"第 {needed} {count_unit}进件的 query_value={needed-1}，满足条件 {operator}{threshold}。"
                return hint
        
        return f"根据条件 {operator}{threshold} 和 selfIncluded={self.self_included} 计算所需进件数量。"
    
    def get_formatted_config(self) -> Dict[str, Any]:
        """获取格式化的模板配置"""
        config = super().get_formatted_config()
        config.update({
            'calcMethod': self.calc_method,
            'aggregateByDay': self.aggregate_by_day,
            'readCurrentField': self.read_current_field,
            'recentExcluded': self.recent_excluded,
            'recentCount': self.recent_count,
            'subDimFields': self.sub_dim_fields
        })
        return config
    
    def get_field_condition_description(self) -> str:
        """
        获取 fieldCondition 的可读描述
        
        Returns:
            筛选条件的描述文本
        """
        if not self.field_condition:
            return "无筛选条件"
        
        filter_logic = self.field_condition.get('filterLogic', 'ALL')
        conditions = self.field_condition.get('conditions', [])
        
        if not conditions:
            return "无筛选条件"
        
        logic_map = {
            'ALL': '全部满足',
            'ANY': '任一满足',
            'NONE': '全部不满足'
        }
        
        desc = f"筛选逻辑: {logic_map.get(filter_logic, filter_logic)}\n"
        
        for i, cond in enumerate(conditions, 1):
            field_code = cond.get('fieldCode', '')
            logic = cond.get('logic', '')
            ref_value = cond.get('refValue', '')
            data_type = cond.get('dataType', '')
            
            logic_desc_map = {
                'EQUAL': '等于',
                'NOT_EQUAL': '不等于',
                'GREATER_THAN': '大于',
                'LESS_THAN': '小于',
                'GREATER_THAN_OR_EQUAL': '大于等于',
                'LESS_THAN_OR_EQUAL': '小于等于'
            }
            logic_desc = logic_desc_map.get(logic, logic)
            
            desc += f"  {i}. {field_code} {logic_desc} {ref_value} ({data_type})\n"
        
        return desc
