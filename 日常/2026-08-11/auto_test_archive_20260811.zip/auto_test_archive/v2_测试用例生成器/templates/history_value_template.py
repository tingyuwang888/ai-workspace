"""
HISTORY_VALUE 模板策略 - 历史取值类模板

计算逻辑：取一段时间内满足条件的历史进件中，某个字段的首笔/最近一笔值
- 默认值：null（无历史进件时）
- 结果类型：取决于 valueTakenFieldCode 对应字段（DOUBLE 或 STRING）

核心配置：
- valueTakenMethod：取值方式
  - EARLIEST = 取最早一笔（首笔）
  - LATEST = 取最近一笔
- valueTakenFieldCode：被取值的字段（如 S_F_AMOUNT 交易金额、S_S_IPPROV 省份）
- dimFieldCode：维度字段，用于分组（如银行卡号、登录账号）
- fieldCondition：筛选条件，只有满足条件的进件才会参与取值
- sceneCondition：场景条件，事件类型过滤

与其他模板的关键区别：
- SET/COUNT/STATISTICS 返回聚合数值（整数或浮点数）
- HISTORY_VALUE 返回历史进件中某个字段的**原始值**（字符串或数值）
- 结果可用于与当前进件字段进行比较（如"最近一笔IP省份 != 当前IP省份"）

示例：
- "4小时内同一银行卡号首笔成功出入账交易金额"
  - valueTakenMethod: EARLIEST, valueTakenFieldCode: S_F_AMOUNT
  - 返回最早一笔满足条件的进件的交易金额
- "2小时内同一银行卡号最近一笔在无卡取现预约时IP地址归属省份"
  - valueTakenMethod: LATEST, valueTakenFieldCode: S_S_IPPROV
  - 返回最近一笔满足条件的进件的IP归属省份
"""

from typing import Dict, List, Any, Optional
from templates.base import TemplateStrategy


class HistoryValueTemplateStrategy(TemplateStrategy):
    """
    HISTORY_VALUE 模板策略实现

    历史取值类模板：取满足条件的历史进件中某个字段的首笔/最近一笔值
    """

    TEMPLATE_CODE = "HISTORY_VALUE"
    TEMPLATE_NAME = "历史取值类模板"
    TEMPLATE_DESCRIPTION = "取一段时间内满足条件的历史进件中某个字段的首笔或最近一笔值"

    def __init__(self, metric_def: Dict[str, Any]):
        super().__init__(metric_def)
        self.value_taken_method = self.template_config.get('valueTakenMethod', 'LATEST')
        self.value_taken_field_code = self.template_config.get('valueTakenFieldCode', '')
        self.read_current_field = self.template_config.get('readCurrentField', False)

        # 数据类型
        self.metric_data_type = metric_def.get('metricDataType', 'STRING')

        # 提取 fieldCondition（筛选条件）
        self.field_condition = metric_def.get('fieldCondition', {})

        # 提取 sceneCondition（场景条件）
        self.scene_condition = metric_def.get('sceneCondition', {})

    def get_prompt_description(self) -> str:
        """获取用于 Prompt 的模板计算规则描述"""
        time_desc = self.get_time_slice_description()
        self_included_desc = self.get_self_included_description()

        method_map = {
            'EARLIEST': '最早一笔（首笔）',
            'LATEST': '最近一笔'
        }
        method_desc = method_map.get(self.value_taken_method, self.value_taken_method)

        description = f"""**模板类型**: {self.TEMPLATE_NAME}（{self.TEMPLATE_CODE}）
**计算方式**: 取满足条件的历史进件中 `{self.value_taken_field_code}` 字段的**{method_desc}**值
**时间窗口**: {time_desc}
**selfIncluded**: {self.self_included}（{self_included_desc}）
**取值方式**: {self.value_taken_method}（{method_desc}）
**取值字段**: {self.value_taken_field_code}
**结果类型**: {self.metric_data_type}
"""

        description += f"""
**计算规则详解**：
- 维度字段（dimFieldCode）: `{self.dim_field_code}` - 用于分组
- 取值字段（valueTakenFieldCode）: `{self.value_taken_field_code}` - 从匹配的历史进件中取此字段的值
- 取值方法: {self.value_taken_method}
  - EARLIEST: 在时间窗口内满足条件的进件中，取**时间最早**的那笔的 `{self.value_taken_field_code}` 值
  - LATEST: 在时间窗口内满足条件的进件中，取**时间最近**的那笔的 `{self.value_taken_field_code}` 值
- 筛选条件（fieldCondition）: 每笔历史进件必须满足筛选条件才会被考虑
- **结果是单个值**（不是聚合数值），可能是字符串（如省份名）或数值（如交易金额）
- **无历史进件时返回 null**
"""

        description += f"""
**与聚合类指标的核心区别**：
- SET/COUNT/STATISTICS 返回**聚合统计值**（如计数=5，累加金额=50000）
- HISTORY_VALUE 返回**历史进件中某个字段的原始值**（如"北京"、"1000"）
- 常用于**比较场景**：将历史值与当前进件的字段进行对比
  - 例如：最近一笔IP省份 != 当前IP省份 → 判断IP是否发生变化
  - 例如：首笔交易金额 <= 1000 → 判断是否为小额试探
"""

        if self.self_included:
            description += f"""
**selfIncluded=true 逻辑**：
- 当前进件**先计入历史**，再取值
- 如果当前进件满足条件且是{method_desc}，则返回当前进件自身的 `{self.value_taken_field_code}` 值
"""
        else:
            description += f"""
**selfIncluded=false 逻辑（默认）**：
- 先从历史进件中取值（**不包含当前进件**），再将当前进件纳入历史
- query_value = 历史窗口内满足条件的进件中的{method_desc}的 `{self.value_taken_field_code}` 值
- 如果没有符合条件的历史进件，query_value = null
- **第1笔进件（满足条件）**：query_value = null（没有历史）
- **第2笔进件（满足条件）**：query_value = 第1笔的 `{self.value_taken_field_code}` 值
"""

        description += f"""
**进件生成要点**：
1. 所有进件的维度字段 `{self.dim_field_code}` 必须相同（用于分组）
2. **历史进件必须满足 fieldCondition 中定义的筛选条件**，其值才会被取用
3. 所有进件时间必须在 {time_desc} 的滑动窗口内
4. **取值方式为 {self.value_taken_method}**：
"""
        if self.value_taken_method == 'EARLIEST':
            description += f"""   - 系统取窗口内**最早**满足条件的进件的 `{self.value_taken_field_code}` 值
   - 要使该指标值 = X，需要确保窗口内最早的一笔满足条件的进件的该字段值为 X
   - 后续进件的该字段值不会影响指标结果（除非最早的进件滑出窗口）
"""
        else:
            description += f"""   - 系统取窗口内**最近**满足条件的进件的 `{self.value_taken_field_code}` 值
   - 要使该指标值 = X，需要确保窗口内最近的一笔满足条件的进件的该字段值为 X
   - 新进件（满足条件）会覆盖旧的取值结果
"""

        description += f"""5. **与条件判断的配合**：
   - 该指标常与当前进件的某个字段进行比较（如 != 或 >=）
   - 需要精心设计历史进件的字段值，使指标的取值结果满足或不满足比较条件
   - 例如：要使"历史IP省份 != 当前IP省份"成立，历史进件和验证进件的 IP 省份应不同
"""
        return description

    def get_required_fields(self) -> List[str]:
        """获取该模板必需的字段代码列表"""
        fields = []
        if self.dim_field_code:
            fields.append(self.dim_field_code)
        if self.value_taken_field_code:
            fields.append(self.value_taken_field_code)

        # 从 fieldCondition 中提取涉及的字段
        conditions = self.field_condition.get('conditions', [])
        for cond in conditions:
            field_code = cond.get('fieldCode')
            if field_code:
                fields.append(field_code)
            sub_conditions = cond.get('conditions', [])
            for sub_cond in sub_conditions:
                sub_field_code = sub_cond.get('fieldCode')
                if sub_field_code:
                    fields.append(sub_field_code)
            if cond.get('refType') == 'VARIABLE' and cond.get('refValue'):
                fields.append(cond.get('refValue'))

        return list(set(fields))

    def calculate_expected_value(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        计算当前进件的预期指标值

        HISTORY_VALUE 模板取历史进件中某字段的首笔/最近一笔值。
        """
        if self.self_included:
            # selfIncluded=true: 先将当前进件纳入，再取值
            all_events = history_events + [current_event]
            query_value = self._take_value(all_events)
            after_update = query_value
        else:
            # selfIncluded=false: 先从历史取值，再纳入当前
            query_value = self._take_value(history_events)
            all_events = history_events + [current_event]
            after_update = self._take_value(all_events)

        return {
            'query_value': query_value,
            'after_update': after_update,
            'self_included': self.self_included
        }

    def _take_value(self, events: List[Dict[str, Any]]) -> Optional[Any]:
        """根据取值方法从事件列表中取值"""
        if not events:
            return None

        if self.value_taken_method == 'EARLIEST':
            target = events[0]
        elif self.value_taken_method == 'LATEST':
            target = events[-1]
        else:
            target = events[-1]

        value = target.get('data', {}).get(self.value_taken_field_code)
        if value is None:
            return None

        # 根据数据类型转换
        if self.metric_data_type == 'DOUBLE':
            try:
                return float(value)
            except (ValueError, TypeError):
                return value
        elif self.metric_data_type == 'INT':
            try:
                return int(value)
            except (ValueError, TypeError):
                return value
        return value

    def get_event_generation_hint(self, threshold: Any, operator: str) -> str:
        """获取进件生成提示"""
        method_desc = "最早一笔" if self.value_taken_method == 'EARLIEST' else "最近一笔"

        if operator in ['!=', '==', '=']:
            if operator == '!=':
                return (
                    f"需要确保窗口内{method_desc}满足条件的历史进件的 `{self.value_taken_field_code}` "
                    f"值与比较目标**不同**。"
                    f"例如：历史进件设置为一个值，验证进件设置为另一个不同的值。"
                )
            else:
                return (
                    f"需要确保窗口内{method_desc}满足条件的历史进件的 `{self.value_taken_field_code}` "
                    f"值与比较目标**相同**（= {threshold}）。"
                )
        elif operator in ['>=', '>', '<=', '<']:
            return (
                f"需要确保窗口内{method_desc}满足条件的历史进件的 `{self.value_taken_field_code}` "
                f"值满足 {operator} {threshold}。"
            )
        return (
            f"根据条件 {operator}{threshold}，设计历史进件使{method_desc}的 "
            f"`{self.value_taken_field_code}` 值满足要求。"
        )

    def get_formatted_config(self) -> Dict[str, Any]:
        """获取格式化的模板配置"""
        config = super().get_formatted_config()
        config.update({
            'valueTakenMethod': self.value_taken_method,
            'valueTakenFieldCode': self.value_taken_field_code,
            'readCurrentField': self.read_current_field,
            'metricDataType': self.metric_data_type
        })
        return config

    def get_field_condition_description(self) -> str:
        """获取 fieldCondition 的可读描述"""
        if not self.field_condition:
            return "无筛选条件"

        filter_logic = self.field_condition.get('filterLogic', 'ALL')
        conditions = self.field_condition.get('conditions', [])

        if not conditions:
            return "无筛选条件"

        logic_map = {
            'ALL': '全部满足',
            'ANY': '任一满足',
            'NONE': '全部不满足'
        }

        desc = f"筛选逻辑: {logic_map.get(filter_logic, filter_logic)}\n"

        for i, cond in enumerate(conditions, 1):
            field_code = cond.get('fieldCode', '')
            logic = cond.get('logic', '')
            ref_type = cond.get('refType', 'CONSTANT')
            ref_value = cond.get('refValue', '')
            data_type = cond.get('dataType', '')

            logic_desc_map = {
                'EQUAL': '等于',
                'NOT_EQUAL': '不等于',
                'GREATER_THAN': '大于',
                'LESS_THAN': '小于',
                'GREATER_THAN_OR_EQUAL': '大于等于',
                'LESS_THAN_OR_EQUAL': '小于等于'
            }
            logic_desc = logic_desc_map.get(logic, logic)

            if ref_type == 'VARIABLE':
                desc += f"  {i}. {field_code} {logic_desc} 字段[{ref_value}]的值 ({data_type}, 动态比较)\n"
            else:
                desc += f"  {i}. {field_code} {logic_desc} {ref_value} ({data_type})\n"

            # 处理分组子条件
            sub_conditions = cond.get('conditions', [])
            for j, sub_cond in enumerate(sub_conditions, 1):
                sub_field = sub_cond.get('fieldCode', '')
                sub_logic = sub_cond.get('logic', '')
                sub_ref = sub_cond.get('refValue', '')
                sub_type = sub_cond.get('dataType', '')
                sub_logic_desc = logic_desc_map.get(sub_logic, sub_logic)
                desc += f"    {i}.{j}. {sub_field} {sub_logic_desc} {sub_ref} ({sub_type})\n"

        return desc
