"""
TREND 模板策略 - 趋势类模板

计算逻辑：一段时间内某属性满足趋势条件的最大次数或最大累计个数
- 默认值：0
- 结果类型：整数型（INT）

四种计算方式（calcMethod）：

1. ASC_TOTAL_COUNT（上升总次数）：
   - 统计窗口内相邻事件对中，满足上升趋势条件的总次数

2. DESC_TOTAL_COUNT（下降总次数）：
   - 统计窗口内相邻事件对中，满足下降趋势条件的总次数

3. MAX_CONSECUTIVE_COUNT（最大连续次数）：
   - 在窗口内按时间排序事件，逐对比较 calcFieldCode 字段值
   - 找出连续满足趋势条件的最大连续对数
   - 示例：值序列 [100, 200, 300, 250, 350] trend=ASC
     → 趋势满足: [T, T, F, T]
     → 最大连续次数 = 2（前两个 T）

4. MAX_CONSECUTIVE_ACCUMULATED_COUNT（最大连续累计个数）：
   - 在满足趋势的行为中，找最大连续满足的次数

三种趋势方向（trend）：
- ASC（上升）：后一笔的值比前一笔大
- DESC（下降）：后一笔的值比前一笔小
- FLUCTUATION（波动）：既有上升又有下降

比较幅度配置：
- compareMethod：比较运算符（EQUAL/GREATER_THAN/GREATER_THAN_OR_EQUAL等）
- scale：比较阈值（如 "1" 表示差值为1）
- measurement：比较方式
  - ABSOLUTE：绝对值比较（差值直接与 scale 比较）
  - RELATIVE：相对比例比较（差值百分比与 scale 比较）

核心配置：
- calcMethod：计算方式
- trend：趋势方向（ASC/DESC/FLUCTUATION）
- calcFieldCode：计算字段（数值型）
- compareMethod：比较运算符
- scale：比较值
- measurement：比较方式（ABSOLUTE/RELATIVE）
- dimFieldCode：主维度字段
- subDimFields：子维度字段列表
- timeSlice：时间窗口
- fieldCondition：事件过滤条件

示例指标：
- "登录_5分钟内同一设备ID登录的登录账号呈现出升序且递增间隔为1"（ASC + EQUAL + scale=1）
- "取现_2小时内同一银行卡号失败交易的交易金额连续递减次数"（DESC + GREATER_THAN + scale=0）
"""

from typing import Dict, List, Any, Optional
from templates.base import TemplateStrategy


class TrendTemplateStrategy(TemplateStrategy):
    """
    TREND 模板策略实现

    趋势类模板：统计满足趋势条件的最大次数或最大累计个数
    """

    TEMPLATE_CODE = "TREND"
    TEMPLATE_NAME = "趋势类模板"
    TEMPLATE_DESCRIPTION = "一段时间内某属性满足趋势条件的最大次数或最大累计个数"

    CALC_METHOD_MAP = {
        'MAX_CONSECUTIVE_COUNT': '最大连续次数',
        'MAX_CONSECUTIVE_ACCUMULATED_COUNT': '最大连续累计个数',
        'ASC_TOTAL_COUNT': '上升总次数',
        'DESC_TOTAL_COUNT': '下降总次数',
    }

    TREND_MAP = {
        'ASC': '上升',
        'DESC': '下降',
        'FLUCTUATION': '波动',
    }

    COMPARE_METHOD_MAP = {
        'EQUAL': '等于',
        'GREATER_THAN': '大于',
        'GREATER_THAN_OR_EQUAL': '大于等于',
        'LESS_THAN': '小于',
        'LESS_THAN_OR_EQUAL': '小于等于',
    }

    MEASUREMENT_MAP = {
        'ABSOLUTE': '绝对值',
        'RELATIVE': '相对比例(%)',
    }

    def __init__(self, metric_def: Dict[str, Any]):
        super().__init__(metric_def)

        # 计算方式
        self.calc_method = self.template_config.get('calcMethod', 'MAX_CONSECUTIVE_COUNT')

        # 趋势方向
        self.trend = self.template_config.get('trend', 'ASC')

        # 计算字段
        self.calc_field_code = self.template_config.get('calcFieldCode', '')

        # 比较配置
        self.compare_method = self.template_config.get('compareMethod', 'GREATER_THAN')
        self.scale = self.template_config.get('scale', '0')
        self.measurement = self.template_config.get('measurement', 'ABSOLUTE')

        # 子维度字段
        self.sub_dim_fields = self.template_config.get('subDimFields', [])

        # 事件过滤条件
        self.field_condition = metric_def.get('fieldCondition', {})

    def get_prompt_description(self) -> str:
        """获取用于 Prompt 的模板计算规则描述"""
        time_desc = self.get_time_slice_description()
        self_included_desc = self.get_self_included_description()
        calc_method_cn = self.CALC_METHOD_MAP.get(self.calc_method, self.calc_method)
        trend_cn = self.TREND_MAP.get(self.trend, self.trend)
        compare_cn = self.COMPARE_METHOD_MAP.get(self.compare_method, self.compare_method)
        measurement_cn = self.MEASUREMENT_MAP.get(self.measurement, self.measurement)

        # 构建比较幅度描述
        scale_val = self.scale
        if self.measurement == 'ABSOLUTE':
            amplitude_desc = f"相邻两笔差值（绝对值）{compare_cn} {scale_val}"
        else:
            amplitude_desc = f"相邻两笔差值占前一笔比例 {compare_cn} {scale_val}%"

        # 子维度字段描述
        sub_dim_desc = ""
        if self.sub_dim_fields:
            sub_dim_codes = [f.get('dimFieldCode', '') for f in self.sub_dim_fields]
            sub_dim_desc = f"\n**子维度字段**: {', '.join(sub_dim_codes)} - 同一主维度内进一步按子维度分组"

        # fieldCondition 描述
        fc_desc = self._get_field_condition_desc()

        description = f"""**模板类型**: {self.TEMPLATE_NAME}（{self.TEMPLATE_CODE}）
**计算方式**: {calc_method_cn}（{self.calc_method}）
**趋势方向**: {trend_cn}（{self.trend}）
**计算字段**: `{self.calc_field_code}` - 用于比较趋势的数值型字段
**比较幅度**: {amplitude_desc}（measurement={self.measurement}）
**时间窗口**: {time_desc}
**selfIncluded**: {self.self_included}（{self_included_desc}）
**默认值**: 0（整数型）{sub_dim_desc}
"""

        if self.calc_method == 'MAX_CONSECUTIVE_COUNT':
            description += self._get_max_consecutive_count_desc(
                trend_cn, amplitude_desc, fc_desc
            )
        elif self.calc_method == 'MAX_CONSECUTIVE_ACCUMULATED_COUNT':
            description += self._get_max_consecutive_accumulated_count_desc(
                trend_cn, amplitude_desc, fc_desc
            )
        else:
            description += self._get_total_count_desc(
                trend_cn, amplitude_desc, fc_desc
            )

        return description

    def _get_field_condition_desc(self) -> str:
        """获取 fieldCondition 的简要描述"""
        logic_map = {
            'EQUAL': '等于', 'NOT_EQUAL': '不等于',
            'GREATER_THAN': '大于', 'LESS_THAN': '小于',
            'GREATER_THAN_OR_EQUAL': '大于等于', 'LESS_THAN_OR_EQUAL': '小于等于',
            'NOT_NULL': '不为空',
        }
        conditions = self.field_condition.get('conditions', [])
        if not conditions:
            return ""

        parts = []
        for cond in conditions:
            field_code = cond.get('fieldCode', '')
            logic = cond.get('logic', '')
            ref_value = cond.get('refValue', '')
            sub_conds = cond.get('conditions', [])

            if sub_conds:
                group_logic = cond.get('groupLogic', 'AND')
                sub_parts = []
                for sc in sub_conds:
                    sf = sc.get('fieldCode', '')
                    sl = sc.get('logic', '')
                    srv = sc.get('refValue', '')
                    sl_cn = logic_map.get(sl, sl)
                    sub_parts.append(f"{sf} {sl_cn} {srv}" if srv else f"{sf} {sl_cn}")
                parts.append(f"({f' {group_logic} '.join(sub_parts)})")
            elif field_code and logic:
                logic_cn = logic_map.get(logic, logic)
                parts.append(f"{field_code} {logic_cn} {ref_value}" if ref_value else f"{field_code} {logic_cn}")

        if parts:
            return f"\n  - 事件过滤条件(fieldCondition): {' AND '.join(parts)}"
        return ""

    def _get_max_consecutive_count_desc(
        self, trend_cn: str, amplitude_desc: str, fc_desc: str
    ) -> str:
        """MAX_CONSECUTIVE_COUNT 的详细描述"""
        desc = f"""
**计算规则详解**：
- 维度字段: `{self.dim_field_code}` - 用于分组{fc_desc}
- 在时间窗口内，按时间排序事件（仅保留通过 fieldCondition 筛选的事件）
- 对相邻两笔事件的 `{self.calc_field_code}` 字段值进行比较：
"""
        if self.trend == 'ASC':
            desc += f"""  - 上升趋势判定：后一笔值 - 前一笔值 = diff
  - 判定条件：diff {self.COMPARE_METHOD_MAP.get(self.compare_method, self.compare_method)} {self.scale}
  - 若满足，则这一对算作一次"上升满足"
"""
        elif self.trend == 'DESC':
            desc += f"""  - 下降趋势判定：前一笔值 - 后一笔值 = diff
  - 判定条件：diff {self.COMPARE_METHOD_MAP.get(self.compare_method, self.compare_method)} {self.scale}
  - 若满足，则这一对算作一次"下降满足"
"""
        else:
            desc += """  - 波动趋势判定：序列中既存在上升对又存在下降对
  - 每出现一对使得序列同时包含上升和下降的情况，计数+1
"""
        desc += f"""- 在满足趋势条件的相邻对序列中，找出**最大连续长度**
- 结果 = 最大连续满足趋势条件的对数（整数）

**示例**（trend={self.trend}, {amplitude_desc}，selfIncluded=false）：
"""
        if self.trend == 'DESC':
            desc += """- 5笔进件中通过过滤的事件金额: [1000, 800, 600, 900, 700]
  → 相邻对diff(前-后): [200, 200, -300, 200]
  → 满足条件: [T, T, F, T]
  → 最大连续 = 2
"""
        else:
            desc += """- 5笔进件中通过过滤的事件值: [1001, 1002, 1003, 1005, 1006]
  → 相邻对diff(后-前): [1, 1, 2, 1]
  → 满足条件(等于1): [T, T, F, T]
  → 最大连续 = 2
"""

        if self.self_included:
            desc += """
**selfIncluded=true 影响**：
- 当前进件**先计入**窗口再计算最大连续次数
- 当前进件的 calcField 值会影响最后一对的趋势判定
"""
        else:
            desc += """
**selfIncluded=false 影响（默认）**：
- 先查询历史事件序列的最大连续次数作为 query_value
- 当前进件不参与本次查询
- 第1笔（无历史）：query_value = 0
- 第2笔（1笔历史，0个比较对）：query_value = 0
- 第3笔（2笔历史，1个比较对）：query_value = 0 或 1
"""
        return desc

    def _get_max_consecutive_accumulated_count_desc(
        self, trend_cn: str, amplitude_desc: str, fc_desc: str
    ) -> str:
        """MAX_CONSECUTIVE_ACCUMULATED_COUNT 的详细描述"""
        return f"""
**计算规则详解**：
- 维度字段: `{self.dim_field_code}` - 用于分组{fc_desc}
- 在满足趋势条件的行为序列中，找最大连续满足的次数
- 先判定每对相邻事件是否满足趋势（{trend_cn}），再找最大连续满足的次数
- 结果 = 在趋势满足的子序列中，最大连续满足的对数（整数）
"""

    def _get_total_count_desc(
        self, trend_cn: str, amplitude_desc: str, fc_desc: str
    ) -> str:
        """ASC_TOTAL_COUNT / DESC_TOTAL_COUNT 的详细描述"""
        return f"""
**计算规则详解**：
- 维度字段: `{self.dim_field_code}` - 用于分组{fc_desc}
- 在时间窗口内，按时间排序事件
- 统计所有满足{trend_cn}趋势条件的相邻对总数
- 结果 = 满足趋势条件的总次数（整数，不要求连续）
"""

    def get_required_fields(self) -> List[str]:
        """获取该模板必需的字段代码列表"""
        fields = []
        if self.dim_field_code:
            fields.append(self.dim_field_code)
        if self.calc_field_code:
            fields.append(self.calc_field_code)

        # 子维度字段
        for sub in self.sub_dim_fields:
            sub_code = sub.get('dimFieldCode')
            if sub_code:
                fields.append(sub_code)

        # fieldCondition 中的字段
        conditions = self.field_condition.get('conditions', [])
        for cond in conditions:
            field_code = cond.get('fieldCode')
            if field_code:
                fields.append(field_code)
            sub_conditions = cond.get('conditions', [])
            for sub_cond in sub_conditions:
                sub_field_code = sub_cond.get('fieldCode')
                if sub_field_code:
                    fields.append(sub_field_code)

        return list(set(fields))

    def calculate_expected_value(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        计算当前进件的预期指标值

        TREND 模板计算满足趋势条件的最大连续次数或总次数。
        默认值为 0。
        """
        from loaders.metadata_loader import MetadataManager
        meta = MetadataManager()
        field_def = meta.get_field_def(self.calc_field_code)
        service_param = field_def.get('serviceParam', self.calc_field_code.lower()) if field_def else self.calc_field_code.lower()

        # 提取满足 fieldCondition 的事件的 calcField 值
        def extract_values(events: List[Dict[str, Any]]) -> List[float]:
            values = []
            for event in events:
                data = event.get('data', {})
                # 简化的 fieldCondition 检查
                if self._passes_field_condition(data, meta):
                    val = data.get(service_param)
                    if val is not None:
                        try:
                            values.append(float(val))
                        except (ValueError, TypeError):
                            pass
            return values

        if self.self_included:
            all_events = history_events + [current_event]
            all_values = extract_values(all_events)
            query_value = self._compute_trend_count(all_values)
            after_update = query_value
        else:
            history_values = extract_values(history_events)
            query_value = self._compute_trend_count(history_values)
            all_values = extract_values(history_events + [current_event])
            after_update = self._compute_trend_count(all_values)

        return {
            'query_value': query_value,
            'after_update': after_update,
            'self_included': self.self_included
        }

    def _passes_field_condition(self, data: Dict[str, Any], meta) -> bool:
        """检查事件数据是否通过 fieldCondition 筛选"""
        conditions = self.field_condition.get('conditions', [])
        if not conditions:
            return True

        filter_logic = self.field_condition.get('filterLogic', 'ALL')

        for cond in conditions:
            sub_conditions = cond.get('conditions', [])
            if sub_conditions:
                group_logic = cond.get('groupLogic', 'AND')
                results = []
                for sc in sub_conditions:
                    results.append(self._check_single_condition(sc, data, meta))
                if group_logic == 'AND':
                    group_result = all(results)
                else:
                    group_result = any(results)
                if filter_logic == 'ALL' and not group_result:
                    return False
            else:
                result = self._check_single_condition(cond, data, meta)
                if filter_logic == 'ALL' and not result:
                    return False

        return True

    def _check_single_condition(
        self, cond: Dict[str, Any], data: Dict[str, Any], meta
    ) -> bool:
        """检查单个条件"""
        field_code = cond.get('fieldCode', '')
        logic = cond.get('logic', '')
        ref_value = cond.get('refValue', '')

        field_def = meta.get_field_def(field_code)
        service_param = field_def.get('serviceParam', field_code.lower()) if field_def else field_code.lower()
        actual_value = data.get(service_param)

        if logic == 'NOT_NULL':
            return actual_value is not None and str(actual_value).strip() != ''
        if logic == 'IS_NULL':
            return actual_value is None or str(actual_value).strip() == ''
        if logic == 'EQUAL':
            return str(actual_value) == str(ref_value)
        if logic == 'NOT_EQUAL':
            return str(actual_value) != str(ref_value)

        try:
            av = float(actual_value)
            rv = float(ref_value)
            if logic == 'GREATER_THAN':
                return av > rv
            if logic == 'LESS_THAN':
                return av < rv
            if logic == 'GREATER_THAN_OR_EQUAL':
                return av >= rv
            if logic == 'LESS_THAN_OR_EQUAL':
                return av <= rv
        except (ValueError, TypeError):
            pass

        return False

    def _check_trend_pair(self, prev_value: float, next_value: float) -> bool:
        """检查一对相邻值是否满足趋势条件"""
        # 计算差值
        if self.trend == 'ASC':
            diff = next_value - prev_value
        elif self.trend == 'DESC':
            diff = prev_value - next_value
        else:
            # FLUCTUATION 需要在序列级别判断
            return False

        # 应用 measurement
        if self.measurement == 'RELATIVE':
            if prev_value == 0:
                return False
            diff = (diff / abs(prev_value)) * 100

        # 应用 compareMethod + scale
        try:
            scale_val = float(self.scale)
        except (ValueError, TypeError):
            scale_val = 0.0

        return self._compare(diff, scale_val)

    def _compare(self, value: float, threshold: float) -> bool:
        """应用比较运算符"""
        if self.compare_method == 'EQUAL':
            return abs(value - threshold) < 1e-9
        elif self.compare_method == 'GREATER_THAN':
            return value > threshold
        elif self.compare_method == 'GREATER_THAN_OR_EQUAL':
            return value >= threshold
        elif self.compare_method == 'LESS_THAN':
            return value < threshold
        elif self.compare_method == 'LESS_THAN_OR_EQUAL':
            return value <= threshold
        return False

    def _compute_trend_count(self, values: List[float]) -> int:
        """根据 calcMethod 计算趋势计数"""
        if len(values) < 2:
            return 0

        if self.trend == 'FLUCTUATION':
            return self._compute_fluctuation_count(values)

        # 构建满足趋势条件的布尔序列
        satisfies = []
        for i in range(1, len(values)):
            satisfies.append(self._check_trend_pair(values[i - 1], values[i]))

        if self.calc_method == 'MAX_CONSECUTIVE_COUNT':
            return self._max_consecutive_true(satisfies)
        elif self.calc_method == 'MAX_CONSECUTIVE_ACCUMULATED_COUNT':
            return self._max_consecutive_true(satisfies)
        elif self.calc_method in ('ASC_TOTAL_COUNT', 'DESC_TOTAL_COUNT'):
            return sum(1 for s in satisfies if s)
        else:
            return self._max_consecutive_true(satisfies)

    def _compute_fluctuation_count(self, values: List[float]) -> int:
        """计算波动趋势的计数"""
        if len(values) < 3:
            return 0

        has_asc = False
        has_desc = False

        for i in range(1, len(values)):
            if values[i] > values[i - 1]:
                has_asc = True
            elif values[i] < values[i - 1]:
                has_desc = True

        if has_asc and has_desc:
            # 序列存在波动，统计方向变化次数
            changes = 0
            for i in range(2, len(values)):
                prev_dir = values[i - 1] - values[i - 2]
                curr_dir = values[i] - values[i - 1]
                if (prev_dir > 0 and curr_dir < 0) or (prev_dir < 0 and curr_dir > 0):
                    changes += 1
            return changes
        return 0

    def _max_consecutive_true(self, booleans: List[bool]) -> int:
        """计算布尔序列中连续 True 的最大长度"""
        max_count = 0
        current_count = 0
        for b in booleans:
            if b:
                current_count += 1
                max_count = max(max_count, current_count)
            else:
                current_count = 0
        return max_count

    def get_event_generation_hint(self, threshold: int, operator: str) -> str:
        """获取进件生成提示"""
        calc_method_cn = self.CALC_METHOD_MAP.get(self.calc_method, self.calc_method)
        trend_cn = self.TREND_MAP.get(self.trend, self.trend)
        compare_cn = self.COMPARE_METHOD_MAP.get(self.compare_method, self.compare_method)

        if self.calc_method == 'MAX_CONSECUTIVE_COUNT':
            if self.self_included:
                needed = threshold if operator == '>=' else threshold + 1
            else:
                needed = threshold + 1 if operator == '>=' else threshold + 2

            return (
                f"需要生成至少 {needed + 1} 笔连续进件，"
                f"使相邻事件的 {self.calc_field_code} 呈{trend_cn}趋势"
                f"（差值 {compare_cn} {self.scale}），"
                f"连续满足 {threshold} 对以上。"
                f"selfIncluded={self.self_included}。"
            )
        else:
            return (
                f"需要生成足够进件使满足{trend_cn}趋势条件的总次数 "
                f"{operator} {threshold}。"
            )

    def get_formatted_config(self) -> Dict[str, Any]:
        """获取格式化的模板配置"""
        config = super().get_formatted_config()
        config.update({
            'calcMethod': self.calc_method,
            'trend': self.trend,
            'calcFieldCode': self.calc_field_code,
            'compareMethod': self.compare_method,
            'scale': self.scale,
            'measurement': self.measurement,
        })
        if self.sub_dim_fields:
            config['subDimFields'] = self.sub_dim_fields
        return config
