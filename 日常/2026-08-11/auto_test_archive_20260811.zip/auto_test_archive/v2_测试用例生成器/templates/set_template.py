"""
SET 模板策略 - 关联类模板

计算逻辑：一段时间内某属性关联其他属性的去重数量
- 默认值：0
- 结果类型：整数型

示例：
- "24小时内同一设备ID关联注册成功登录账号个数"
- dimFieldCode: S_S_DEVICEID（维度字段，用于分组）
- setFieldCode: S_S_ACCOUNTLOGIN（集合字段，用于去重计数）
"""

from typing import Dict, List, Any
from templates.base import TemplateStrategy


class SetTemplateStrategy(TemplateStrategy):
    """
    SET 模板策略实现
    
    关联类模板：统计维度字段相同、集合字段不同的进件数量（去重）
    """
    
    TEMPLATE_CODE = "SET"
    TEMPLATE_NAME = "关联类模板"
    TEMPLATE_DESCRIPTION = "一段时间内某属性关联其他属性的去重数量"
    
    def __init__(self, metric_def: Dict[str, Any]):
        super().__init__(metric_def)
        self.set_field_code = self.template_config.get('setFieldCode', '')
        self.set_slice_size = self.template_config.get('setSliceSize', 20)
        self.read_current_field = self.template_config.get('readCurrentField', False)
    
    def get_prompt_description(self) -> str:
        """获取用于 Prompt 的模板计算规则描述"""
        time_desc = self.get_time_slice_description()
        self_included_desc = self.get_self_included_description()
        
        description = f"""**模板类型**: {self.TEMPLATE_NAME}（{self.TEMPLATE_CODE}）
**计算方式**: 统计 `{self.dim_field_code}` 相同的进件中，`{self.set_field_code}` 的**去重数量**
**时间窗口**: {time_desc}
**selfIncluded**: {self.self_included}（{self_included_desc}）

**计算规则详解**：
- 维度字段（dimFieldCode）: `{self.dim_field_code}` - 用于分组聚合
- 集合字段（setFieldCode）: `{self.set_field_code}` - 每笔进件该字段的值会被收集并去重
- 结果 = 时间窗口内，维度字段相同的进件中，集合字段的不同值数量

**selfIncluded 影响**：
"""
        if self.self_included:
            description += """- `selfIncluded=true`: 当前进件的集合字段值**先计入**再查询
  - 第1笔：集合={v1}，query_value=1（已含自己）
  - 第2笔（集合字段值=v2≠v1）：集合={v1,v2}，query_value=2
  - 第N笔（集合字段值=vN，新值）：query_value=N
  - 注意：如果多笔进件的集合字段值相同，则不会增加计数（去重）"""
        else:
            description += """- `selfIncluded=false`: 先查询历史，**再**将当前进件的集合字段值计入
  - 第1笔：历史集合={}，query_value=0
  - 第2笔（集合字段值=v2≠v1）：历史集合={v1}，query_value=1
  - 第N笔（集合字段值=vN，新值）：query_value=N-1
  - 注意：如果多笔进件的集合字段值相同，则不会增加计数（去重）"""
        
        description += f"""

**进件生成要点**：
1. 所有进件的维度字段 `{self.dim_field_code}` 必须相同（用于聚合）
2. 每笔进件的集合字段 `{self.set_field_code}` 应该**不同**（否则不会增加去重计数）
3. 所有进件时间必须在 {time_desc} 的滑动窗口内
"""
        return description
    
    def get_required_fields(self) -> List[str]:
        """获取该模板必需的字段代码列表"""
        fields = []
        if self.dim_field_code:
            fields.append(self.dim_field_code)
        if self.set_field_code:
            fields.append(self.set_field_code)
        return fields
    
    def calculate_expected_value(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        计算当前进件的预期指标值
        
        SET 模板计算去重集合的大小。
        """
        # 提取历史进件的集合字段值（去重）
        history_set = set()
        for event in history_events:
            value = event.get('data', {}).get(self.set_field_code)
            if value is not None:
                history_set.add(value)
        
        # 当前进件的集合字段值
        current_value = current_event.get('data', {}).get(self.set_field_code)
        
        if self.self_included:
            # selfIncluded=true: 先更新再查询
            if current_value is not None:
                history_set.add(current_value)
            query_value = len(history_set)
            after_update = query_value
        else:
            # selfIncluded=false: 先查询再更新
            query_value = len(history_set)
            if current_value is not None:
                history_set.add(current_value)
            after_update = len(history_set)
        
        return {
            'query_value': query_value,
            'after_update': after_update,
            'self_included': self.self_included
        }
    
    def get_event_generation_hint(self, threshold: int, operator: str) -> str:
        """获取进件生成提示"""
        if self.self_included:
            if operator in ['>=', '>']:
                needed = threshold if operator == '>=' else threshold + 1
                return (
                    f"需要生成 {needed} 笔进件，每笔进件的 `{self.set_field_code}` 值各不相同。"
                    f"第 {needed} 笔进件的 query_value={needed}，满足条件 {operator}{threshold}。"
                )
            elif operator in ['<=', '<']:
                return (
                    f"生成的进件数量应使去重集合大小始终满足条件 {operator}{threshold}。"
                    f"注意：selfIncluded=true 时第一笔就有 query_value=1。"
                )
        else:
            if operator in ['>=', '>']:
                needed = threshold + 1 if operator == '>=' else threshold + 2
                return (
                    f"需要生成 {needed} 笔进件，每笔进件的 `{self.set_field_code}` 值各不相同。"
                    f"第 {needed} 笔进件的 query_value={needed-1}，满足条件 {operator}{threshold}。"
                )
            elif operator in ['<=', '<']:
                return (
                    f"生成的进件数量应使去重集合大小始终满足条件 {operator}{threshold}。"
                )
        
        return f"根据条件 {operator}{threshold} 和 selfIncluded={self.self_included} 计算所需进件数量。"
    
    def get_formatted_config(self) -> Dict[str, Any]:
        """获取格式化的模板配置"""
        config = super().get_formatted_config()
        config.update({
            'setFieldCode': self.set_field_code,
            'setSliceSize': self.set_slice_size,
            'readCurrentField': self.read_current_field
        })
        return config
