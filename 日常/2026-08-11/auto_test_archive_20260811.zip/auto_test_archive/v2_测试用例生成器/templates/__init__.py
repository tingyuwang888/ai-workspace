"""
指标模板策略模块

提供不同指标模板类型的策略实现，支持：
- SET：关联类模板（去重统计）
- COUNT：次数类模板（计数/天数统计）
- STATISTICS：金额类模板（SUM/AVG/MAX/MIN）
- HISTORY_VALUE：历史取值类模板（首笔/最近一笔值）
- FORMULA：公式类模板（DSL公式计算）
- TIME_GAP：时间差类模板（时间间隔/事件时间间隔）
- CONSECUTIVE：连续类模板（最大连续次数/最大连续累计个数）
- TREND：趋势类模板（趋势方向的最大连续/总次数）
- MOVEMENT：移动类模板（移动距离/移动速度）
"""

from templates.base import TemplateStrategy, TemplateRegistry
from templates.set_template import SetTemplateStrategy
from templates.count_template import CountTemplateStrategy
from templates.statistics_template import StatisticsTemplateStrategy
from templates.history_value_template import HistoryValueTemplateStrategy
from templates.formula_template import FormulaTemplateStrategy
from templates.time_gap_template import TimeGapTemplateStrategy
from templates.consecutive_template import ConsecutiveTemplateStrategy
from templates.trend_template import TrendTemplateStrategy
from templates.movement_template import MovementTemplateStrategy

# 注册内置模板策略
TemplateRegistry.register('SET', SetTemplateStrategy)
TemplateRegistry.register('COUNT', CountTemplateStrategy)
TemplateRegistry.register('STATISTICS', StatisticsTemplateStrategy)
TemplateRegistry.register('HISTORY_VALUE', HistoryValueTemplateStrategy)
TemplateRegistry.register('FORMULA', FormulaTemplateStrategy)
TemplateRegistry.register('TIME_GAP', TimeGapTemplateStrategy)
TemplateRegistry.register('CONSECUTIVE', ConsecutiveTemplateStrategy)
TemplateRegistry.register('TREND', TrendTemplateStrategy)
TemplateRegistry.register('MOVEMENT', MovementTemplateStrategy)

__all__ = [
    'TemplateStrategy',
    'TemplateRegistry',
    'SetTemplateStrategy',
    'CountTemplateStrategy',
    'StatisticsTemplateStrategy',
    'HistoryValueTemplateStrategy',
    'FormulaTemplateStrategy',
    'TimeGapTemplateStrategy',
    'ConsecutiveTemplateStrategy',
    'TrendTemplateStrategy',
    'MovementTemplateStrategy',
]
