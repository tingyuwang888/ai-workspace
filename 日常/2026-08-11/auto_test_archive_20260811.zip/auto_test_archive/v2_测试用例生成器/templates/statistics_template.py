"""
STATISTICS 模板策略 - 金额类模板

计算逻辑：一段时间内某属性的数值型字段的统计值（SUM/AVG/MAX/MIN）
- 默认值：0
- 结果类型：DOUBLE（浮点型）

核心配置：
- calcMethod：统计方法（SUM=求和、AVG=平均、MAX=最大、MIN=最小）
- calcFieldCode：被统计的数值字段（如 S_F_AMOUNT 交易金额）
- dimFieldCode：维度字段，用于分组（如银行卡号、客户编号）
- fieldCondition：筛选条件，只有满足条件的进件才参与统计
- sceneCondition：场景条件，事件类型过滤（由策略定义决定，不通过入参控制）

示例：
- "1天内同一客户编号累计转账成功金额"
- dimFieldCode: S_S_CUSTNO（维度字段，用于分组）
- calcFieldCode: S_F_AMOUNT（被累加的金额字段）
- calcMethod: SUM（求和）
- fieldCondition: 交易状态=成功
"""

from typing import Dict, List, Any
from templates.base import TemplateStrategy


class StatisticsTemplateStrategy(TemplateStrategy):
    """
    STATISTICS 模板策略实现

    金额类模板：对满足条件的进件的数值字段进行统计计算（SUM/AVG/MAX/MIN）
    """

    TEMPLATE_CODE = "STATISTICS"
    TEMPLATE_NAME = "金额类模板"
    TEMPLATE_DESCRIPTION = "一段时间内某属性的数值型字段的统计值"

    def __init__(self, metric_def: Dict[str, Any]):
        super().__init__(metric_def)
        self.calc_method = self.template_config.get('calcMethod', 'SUM')
        self.calc_field_code = self.template_config.get('calcFieldCode', '')
        self.read_current_field = self.template_config.get('readCurrentField', False)

        # 近期排除配置
        self.recent_excluded = self.time_slice.get('recentExcluded', False) or False
        self.recent_count = self.time_slice.get('recentCount') or 0

        # 提取 fieldCondition（筛选条件）
        self.field_condition = metric_def.get('fieldCondition', {})

        # 提取 sceneCondition（场景条件）
        self.scene_condition = metric_def.get('sceneCondition', {})

    def get_prompt_description(self) -> str:
        """获取用于 Prompt 的模板计算规则描述"""
        time_desc = self.get_time_slice_description()
        self_included_desc = self.get_self_included_description()

        calc_method_map = {
            'SUM': '累加求和',
            'AVG': '求平均值',
            'MAX': '取最大值',
            'MIN': '取最小值'
        }
        calc_desc = calc_method_map.get(self.calc_method, self.calc_method)

        description = f"""**模板类型**: {self.TEMPLATE_NAME}（{self.TEMPLATE_CODE}）
**计算方式**: 对满足条件的进件，取 `{self.calc_field_code}` 字段值进行 **{calc_desc}**
**时间窗口**: {time_desc}
**selfIncluded**: {self.self_included}（{self_included_desc}）
**统计方法**: {self.calc_method}
**统计字段**: {self.calc_field_code}
"""

        description += f"""
**计算规则详解**：
- 维度字段（dimFieldCode）: `{self.dim_field_code}` - 用于分组聚合
- 统计字段（calcFieldCode）: `{self.calc_field_code}` - 每笔进件该字段的数值会参与统计
- 筛选条件（fieldCondition）: 每笔进件必须满足筛选条件才会参与统计
- 结果 = 时间窗口内，维度字段相同且满足筛选条件的进件中，统计字段的{calc_desc}值
- **结果类型**: DOUBLE（浮点数），不是整数！
"""

        # SUM 的具体说明
        if self.calc_method == 'SUM':
            description += f"""
**SUM 累加逻辑**：
- 每笔满足条件的进件，其 `{self.calc_field_code}` 值会被累加
- 例如：3笔进件金额分别为 10000、15000、20000，则 SUM = 45000
- ⚠️ 注意：`{self.calc_field_code}` 的值必须是数值型，且每笔进件可以不同
"""

        description += f"""
**selfIncluded 影响（金额累加场景）**：
"""
        if self.self_included:
            description += f"""- `selfIncluded=true`: 当前进件的 `{self.calc_field_code}` **先计入**再查询
  - 第1笔（金额=A1，满足条件）：query_value=A1
  - 第2笔（金额=A2，满足条件）：query_value=A1+A2
  - 第N笔（金额=AN，满足条件）：query_value=A1+A2+...+AN
  - 注意：不满足 fieldCondition 的进件金额不会被累加"""
        else:
            description += f"""- `selfIncluded=false`: 先查询历史累计，**再**将当前进件金额计入
  - 第1笔（金额=A1，满足条件）：query_value=0（不含自己）
  - 第2笔（金额=A2，满足条件）：query_value=A1
  - 第3笔（金额=A3，满足条件）：query_value=A1+A2
  - 第N笔（金额=AN，满足条件）：query_value=A1+A2+...+A(N-1)
  - after_update = query_value + AN（处理后的累计值）
  - 注意：不满足 fieldCondition 的进件金额不会被累加"""

        description += f"""

**进件生成要点**：
1. 所有进件的维度字段 `{self.dim_field_code}` 必须相同（用于聚合）
2. **每笔进件必须满足 fieldCondition 中定义的筛选条件**，其金额才会被累加
3. 每笔进件的 `{self.calc_field_code}` 字段值（金额）可以不同，需合理设计使累计值达到或不达到阈值
4. 所有进件时间必须在 {time_desc} 的滑动窗口内
5. **金额分配策略**：
   - 要触发条件（如 >=45000）：设计若干笔金额之和达到阈值，如 15000×3=45000
   - 不触发条件：确保累计金额低于阈值，如 10000×2=20000 < 45000
   - 推荐：使用整数金额（如 10000、15000、20000），便于验证
"""
        return description

    def get_required_fields(self) -> List[str]:
        """获取该模板必需的字段代码列表"""
        fields = []
        if self.dim_field_code:
            fields.append(self.dim_field_code)
        if self.calc_field_code:
            fields.append(self.calc_field_code)

        # 从 fieldCondition 中提取涉及的字段
        conditions = self.field_condition.get('conditions', [])
        for cond in conditions:
            field_code = cond.get('fieldCode')
            if field_code:
                fields.append(field_code)
            # 处理分组条件
            sub_conditions = cond.get('conditions', [])
            for sub_cond in sub_conditions:
                sub_field_code = sub_cond.get('fieldCode')
                if sub_field_code:
                    fields.append(sub_field_code)
            # 处理 VARIABLE 引用的字段
            if cond.get('refType') == 'VARIABLE' and cond.get('refValue'):
                fields.append(cond.get('refValue'))

        return list(set(fields))

    def calculate_expected_value(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        计算当前进件的预期指标值

        STATISTICS 模板计算满足条件的进件的统计值（SUM/AVG/MAX/MIN）。
        """
        # 提取历史进件的统计字段值
        history_values = []
        for event in history_events:
            value = event.get('data', {}).get(self.calc_field_code)
            if value is not None:
                try:
                    history_values.append(float(value))
                except (ValueError, TypeError):
                    pass

        # 当前进件的统计字段值
        current_value = None
        raw_value = current_event.get('data', {}).get(self.calc_field_code)
        if raw_value is not None:
            try:
                current_value = float(raw_value)
            except (ValueError, TypeError):
                pass

        if self.self_included:
            # selfIncluded=true: 先更新再查询
            if current_value is not None:
                history_values.append(current_value)
            query_value = self._calc_stat(history_values)
            after_update = query_value
        else:
            # selfIncluded=false: 先查询再更新
            query_value = self._calc_stat(history_values)
            if current_value is not None:
                history_values.append(current_value)
            after_update = self._calc_stat(history_values)

        return {
            'query_value': query_value,
            'after_update': after_update,
            'self_included': self.self_included
        }

    def _calc_stat(self, values: List[float]) -> float:
        """根据统计方法计算结果"""
        if not values:
            return 0.0

        if self.calc_method == 'SUM':
            return sum(values)
        elif self.calc_method == 'AVG':
            return sum(values) / len(values)
        elif self.calc_method == 'MAX':
            return max(values)
        elif self.calc_method == 'MIN':
            return min(values)
        else:
            return sum(values)

    def get_event_generation_hint(self, threshold: float, operator: str) -> str:
        """获取进件生成提示"""
        if self.calc_method == 'SUM':
            if operator in ['>=', '>']:
                target = threshold if operator == '>=' else threshold + 1
                if self.self_included:
                    return (
                        f"需要设计若干笔满足条件的进件，使 `{self.calc_field_code}` 的累加和达到 {target}。"
                        f"selfIncluded=true，当前笔金额也计入 query_value。"
                        f"推荐：将 {target} 拆分为若干笔整数金额（如 {int(target)}=N笔×单笔金额）。"
                    )
                else:
                    return (
                        f"需要设计若干笔满足条件的进件，使历史进件 `{self.calc_field_code}` 的累加和达到 {target}。"
                        f"selfIncluded=false，query_value 不含当前笔金额。"
                        f"需要足够的历史进件使历史累计 >= {target}，再来一笔验证进件。"
                    )
            elif operator in ['<=', '<']:
                return (
                    f"设计进件使 `{self.calc_field_code}` 的累加和始终满足条件 {operator}{threshold}。"
                )
        return f"根据条件 {operator}{threshold} 和 selfIncluded={self.self_included} 计算所需进件金额分配。"

    def get_formatted_config(self) -> Dict[str, Any]:
        """获取格式化的模板配置"""
        config = super().get_formatted_config()
        config.update({
            'calcMethod': self.calc_method,
            'calcFieldCode': self.calc_field_code,
            'readCurrentField': self.read_current_field,
            'recentExcluded': self.recent_excluded,
            'recentCount': self.recent_count
        })
        return config

    def get_field_condition_description(self) -> str:
        """获取 fieldCondition 的可读描述"""
        if not self.field_condition:
            return "无筛选条件"

        filter_logic = self.field_condition.get('filterLogic', 'ALL')
        conditions = self.field_condition.get('conditions', [])

        if not conditions:
            return "无筛选条件"

        logic_map = {
            'ALL': '全部满足',
            'ANY': '任一满足',
            'NONE': '全部不满足'
        }

        desc = f"筛选逻辑: {logic_map.get(filter_logic, filter_logic)}\n"

        for i, cond in enumerate(conditions, 1):
            field_code = cond.get('fieldCode', '')
            logic = cond.get('logic', '')
            ref_type = cond.get('refType', 'CONSTANT')
            ref_value = cond.get('refValue', '')
            data_type = cond.get('dataType', '')

            logic_desc_map = {
                'EQUAL': '等于',
                'NOT_EQUAL': '不等于',
                'GREATER_THAN': '大于',
                'LESS_THAN': '小于',
                'GREATER_THAN_OR_EQUAL': '大于等于',
                'LESS_THAN_OR_EQUAL': '小于等于'
            }
            logic_desc = logic_desc_map.get(logic, logic)

            if ref_type == 'VARIABLE':
                desc += f"  {i}. {field_code} {logic_desc} 字段[{ref_value}]的值 ({data_type}, 动态比较)\n"
            else:
                desc += f"  {i}. {field_code} {logic_desc} {ref_value} ({data_type})\n"

        return desc
