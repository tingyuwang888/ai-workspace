"""
MOVEMENT 模板策略 - 移动类模板

计算逻辑：一段时间内某属性的移动距离或移动速度
- 默认值：null
- 结果类型：小数型（DOUBLE）

两种计算方式（calcMethod）：

1. DISTANCE（移动距离，单位：米）：
   - 根据经纬度计算主属性一段时间内移动的累计距离
   - 按时间排序窗口内事件，计算相邻事件之间的地理距离并求和
   - 使用 Haversine 公式计算两点间的地球表面距离

2. SPEED（移动速度，单位：米/小时）：
   - 根据经纬度计算主属性一段时间内的移动速度
   - 速度 = 累计移动距离 / 时间跨度（小时）
   - 时间跨度 = 窗口内最后一个事件时间 - 第一个事件时间

核心配置：
- calcMethod：计算方式（DISTANCE / SPEED）
- longitudeFieldCode：经度字段
- latitudeFieldCode：纬度字段
- dimFieldCode：主维度字段
- timeSlice：时间窗口
- fieldCondition：事件过滤条件

示例指标：
- "登录_2小时内同一登录账号移动距离"（DISTANCE，selfIncluded=true）
"""

import math
from datetime import datetime
from typing import Dict, List, Any, Optional

from templates.base import TemplateStrategy


class MovementTemplateStrategy(TemplateStrategy):
    """
    MOVEMENT 模板策略实现

    移动类模板：计算一段时间内某属性的移动距离或移动速度
    """

    TEMPLATE_CODE = "MOVEMENT"
    TEMPLATE_NAME = "移动类模板"
    TEMPLATE_DESCRIPTION = "一段时间内某属性的移动距离或移动速度"

    CALC_METHOD_MAP = {
        'DISTANCE': '移动距离（米）',
        'SPEED': '移动速度（米/小时）',
    }

    def __init__(self, metric_def: Dict[str, Any]):
        super().__init__(metric_def)

        # 计算方式
        self.calc_method = self.template_config.get('calcMethod', 'DISTANCE')

        # 经纬度字段
        self.longitude_field_code = self.template_config.get('longitudeFieldCode', '')
        self.latitude_field_code = self.template_config.get('latitudeFieldCode', '')

        # 事件过滤条件
        self.field_condition = metric_def.get('fieldCondition', {})

    # ------------------------------------------------------------------ #
    #  Prompt 描述
    # ------------------------------------------------------------------ #

    def get_prompt_description(self) -> str:
        """获取用于 Prompt 的模板计算规则描述"""
        time_desc = self.get_time_slice_description()
        self_included_desc = self.get_self_included_description()
        calc_method_cn = self.CALC_METHOD_MAP.get(self.calc_method, self.calc_method)

        # fieldCondition 描述
        fc_desc = self._get_field_condition_desc()

        description = f"""**模板类型**: {self.TEMPLATE_NAME}（{self.TEMPLATE_CODE}）
**计算方式**: {calc_method_cn}（{self.calc_method}）
**经度字段**: `{self.longitude_field_code}`
**纬度字段**: `{self.latitude_field_code}`
**时间窗口**: {time_desc}
**selfIncluded**: {self.self_included}（{self_included_desc}）
**默认值**: null（小数型，无数据或不足2个坐标点时返回 null）
"""

        if self.calc_method == 'DISTANCE':
            description += self._get_distance_desc(fc_desc)
        else:
            description += self._get_speed_desc(fc_desc)

        return description

    def _get_field_condition_desc(self) -> str:
        """获取 fieldCondition 的简要描述"""
        logic_map = {
            'EQUAL': '等于', 'NOT_EQUAL': '不等于',
            'GREATER_THAN': '大于', 'LESS_THAN': '小于',
            'GREATER_THAN_OR_EQUAL': '大于等于', 'LESS_THAN_OR_EQUAL': '小于等于',
            'NOT_NULL': '不为空',
        }
        conditions = self.field_condition.get('conditions', [])
        if not conditions:
            return ""

        parts = []
        for cond in conditions:
            field_code = cond.get('fieldCode', '')
            logic = cond.get('logic', '')
            ref_value = cond.get('refValue', '')
            sub_conds = cond.get('conditions', [])

            if sub_conds:
                group_logic = cond.get('groupLogic', 'AND')
                sub_parts = []
                for sc in sub_conds:
                    sf = sc.get('fieldCode', '')
                    sl = sc.get('logic', '')
                    srv = sc.get('refValue', '')
                    sl_cn = logic_map.get(sl, sl)
                    sub_parts.append(f"{sf} {sl_cn} {srv}" if srv else f"{sf} {sl_cn}")
                parts.append(f"({f' {group_logic} '.join(sub_parts)})")
            elif field_code and logic:
                logic_cn = logic_map.get(logic, logic)
                parts.append(f"{field_code} {logic_cn} {ref_value}" if ref_value else f"{field_code} {logic_cn}")

        if parts:
            return f"\n  - 事件过滤条件(fieldCondition): {' AND '.join(parts)}"
        return ""

    def _get_distance_desc(self, fc_desc: str) -> str:
        """移动距离（DISTANCE）的详细计算规则描述"""
        desc = f"""
**计算规则详解**：
- 维度字段: `{self.dim_field_code}` - 用于分组{fc_desc}
- 在时间窗口内，按时间排序同一维度的所有事件
- 提取每笔事件的经度（`{self.longitude_field_code}`）和纬度（`{self.latitude_field_code}`）
- 使用 Haversine 公式计算相邻两笔事件之间的地球表面距离（米）
- 将所有相邻事件对的距离累加，得到总移动距离
- 窗口内仅有 0 或 1 笔有效事件时，返回 **null**（无法计算移动距离）
- 2 笔及以上事件时返回累计距离（单位：米，小数型）

**Haversine 公式**（地球表面两点距离）：
- R = 6371000 米（地球平均半径）
- d = 2R × arcsin(√(sin²((φ₂−φ₁)/2) + cos(φ₁)·cos(φ₂)·sin²((λ₂−λ₁)/2)))

**⚠️ 关于 expected_metric_values 中 query_value 的设置**：
- 移动距离由 Haversine 公式计算，LLM 难以精确计算
- **第1笔进件（窗口内不足2个点）：query_value = null**
- **第2笔及之后：query_value 设为 null，系统会根据经纬度自动计算**
- LLM 的核心任务是构造合适的经纬度坐标，使移动距离满足条件要求

**常用中国城市经纬度参考**（用于构造测试数据）：
- 北京: (116.407, 39.904)，上海: (121.474, 31.230)（≈1068km）
- 广州: (113.264, 23.129)，深圳: (114.058, 22.543)（≈105km）
- 成都: (104.066, 30.573)，重庆: (106.551, 29.563)（≈269km）
- 北京→广州 ≈ 1888km，上海→广州 ≈ 1213km
"""

        if self.self_included:
            desc += """
**selfIncluded=true 影响**：
- 当前进件**参与**移动距离计算（先更新再查询）
- 第1笔进件：窗口仅当前1笔，无法计算距离 → query_value = null
- 第2笔进件：窗口包含历史1笔+当前，可计算1段距离 → query_value = 两点距离
- 第3笔进件：窗口包含历史2笔+当前，累加2段距离 → query_value = 总距离
"""
        else:
            desc += """
**selfIncluded=false 影响**：
- 先查询历史事件的移动距离作为 query_value，当前进件不参与
- 第1笔（无历史）：query_value = null
- 第2笔（1笔历史，仅1个点）：query_value = null
- 第3笔（2笔历史）：query_value = 两点距离
"""
        return desc

    def _get_speed_desc(self, fc_desc: str) -> str:
        """移动速度（SPEED）的详细计算规则描述"""
        return f"""
**计算规则详解**：
- 维度字段: `{self.dim_field_code}` - 用于分组{fc_desc}
- 在时间窗口内，按时间排序同一维度的所有事件
- 计算累计移动距离（同 DISTANCE 方式，Haversine 公式）
- 计算时间跨度 = 最后一笔事件时间 − 第一笔事件时间（小时）
- 移动速度 = 累计移动距离 / 时间跨度（米/小时）
- 窗口内仅有 0 或 1 笔有效事件时，返回 **null**
- 若时间跨度为 0（所有事件同一时刻），返回 **null**

**⚠️ 关于 expected_metric_values 中 query_value 的设置**：
- 移动速度涉及距离计算，LLM 难以精确计算
- **不足2个点或时间跨度为0时：query_value = null**
- **其他情况：query_value 设为 null，系统会根据经纬度和时间自动计算**
"""

    # ------------------------------------------------------------------ #
    #  字段依赖
    # ------------------------------------------------------------------ #

    def get_required_fields(self) -> List[str]:
        """获取该模板必需的字段代码列表"""
        fields = []
        if self.dim_field_code:
            fields.append(self.dim_field_code)
        if self.longitude_field_code:
            fields.append(self.longitude_field_code)
        if self.latitude_field_code:
            fields.append(self.latitude_field_code)

        # fieldCondition 中的字段
        conditions = self.field_condition.get('conditions', [])
        for cond in conditions:
            field_code = cond.get('fieldCode')
            if field_code:
                fields.append(field_code)
            sub_conditions = cond.get('conditions', [])
            for sub_cond in sub_conditions:
                sub_field_code = sub_cond.get('fieldCode')
                if sub_field_code:
                    fields.append(sub_field_code)

        return list(set(fields))

    # ------------------------------------------------------------------ #
    #  核心计算
    # ------------------------------------------------------------------ #

    def calculate_expected_value(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        计算当前进件的预期指标值

        MOVEMENT 模板计算移动距离或移动速度。
        默认值为 null（None）。
        """
        from loaders.metadata_loader import MetadataManager
        meta = MetadataManager()

        # 获取经纬度字段的 serviceParam
        lng_field_def = meta.get_field_def(self.longitude_field_code)
        lat_field_def = meta.get_field_def(self.latitude_field_code)
        lng_param = (lng_field_def.get('serviceParam', self.longitude_field_code.lower())
                     if lng_field_def else self.longitude_field_code.lower())
        lat_param = (lat_field_def.get('serviceParam', self.latitude_field_code.lower())
                     if lat_field_def else self.latitude_field_code.lower())

        if self.self_included:
            all_events = history_events + [current_event]
            query_value = self._compute_movement(all_events, lng_param, lat_param, meta)
            after_update = query_value
        else:
            query_value = self._compute_movement(history_events, lng_param, lat_param, meta)
            all_events = history_events + [current_event]
            after_update = self._compute_movement(all_events, lng_param, lat_param, meta)

        return {
            'query_value': query_value,
            'after_update': after_update,
            'self_included': self.self_included
        }

    def _compute_movement(
        self,
        events: List[Dict[str, Any]],
        lng_param: str,
        lat_param: str,
        meta
    ) -> Optional[float]:
        """
        计算事件序列的移动距离或速度

        Returns:
            移动距离（米）或速度（米/小时），若无法计算则返回 None
        """
        if len(events) < 2:
            return None

        # 提取有效的经纬度数据点（按事件顺序即时间顺序）
        points = []
        for event in events:
            data = event.get('data', {})
            # fieldCondition 过滤
            if not self._passes_field_condition(data, meta):
                continue
            try:
                lng = float(data.get(lng_param, 0))
                lat = float(data.get(lat_param, 0))
                biztime = data.get('biztime', '')
                if lng != 0 or lat != 0:  # 排除无效坐标（0,0）
                    points.append((lat, lng, biztime))
            except (ValueError, TypeError):
                continue

        if len(points) < 2:
            return None

        # 计算累计距离
        total_distance = 0.0
        for i in range(1, len(points)):
            lat1, lng1, _ = points[i - 1]
            lat2, lng2, _ = points[i]
            dist = self._haversine_distance(lat1, lng1, lat2, lng2)
            total_distance += dist

        if self.calc_method == 'DISTANCE':
            return round(total_distance, 2)

        elif self.calc_method == 'SPEED':
            # 计算时间跨度（小时）
            try:
                first_time = self._parse_time(points[0][2])
                last_time = self._parse_time(points[-1][2])
                if first_time is None or last_time is None:
                    return None
                time_span_hours = (last_time - first_time).total_seconds() / 3600
                if time_span_hours <= 0:
                    return None
                return round(total_distance / time_span_hours, 2)
            except (ValueError, TypeError):
                return None

        return None

    @staticmethod
    def _parse_time(time_str: str) -> Optional[datetime]:
        """解析时间字符串"""
        for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', '%Y/%m/%d %H:%M:%S'):
            try:
                return datetime.strptime(time_str, fmt)
            except ValueError:
                continue
        return None

    @staticmethod
    def _haversine_distance(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
        """
        使用 Haversine 公式计算两个经纬度点之间的距离（米）

        Args:
            lat1, lng1: 第一个点的纬度和经度
            lat2, lng2: 第二个点的纬度和经度

        Returns:
            两点间的距离（米）
        """
        R = 6371000  # 地球平均半径（米）

        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        delta_phi = math.radians(lat2 - lat1)
        delta_lambda = math.radians(lng2 - lng1)

        a = (math.sin(delta_phi / 2) ** 2 +
             math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

        return R * c

    # ------------------------------------------------------------------ #
    #  fieldCondition 过滤
    # ------------------------------------------------------------------ #

    def _passes_field_condition(self, data: Dict[str, Any], meta) -> bool:
        """检查事件数据是否通过 fieldCondition 筛选"""
        conditions = self.field_condition.get('conditions', [])
        if not conditions:
            return True

        filter_logic = self.field_condition.get('filterLogic', 'ALL')

        for cond in conditions:
            sub_conditions = cond.get('conditions', [])
            if sub_conditions:
                group_logic = cond.get('groupLogic', 'AND')
                results = []
                for sc in sub_conditions:
                    results.append(self._check_single_condition(sc, data, meta))
                if group_logic == 'AND':
                    group_result = all(results)
                else:
                    group_result = any(results)
                if filter_logic == 'ALL' and not group_result:
                    return False
            else:
                result = self._check_single_condition(cond, data, meta)
                if filter_logic == 'ALL' and not result:
                    return False

        return True

    def _check_single_condition(
        self, cond: Dict[str, Any], data: Dict[str, Any], meta
    ) -> bool:
        """检查单个条件"""
        field_code = cond.get('fieldCode', '')
        logic = cond.get('logic', '')
        ref_value = cond.get('refValue', '')

        field_def = meta.get_field_def(field_code)
        service_param = (field_def.get('serviceParam', field_code.lower())
                         if field_def else field_code.lower())
        actual_value = data.get(service_param)

        if logic == 'NOT_NULL':
            return actual_value is not None and str(actual_value).strip() != ''
        if logic == 'IS_NULL':
            return actual_value is None or str(actual_value).strip() == ''
        if logic == 'EQUAL':
            return str(actual_value) == str(ref_value)
        if logic == 'NOT_EQUAL':
            return str(actual_value) != str(ref_value)

        try:
            av = float(actual_value)
            rv = float(ref_value)
            if logic == 'GREATER_THAN':
                return av > rv
            if logic == 'LESS_THAN':
                return av < rv
            if logic == 'GREATER_THAN_OR_EQUAL':
                return av >= rv
            if logic == 'LESS_THAN_OR_EQUAL':
                return av <= rv
        except (ValueError, TypeError):
            pass

        return False

    # ------------------------------------------------------------------ #
    #  辅助方法
    # ------------------------------------------------------------------ #

    def get_event_generation_hint(self, threshold: int, operator: str) -> str:
        """获取进件生成提示"""
        if self.calc_method == 'DISTANCE':
            return (
                f"需要生成进件序列，使同一维度字段的经纬度坐标在时间窗口内"
                f"的累计移动距离 {operator} {threshold} 米。"
                f"可以使用中国城市间的真实经纬度坐标，确保城市间距离满足条件。"
                f"selfIncluded={self.self_included}。"
            )
        else:
            return (
                f"需要生成进件序列，使同一维度字段在时间窗口内的移动速度 "
                f"{operator} {threshold} 米/小时。"
                f"selfIncluded={self.self_included}。"
            )

    def get_formatted_config(self) -> Dict[str, Any]:
        """获取格式化的模板配置"""
        config = super().get_formatted_config()
        config.update({
            'calcMethod': self.calc_method,
            'longitudeFieldCode': self.longitude_field_code,
            'latitudeFieldCode': self.latitude_field_code,
        })
        return config
