"""
CONSECUTIVE 模板策略 - 连续类模板

计算逻辑：一段时间内某属性满足连续条件的最大次数或最大累计个数
- 默认值：0
- 结果类型：整数型（INT）

两种计算方式（calcMethod）：

1. MAX_CONSECUTIVE_COUNT（最大连续次数）：
   - 在窗口内按时间排序的事件序列中，找到满足条件的最大连续长度
   - condition 定义了每笔事件需要满足的条件（如交易状态=失败）
   - selfIncluded=false（默认）：仅看历史事件（不含当前）
   - 结果 = 窗口内满足条件的事件组成的连续子序列的最大长度
   - 示例：事件满足条件的序列为 [T,T,F,T,T,T]（T=满足,F=不满足）
     → 最大连续次数 = 3（后三个 T）

2. MAX_CONSECUTIVE_ACCUMULATED_COUNT（最大连续累计个数）：
   - 按天或小时分组（accumulateMethod: BY_DAY / BY_HOUR）
   - 每组计算满足 fieldCondition 的事件的 condition 字段累计值
   - 判断每组累计值是否满足 condition（如金额>=9000）
   - 找出连续满足条件的最大组数
   - 示例：3天内按天分组，每天累计金额 [10000, 5000, 12000]
     → 满足>=9000: [T, F, T]
     → 最大连续天数 = 1

核心配置：
- calcMethod：计算方式（MAX_CONSECUTIVE_COUNT / MAX_CONSECUTIVE_ACCUMULATED_COUNT）
- condition：连续条件定义（fieldCode, logic, refValue, accumulateMethod）
- dimFieldCode：维度字段
- timeSlice：时间窗口
- fieldCondition：事件过滤条件（决定哪些事件参与计算）
- sceneCondition：事件类型过滤

示例指标：
- "出账_1天内同一银行卡号连续出账失败次数"（MAX_CONSECUTIVE_COUNT）
- "取现_3天内同一银行卡号每日累计...金额大于等于9000的天数"（MAX_CONSECUTIVE_ACCUMULATED_COUNT + BY_DAY）
"""

from typing import Dict, List, Any, Optional
from templates.base import TemplateStrategy


class ConsecutiveTemplateStrategy(TemplateStrategy):
    """
    CONSECUTIVE 模板策略实现

    连续类模板：统计满足连续条件的最大次数或最大累计个数
    """

    TEMPLATE_CODE = "CONSECUTIVE"
    TEMPLATE_NAME = "连续类模板"
    TEMPLATE_DESCRIPTION = "一段时间内某属性满足连续条件的最大次数或最大累计个数"

    # 计算方式映射
    CALC_METHOD_MAP = {
        'MAX_CONSECUTIVE_COUNT': '最大连续次数',
        'MAX_CONSECUTIVE_ACCUMULATED_COUNT': '最大连续累计个数',
    }

    # 比较逻辑映射
    LOGIC_MAP = {
        'EQUAL': '等于',
        'NOT_EQUAL': '不等于',
        'GREATER_THAN': '大于',
        'LESS_THAN': '小于',
        'GREATER_THAN_OR_EQUAL': '大于等于',
        'LESS_THAN_OR_EQUAL': '小于等于',
        'NOT_NULL': '不为空',
    }

    # 累计方式映射
    ACCUMULATE_METHOD_MAP = {
        'BY_DAY': '按天',
        'BY_HOUR': '按小时',
    }

    def __init__(self, metric_def: Dict[str, Any]):
        super().__init__(metric_def)

        # 计算方式
        self.calc_method = self.template_config.get('calcMethod', 'MAX_CONSECUTIVE_COUNT')

        # 连续条件定义
        self.condition = self.template_config.get('condition', {})
        self.condition_field_code = self.condition.get('fieldCode', '')
        self.condition_logic = self.condition.get('logic', 'EQUAL')
        self.condition_ref_value = self.condition.get('refValue', '')
        self.condition_data_type = self.condition.get('dataType', 'STRING')
        self.condition_display_name = self.condition.get('displayName', '')

        # 枚举值（如果是枚举类型字段）
        self.enum_items = self.condition.get('enumFieldItemList', [])

        # 累计方式（仅 MAX_CONSECUTIVE_ACCUMULATED_COUNT 使用）
        self.accumulate_method = self.condition.get('accumulateMethod', None)

        # 事件过滤条件
        self.field_condition = metric_def.get('fieldCondition', {})

    def get_prompt_description(self) -> str:
        """获取用于 Prompt 的模板计算规则描述"""
        time_desc = self.get_time_slice_description()
        self_included_desc = self.get_self_included_description()
        calc_method_cn = self.CALC_METHOD_MAP.get(self.calc_method, self.calc_method)
        logic_cn = self.LOGIC_MAP.get(self.condition_logic, self.condition_logic)

        # 条件描述
        ref_value_display = self._get_ref_value_display()
        condition_desc = f"{self.condition_display_name}({self.condition_field_code}) {logic_cn} {ref_value_display}"

        description = f"""**模板类型**: {self.TEMPLATE_NAME}（{self.TEMPLATE_CODE}）
**计算方式**: {calc_method_cn}（{self.calc_method}）
**时间窗口**: {time_desc}
**selfIncluded**: {self.self_included}（{self_included_desc}）
**连续条件**: {condition_desc}
**默认值**: 0（整数型）
"""

        if self.calc_method == 'MAX_CONSECUTIVE_COUNT':
            description += self._get_max_consecutive_count_desc(time_desc, condition_desc)
        else:
            description += self._get_max_consecutive_accumulated_count_desc(time_desc, condition_desc)

        return description

    def _get_ref_value_display(self) -> str:
        """获取条件参考值的可读显示"""
        ref_value = self.condition_ref_value
        # 如果有枚举列表，尝试找到显示名
        if self.enum_items:
            for item in self.enum_items:
                if str(item.get('value', '')) == str(ref_value):
                    return f"{ref_value}（{item.get('description', '')}）"
        return str(ref_value)

    def _get_max_consecutive_count_desc(self, time_desc: str, condition_desc: str) -> str:
        """MAX_CONSECUTIVE_COUNT 的详细描述"""
        desc = f"""
**计算规则详解**：
- 维度字段: `{self.dim_field_code}` - 用于分组
- 在 {time_desc} 窗口内，按时间排序所有事件
- 逐笔检查每个事件是否满足连续条件: {condition_desc}
- 找出满足条件的**最长连续子序列**的长度
- 结果 = 最大连续次数（整数）

**示例**（selfIncluded=false，条件=交易状态等于失败）：
- 5笔进件，交易状态分别为：[失败, 失败, 成功, 失败, 失败]
  → 满足条件序列: [T, T, F, T, T]
  → 最大连续: 2（前两个 T 或后两个 T）
"""
        if self.self_included:
            desc += """
**selfIncluded=true 影响**：
- 当前进件**先计入**窗口再计算最大连续次数
- 第1笔（满足条件）：query_value = 1
- 连续第N笔满足条件：query_value = max(历史最大连续, 含自己的当前连续长度)
"""
        else:
            desc += """
**selfIncluded=false 影响**：
- 先查询历史事件的最大连续次数，再将当前事件计入
- 第1笔：query_value = 0（无历史）
- 第2笔（前1笔满足条件）：query_value = 1
- 连续第N笔满足条件：query_value = N-1
"""
        return desc

    def _get_max_consecutive_accumulated_count_desc(self, time_desc: str, condition_desc: str) -> str:
        """MAX_CONSECUTIVE_ACCUMULATED_COUNT 的详细描述"""
        accumulate_cn = self.ACCUMULATE_METHOD_MAP.get(self.accumulate_method, '按天')
        group_unit = '天' if self.accumulate_method == 'BY_DAY' else '小时'

        # fieldCondition 描述
        fc_desc = self._get_field_condition_desc()

        desc = f"""
**计算规则详解**：
- 维度字段: `{self.dim_field_code}` - 用于分组
- 累计方式: {accumulate_cn}（{group_unit}为单位分组）
- 步骤1: 在 {time_desc} 窗口内，将事件{accumulate_cn}分组
- 步骤2: 每组中，仅统计满足 fieldCondition 的事件{fc_desc}
- 步骤3: 对每组中满足 fieldCondition 的事件，累计 {self.condition_display_name}({self.condition_field_code}) 的值
- 步骤4: 判断每组的累计值是否满足条件: {condition_desc}
- 步骤5: 在时间排序的分组序列中，找出连续满足条件的最大{group_unit}数
- 结果 = 最大连续{group_unit}数（整数）

**示例**（{accumulate_cn}分组，条件=累计金额>=9000）：
- 3天内事件按天分组，每天累计金额: [10000, 5000, 12000]
  → 满足>=9000: [T, F, T]
  → 最大连续天数 = 1
- 如果每天累计金额: [10000, 9500, 12000]
  → 满足>=9000: [T, T, T]
  → 最大连续天数 = 3
"""
        if self.self_included:
            desc += f"""
**selfIncluded=true 影响**：
- 当前进件**先计入**所在{group_unit}的分组再计算
- 当前进件的金额会累加到其所在{group_unit}的累计值中
"""
        else:
            desc += f"""
**selfIncluded=false 影响**：
- 先查询历史分组的连续满足情况，再将当前事件计入
- 当前进件的数据不参与本次查询的累计计算
"""
        return desc

    def _get_field_condition_desc(self) -> str:
        """获取 fieldCondition 的简要描述"""
        conditions = self.field_condition.get('conditions', [])
        if not conditions:
            return ""

        parts = []
        for cond in conditions:
            field_code = cond.get('fieldCode', '')
            logic = cond.get('logic', '')
            ref_value = cond.get('refValue', '')
            if field_code and logic:
                logic_cn = self.LOGIC_MAP.get(logic, logic)
                parts.append(f"{field_code} {logic_cn} {ref_value}")
            # 处理分组条件
            sub_conds = cond.get('conditions', [])
            for sc in sub_conds:
                sf = sc.get('fieldCode', '')
                sl = sc.get('logic', '')
                srv = sc.get('refValue', '')
                if sf and sl:
                    sl_cn = self.LOGIC_MAP.get(sl, sl)
                    parts.append(f"{sf} {sl_cn} {srv}")

        if parts:
            return f"\n  - 事件过滤条件(fieldCondition): {' AND '.join(parts)}"
        return ""

    def get_required_fields(self) -> List[str]:
        """获取该模板必需的字段代码列表"""
        fields = []
        if self.dim_field_code:
            fields.append(self.dim_field_code)

        # 连续条件字段
        if self.condition_field_code:
            fields.append(self.condition_field_code)

        # fieldCondition 中的字段
        conditions = self.field_condition.get('conditions', [])
        for cond in conditions:
            field_code = cond.get('fieldCode')
            if field_code:
                fields.append(field_code)
            sub_conditions = cond.get('conditions', [])
            for sub_cond in sub_conditions:
                sub_field_code = sub_cond.get('fieldCode')
                if sub_field_code:
                    fields.append(sub_field_code)

        return list(set(fields))

    def calculate_expected_value(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        计算当前进件的预期指标值

        CONSECUTIVE 模板计算满足连续条件的最大次数或最大累计个数。
        默认值为 0。
        """
        if self.calc_method == 'MAX_CONSECUTIVE_COUNT':
            return self._calculate_max_consecutive_count(history_events, current_event)
        else:
            return self._calculate_max_consecutive_accumulated_count(history_events, current_event)

    def _check_condition(self, value: Any) -> bool:
        """检查单个值是否满足连续条件"""
        if value is None:
            return False

        logic = self.condition_logic
        ref_value = self.condition_ref_value

        try:
            if logic == 'EQUAL':
                return str(value) == str(ref_value)
            elif logic == 'NOT_EQUAL':
                return str(value) != str(ref_value)
            elif logic == 'GREATER_THAN':
                return float(value) > float(ref_value)
            elif logic == 'LESS_THAN':
                return float(value) < float(ref_value)
            elif logic == 'GREATER_THAN_OR_EQUAL':
                return float(value) >= float(ref_value)
            elif logic == 'LESS_THAN_OR_EQUAL':
                return float(value) <= float(ref_value)
            elif logic == 'NOT_NULL':
                return value is not None and str(value).strip() != ''
        except (ValueError, TypeError):
            return False

        return False

    def _max_consecutive_true(self, booleans: List[bool]) -> int:
        """计算布尔序列中连续 True 的最大长度"""
        max_count = 0
        current_count = 0
        for b in booleans:
            if b:
                current_count += 1
                max_count = max(max_count, current_count)
            else:
                current_count = 0
        return max_count

    def _calculate_max_consecutive_count(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """计算最大连续次数"""
        # 从历史事件中提取条件字段值，按时间排序
        # history_events 假定已按时间排序
        from loaders.metadata_loader import MetadataManager
        meta = MetadataManager()
        field_def = meta.get_field_def(self.condition_field_code)
        service_param = field_def.get('serviceParam', self.condition_field_code.lower()) if field_def else self.condition_field_code.lower()

        history_values = []
        for event in history_events:
            data = event.get('data', {})
            val = data.get(service_param)
            history_values.append(self._check_condition(val))

        if self.self_included:
            # selfIncluded=true: 当前事件先计入再查询
            current_data = current_event.get('data', {})
            current_val = current_data.get(service_param)
            all_values = history_values + [self._check_condition(current_val)]
            query_value = self._max_consecutive_true(all_values)
            after_update = query_value
        else:
            # selfIncluded=false: 先查询历史的最大连续，再更新
            query_value = self._max_consecutive_true(history_values)
            current_data = current_event.get('data', {})
            current_val = current_data.get(service_param)
            all_values = history_values + [self._check_condition(current_val)]
            after_update = self._max_consecutive_true(all_values)

        return {
            'query_value': query_value,
            'after_update': after_update,
            'self_included': self.self_included
        }

    def _calculate_max_consecutive_accumulated_count(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """计算最大连续累计个数（按天/小时分组）"""
        from loaders.metadata_loader import MetadataManager
        meta = MetadataManager()
        field_def = meta.get_field_def(self.condition_field_code)
        service_param = field_def.get('serviceParam', self.condition_field_code.lower()) if field_def else self.condition_field_code.lower()

        group_unit = 'day' if self.accumulate_method == 'BY_DAY' else 'hour'

        def get_group_key(event: Dict[str, Any]) -> Optional[str]:
            """从事件中提取分组键（天或小时）"""
            biztime = event.get('data', {}).get('biztime', '')
            if not biztime:
                return None
            if group_unit == 'day':
                return biztime.split(' ')[0] if ' ' in biztime else biztime[:10]
            else:
                # 按小时: 取到 YYYY-MM-DD HH
                parts = biztime.split(':')
                return parts[0] if parts else biztime[:13]

        def accumulate_events(events: List[Dict[str, Any]]) -> Dict[str, float]:
            """将事件按分组键累计 condition 字段值"""
            groups = {}
            for event in events:
                key = get_group_key(event)
                if key is None:
                    continue
                data = event.get('data', {})
                val = data.get(service_param)
                try:
                    val_num = float(val) if val is not None else 0.0
                except (ValueError, TypeError):
                    val_num = 0.0
                groups[key] = groups.get(key, 0.0) + val_num
            return groups

        # 累计历史事件
        history_groups = accumulate_events(history_events)

        if self.self_included:
            # selfIncluded=true: 当前事件先计入再查询
            current_key = get_group_key(current_event)
            if current_key is not None:
                current_data = current_event.get('data', {})
                current_val = current_data.get(service_param)
                try:
                    current_num = float(current_val) if current_val is not None else 0.0
                except (ValueError, TypeError):
                    current_num = 0.0
                history_groups[current_key] = history_groups.get(current_key, 0.0) + current_num

            # 按时间排序分组键
            sorted_keys = sorted(history_groups.keys())
            group_satisfies = [self._check_condition(history_groups[k]) for k in sorted_keys]
            query_value = self._max_consecutive_true(group_satisfies)
            after_update = query_value
        else:
            # selfIncluded=false: 先查询历史分组
            sorted_keys = sorted(history_groups.keys())
            group_satisfies = [self._check_condition(history_groups[k]) for k in sorted_keys]
            query_value = self._max_consecutive_true(group_satisfies)

            # 更新后加入当前事件
            current_key = get_group_key(current_event)
            if current_key is not None:
                current_data = current_event.get('data', {})
                current_val = current_data.get(service_param)
                try:
                    current_num = float(current_val) if current_val is not None else 0.0
                except (ValueError, TypeError):
                    current_num = 0.0
                history_groups[current_key] = history_groups.get(current_key, 0.0) + current_num
            sorted_keys_after = sorted(history_groups.keys())
            group_satisfies_after = [self._check_condition(history_groups[k]) for k in sorted_keys_after]
            after_update = self._max_consecutive_true(group_satisfies_after)

        return {
            'query_value': query_value,
            'after_update': after_update,
            'self_included': self.self_included
        }

    def get_event_generation_hint(self, threshold: int, operator: str) -> str:
        """获取进件生成提示"""
        calc_method_cn = self.CALC_METHOD_MAP.get(self.calc_method, self.calc_method)
        logic_cn = self.LOGIC_MAP.get(self.condition_logic, self.condition_logic)
        ref_value_display = self._get_ref_value_display()

        if self.calc_method == 'MAX_CONSECUTIVE_COUNT':
            if self.self_included:
                needed = threshold if operator == '>=' else threshold + 1
            else:
                needed = threshold + 1 if operator == '>=' else threshold + 2

            return (
                f"需要生成 {needed} 笔**连续**满足条件（{self.condition_display_name} {logic_cn} {ref_value_display}）的进件。"
                f"中间不能有不满足条件的进件打断连续性。"
                f"selfIncluded={self.self_included}，最后一笔的 query_value={needed - (0 if self.self_included else 1)}。"
            )
        else:
            group_unit = '天' if self.accumulate_method == 'BY_DAY' else '小时'
            return (
                f"需要在连续的{threshold}个{group_unit}中，每个{group_unit}的累计{self.condition_display_name}"
                f"都满足 {logic_cn} {ref_value_display}。"
                f"进件需分布在不同{group_unit}，确保每个{group_unit}的累计值达标。"
            )

    def get_formatted_config(self) -> Dict[str, Any]:
        """获取格式化的模板配置"""
        config = super().get_formatted_config()
        config.update({
            'calcMethod': self.calc_method,
            'condition': {
                'fieldCode': self.condition_field_code,
                'displayName': self.condition_display_name,
                'logic': self.condition_logic,
                'refValue': self.condition_ref_value,
                'dataType': self.condition_data_type,
            },
        })
        if self.accumulate_method:
            config['accumulateMethod'] = self.accumulate_method
        return config
