"""
TIME_GAP 模板策略 - 时间差类模板

计算逻辑：统计一段时间内事件之间的时间间隔
- 默认值：null（无法计算时）
- 结果类型：DOUBLE（小数型）

两种统计方式（timeCalcMethod）：

1. INTERVAL（时间间隔）：
   - 对窗口内事件两两相邻的时间间隔做聚合（AVG/MIN/MAX/分位点）
   - 使用 timeFieldCode 指定的时间字段计算间隔
   - selfIncluded=false（默认）：仅用历史事件（不含当前）计算间隔
   - 至少需要 2 笔历史事件才能计算出 1 个间隔，否则返回 null
   - 示例：4笔进件 t1=31s, t2=34s, t3=36s, t4=39s（selfIncluded=false）
     → e1: null, e2: null, e3: AVG([3])=3, e4: AVG([3,2])=2.5

2. EVENT_INTERVAL（事件时间间隔）：
   - 计算指定事件到当前事件的时间间隔
   - 始终不含当前事件（在历史事件中搜索匹配事件）
   - valueTakenMethod 控制取哪一笔：LATEST=最近一笔, EARLIEST=最早一笔
   - 无匹配事件时返回 null

核心配置：
- timeCalcMethod：统计方式（INTERVAL / EVENT_INTERVAL）
- calcMethod：聚合函数（AVG/MIN/MAX），仅 INTERVAL 使用
- timeFieldCode：时间字段编码，仅 INTERVAL 使用
- valueTakenMethod：取值方式（LATEST/EARLIEST），仅 EVENT_INTERVAL 使用
- eventType：事件类型编码，仅 EVENT_INTERVAL 使用
- eventTypeFieldCode：事件类型字段编码，仅 EVENT_INTERVAL 使用
- timeUnit：结果时间单位（SECOND/MINUTE/HOUR/DAY）
- dimFieldCode：维度字段
- timeSlice：时间窗口

示例指标：
- "登录_10分钟内同一异地设备ID登录平均时间间隔秒数"（INTERVAL + AVG）
- "对公出入账_15分钟内同一银行卡号陌生账户入账事件距当前时间间隔"（EVENT_INTERVAL）
"""

from typing import Dict, List, Any, Optional
from templates.base import TemplateStrategy


class TimeGapTemplateStrategy(TemplateStrategy):
    """
    TIME_GAP 模板策略实现

    时间差类模板：统计一段时间内事件之间的时间间隔
    """

    TEMPLATE_CODE = "TIME_GAP"
    TEMPLATE_NAME = "时间差类模板"
    TEMPLATE_DESCRIPTION = "统计一段时间内事件之间的时间间隔"

    # 聚合函数映射
    CALC_METHOD_MAP = {
        'AVG': '平均值',
        'MIN': '最小值',
        'MAX': '最大值',
        'PERCENTILE': '分位点',
    }

    # 时间单位映射
    TIME_UNIT_MAP = {
        'SECOND': '秒',
        'MINUTE': '分钟',
        'HOUR': '小时',
        'DAY': '天',
    }

    # 取值方式映射
    VALUE_TAKEN_METHOD_MAP = {
        'LATEST': '最近一笔',
        'EARLIEST': '最早一笔',
    }

    def __init__(self, metric_def: Dict[str, Any]):
        super().__init__(metric_def)

        # 统计方式：INTERVAL（时间间隔） / EVENT_INTERVAL（事件时间间隔）
        self.time_calc_method = self.template_config.get('timeCalcMethod', 'INTERVAL')

        # 结果时间单位
        self.time_unit = self.template_config.get('timeUnit', 'SECOND')
        self.time_unit_cn = self.TIME_UNIT_MAP.get(self.time_unit, self.time_unit)

        # INTERVAL 专有配置
        self.calc_method = self.template_config.get('calcMethod', 'AVG')
        self.calc_method_cn = self.CALC_METHOD_MAP.get(self.calc_method, self.calc_method)
        self.time_field_code = self.template_config.get('timeFieldCode', '')

        # EVENT_INTERVAL 专有配置
        self.value_taken_method = self.template_config.get('valueTakenMethod', 'LATEST')
        self.value_taken_method_cn = self.VALUE_TAKEN_METHOD_MAP.get(
            self.value_taken_method, self.value_taken_method
        )
        self.event_type = self.template_config.get('eventType', '')
        self.event_type_field_code = self.template_config.get('eventTypeFieldCode', '')

        # 通用配置
        self.read_current_field = self.template_config.get('readCurrentField', False)
        self.metric_data_type = metric_def.get('metricDataType', 'DOUBLE')

        # 提取条件
        self.field_condition = metric_def.get('fieldCondition') or {}
        self.scene_condition = metric_def.get('sceneCondition') or {}

    def get_prompt_description(self) -> str:
        """获取用于 Prompt 的模板计算规则描述"""
        time_window_desc = self.get_time_slice_description()
        self_included_desc = self.get_self_included_description()

        if self.time_calc_method == 'INTERVAL':
            return self._get_interval_prompt_description(time_window_desc, self_included_desc)
        else:
            return self._get_event_interval_prompt_description(time_window_desc)

    def _get_interval_prompt_description(
        self, time_window_desc: str, self_included_desc: str
    ) -> str:
        """INTERVAL 类型的提示词描述"""
        description = f"""**模板类型**: {self.TEMPLATE_NAME}（{self.TEMPLATE_CODE}）
**统计方式**: 时间间隔（INTERVAL）
**计算方式**: 对窗口内事件两两相邻的时间间隔取 **{self.calc_method_cn}**（{self.calc_method}）
**时间字段**: `{self.time_field_code}` - 用于计算相邻事件间的时间差
**时间窗口**: {time_window_desc}
**selfIncluded**: {self.self_included}（{self_included_desc}）
**结果单位**: {self.time_unit_cn}（{self.time_unit}）
**结果类型**: {self.metric_data_type}（小数型）
**默认值**: null

**计算规则详解**：
- 维度字段（dimFieldCode）: `{self.dim_field_code}` - 用于分组
- 在时间窗口内收集同一维度的历史事件，按时间字段 `{self.time_field_code}` 排序
- 计算相邻事件之间的时间差（单位：{self.time_unit_cn}）
- 对所有时间差取 {self.calc_method_cn}（{self.calc_method}）作为结果
"""
        if self.self_included:
            description += f"""
**selfIncluded=true 逻辑**：
- 当前事件**参与**间隔计算
- 先将当前事件纳入窗口，再计算所有相邻间隔的 {self.calc_method_cn}
- 窗口内仅 1 笔事件（当前事件本身）时：返回 null（无法计算间隔）
- 窗口内 2 笔事件时：返回它们之间的时间差
"""
        else:
            description += f"""
**selfIncluded=false 逻辑（默认）**：
- 当前事件**不参与**间隔计算
- 仅用当前事件之前的历史事件计算相邻间隔的 {self.calc_method_cn}
- 窗口内历史事件不足 2 笔时：返回 null（无法计算间隔）
- 窗口内历史事件恰好 2 笔时：返回它们之间的时间差
- 窗口内历史事件 >= 3 笔时：有多个间隔，取 {self.calc_method_cn}
"""

        description += f"""
**计算示例**（selfIncluded=false，{self.calc_method}，单位={self.time_unit_cn}）：
假设 4 笔进件的 `{self.time_field_code}` 分别为 T1, T2, T3, T4：
- 进件1(T1): query_value = null（0 笔历史，无法计算间隔）
- 进件2(T2): query_value = null（1 笔历史 [T1]，不足 2 笔，无法计算间隔）
- 进件3(T3): query_value = {self.calc_method}([T2-T1]) = T2-T1（2 笔历史，1 个间隔）
- 进件4(T4): query_value = {self.calc_method}([T2-T1, T3-T2])（3 笔历史，2 个间隔）

**进件生成要点**：
1. 所有进件的维度字段 `{self.dim_field_code}` 必须相同
2. 进件的 `{self.time_field_code}` 字段决定时间间隔的计算
3. 要使 query_value 不为 null，历史事件至少需要 2 笔（产生至少 1 个间隔）
4. 精确控制进件时间间距以获得目标 {self.calc_method_cn} 值
5. 时间差以 **{self.time_unit_cn}** 为单位，需将实际间隔转换为对应单位
6. 所有进件的 `{self.time_field_code}` 时间必须在时间窗口 {time_window_desc} 内
7. 每笔进件必须满足 fieldCondition 约束才会被纳入统计
"""
        return description

    def _get_event_interval_prompt_description(self, time_window_desc: str) -> str:
        """EVENT_INTERVAL 类型的提示词描述"""

        # 构建事件匹配条件描述
        match_conditions = []
        scene_list = self.scene_condition.get('sceneList', [])
        if scene_list:
            scene_field = self.scene_condition.get('sceneFieldCode', '')
            match_conditions.append(
                f"事件类型字段 `{scene_field}` 的值在 {scene_list} 中"
            )

        fc_conditions = self.field_condition.get('conditions', [])
        for cond in fc_conditions:
            field_code = cond.get('fieldCode', '')
            logic = cond.get('logic', '')
            ref_value = cond.get('refValue', '')
            ref_type = cond.get('refType', 'CONSTANT')
            sub_conditions = cond.get('conditions', [])

            if sub_conditions:
                group_logic = cond.get('groupLogic', 'AND')
                for sub in sub_conditions:
                    sf = sub.get('fieldCode', '')
                    sl = sub.get('logic', '')
                    sv = sub.get('refValue', '')
                    match_conditions.append(f"`{sf}` {sl} '{sv}'")
            elif field_code:
                if ref_type == 'VARIABLE':
                    match_conditions.append(f"`{field_code}` {logic} 字段[{ref_value}]的值")
                else:
                    match_conditions.append(f"`{field_code}` {logic} '{ref_value}'")

        match_desc = '\n'.join(f"  - {c}" for c in match_conditions) if match_conditions else "  - 无额外条件"

        description = f"""**模板类型**: {self.TEMPLATE_NAME}（{self.TEMPLATE_CODE}）
**统计方式**: 事件时间间隔（EVENT_INTERVAL）
**计算方式**: 在时间窗口内查找{self.value_taken_method_cn}匹配事件，计算该事件到当前事件的时间差
**取值方式**: {self.value_taken_method}（{self.value_taken_method_cn}）
**时间窗口**: {time_window_desc}
**结果单位**: {self.time_unit_cn}（{self.time_unit}）
**结果类型**: {self.metric_data_type}（小数型）
**默认值**: null

**匹配事件条件**（历史事件需同时满足以下条件才被视为"匹配事件"）：
{match_desc}

**计算规则详解**：
- 维度字段（dimFieldCode）: `{self.dim_field_code}` - 用于分组
- **始终不含当前事件**：在历史事件中搜索匹配事件，当前进件不会匹配到自身
- 在时间窗口内，查找同一维度下满足条件的{self.value_taken_method_cn}历史事件
- 计算该匹配事件的时间到当前事件时间的差值，单位为 {self.time_unit_cn}
- 无匹配事件时返回 null
"""

        description += f"""
**计算示例**（取{self.value_taken_method_cn}，单位={self.time_unit_cn}）：
假设 3 笔进件 e1(T1), e2(T2), e3(T3)，其中 e1 和 e2 满足匹配条件，e3 不满足：
- 进件1(T1): query_value = null（无更早的匹配事件）
- 进件2(T2): query_value = (T2-T1) 转换为{self.time_unit_cn}（T1 是最近/最早的匹配事件）
- 进件3(T3): query_value = (T3-T2) 或 (T3-T1) 转换为{self.time_unit_cn}（取决于 LATEST/EARLIEST）

**进件生成要点**：
1. 所有进件的维度字段 `{self.dim_field_code}` 必须相同
2. 要使 query_value 不为 null，之前必须存在满足匹配条件的事件
3. 精确控制匹配事件和当前事件之间的时间差以获得目标值
4. 时间差以 **{self.time_unit_cn}** 为单位
5. 匹配事件必须同时满足 sceneCondition 和 fieldCondition
6. 所有进件时间必须在时间窗口 {time_window_desc} 内
7. 当需要返回 null 时，确保窗口内无满足条件的历史事件
"""
        return description

    def get_required_fields(self) -> List[str]:
        """获取该模板必需的字段代码列表"""
        fields = []
        if self.dim_field_code:
            fields.append(self.dim_field_code)
        if self.time_field_code:
            fields.append(self.time_field_code)
        if self.event_type_field_code:
            fields.append(self.event_type_field_code)

        # 从 fieldCondition 中提取字段
        conditions = self.field_condition.get('conditions', [])
        for cond in conditions:
            field_code = cond.get('fieldCode')
            if field_code:
                fields.append(field_code)
            sub_conditions = cond.get('conditions', [])
            for sub_cond in sub_conditions:
                sub_field_code = sub_cond.get('fieldCode')
                if sub_field_code:
                    fields.append(sub_field_code)
            if cond.get('refType') == 'VARIABLE' and cond.get('refValue'):
                fields.append(cond.get('refValue'))

        return list(set(fields))

    def calculate_expected_value(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        计算当前进件的预期指标值

        TIME_GAP 模板根据统计方式计算时间间隔。
        """
        if self.time_calc_method == 'INTERVAL':
            return self._calculate_interval(history_events, current_event)
        else:
            return self._calculate_event_interval(history_events, current_event)

    def _calculate_interval(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """INTERVAL 类型的计算"""
        if self.self_included:
            all_events = history_events + [current_event]
            query_value = self._compute_interval_aggregate(all_events)
            after_update = query_value
        else:
            query_value = self._compute_interval_aggregate(history_events)
            all_events = history_events + [current_event]
            after_update = self._compute_interval_aggregate(all_events)

        return {
            'query_value': query_value,
            'after_update': after_update,
            'self_included': self.self_included
        }

    def _compute_interval_aggregate(self, events: List[Dict[str, Any]]) -> Optional[float]:
        """计算事件间隔的聚合值"""
        if len(events) < 2:
            return None

        # 提取时间字段值并排序（简化处理，假设事件已按时间排序）
        intervals = []
        for i in range(1, len(events)):
            prev_time = events[i - 1].get('data', {}).get(self.time_field_code)
            curr_time = events[i].get('data', {}).get(self.time_field_code)
            if prev_time and curr_time:
                diff = self._time_diff(prev_time, curr_time)
                if diff is not None:
                    intervals.append(diff)

        if not intervals:
            return None

        if self.calc_method == 'AVG':
            return sum(intervals) / len(intervals)
        elif self.calc_method == 'MIN':
            return min(intervals)
        elif self.calc_method == 'MAX':
            return max(intervals)
        else:
            return sum(intervals) / len(intervals)

    def _calculate_event_interval(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """EVENT_INTERVAL 类型的计算（始终不含当前事件）"""
        query_value = self._find_event_interval(history_events, current_event)
        # after_update 与 query_value 相同（当前事件加入后不影响自身的计算结果）
        after_update = query_value

        return {
            'query_value': query_value,
            'after_update': after_update,
            'self_included': False  # EVENT_INTERVAL 始终不含当前
        }

    def _find_event_interval(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Optional[float]:
        """查找匹配事件并计算时间间隔"""
        if not history_events:
            return None

        # 按取值方式选择匹配事件
        if self.value_taken_method == 'LATEST':
            # 从最近的开始查找
            for event in reversed(history_events):
                if self._match_event(event):
                    return self._time_diff_from_event(event, current_event)
        else:  # EARLIEST
            for event in history_events:
                if self._match_event(event):
                    return self._time_diff_from_event(event, current_event)

        return None

    def _match_event(self, event: Dict[str, Any]) -> bool:
        """检查事件是否匹配条件（简化版本）"""
        # 实际匹配需要检查 sceneCondition + fieldCondition
        # 这里提供基本框架
        return True

    def _time_diff(self, time1_str: str, time2_str: str) -> Optional[float]:
        """计算两个时间字符串之间的差值（按配置的单位）"""
        try:
            from datetime import datetime
            t1 = datetime.strptime(time1_str, '%Y-%m-%d %H:%M:%S')
            t2 = datetime.strptime(time2_str, '%Y-%m-%d %H:%M:%S')
            diff_seconds = (t2 - t1).total_seconds()
            return self._convert_to_unit(diff_seconds)
        except (ValueError, TypeError):
            return None

    def _time_diff_from_event(
        self, match_event: Dict[str, Any], current_event: Dict[str, Any]
    ) -> Optional[float]:
        """计算匹配事件到当前事件的时间差"""
        match_time = match_event.get('data', {}).get('biztime', '')
        current_time = current_event.get('data', {}).get('biztime', '')
        if match_time and current_time:
            return self._time_diff(match_time, current_time)
        return None

    def _convert_to_unit(self, seconds: float) -> float:
        """将秒数转换为指定单位"""
        if self.time_unit == 'SECOND':
            return seconds
        elif self.time_unit == 'MINUTE':
            return seconds / 60.0
        elif self.time_unit == 'HOUR':
            return seconds / 3600.0
        elif self.time_unit == 'DAY':
            return seconds / 86400.0
        return seconds

    def get_event_generation_hint(self, threshold: Any, operator: str) -> str:
        """获取进件生成提示"""
        if self.time_calc_method == 'INTERVAL':
            return (
                f"需要构造足够的历史进件（至少 2 笔），使相邻进件时间间隔的"
                f" {self.calc_method_cn} 值 {operator} {threshold} {self.time_unit_cn}。"
                f"精确控制进件时间来达到目标间隔值。"
            )
        else:
            return (
                f"需要先构造满足匹配条件的历史事件，再发送验证进件。"
                f"控制匹配事件到验证进件的时间差使其 {operator} {threshold} {self.time_unit_cn}。"
                f"取值方式为 {self.value_taken_method_cn}。"
            )

    def get_formatted_config(self) -> Dict[str, Any]:
        """获取格式化的模板配置"""
        config = super().get_formatted_config()
        config.update({
            'timeCalcMethod': self.time_calc_method,
            'timeUnit': self.time_unit,
            'metricDataType': self.metric_data_type,
        })

        if self.time_calc_method == 'INTERVAL':
            config.update({
                'calcMethod': self.calc_method,
                'timeFieldCode': self.time_field_code,
            })
        else:
            config.update({
                'valueTakenMethod': self.value_taken_method,
                'eventType': self.event_type,
                'eventTypeFieldCode': self.event_type_field_code,
            })

        return config

    def get_field_condition_description(self) -> str:
        """获取 fieldCondition 的可读描述"""
        if not self.field_condition:
            return "无筛选条件"

        filter_logic = self.field_condition.get('filterLogic', 'ALL')
        conditions = self.field_condition.get('conditions', [])

        if not conditions:
            return "无筛选条件"

        logic_map = {
            'ALL': '全部满足',
            'ANY': '任一满足',
            'NONE': '全部不满足'
        }

        desc = f"筛选逻辑: {logic_map.get(filter_logic, filter_logic)}\n"

        logic_desc_map = {
            'EQUAL': '等于',
            'NOT_EQUAL': '不等于',
            'GREATER_THAN': '大于',
            'LESS_THAN': '小于',
            'GREATER_THAN_OR_EQUAL': '大于等于',
            'LESS_THAN_OR_EQUAL': '小于等于',
            'NOT_NULL': '不为空',
            'IS_NULL': '为空',
        }

        for i, cond in enumerate(conditions, 1):
            field_code = cond.get('fieldCode', '')
            logic = cond.get('logic', '')
            ref_type = cond.get('refType', 'CONSTANT')
            ref_value = cond.get('refValue', '')
            data_type = cond.get('dataType', '')
            logic_desc = logic_desc_map.get(logic, logic)

            sub_conditions = cond.get('conditions', [])
            if sub_conditions:
                group_logic = cond.get('groupLogic', 'AND')
                desc += f"  条件组{i}（{group_logic}）：\n"
                for j, sub_cond in enumerate(sub_conditions, 1):
                    sf = sub_cond.get('fieldCode', '')
                    sl = sub_cond.get('logic', '')
                    sr = sub_cond.get('refValue', '')
                    st = sub_cond.get('dataType', '')
                    sld = logic_desc_map.get(sl, sl)
                    desc += f"    {i}.{j}. {sf} {sld} {sr} ({st})\n"
            elif field_code:
                if ref_type == 'VARIABLE':
                    desc += f"  {i}. {field_code} {logic_desc} 字段[{ref_value}]的值 ({data_type}, 动态比较)\n"
                else:
                    desc += f"  {i}. {field_code} {logic_desc} {ref_value} ({data_type})\n"

        return desc
