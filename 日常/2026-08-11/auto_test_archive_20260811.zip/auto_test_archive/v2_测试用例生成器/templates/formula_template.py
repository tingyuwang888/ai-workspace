"""
FORMULA 模板策略 - 公式类模板

计算逻辑：通过书写公式的形式对字段或指标进行再次计算
- 默认值：null
- 结果类型：指定类型（通常为 DOUBLE）

核心特点：
- 公式使用 DSL 语法，支持 if/else、return 等控制语句
- 通过 @metricCode 引用其他指标的实时计算值
- 通过 @fieldCode 引用当前进件的字段值
- 通过 #functionName() 调用内置函数（如 #nvl、#isNull、#sum 等）
- 公式指标本身没有 dimFieldCode、timeSlice、sceneCondition、fieldCondition
- 其行为完全由被引用的指标和字段决定

示例：
- "对公转账_1天内同一银行卡号累计转账成功加当前笔交易金额"
  formula: return #nvl(@txsgfankaa,0)+#nvl(@S_F_AMOUNT,0);
  引用 @txsgfankaa = STATISTICS(SUM) 指标 + @S_F_AMOUNT = 交易金额字段

- "对公出账_同一银行卡号当前笔交易金额与最近6个月出账笔均金额比值"
  formula: if(#isNull(@S_F_AMOUNT)or #isNull(@bae14en7kb)){ return 0; }else{ return @S_F_AMOUNT/@bae14en7kb; }
  引用 @bae14en7kb = STATISTICS(AVG) 指标 + @S_F_AMOUNT = 交易金额字段
"""

import re
from typing import Dict, List, Any, Optional
from templates.base import TemplateStrategy


# 内置函数说明映射（realValue -> 中文描述）
BUILTIN_FUNCTIONS = {
    'nvl': '空赋值：若第一个参数为空则返回第二个参数，否则返回第一个参数',
    'isNull': '为空判断：参数为空返回true',
    'isNotNull': '不为空判断：参数不为空返回true',
    'sum': '求和：多个数值求和',
    'min': '最小值：取多个数值中的最小值',
    'max': '最大值：取多个数值中的最大值',
    'avg': '平均值：求多个数值的平均值',
    'abs': '绝对值：取绝对值',
    'ceil': '向上取整',
    'floor': '向下取整',
    'round': '四舍五入：第二参数指定保留小数位数',
    'eq': '等于：两参数相等返回true',
    'neq': '不等于：两参数不等返回true',
    'toNumber': '转数字：将参数转为数值',
    'toString': '转字符串：将参数转为字符串',
    'contains': '包含：第一个参数包含第二个参数时返回true',
    'notContains': '不包含：第一个参数不包含第二个参数时返回true',
    'len': '求长度：返回字符串长度或列表元素个数',
    'substring': '截取字符串：提取指定范围的子串',
    'trim': '去头尾空格',
    'concat': '拼接字符串',
    'random': '随机数：生成[0,1)区间的随机数',
    'std': '标准差',
    'variance': '方差',
    'union': '求并集',
    'intersect': '求交集',
    'append': '列表追加',
    'dedup': '列表去重',
    'sort': '列表排序',
}


class FormulaTemplateStrategy(TemplateStrategy):
    """
    FORMULA 模板策略实现
    
    公式类模板：通过 DSL 公式引用其他指标和字段进行计算
    - 无自有 dimFieldCode/timeSlice/sceneCondition/fieldCondition
    - 完全依赖被引用的指标和字段
    - 公式结果类型由 returnType 指定（通常为 DOUBLE）
    """
    
    TEMPLATE_CODE = "FORMULA"
    TEMPLATE_NAME = "公式类模板"
    TEMPLATE_DESCRIPTION = "通过书写公式的形式对字段或指标进行再次计算"
    
    def __init__(self, metric_def: Dict[str, Any]):
        super().__init__(metric_def)
        self.formula = self.template_config.get('formula', '')
        self.formula_type = self.template_config.get('formulaType', 'DSL')
        self.return_type = self.template_config.get('returnType', 'DOUBLE')
        
        # 解析公式引用
        self._referenced_codes = self._parse_references()
        self._used_functions = self._parse_functions()
        
        # 上下文信息（由外部设置，用于解析引用名称）
        self._metrics_context: Dict[str, Any] = {}
        self._fields_context: Dict[str, Any] = {}
    
    def set_formula_context(
        self,
        metrics_context: Dict[str, Any],
        fields_context: Optional[Dict[str, Any]] = None
    ):
        """
        设置公式解析上下文（用于将 @code 解析为人类可读名称）
        
        Args:
            metrics_context: 所有指标元数据 {指标名: 指标定义}
            fields_context: 所有字段元数据 {字段编码: 字段定义}
        """
        self._metrics_context = metrics_context or {}
        self._fields_context = fields_context or {}
    
    def _parse_references(self) -> List[str]:
        """
        从公式中解析所有 @引用 的代码
        
        Returns:
            引用代码列表（如 ['txsgfankaa', 'S_F_AMOUNT']）
        """
        if not self.formula:
            return []
        return re.findall(r'@(\w+)', self.formula)
    
    def _parse_functions(self) -> List[str]:
        """
        从公式中解析所有 #函数 调用
        
        Returns:
            函数名列表（如 ['nvl', 'isNull', 'sum']）
        """
        if not self.formula:
            return []
        functions = re.findall(r'#(\w+)\s*\(', self.formula)
        return list(dict.fromkeys(functions))  # 去重保序
    
    def resolve_references(self) -> Dict[str, Dict[str, Any]]:
        """
        将公式中的 @引用代码 解析为具体的指标或字段信息
        
        Returns:
            {code: {'type': 'metric'|'field', 'name': str, 'def': dict}} 的字典
        """
        resolved = {}
        
        # 构建 metricCode -> metricName 映射
        code_to_name = {}
        for name, mdef in self._metrics_context.items():
            code = mdef.get('metricCode', '')
            if code:
                code_to_name[code] = name
        
        for ref_code in self._referenced_codes:
            if ref_code in resolved:
                continue
            
            # 优先匹配指标（metricCode）
            if ref_code in code_to_name:
                metric_name = code_to_name[ref_code]
                resolved[ref_code] = {
                    'type': 'metric',
                    'name': metric_name,
                    'def': self._metrics_context.get(metric_name, {})
                }
            # 再匹配字段（fieldCode）
            elif ref_code in self._fields_context:
                field_def = self._fields_context[ref_code]
                resolved[ref_code] = {
                    'type': 'field',
                    'name': field_def.get('displayName', ref_code),
                    'service_param': field_def.get('serviceParam', ref_code.lower()),
                    'def': field_def
                }
            else:
                # 未知引用
                resolved[ref_code] = {
                    'type': 'unknown',
                    'name': ref_code,
                    'def': {}
                }
        
        return resolved
    
    def get_human_readable_formula(self) -> str:
        """
        将 DSL 公式转换为人类可读的描述
        
        Returns:
            可读的公式表达式
        """
        resolved = self.resolve_references()
        readable = self.formula
        
        # 替换 @引用 为可读名称
        for code, info in resolved.items():
            if info['type'] == 'metric':
                replacement = f"【指标:{info['name']}】"
            elif info['type'] == 'field':
                replacement = f"【字段:{info['name']}({info.get('service_param', code)})】"
            else:
                replacement = f"【{code}】"
            readable = readable.replace(f"@{code}", replacement)
        
        # 替换 #函数 为中文名
        for func_name in self._used_functions:
            if func_name in BUILTIN_FUNCTIONS:
                # 只替换函数名部分，保留括号
                readable = readable.replace(f"#{func_name}(", f"#{func_name}(")
        
        return readable
    
    def get_referenced_metric_codes(self) -> List[str]:
        """
        获取公式引用的所有指标 metricCode
        
        Returns:
            指标代码列表
        """
        resolved = self.resolve_references()
        return [code for code, info in resolved.items() if info['type'] == 'metric']
    
    def get_referenced_metric_names(self) -> List[str]:
        """
        获取公式引用的所有指标名称
        
        Returns:
            指标名称列表
        """
        resolved = self.resolve_references()
        return [info['name'] for info in resolved.values() if info['type'] == 'metric']
    
    def get_referenced_field_codes(self) -> List[str]:
        """
        获取公式引用的所有字段 fieldCode
        
        Returns:
            字段编码列表
        """
        resolved = self.resolve_references()
        return [code for code, info in resolved.items() if info['type'] == 'field']
    
    def get_prompt_description(self) -> str:
        """获取用于 Prompt 的模板计算规则描述"""
        resolved = self.resolve_references()
        
        description = f"""**模板类型**: {self.TEMPLATE_NAME}（{self.TEMPLATE_CODE}）
**公式类型**: {self.formula_type}
**返回类型**: {self.return_type}
**原始公式**:
```
{self.formula}
```

**公式解读**:
{self.get_human_readable_formula()}

"""
        # 列出引用的指标
        metric_refs = [(code, info) for code, info in resolved.items() if info['type'] == 'metric']
        if metric_refs:
            description += "**引用的指标（公式中的 @metricCode → 对应指标）**:\n"
            for code, info in metric_refs:
                metric_def = info.get('def', {})
                template_code = metric_def.get('templateCode', 'UNKNOWN')
                tc = metric_def.get('templateConfig', {})
                ts = tc.get('timeSlice', {})
                time_desc = ''
                if ts:
                    count = ts.get('count', '')
                    unit = ts.get('timeUnit', '')
                    unit_map = {'SECOND': '秒', 'MINUTE': '分钟', 'HOUR': '小时',
                                'DAY': '天', 'WEEK': '周', 'MONTH': '月'}
                    time_desc = f", 窗口:{count}{unit_map.get(unit, unit)}"
                self_inc = ts.get('selfIncluded', False)
                self_desc = "含当前" if self_inc else "不含当前"
                
                extra = ''
                if template_code == 'STATISTICS':
                    calc_method = tc.get('calcMethod', 'SUM')
                    calc_field = tc.get('calcFieldCode', '')
                    extra = f", 计算:{calc_method}, 字段:{calc_field}"
                elif template_code == 'COUNT':
                    extra = ", 计数"
                elif template_code == 'HISTORY_VALUE':
                    vtm = tc.get('valueTakenMethod', 'LATEST')
                    vtf = tc.get('valueTakenFieldCode', '')
                    extra = f", {'首笔' if vtm == 'EARLIEST' else '最近一笔'}, 取值:{vtf}"
                
                description += (
                    f"  - `@{code}` → **{info['name']}** "
                    f"({template_code}, {self_desc}{time_desc}{extra})\n"
                )
        
        # 列出引用的字段
        field_refs = [(code, info) for code, info in resolved.items() if info['type'] == 'field']
        if field_refs:
            description += "\n**引用的字段（公式中的 @fieldCode → 对应字段）**:\n"
            for code, info in field_refs:
                field_def = info.get('def', {})
                data_type = field_def.get('dataType', 'STRING')
                sp = info.get('service_param', code)
                description += f"  - `@{code}` → **{info['name']}** (serviceParam: `{sp}`, 类型: {data_type})\n"
        
        # 列出使用的内置函数
        if self._used_functions:
            description += "\n**使用的内置函数**:\n"
            for func_name in self._used_functions:
                func_desc = BUILTIN_FUNCTIONS.get(func_name, '未知函数')
                description += f"  - `#{func_name}()`: {func_desc}\n"
        
        # 计算规则说明
        description += f"""
**FORMULA 指标计算规则**:
1. 公式指标本身没有时间窗口和维度字段，其值由公式实时计算得出
2. 公式中引用的其他指标（@metricCode）会根据各自的模板类型独立计算
3. 公式中引用的字段（@fieldCode）取自当前进件的字段值
4. 公式在每次进件请求时实时求值，结果用于规则条件判断
5. **重要**：LLM 在 `expected_metric_values` 中必须同时包含：
   - 公式引用的依赖指标（如 STATISTICS/COUNT 类指标）的 query_value/after_update
   - 公式指标本身的 query_value（根据依赖指标和字段值计算得出）
6. 公式指标的 `query_value` = 将依赖指标的 query_value 和当前进件字段值代入公式计算的结果
7. 公式指标的 `after_update` = 将依赖指标的 after_update 和当前进件字段值代入公式计算的结果（通常与 query_value 不同）
8. 公式指标的 `self_included` 设为 false（公式本身不存储，无 selfIncluded 概念）
"""
        
        return description
    
    def get_required_fields(self) -> List[str]:
        """
        获取该模板必需的字段代码列表
        
        FORMULA 模板需要：
        - 公式中直接引用的字段（@fieldCode）
        - 被引用指标所需的字段（递归获取）
        """
        fields = []
        
        # 公式直接引用的字段
        fields.extend(self.get_referenced_field_codes())
        
        return list(set(fields))
    
    def calculate_expected_value(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        计算当前进件的预期指标值
        
        FORMULA 模板的值由公式实时计算，这里返回占位结构。
        实际值需要在验证时从 API 响应获取。
        """
        return {
            'query_value': None,  # 需要根据公式和依赖指标计算
            'after_update': None,
            'self_included': False
        }
    
    def get_event_generation_hint(self, threshold: int, operator: str) -> str:
        """获取进件生成提示"""
        resolved = self.resolve_references()
        
        metric_refs = [info for info in resolved.values() if info['type'] == 'metric']
        field_refs = [info for info in resolved.values() if info['type'] == 'field']
        
        hint = f"公式指标的条件为 {operator} {threshold}。\n"
        hint += f"公式: {self.formula}\n"
        
        if metric_refs:
            hint += "需要通过控制以下依赖指标的值来满足条件:\n"
            for ref in metric_refs:
                hint += f"  - {ref['name']}（控制其历史进件数量/金额来调整指标值）\n"
        
        if field_refs:
            hint += "同时需要控制以下字段值:\n"
            for ref in field_refs:
                hint += f"  - {ref['name']}（设置合适的字段值使公式结果满足条件）\n"
        
        return hint
    
    def get_formatted_config(self) -> Dict[str, Any]:
        """获取格式化的模板配置"""
        config = super().get_formatted_config()
        config.update({
            'formulaType': self.formula_type,
            'formula': self.formula,
            'returnType': self.return_type,
            'referencedCodes': self._referenced_codes,
            'usedFunctions': self._used_functions
        })
        return config
