"""
模板策略基类与注册机制

定义指标模板的统一接口，支持：
- 获取模板的 Prompt 描述
- 获取模板必需的字段
- 计算预期指标值
- 验证进件序列
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional


class TemplateStrategy(ABC):
    """
    指标模板策略基类
    
    每种模板类型（SET、COUNT、SUM等）实现此接口，
    提供特定于该模板的计算逻辑和 Prompt 描述。
    """
    
    # 模板代码（子类必须覆盖）
    TEMPLATE_CODE: str = ""
    
    # 模板中文名称
    TEMPLATE_NAME: str = ""
    
    # 模板描述
    TEMPLATE_DESCRIPTION: str = ""
    
    def __init__(self, metric_def: Dict[str, Any]):
        """
        初始化模板策略
        
        Args:
            metric_def: 指标元数据定义
        """
        self.metric_def = metric_def
        self.metric_name = metric_def.get('metricName', '')
        self.template_config = metric_def.get('templateConfig', {})
        self.time_slice = self.template_config.get('timeSlice', {})
        # selfIncluded=null 视为 false（不包含当前进件）
        self.self_included = self.time_slice.get('selfIncluded') or False
        self.dim_field_code = self.template_config.get('dimFieldCode', '')
    
    @abstractmethod
    def get_prompt_description(self) -> str:
        """
        获取用于 Prompt 的模板计算规则描述
        
        Returns:
            模板计算规则的详细描述文本
        """
        pass
    
    @abstractmethod
    def get_required_fields(self) -> List[str]:
        """
        获取该模板必需的字段代码列表
        
        Returns:
            字段代码列表（如 ['S_S_DEVICEID', 'S_S_ACCOUNTLOGIN']）
        """
        pass
    
    @abstractmethod
    def calculate_expected_value(
        self,
        history_events: List[Dict[str, Any]],
        current_event: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        计算当前进件的预期指标值
        
        Args:
            history_events: 历史进件列表
            current_event: 当前进件
        
        Returns:
            包含 query_value, after_update, self_included 的字典
        """
        pass
    
    @abstractmethod
    def get_event_generation_hint(self, threshold: int, operator: str) -> str:
        """
        获取进件生成提示（告诉 LLM 如何生成进件序列）
        
        Args:
            threshold: 阈值
            operator: 比较操作符（>=, >, ==, <, <= 等）
        
        Returns:
            生成提示文本
        """
        pass
    
    def get_time_slice_description(self) -> str:
        """
        获取时间窗口描述
        
        Returns:
            时间窗口描述文本
        """
        count = self.time_slice.get('count', 0)
        unit = self.time_slice.get('timeUnit', 'HOUR')
        
        unit_map = {
            'SECOND': '秒',
            'MINUTE': '分钟',
            'HOUR': '小时',
            'DAY': '天',
            'WEEK': '周',
            'MONTH': '月'
        }
        unit_cn = unit_map.get(unit, unit)
        
        return f"{count}{unit_cn}"
    
    def get_self_included_description(self) -> str:
        """
        获取 selfIncluded 配置描述
        
        Returns:
            selfIncluded 描述文本
        """
        if self.self_included:
            return "包含当前进件（先更新再查询）"
        else:
            return "不包含当前进件（先查询再更新）"
    
    def get_formatted_config(self) -> Dict[str, Any]:
        """
        获取格式化的模板配置（用于 Prompt）
        
        Returns:
            格式化的配置字典
        """
        return {
            'metricName': self.metric_name,
            'templateCode': self.TEMPLATE_CODE,
            'templateName': self.TEMPLATE_NAME,
            'dimFieldCode': self.dim_field_code,
            'timeSlice': {
                'count': self.time_slice.get('count'),
                'timeUnit': self.time_slice.get('timeUnit'),
                'selfIncluded': self.self_included
            },
            'timeSliceDescription': self.get_time_slice_description(),
            'selfIncludedDescription': self.get_self_included_description()
        }


class TemplateRegistry:
    """
    模板策略注册中心
    
    管理所有已注册的模板策略，提供工厂方法创建策略实例。
    """
    
    _strategies: Dict[str, type] = {}
    
    @classmethod
    def register(cls, template_code: str, strategy_class: type):
        """
        注册模板策略
        
        Args:
            template_code: 模板代码（如 'SET', 'COUNT'）
            strategy_class: 策略类（TemplateStrategy 子类）
        """
        cls._strategies[template_code] = strategy_class
    
    @classmethod
    def get_strategy(cls, metric_def: Dict[str, Any]) -> Optional[TemplateStrategy]:
        """
        获取指标对应的模板策略实例
        
        Args:
            metric_def: 指标元数据定义
        
        Returns:
            模板策略实例，如果模板未注册则返回 None
        """
        template_code = metric_def.get('templateCode', '')
        strategy_class = cls._strategies.get(template_code)
        
        if strategy_class:
            return strategy_class(metric_def)
        
        return None
    
    @classmethod
    def is_supported(cls, template_code: str) -> bool:
        """
        检查模板是否已支持
        
        Args:
            template_code: 模板代码
        
        Returns:
            是否已注册该模板的策略
        """
        return template_code in cls._strategies
    
    @classmethod
    def get_supported_templates(cls) -> List[str]:
        """
        获取所有已支持的模板代码列表
        
        Returns:
            模板代码列表
        """
        return list(cls._strategies.keys())
    
    @classmethod
    def get_all_prompt_descriptions(cls, metrics_metadata: Dict[str, Any]) -> str:
        """
        获取所有指标的模板描述（用于 Prompt）
        
        Args:
            metrics_metadata: 指标元数据字典 {指标名: 指标定义}
        
        Returns:
            组合的描述文本
        """
        descriptions = []
        
        for metric_name, metric_def in metrics_metadata.items():
            strategy = cls.get_strategy(metric_def)
            if strategy:
                desc = strategy.get_prompt_description()
                descriptions.append(f"### {metric_name}\n{desc}")
            else:
                template_code = metric_def.get('templateCode', 'UNKNOWN')
                descriptions.append(
                    f"### {metric_name}\n"
                    f"**警告**：模板类型 `{template_code}` 暂未支持，"
                    f"请参考指标定义自行理解计算逻辑。"
                )
        
        return "\n\n".join(descriptions)
