# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Risk control rule test case generator (v2.0). Reads Excel rule files, parses conditions, enumerates test scenarios, and uses LLM (DashScope/Qwen) to generate ordered event sequences that cumulatively trigger metrics. Written in Chinese (comments, logs, variable names in strings).

## Commands

```bash
# Install dependencies (Python 3.9+, use venv in .venv/)
pip install -r requirements.txt

# Generate test cases from Excel rules
python main.py generate --input <rules.xlsx> --output ./output

# Generate with options
python main.py generate -i <rules.xlsx> -o ./output -v              # verbose
python main.py generate -i <rules.xlsx> -o ./output --dry-run       # skip LLM calls
python main.py generate -i <rules.xlsx> -o ./output --parallel      # multi-threaded
python main.py generate -i <rules.xlsx> -o ./output --sheet <name>  # specific sheet
python main.py generate -i <rules.xlsx> --base-info base_info/RCBC  # tenant-specific metadata
python main.py generate -i <rules.xlsx> --max-scenarios 16          # limit scenarios per rule

# Validate generated test cases against risk decision API
python main.py validate --input ./output/test_cases_xxx.json
python main.py validate -i ./output/ --report-dir ./reports         # batch validate directory
```

## Environment Variables (.env)

- `DASHSCOPE_API_KEY` - LLM API key (required for generation)
- `LLM_MODEL` - Model name (default: `qwen-plus`)
- `LLM_BASE_URL` - OpenAI-compatible API endpoint
- `LLM_TIMEOUT` - Request timeout in seconds (default: 120)
- `VALIDATOR_API_BASE_URL` - Risk decision API endpoint (required for validation)

## Architecture

### 6-Stage Pipeline (main.py)

1. **Load metadata** - JSON files from `base_info/` (fields, metrics, mappings)
2. **Load Excel rules** - Parse Excel into structured rule dicts, validate field mappings
3. **Parse rule description** - Extract conditions with operators and operand types (metric vs constant)
4. **Enumerate scenarios** - Generate 2^n condition combinations, filter by trigger logic
5. **Analyze dependencies** - Detect metric time-window containment relationships, filter feasible scenarios
6. **Generate event sequences** - LLM produces ordered events that cumulatively trigger target metrics

### Key Module Responsibilities

| Module | Role |
|--------|------|
| `loaders/rule_parser.py` | Parses natural-language rule descriptions into structured `Condition` objects with typed operands |
| `loaders/metadata_loader.py` | `MetadataManager` loads and cross-references field/metric/mapping JSON metadata |
| `analyzers/scenario_enumerator.py` | Generates all boolean combinations of conditions, applies trigger logic to determine expected hit |
| `analyzers/dependency_analyzer.py` | Detects when one metric's time window contains another; filters infeasible scenarios |
| `generators/sequence_generator.py` | Orchestrates LLM calls per scenario; supports parallel generation via `ThreadPoolExecutor` |
| `llm/prompts.py` | Builds structured prompts with metric definitions, field constraints, and template-specific guidance |
| `templates/` | 10 strategy classes (one per metric template type) that provide template-specific prompt sections and validation |
| `validators/rule_validator.py` | Sends generated events to the risk decision API and compares actual vs expected results |
| `output/json_writer.py` | Writes per-rule and batch JSON results |
| `output/excel_writer.py` | Writes test cases back into Excel format |

### Template Types (templates/)

Each metric template has its own strategy class inheriting from `templates/base.py`:
SET, COUNT, STATISTICS (SUM/AVG/MAX/MIN), HISTORY_VALUE, TIME_GAP, CONSECUTIVE, TREND, FORMULA, MOVEMENT

### Metadata Structure (base_info/)

- `base_info/common/` - Default metadata shared across tenants
- `base_info/RCBC/` - Tenant-specific overrides (selected via `--base-info`)
- Key files: `filed_metadata.json` (field definitions), `salaxy_metadata.json` (metric definitions), `mapping_config.json` (event types, channels, org mappings)

### Exception Hierarchy

- `MappingError` -> `MetricMappingError`, `FieldMappingError`
- `ValidationError` -> `SceneConditionError`, `FieldConditionError`

These are raised during parsing/validation to skip individual rules with structured error messages rather than crashing the batch.

### Dual-Operand Conditions

Conditions can have metrics on both sides (e.g., metric_A > metric_B). The parser identifies operand types (metric vs constant) which affects how scenarios and event sequences are generated.

### FORMULA Metrics

FORMULA template metrics reference other metrics via `@metricCode` syntax in their formula expressions. The system expands these dependencies for fieldCondition validation.
