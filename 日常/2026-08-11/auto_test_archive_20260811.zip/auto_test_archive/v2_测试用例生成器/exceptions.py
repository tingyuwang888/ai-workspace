"""
自定义异常类

定义项目中使用的各种异常类型，便于错误处理和日志记录。
"""


class MappingError(Exception):
    """
    映射错误基类
    
    当Excel中的字段或指标无法映射到元数据时抛出。
    """
    pass


class MetricMappingError(MappingError):
    """
    指标映射错误
    
    当规则中使用的指标名称在 salaxy_metadata.json 中找不到对应定义时抛出。
    
    Attributes:
        metric_name: 无法映射的指标名称
        rule_name: 所属规则名称
    """
    
    def __init__(self, metric_name: str, rule_name: str = ""):
        self.metric_name = metric_name
        self.rule_name = rule_name
        message = f"指标 '{metric_name}' 在 salaxy_metadata.json 中未找到映射定义"
        if rule_name:
            message = f"规则 '{rule_name}': {message}"
        super().__init__(message)


class FieldMappingError(MappingError):
    """
    字段映射错误
    
    当Excel中的字段名称在 filed_metadata.json 中找不到对应定义时抛出。
    
    Attributes:
        field_name: 无法映射的字段名称
        rule_name: 所属规则名称
    """
    
    def __init__(self, field_name: str, rule_name: str = ""):
        self.field_name = field_name
        self.rule_name = rule_name
        message = f"字段 '{field_name}' 在 filed_metadata.json 中未找到映射定义"
        if rule_name:
            message = f"规则 '{rule_name}': {message}"
        super().__init__(message)


class ValidationError(Exception):
    """验证错误基类"""
    pass


class SceneConditionError(ValidationError):
    """场景条件验证错误"""
    pass


class FieldConditionError(ValidationError):
    """
    FieldCondition字段缺失错误
    
    当指标的fieldCondition中引用的字段不在入参字段白名单中时抛出。
    这会导致指标无法正确计算，因为系统无法获取该字段的值。
    
    Attributes:
        field_code: 缺失的字段编码（如 S_E_TRANSSTAT）
        field_name: 缺失的字段名称（如 transstat）
        metric_name: 所属指标名称
        rule_name: 所属规则名称
    """
    
    def __init__(self, field_code: str, field_name: str, metric_name: str = "", rule_name: str = ""):
        self.field_code = field_code
        self.field_name = field_name
        self.metric_name = metric_name
        self.rule_name = rule_name
        message = f"字段 '{field_name}' (编码: {field_code}) 不在入参字段白名单中"
        if metric_name:
            message = f"指标 '{metric_name}' 的fieldCondition引用{message}"
        if rule_name:
            message = f"规则 '{rule_name}': {message}"
        message += "，该指标将无法正确计算。请将此字段添加到Excel的'入参字段-业务'或'入参字段-配置'中。"
        super().__init__(message)
