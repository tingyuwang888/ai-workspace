"""
智能场景枚举器 - 在保持高测试覆盖率的前提下，大幅减少复杂规则的场景数量

策略分层：
  1. 边界覆盖 (Boundary): 全触发/全不触发 + 单条件翻转
  2. Pairwise 覆盖: 确保任意两个条件的 4 种组合 (TT/TF/FT/FF) 均被覆盖
  3. 触发逻辑感知: 平衡"规则触发"与"规则不触发"场景

阈值控制：
  - 2^n <= max_scenarios: 退化为全枚举，行为不变
  - 2^n >  max_scenarios: 使用 Smart 策略缩减
"""

import random
from itertools import product, combinations as iter_combinations
from typing import List, Dict, Tuple, Set, Optional
from dataclasses import dataclass

from analyzers.scenario_enumerator import (
    TestScenario,
    evaluate_trigger_logic,
    generate_scenario_name,
)
from utils.logger import get_logger


# ---------------------------------------------------------------------------
# 默认上限：超过此值自动启用 Smart 缩减
# ---------------------------------------------------------------------------
DEFAULT_MAX_SCENARIOS = 32


# ---------------------------------------------------------------------------
# 1) 边界覆盖：生成必选场景
# ---------------------------------------------------------------------------
def _generate_boundary_scenarios(
    condition_ids: List[str],
) -> List[Tuple[bool, ...]]:
    """
    返回边界场景组合：
      - 全 True
      - 全 False
      - 从全 True 逐个翻转为 False（N 个）
      - 从全 False 逐个翻转为 True（N 个）
    共 2 + 2*N 个（去重后可能略少）
    """
    n = len(condition_ids)
    combos: List[Tuple[bool, ...]] = []

    all_true = tuple([True] * n)
    all_false = tuple([False] * n)

    combos.append(all_true)
    combos.append(all_false)

    # 从全 True 翻转单个条件
    for i in range(n):
        c = list(all_true)
        c[i] = False
        combos.append(tuple(c))

    # 从全 False 翻转单个条件
    for i in range(n):
        c = list(all_false)
        c[i] = True
        combos.append(tuple(c))

    # 去重
    seen: Set[Tuple[bool, ...]] = set()
    unique = []
    for c in combos:
        if c not in seen:
            seen.add(c)
            unique.append(c)
    return unique


# ---------------------------------------------------------------------------
# 2) Pairwise 覆盖：贪心生成覆盖数组
# ---------------------------------------------------------------------------
def _generate_pairwise_scenarios(
    condition_ids: List[str],
    existing: Set[Tuple[bool, ...]],
    budget: int,
) -> List[Tuple[bool, ...]]:
    """
    贪心 Pairwise 覆盖：确保任意 2 个条件的 4 种组合 (TT/TF/FT/FF) 均被覆盖。

    算法思路（AETG-lite）：
      1. 计算所有尚未被 existing 覆盖的 pair 组合
      2. 每次贪心生成一个新组合，使其覆盖最多的未覆盖 pair
      3. 直到全部覆盖 or 超出 budget
    """
    n = len(condition_ids)

    # 构造所有 pair 需求集合
    # pair 表示为 ((i, vi), (j, vj))，其中 vi/vj ∈ {True, False}
    all_pairs: Set[Tuple[Tuple[int, bool], Tuple[int, bool]]] = set()
    for i, j in iter_combinations(range(n), 2):
        for vi in (True, False):
            for vj in (True, False):
                all_pairs.add(((i, vi), (j, vj)))

    # 标记 existing 已覆盖的 pair
    for combo in existing:
        _remove_covered_pairs(combo, all_pairs, n)

    if not all_pairs:
        return []

    new_combos: List[Tuple[bool, ...]] = []

    for _ in range(budget):
        if not all_pairs:
            break

        best_combo = _greedy_pick(n, all_pairs)
        if best_combo in existing:
            # 碰撞（极罕见），跳过
            _remove_covered_pairs(best_combo, all_pairs, n)
            continue

        new_combos.append(best_combo)
        existing.add(best_combo)
        _remove_covered_pairs(best_combo, all_pairs, n)

    return new_combos


def _remove_covered_pairs(
    combo: Tuple[bool, ...],
    uncovered: Set[Tuple[Tuple[int, bool], Tuple[int, bool]]],
    n: int,
):
    """从 uncovered 中移除 combo 覆盖的所有 pair"""
    to_remove = set()
    for i, j in iter_combinations(range(n), 2):
        pair = ((i, combo[i]), (j, combo[j]))
        if pair in uncovered:
            to_remove.add(pair)
    uncovered -= to_remove


def _greedy_pick(
    n: int,
    uncovered: Set[Tuple[Tuple[int, bool], Tuple[int, bool]]],
) -> Tuple[bool, ...]:
    """
    贪心选择一个 n 维 bool 向量，使覆盖的 uncovered pair 数量最大。

    简化做法：随机采样若干候选，选最优。
    """
    best: Optional[Tuple[bool, ...]] = None
    best_score = -1

    # 采样次数：n 较小时可精确，n 较大时随机抽样
    sample_count = min(200, 2 ** n)

    if 2 ** n <= 200:
        # 可以穷举
        candidates = list(product([True, False], repeat=n))
    else:
        candidates = [
            tuple(random.choice([True, False]) for _ in range(n))
            for _ in range(sample_count)
        ]

    for candidate in candidates:
        score = 0
        for i, j in iter_combinations(range(n), 2):
            pair = ((i, candidate[i]), (j, candidate[j]))
            if pair in uncovered:
                score += 1
        if score > best_score:
            best_score = score
            best = candidate

    return best  # type: ignore


# ---------------------------------------------------------------------------
# 3) 触发逻辑感知平衡
# ---------------------------------------------------------------------------
def _balance_trigger_groups(
    combos: List[Tuple[bool, ...]],
    condition_ids: List[str],
    trigger_logic: str,
    budget: int,
) -> List[Tuple[bool, ...]]:
    """
    检查触发/不触发场景比例，如果严重失衡（某一侧 < 20%），
    通过随机采样补充不足一侧的场景。
    """
    n = len(condition_ids)

    triggered = []
    not_triggered = []
    combo_set = set(combos)

    for combo in combos:
        states = dict(zip(condition_ids, combo))
        hit = evaluate_trigger_logic(trigger_logic, states)
        if hit:
            triggered.append(combo)
        else:
            not_triggered.append(combo)

    total = len(combos)
    if total == 0:
        return combos

    trig_ratio = len(triggered) / total
    min_ratio = 0.15  # 至少 15% 的比例

    extra: List[Tuple[bool, ...]] = []

    if trig_ratio < min_ratio and budget > 0:
        # 触发场景不足，随机采样补充
        extra = _random_sample_with_filter(
            n, condition_ids, trigger_logic,
            target_hit=True,
            exclude=combo_set,
            count=min(budget, max(3, int(total * 0.2))),
        )
    elif (1 - trig_ratio) < min_ratio and budget > 0:
        # 不触发场景不足
        extra = _random_sample_with_filter(
            n, condition_ids, trigger_logic,
            target_hit=False,
            exclude=combo_set,
            count=min(budget, max(3, int(total * 0.2))),
        )

    return combos + extra


def _random_sample_with_filter(
    n: int,
    condition_ids: List[str],
    trigger_logic: str,
    target_hit: bool,
    exclude: Set[Tuple[bool, ...]],
    count: int,
    max_attempts: int = 2000,
) -> List[Tuple[bool, ...]]:
    """随机采样满足 target_hit 条件的组合"""
    results: List[Tuple[bool, ...]] = []
    seen = set(exclude)

    for _ in range(max_attempts):
        if len(results) >= count:
            break
        combo = tuple(random.choice([True, False]) for _ in range(n))
        if combo in seen:
            continue
        states = dict(zip(condition_ids, combo))
        hit = evaluate_trigger_logic(trigger_logic, states)
        if hit == target_hit:
            results.append(combo)
            seen.add(combo)

    return results


# ---------------------------------------------------------------------------
# 主入口：智能场景枚举
# ---------------------------------------------------------------------------
def smart_enumerate_scenarios(
    condition_ids: List[str],
    trigger_logic: str,
    max_scenarios: int = DEFAULT_MAX_SCENARIOS,
) -> List[TestScenario]:
    """
    智能场景枚举入口。

    当 2^N <= max_scenarios 时，退化为全枚举（与原行为完全一致）。
    否则分三步生成精简的场景集合：
      1. 边界覆盖
      2. Pairwise 补充
      3. 触发逻辑平衡

    Args:
        condition_ids: 条件 ID 列表
        trigger_logic: 触发逻辑表达式
        max_scenarios: 最大场景数（默认 32）

    Returns:
        TestScenario 列表
    """
    logger = get_logger()
    n = len(condition_ids)
    full_count = 2 ** n

    # ---- 判定是否需要缩减 ----
    if full_count <= max_scenarios:
        # 全枚举
        logger.debug(f"条件数 {n} (2^{n}={full_count} ≤ {max_scenarios})，使用全枚举")
        return _build_scenarios_from_combos(
            list(product([True, False], repeat=n)),
            condition_ids,
            trigger_logic,
            strategy="FULL",
        )

    logger.info(f"  - 条件数 {n}, 全枚举需 {full_count} 场景 → 启用智能缩减 (上限 {max_scenarios})")

    # ---- Step 1: 边界覆盖 ----
    boundary = _generate_boundary_scenarios(condition_ids)
    logger.debug(f"边界覆盖: {len(boundary)} 个场景")

    combo_set: Set[Tuple[bool, ...]] = set(boundary)
    all_combos = list(boundary)

    # ---- Step 2: Pairwise 补充 ----
    pairwise_budget = max(0, max_scenarios - len(all_combos) - 4)  # 预留 4 个给 balance
    if pairwise_budget > 0:
        pairwise = _generate_pairwise_scenarios(condition_ids, combo_set, pairwise_budget)
        all_combos.extend(pairwise)
        logger.debug(f"Pairwise 补充: {len(pairwise)} 个场景")

    # ---- Step 3: 触发逻辑平衡 ----
    balance_budget = max(0, max_scenarios - len(all_combos))
    all_combos = _balance_trigger_groups(
        all_combos, condition_ids, trigger_logic, balance_budget
    )
    logger.debug(f"触发平衡后: {len(all_combos)} 个场景")

    # 去重 & 截断
    seen: Set[Tuple[bool, ...]] = set()
    unique_combos: List[Tuple[bool, ...]] = []
    for c in all_combos:
        if c not in seen:
            seen.add(c)
            unique_combos.append(c)

    if len(unique_combos) > max_scenarios:
        unique_combos = unique_combos[:max_scenarios]

    scenarios = _build_scenarios_from_combos(
        unique_combos, condition_ids, trigger_logic, strategy="SMART"
    )

    # ---- 打印统计 ----
    triggered_count = sum(1 for s in scenarios if s.expected_rule_hit)
    not_triggered_count = len(scenarios) - triggered_count
    reduction = (1 - len(scenarios) / full_count) * 100

    logger.info(f"  - 智能缩减: {full_count} → {len(scenarios)} 场景 (减少 {reduction:.0f}%)")
    logger.info(f"  - 触发/不触发: {triggered_count}/{not_triggered_count}")

    return scenarios


# ---------------------------------------------------------------------------
# 辅助：从 combo 列表构建 TestScenario
# ---------------------------------------------------------------------------
def _build_scenarios_from_combos(
    combos: List[Tuple[bool, ...]],
    condition_ids: List[str],
    trigger_logic: str,
    strategy: str = "FULL",
) -> List[TestScenario]:
    """将 bool 组合列表转换为 TestScenario 对象列表"""
    scenarios: List[TestScenario] = []

    for idx, combo in enumerate(combos, 1):
        condition_states = dict(zip(condition_ids, combo))
        expected_hit = evaluate_trigger_logic(trigger_logic, condition_states)
        scenario_name = generate_scenario_name(condition_states)

        scenario = TestScenario(
            scenario_id=f"SC_{idx:03d}",
            scenario_name=scenario_name,
            condition_states=condition_states,
            expected_rule_hit=expected_hit,
            constraint_notes=[],
        )
        scenarios.append(scenario)

    return scenarios


# ---------------------------------------------------------------------------
# Pairwise 覆盖率计算（用于验证和日志）
# ---------------------------------------------------------------------------
def compute_pairwise_coverage(
    combos: List[Tuple[bool, ...]],
    n: int,
) -> float:
    """计算给定组合集的 pairwise 覆盖率 (0.0 ~ 1.0)"""
    all_pairs: Set[Tuple[Tuple[int, bool], Tuple[int, bool]]] = set()
    for i, j in iter_combinations(range(n), 2):
        for vi in (True, False):
            for vj in (True, False):
                all_pairs.add(((i, vi), (j, vj)))

    total_pairs = len(all_pairs)
    if total_pairs == 0:
        return 1.0

    covered: Set[Tuple[Tuple[int, bool], Tuple[int, bool]]] = set()
    for combo in combos:
        for i, j in iter_combinations(range(n), 2):
            pair = ((i, combo[i]), (j, combo[j]))
            covered.add(pair)

    return len(covered) / total_pairs


# ---------------------------------------------------------------------------
# 调试 / 独立测试
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")

    print("=" * 60)
    print("智能场景枚举器 - 测试")
    print("=" * 60)

    # 测试 8 个条件
    cond_ids = [f"条件{i}" for i in range(1, 9)]
    logic = " and ".join(cond_ids)

    print(f"\n条件数: {len(cond_ids)}")
    print(f"触发逻辑: {logic}")
    print(f"全枚举: {2**len(cond_ids)} 场景")

    scenarios = smart_enumerate_scenarios(cond_ids, logic, max_scenarios=32)

    print(f"\n智能缩减后: {len(scenarios)} 场景")

    triggered = sum(1 for s in scenarios if s.expected_rule_hit)
    not_triggered = len(scenarios) - triggered
    print(f"  触发: {triggered}, 不触发: {not_triggered}")

    # 计算 pairwise 覆盖率
    combos = [tuple(s.condition_states[c] for c in cond_ids) for s in scenarios]
    coverage = compute_pairwise_coverage(combos, len(cond_ids))
    print(f"  Pairwise 覆盖率: {coverage:.1%}")

    print(f"\n场景列表:")
    for s in scenarios:
        hit = "触发" if s.expected_rule_hit else "不触发"
        true_count = sum(1 for v in s.condition_states.values() if v)
        print(f"  {s.scenario_id}: {s.scenario_name:20s} -> {hit} (T={true_count}/{len(cond_ids)})")
