"""
场景枚举器 - 基于触发逻辑枚举所有测试场景
"""

import re
from itertools import product
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from utils.logger import get_logger


@dataclass
class TestScenario:
    """测试场景"""
    scenario_id: str                    # 场景ID
    scenario_name: str                  # 场景名称
    condition_states: Dict[str, bool]   # 条件状态 {条件ID: True/False}
    expected_rule_hit: bool             # 预期规则是否触发
    constraint_notes: List[str]         # 约束说明（由依赖分析填充）


def enumerate_scenarios(condition_ids: List[str], trigger_logic: str) -> List[TestScenario]:
    """
    基于触发逻辑枚举所有测试场景
    
    Args:
        condition_ids: 条件ID列表，如["条件1", "条件2"]
        trigger_logic: 触发逻辑，如"条件1 or 条件2"
    
    Returns:
        测试场景列表
    """
    logger = get_logger()
    
    if not condition_ids:
        return []
    
    n = len(condition_ids)
    
    # 生成所有True/False组合
    combinations = list(product([True, False], repeat=n))
    
    scenarios = []
    scenario_index = 1
    
    for combo in combinations:
        # 创建条件状态字典
        condition_states = dict(zip(condition_ids, combo))
        
        # 计算预期规则触发结果
        expected_hit = evaluate_trigger_logic(trigger_logic, condition_states)
        
        # 生成场景名称
        scenario_name = generate_scenario_name(condition_states)
        
        scenario = TestScenario(
            scenario_id=f"SC_{scenario_index:03d}",
            scenario_name=scenario_name,
            condition_states=condition_states,
            expected_rule_hit=expected_hit,
            constraint_notes=[]
        )
        scenarios.append(scenario)
        scenario_index += 1
    
    logger.debug(f"枚举了 {len(scenarios)} 个测试场景")
    
    return scenarios


def evaluate_trigger_logic(logic: str, states: Dict[str, bool]) -> bool:
    """
    计算触发逻辑结果
    
    Args:
        logic: 触发逻辑表达式，如"条件1 or 条件2"
        states: 条件状态字典，如{"条件1": True, "条件2": False}
    
    Returns:
        逻辑表达式的计算结果
    """
    if not logic:
        # 如果没有触发逻辑，默认所有条件AND
        return all(states.values())
    
    # 将中文条件ID替换为布尔值
    expr = logic
    
    # 按条件ID长度降序排列，避免"条件1"被"条件10"部分替换
    sorted_ids = sorted(states.keys(), key=len, reverse=True)
    
    for cond_id in sorted_ids:
        # 使用单词边界匹配，避免部分替换
        pattern = re.escape(cond_id)
        expr = re.sub(pattern, str(states[cond_id]), expr)
    
    # 规范化中文括号为英文括号
    expr = expr.replace('（', '(')
    expr = expr.replace('）', ')')
    
    # 规范化逻辑运算符
    expr = expr.replace('或', ' or ')
    expr = expr.replace('且', ' and ')
    expr = expr.replace('非', ' not ')
    expr = expr.replace('OR', ' or ')
    expr = expr.replace('AND', ' and ')
    expr = expr.replace('NOT', ' not ')
    
    # 清理多余空格
    expr = ' '.join(expr.split())
    
    try:
        # 使用eval计算（在已验证的表达式上安全使用）
        result = eval(expr)
        return bool(result)
    except Exception as e:
        # 如果计算失败，返回False
        get_logger().warning(f"触发逻辑计算失败: {logic} -> {expr}, 错误: {e}")
        return False


def generate_scenario_name(condition_states: Dict[str, bool]) -> str:
    """
    生成场景名称
    
    Args:
        condition_states: 条件状态字典
    
    Returns:
        场景名称，如"仅条件1触发"、"都触发"、"都不触发"
    """
    hit_conditions = [cid for cid, hit in condition_states.items() if hit]
    not_hit_conditions = [cid for cid, hit in condition_states.items() if not hit]
    
    n_total = len(condition_states)
    n_hit = len(hit_conditions)
    
    if n_hit == 0:
        return "都不触发"
    elif n_hit == n_total:
        return "都触发"
    elif n_hit == 1:
        return f"仅{hit_conditions[0]}触发"
    else:
        return f"{'+'.join(hit_conditions)}触发"


def scenarios_to_dict(scenarios: List[TestScenario]) -> List[Dict[str, Any]]:
    """将场景对象列表转换为字典列表"""
    return [
        {
            'scenario_id': s.scenario_id,
            'scenario_name': s.scenario_name,
            'condition_states': s.condition_states,
            'expected_rule_hit': s.expected_rule_hit,
            'constraint_notes': s.constraint_notes
        }
        for s in scenarios
    ]


def print_scenarios(scenarios: List[TestScenario]):
    """打印场景列表"""
    logger = get_logger()
    
    for i, scenario in enumerate(scenarios, 1):
        logger.scenario(
            i,
            scenario.scenario_name,
            scenario.expected_rule_hit
        )
    
    logger.substep(f"共 {len(scenarios)} 个场景")


class ScenarioEnumerator:
    """场景枚举器类 - 支持全枚举和智能缩减两种模式"""
    
    def __init__(self, max_scenarios: int = 0):
        """
        Args:
            max_scenarios: 每条规则的最大场景数。
                           0 = 不限制（全枚举，兼容旧行为）
                          >0 = 当 2^N 超过此值时启用智能缩减
        """
        self.logger = get_logger()
        self.max_scenarios = max_scenarios
    
    def enumerate_all_scenarios(
        self,
        conditions: List[Any],
        trigger_logic: str
    ) -> List[TestScenario]:
        """
        枚举所有测试场景
        
        Args:
            conditions: 条件对象列表
            trigger_logic: 触发逻辑
        
        Returns:
            测试场景列表
        """
        # 提取条件ID
        condition_ids = []
        for cond in conditions:
            if hasattr(cond, 'condition_id'):
                condition_ids.append(cond.condition_id)
            elif isinstance(cond, dict):
                condition_ids.append(cond.get('condition_id', ''))
        
        # 根据 max_scenarios 决定枚举策略
        if self.max_scenarios > 0:
            from analyzers.smart_enumerator import smart_enumerate_scenarios
            return smart_enumerate_scenarios(
                condition_ids, trigger_logic, self.max_scenarios
            )
        
        # 默认：全枚举（原始行为）
        return enumerate_scenarios(condition_ids, trigger_logic)


if __name__ == "__main__":
    # 测试场景枚举
    test_conditions = ["条件1", "条件2"]
    test_logic = "条件1 or 条件2"
    
    print("=" * 60)
    print("场景枚举测试")
    print("=" * 60)
    
    print(f"\n条件: {test_conditions}")
    print(f"触发逻辑: {test_logic}")
    
    scenarios = enumerate_scenarios(test_conditions, test_logic)
    
    print(f"\n枚举结果:")
    for s in scenarios:
        result_text = "规则触发" if s.expected_rule_hit else "规则不触发"
        print(f"  {s.scenario_id}: {s.scenario_name} -> {result_text}")
        print(f"    条件状态: {s.condition_states}")
    
    # 测试AND逻辑
    print("\n" + "=" * 60)
    test_logic_and = "条件1 and 条件2"
    print(f"触发逻辑: {test_logic_and}")
    
    scenarios_and = enumerate_scenarios(test_conditions, test_logic_and)
    
    print(f"\n枚举结果:")
    for s in scenarios_and:
        result_text = "规则触发" if s.expected_rule_hit else "规则不触发"
        print(f"  {s.scenario_id}: {s.scenario_name} -> {result_text}")
