"""
依赖分析器 - 分析指标间的时间窗口包含关系
"""

from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from utils.logger import get_logger


@dataclass
class MetricDependency:
    """指标依赖关系"""
    metric1: str                    # 指标1名称
    metric2: str                    # 指标2名称
    dependency_type: str            # 依赖类型：TIME_SUBSET, DIM_SHARED等
    description: str                # 依赖描述
    implication: str                # 影响说明


def convert_to_minutes(time_slice: Dict[str, Any]) -> int:
    """
    将时间窗口配置转换为分钟数
    
    Args:
        time_slice: 时间窗口配置，如{"count": 60, "timeUnit": "MINUTE"}
    
    Returns:
        分钟数
    """
    count = time_slice.get('count', 0)
    unit = time_slice.get('timeUnit', 'MINUTE').upper()
    
    if unit == 'MINUTE':
        return count
    elif unit == 'HOUR':
        return count * 60
    elif unit == 'DAY':
        return count * 60 * 24
    elif unit == 'WEEK':
        return count * 60 * 24 * 7
    elif unit == 'MONTH':
        return count * 60 * 24 * 30  # 近似值
    elif unit == 'YEAR':
        return count * 60 * 24 * 365  # 近似值
    else:
        return count


def analyze_metric_dependencies(
    metric_metadata: Dict[str, Any],
    condition_metrics: List[str]
) -> Dict[Tuple[str, str], MetricDependency]:
    """
    分析指标间的依赖关系
    
    Args:
        metric_metadata: 指标元数据
        condition_metrics: 规则条件中涉及的指标名称列表
    
    Returns:
        依赖关系字典，key为(metric1, metric2)元组
    """
    logger = get_logger()
    
    dependencies = {}
    
    # 只分析条件中涉及的指标
    relevant_metrics = {
        name: metric_metadata[name]
        for name in condition_metrics
        if name in metric_metadata
    }
    
    metric_list = list(relevant_metrics.keys())
    
    for i, m1_name in enumerate(metric_list):
        for m2_name in metric_list[i+1:]:
            m1 = relevant_metrics[m1_name]
            m2 = relevant_metrics[m2_name]
            
            # 检查维度字段是否相同
            m1_config = m1.get('templateConfig', {})
            m2_config = m2.get('templateConfig', {})
            
            m1_dim = m1_config.get('dimFieldCode')
            m2_dim = m2_config.get('dimFieldCode')
            
            if m1_dim and m2_dim and m1_dim == m2_dim:
                # 维度相同，检查时间窗口关系
                m1_ts = m1_config.get('timeSlice', {})
                m2_ts = m2_config.get('timeSlice', {})
                
                if m1_ts and m2_ts:
                    m1_minutes = convert_to_minutes(m1_ts)
                    m2_minutes = convert_to_minutes(m2_ts)
                    
                    # 判断时间窗口包含关系
                    if m1_minutes < m2_minutes:
                        # m1的时间窗口是m2的子集
                        dep = MetricDependency(
                            metric1=m1_name,
                            metric2=m2_name,
                            dependency_type="TIME_SUBSET",
                            description=f"{m1_name}({m1_minutes}分钟) ⊂ {m2_name}({m2_minutes}分钟)",
                            implication=f"满足{m1_name}时间窗口条件的进件必然也计入{m2_name}"
                        )
                        dependencies[(m1_name, m2_name)] = dep
                        logger.debug(f"发现依赖: {dep.description}")
                        
                    elif m2_minutes < m1_minutes:
                        # m2的时间窗口是m1的子集
                        dep = MetricDependency(
                            metric1=m2_name,
                            metric2=m1_name,
                            dependency_type="TIME_SUBSET",
                            description=f"{m2_name}({m2_minutes}分钟) ⊂ {m1_name}({m1_minutes}分钟)",
                            implication=f"满足{m2_name}时间窗口条件的进件必然也计入{m1_name}"
                        )
                        dependencies[(m2_name, m1_name)] = dep
                        logger.debug(f"发现依赖: {dep.description}")
    
    return dependencies


def filter_feasible_scenarios(
    scenarios: List[Any],
    dependencies: Dict[Tuple[str, str], MetricDependency],
    condition_to_metric: Dict[str, str]
) -> List[Any]:
    """
    基于依赖关系筛选可行场景并添加约束说明
    
    Args:
        scenarios: 测试场景列表
        dependencies: 指标依赖关系
        condition_to_metric: 条件到指标的映射 {条件ID: 指标名称}
    
    Returns:
        添加了约束说明的场景列表
    """
    logger = get_logger()
    
    # 构建指标到条件的反向映射
    metric_to_condition = {v: k for k, v in condition_to_metric.items()}
    
    for scenario in scenarios:
        constraint_notes = []
        
        for (m1, m2), dep in dependencies.items():
            if dep.dependency_type == "TIME_SUBSET":
                # m1是m2的子集（m1时间窗口更小）
                cond1 = metric_to_condition.get(m1)
                cond2 = metric_to_condition.get(m2)
                
                if cond1 and cond2:
                    state1 = scenario.condition_states.get(cond1, False)
                    state2 = scenario.condition_states.get(cond2, False)
                    
                    # 场景分析
                    if state1 and not state2:
                        # 要求小窗口指标触发，大窗口指标不触发
                        # 这需要特殊的时间分布策略
                        note = f"需要将进件分散到{m1}窗口外但{m2}窗口内"
                        constraint_notes.append(note)
                        logger.debug(f"场景'{scenario.scenario_name}'约束: {note}")
                    
                    elif not state1 and state2:
                        # 要求小窗口指标不触发，大窗口指标触发
                        # 需要在大窗口内但小窗口外生成进件
                        note = f"进件需要在{m2}窗口内但{m1}窗口外"
                        constraint_notes.append(note)
                        logger.debug(f"场景'{scenario.scenario_name}'约束: {note}")
        
        scenario.constraint_notes = constraint_notes
    
    return scenarios


def build_condition_metric_mapping(
    conditions: List[Any],
    metric_metadata: Dict[str, Any]
) -> Dict[str, str]:
    """
    构建条件到指标的映射
    
    Args:
        conditions: 条件列表
        metric_metadata: 指标元数据
    
    Returns:
        条件到指标的映射 {条件ID: 指标名称}
    """
    mapping = {}
    
    for cond in conditions:
        # 检查左操作数
        if hasattr(cond, 'left_operand'):
            if cond.left_operand.metric_name:
                mapping[cond.condition_id] = cond.left_operand.metric_name
        elif isinstance(cond, dict):
            left_op = cond.get('left_operand', {})
            if left_op.get('metric_name'):
                mapping[cond['condition_id']] = left_op['metric_name']
    
    return mapping


def print_dependencies(dependencies: Dict[Tuple[str, str], MetricDependency]):
    """打印依赖关系"""
    logger = get_logger()
    
    if not dependencies:
        logger.substep("未发现指标间的依赖关系")
        return
    
    for (m1, m2), dep in dependencies.items():
        logger.dependency(f"发现依赖: {dep.description}")
        logger.substep(dep.implication, indent=4)


if __name__ == "__main__":
    # 测试依赖分析
    test_metrics = {
        "注册_24小时内同一设备ID关联注册成功登录账号个数": {
            "metricCode": "i7b7ipel3f",
            "templateCode": "SET",
            "templateConfig": {
                "dimFieldCode": "S_S_DEVICEID",
                "setFieldCode": "S_S_ACCOUNTLOGIN",
                "timeSlice": {"count": 24, "timeUnit": "HOUR"}
            }
        },
        "注册_60分钟内同一设备ID关联注册成功登录账号个数": {
            "metricCode": "y43n5k5ixt",
            "templateCode": "SET",
            "templateConfig": {
                "dimFieldCode": "S_S_DEVICEID",
                "setFieldCode": "S_S_ACCOUNTLOGIN",
                "timeSlice": {"count": 60, "timeUnit": "MINUTE"}
            }
        }
    }
    
    condition_metrics = list(test_metrics.keys())
    
    print("=" * 60)
    print("依赖分析测试")
    print("=" * 60)
    
    print(f"\n测试指标: {condition_metrics}")
    
    dependencies = analyze_metric_dependencies(test_metrics, condition_metrics)
    
    print(f"\n依赖关系: {len(dependencies)} 个")
    for (m1, m2), dep in dependencies.items():
        print(f"  {dep.description}")
        print(f"    影响: {dep.implication}")
    
    # 测试场景约束
    from analyzers.scenario_enumerator import enumerate_scenarios, TestScenario
    
    conditions = ["条件1", "条件2"]
    scenarios = enumerate_scenarios(conditions, "条件1 or 条件2")
    
    condition_to_metric = {
        "条件1": "注册_24小时内同一设备ID关联注册成功登录账号个数",
        "条件2": "注册_60分钟内同一设备ID关联注册成功登录账号个数"
    }
    
    scenarios = filter_feasible_scenarios(scenarios, dependencies, condition_to_metric)
    
    print(f"\n场景约束分析:")
    for s in scenarios:
        print(f"  {s.scenario_name}: {s.constraint_notes if s.constraint_notes else '无约束'}")
