#!/usr/bin/env python3
"""
风控规则测试用例生成器 v2.0
==============================

读取Excel规则文件，生成满足指标累积触发机制的测试用例（有序进件序列）。

核心特性：
- 指标通过进件序列累积触发（非直接设置值）
- 支持双指标型条件（左右两侧都可能是指标）
- 分析指标间的联动关系（时间窗口包含）
- 三层处理：场景枚举 -> 可行性分析 -> LLM进件序列生成

使用方法：
    python main.py --input 规则文件.xlsx --output ./output
"""

import argparse
import os
import sys
from typing import Dict, List, Any, Optional

# 确保项目根目录在路径中
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config.settings import Settings
from utils.logger import get_logger, setup_logger
from utils.llm_logger import setup_llm_logger, LLMLogger
from loaders.metadata_loader import MetadataManager
from loaders.excel_loader import load_rules_from_excel, validate_field_mappings
from loaders.rule_parser import parse_rule_description, get_all_metric_names
from analyzers.scenario_enumerator import ScenarioEnumerator
from analyzers.dependency_analyzer import (
    analyze_metric_dependencies,
    filter_feasible_scenarios,
    build_condition_metric_mapping
)
from generators.sequence_generator import SequenceGenerator, test_cases_to_dict
from llm.client import LLMClient
from output.json_writer import (
    write_rule_test_result,
    write_skipped_rule_result,
    generate_summary,
    print_summary,
    write_batch_results
)
from output.excel_writer import write_test_cases_to_excel
from exceptions import MappingError, MetricMappingError, FieldMappingError, FieldConditionError


VERSION = "2.0.0"


def print_banner():
    """打印启动横幅"""
    logger = get_logger()
    logger.banner(f"风控规则测试用例生成器 v{VERSION}")


def load_metadata(settings: Settings) -> Optional[MetadataManager]:
    """加载元数据"""
    logger = get_logger()
    logger.step(1, 6, "加载元数据...")
    
    try:
        manager = MetadataManager(settings.BASE_INFO_DIR)
        manager.load_all()
        manager.print_summary()
        return manager
    except Exception as e:
        logger.error(f"加载元数据失败: {e}")
        return None


def load_rules(excel_path: str, metadata: MetadataManager = None, sheet_name: str = None) -> Optional[List[Dict[str, Any]]]:
    """加载Excel规则"""
    logger = get_logger()
    logger.step(2, 6, "读取Excel规则文件...")
    
    if not os.path.exists(excel_path):
        logger.error(f"规则文件不存在: {excel_path}")
        return None
    
    try:
        rules = load_rules_from_excel(excel_path, sheet_name=sheet_name)
        logger.info(f"  - 文件: {os.path.basename(excel_path)}" + (f" (sheet: {sheet_name})" if sheet_name else ""))
        logger.info(f"  - 规则数量: {len(rules)} 条")
        
        # 校验字段映射（如果提供了metadata）
        if metadata:
            logger.step(2, 6, "校验字段映射...")
            try:
                validate_field_mappings(rules, metadata)
            except FieldMappingError as e:
                logger.error(f"字段映射校验失败: {e}")
                raise  # 重新抛出，阻止后续处理
        
        return rules
    except FieldMappingError:
        raise  # 直接抛出映射错误
    except Exception as e:
        logger.error(f"读取规则文件失败: {e}")
        return None


def _build_skipped_rule_result(
    rule_name: str,
    skip_reason: str,
    output_dir: str,
    rule_no: str = '',
    service_id: str = ''
) -> Dict[str, Any]:
    """
    构建跳过规则的结构化结果，同时输出JSON文件
    
    Args:
        rule_name: 规则名称
        skip_reason: 跳过原因
        output_dir: 输出目录
        rule_no: 规则编号（用于Excel Sheet命名）
        service_id: 服务标识
    
    Returns:
        包含跳过信息的结果字典
    """
    # 输出JSON文件记录跳过原因
    output_path = write_skipped_rule_result(
        rule_name=rule_name,
        skip_reason=skip_reason,
        output_dir=output_dir,
        rule_no=rule_no,
        service_id=service_id
    )
    
    return {
        'rule_name': rule_name,
        'rule_no': rule_no,
        'test_cases': [],
        'summary': {
            'total_test_cases': 0,
            'effective_test_cases': 0,
            'skipped_cases': 0,
            'failed_cases': 0,
            'success_rate': 0,
            'total_events': 0,
            'rule_hit_cases': 0,
            'rule_not_hit_cases': 0,
            'average_events_per_case': 0,
            'scenarios_covered': [],
            'skipped_scenarios': [],
            'failed_scenarios': [],
            'empty_events_scenarios': []
        },
        'output_path': output_path,
        # 规则级别跳过标记
        'rule_skipped': True,
        'rule_skip_reason': skip_reason,
        'service_id': service_id
    }


def process_single_rule(
    rule: Dict[str, Any],
    rule_index: int,
    total_rules: int,
    metadata: MetadataManager,
    generator: SequenceGenerator,
    output_dir: str,
    parallel: bool = False,
    max_workers: int = 5,
    timeout: int = 120,
    retry_times: int = 1,
    max_scenarios: int = 0
) -> Optional[Dict[str, Any]]:
    """处理单条规则"""
    logger = get_logger()
    
    rule_name = rule.get('rule_name', rule.get('规则名称', f'规则{rule_index}'))
    rule_no = rule.get('rule_no', '')
    service_id = rule.get('service_id', '')
    
    logger.section_header(f"处理规则 {rule_index}/{total_rules}: {rule_name}")
    
    # 步骤3: 解析规则描述
    logger.step(3, 6, "解析规则描述...")
    
    rule_desc = rule.get('rule_description', rule.get('规则描述', ''))
    if not rule_desc or rule_desc == 'nan':
        logger.warning(f"规则描述为空，跳过")
        return _build_skipped_rule_result(rule_name, '规则描述为空', output_dir, rule_no, service_id)
    
    # 获取所有已知指标名
    all_metric_names = get_all_metric_names(metadata.metrics_metadata)
    
    # 解析规则（传入指标元数据以识别模板类型）
    try:
        parsed = parse_rule_description(rule_desc, all_metric_names, metadata.metrics_metadata, rule_name, field_metadata=metadata)
    except MetricMappingError as e:
        logger.error(f"  - 指标映射错误: {e}")
        logger.error(f"  - 该规则无法生成测试用例，请补充指标元数据后重试")
        return _build_skipped_rule_result(rule_name, f'指标映射错误: {e}', output_dir, rule_no, service_id)
    except FieldConditionError as e:
        logger.error(f"  - fieldCondition字段缺失: {e}")
        logger.error(f"  - 该规则无法生成测试用例，请补充缺失字段后重试")
        return _build_skipped_rule_result(rule_name, f'fieldCondition字段缺失: {e}', output_dir, rule_no, service_id)
    
    if not parsed or not parsed.get('conditions'):
        logger.warning(f"规则解析失败或无条件")
        return _build_skipped_rule_result(rule_name, '规则解析失败或无条件', output_dir, rule_no, service_id)
    
    # 打印解析结果
    for cond in parsed['conditions']:
        cond_id = cond.condition_id
        cond_text = cond.original_text
        left_type = cond.left_operand.operand_type.value if cond.left_operand else "未知"
        right_type = cond.right_operand.operand_type.value if cond.right_operand else "未知"
        logger.info(f"  - {cond_id}: {cond_text[:50]}...")
        logger.info(f"    类型: 左={left_type}, 右={right_type}")
    
    logger.info(f"  - 触发逻辑: {parsed['trigger_logic']}")
    
    # 步骤3.5: 校验指标fieldCondition字段完整性
    logger.step(3, 6, "校验指标fieldCondition字段...")
    
    # 收集所有可用字段（入参字段-业务 + 入参字段-配置）
    available_fields = []
    available_fields.extend(rule.get('input_fields_business', []))
    available_fields.extend(rule.get('input_fields_config', {}).keys())
    
    # 获取规则中涉及的所有指标
    involved_metrics = set()
    for cond in parsed['conditions']:
        if cond.left_operand and cond.left_operand.metric_name:
            involved_metrics.add(cond.left_operand.metric_name)
    
    # 展开 FORMULA 指标的依赖（其引用的指标也需要校验 fieldCondition）
    expanded_metrics = set(involved_metrics)
    for metric_name in list(involved_metrics):
        metric_def = metadata.get_metric(metric_name)
        if metric_def and metric_def.get('templateCode') == 'FORMULA':
            import re as _re
            formula = metric_def.get('templateConfig', {}).get('formula', '')
            ref_codes = _re.findall(r'@(\w+)', formula)
            # 构建 metricCode -> metricName 映射
            for mname, mdef in metadata.metric_metadata.items():
                if mdef.get('metricCode') in ref_codes:
                    expanded_metrics.add(mname)
    
    # 校验每个指标的fieldCondition字段
    missing_fields_all = []
    for metric_name in expanded_metrics:
        missing = metadata.validate_metric_fieldcondition(metric_name, available_fields)
        if missing:
            missing_fields_all.extend([
                {
                    'metric_name': metric_name,
                    'field_code': f['fieldCode'],
                    'field_name': f['fieldName'],
                    'service_param': f['serviceParam']
                }
                for f in missing
            ])
    
    if missing_fields_all:
        logger.error(f"  - 发现 {len(missing_fields_all)} 个fieldCondition字段缺失:")
        for item in missing_fields_all:
            logger.error(f"    • 指标 '{item['metric_name']}': 字段 '{item['field_name']}' (serviceParam: {item['service_param']})")
        logger.error(f"  - 请将这些字段添加到Excel的'入参字段-业务'列中")
        
        # 抛出异常，阻止继续生成
        first = missing_fields_all[0]
        raise FieldConditionError(
            field_code=first['field_code'],
            field_name=first['field_name'],
            metric_name=first['metric_name'],
            rule_name=rule_name
        )
    
    logger.info(f"  - 所有指标fieldCondition字段校验通过")
    
    # 步骤4: 枚举测试场景
    logger.step(4, 6, "枚举测试场景...")
    
    enumerator = ScenarioEnumerator(max_scenarios=max_scenarios)
    scenarios = enumerator.enumerate_all_scenarios(
        conditions=parsed['conditions'],
        trigger_logic=parsed['trigger_logic']
    )
    
    if not scenarios:
        logger.warning("未能枚举出测试场景")
        return _build_skipped_rule_result(rule_name, '未能枚举出测试场景', output_dir, rule_no, service_id)
    
    for scenario in scenarios[:5]:  # 最多显示5个
        hit_str = "规则触发" if scenario.expected_rule_hit else "规则不触发"
        logger.info(f"  - {scenario.scenario_name} -> {hit_str}")
    
    if len(scenarios) > 5:
        logger.info(f"  ... 共 {len(scenarios)} 个场景")
    else:
        logger.info(f"  - 共 {len(scenarios)} 个场景")
    
    # 步骤5: 分析指标依赖
    logger.step(5, 6, "分析指标依赖...")
    
    # 提取条件中涉及的指标
    condition_metrics = set()
    for cond in parsed['conditions']:
        if cond.left_operand and cond.left_operand.metric_name:
            condition_metrics.add(cond.left_operand.metric_name)
        if cond.right_operand and cond.right_operand.metric_name:
            condition_metrics.add(cond.right_operand.metric_name)
    
    logger.debug(f"涉及指标: {condition_metrics}")
    
    # 分析依赖关系
    dependencies = analyze_metric_dependencies(
        metric_metadata=metadata.metrics_metadata,
        condition_metrics=condition_metrics
    )
    
    if dependencies.get('containments'):
        for cont in dependencies['containments']:
            logger.info(f"  - 发现依赖: {cont['inner_metric_name'][:20]}... ⊂ {cont['outer_metric_name'][:20]}...")
    else:
        logger.info("  - 未发现指标间的时间窗口包含关系")
    
    # 构建条件-指标映射
    condition_metric_map = build_condition_metric_mapping(
        parsed['conditions'],
        metadata.metrics_metadata
    )
    
    # 筛选可行场景
    feasible_scenarios = filter_feasible_scenarios(
        scenarios=scenarios,
        dependencies=dependencies,
        condition_to_metric=condition_metric_map
    )
    
    logger.info(f"  - 可行场景: {len(feasible_scenarios)}/{len(scenarios)} 个")
    
    # 步骤6: 生成进件序列
    logger.step(6, 6, "生成进件序列...")
    
    # 构建规则信息
    # 优先使用rule中已解析的common_fields，如果没有则使用默认值
    common_fields = rule.get('common_fields', {})
    if not common_fields:
        common_fields = {
            '调用类型': rule.get('调用类型', '准实时'),
            '策略编码': rule.get('policy_code', rule.get('策略编码', 'test_policy')),
            '渠道标识': rule.get('渠道标识', 'test_channel')
        }
    
    rule_info = {
        'rule_id': rule.get('rule_no', ''),
        'rule_name': rule_name,
        'trigger_logic': parsed['trigger_logic'],
        'conditions': parsed['conditions'],
        'metrics': list(condition_metrics),
        # 新字段分类结构
        'input_fields_business': rule.get('input_fields_business', []),
        'input_fields_config': rule.get('input_fields_config', {}),
        'non_input_fields': rule.get('non_input_fields', {}),
        # 服务标识（用于验证器动态拼接API URL）
        'service_id': rule.get('service_id', ''),
        # 兼容旧结构
        'common_fields': common_fields,
        'ruleset_params': rule.get('ruleset_params', [])
    }
    
    # 规则级别预校验：事件类型匹配性（避免所有场景逐个重复报错）
    pre_validation = generator.pre_validate_rule(rule_info, common_fields)
    if not pre_validation['valid']:
        logger.warning(f"规则 '{rule_name}' 预校验失败: {pre_validation['message']}")
        logger.warning(f"跳过该规则的所有 {len(feasible_scenarios)} 个场景")
        return _build_skipped_rule_result(rule_name, f"预校验失败: {pre_validation['message']}", output_dir, rule_no, service_id)
    
    # 生成测试用例（支持并行）
    if parallel and len(feasible_scenarios) > 1:
        logger.info(f"  - 使用并行模式: {max_workers} 线程")
        test_cases = generator.generate_all_test_cases_parallel(
            rule_info=rule_info,
            scenarios=feasible_scenarios,
            max_workers=max_workers,
            timeout=timeout,
            retry_times=retry_times
        )
    else:
        test_cases = generator.generate_all_test_cases(
            rule_info=rule_info,
            scenarios=feasible_scenarios
        )
    
    if not test_cases:
        logger.warning("未能生成测试用例")
        return _build_skipped_rule_result(rule_name, '未能生成测试用例', output_dir, rule_no, service_id)
    
    # 转换为字典
    test_cases_dict = test_cases_to_dict(test_cases)
    
    # 写入单条规则结果
    output_path = write_rule_test_result(
        rule_info=rule_info,
        test_cases=test_cases_dict,
        output_dir=output_dir
    )
    
    if output_path:
        logger.info(f"  - 输出文件: {output_path}")
    
    # 打印摘要
    summary = generate_summary(test_cases_dict)
    print_summary(summary)
    
    return {
        'rule_name': rule_name,
        'test_cases': test_cases_dict,
        'summary': summary,
        'output_path': output_path
    }


def main(
    excel_path: str,
    output_dir: str,
    verbose: bool = False,
    dry_run: bool = False,
    parallel: bool = False,
    max_workers: int = 5,
    timeout: int = 120,
    retry_times: int = 1,
    sheet_name: str = None,
    base_info_dir: str = None,
    max_scenarios: int = 0
):
    """
    主入口函数
    
    Args:
        excel_path: Excel规则文件路径
        output_dir: 输出目录
        verbose: 是否输出详细日志
        dry_run: 是否仅模拟运行（不调用LLM）
        parallel: 是否启用并行生成
        max_workers: 最大并发线程数
        timeout: 单个场景超时时间（秒）
        retry_times: 失败重试次数
        sheet_name: 指定Excel中的sheet名称
        base_info_dir: 自定义base_info目录路径
        max_scenarios: 每条规则最大场景数（0=不限制）
    """
    # 设置日志
    setup_logger(verbose=verbose)
    logger = get_logger()
    
    # 打印横幅
    print_banner()
    
    # 初始化配置（如有自定义base_info则在此设置，确保全局生效）
    settings = Settings()
    if base_info_dir:
        settings.set_base_info_dir(base_info_dir)
        logger.debug(f"使用自定义base_info目录: {settings.base_info_dir}")
    
    # 确保输出目录存在
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        logger.debug(f"创建输出目录: {output_dir}")
    
    # 步骤1: 加载元数据
    metadata = load_metadata(settings)
    if not metadata:
        logger.error("无法加载元数据，退出")
        return 1
    
    # 步骤2: 读取规则（先不做字段映射校验，需要先过滤不支持的规则）
    try:
        rules = load_rules(excel_path, metadata=None, sheet_name=sheet_name)
        if not rules:
            logger.error("无法读取规则，退出")
            return 1
    except Exception as e:
        logger.error(f"读取规则失败: {e}")
        return 1
    
    # 步骤2.5: 过滤不支持的规则（模板标识 + 条件属性）
    SUPPORTED_TEMPLATES = {'common', 'custom', 'common/custom', ''}
    filtered_rules = []
    early_skipped_rules = []  # 早期过滤阶段跳过的规则
    
    for i, rule in enumerate(rules, 1):
        rule_name = rule.get('rule_name', f'规则{i}')
        rule_no = rule.get('rule_no', '')
        service_id = rule.get('service_id', '')
        
        # 模板标识校验
        template_code = rule.get('template_code', '')
        if template_code and template_code.lower() not in SUPPORTED_TEMPLATES:
            skip_reason = f"模板标识不支持: '{template_code}'，当前仅支持 common/custom 模板"
            logger.warning(f"规则 '{rule_name}' 的{skip_reason}，跳过该规则的测试用例生成")
            early_skipped_rules.append({
                'rule_name': rule_name,
                'rule_no': rule_no,
                'service_id': service_id,
                'skip_reason': skip_reason
            })
            continue
        
        # 条件属性校验：property 含 "/" 表示条件配置了内嵌规则模板
        condition_properties = rule.get('condition_properties', {})
        if condition_properties:
            nested_conditions = {k: v for k, v in condition_properties.items() if '/' in v}
            if nested_conditions:
                nested_info = ', '.join([f"{k}={v}" for k, v in nested_conditions.items()])
                skip_reason = f"条件属性含内嵌规则模板: {nested_info}"
                logger.warning(f"规则 '{rule_name}' 的条件属性中存在内嵌规则模板，当前不支持，跳过该规则的测试用例生成")
                logger.warning(f"  该规则条件属性如下:")
                for cond_key, cond_val in condition_properties.items():
                    marker = " <-- 含内嵌规则模板" if '/' in cond_val else ""
                    logger.warning(f"    {cond_key}: {cond_val}{marker}")
                early_skipped_rules.append({
                    'rule_name': rule_name,
                    'rule_no': rule_no,
                    'service_id': service_id,
                    'skip_reason': skip_reason
                })
                continue
        
        filtered_rules.append(rule)
    
    if not filtered_rules:
        logger.error("所有规则均被过滤，无可生成的规则")
        return 1
    
    if len(filtered_rules) < len(rules):
        logger.info(f"  - 过滤后剩余规则: {len(filtered_rules)}/{len(rules)} 条")
    
    # 步骤2.5: 校验字段映射（仅对过滤后的规则）
    if metadata:
        logger.step(2, 6, "校验字段映射...")
        try:
            validate_field_mappings(filtered_rules, metadata)
        except FieldMappingError as e:
            logger.error(f"=" * 60)
            logger.error(f"映射错误: {e}")
            logger.error(f"=" * 60)
            logger.error("请检查Excel文件中的字段名称是否正确，或更新元数据文件。")
            return 1
    
    # 初始化LLM通信日志记录器
    llm_logger = setup_llm_logger(output_dir=output_dir)
    logger.debug(f"LLM通信日志: {llm_logger.log_file}")
    
    # 初始化LLM客户端
    if dry_run:
        logger.warning("DRY RUN模式: 不会实际调用LLM")
        llm_client = None
    else:
        try:
            llm_client = LLMClient(llm_logger=llm_logger)
            if llm_client.client:
                logger.debug(f"LLM客户端初始化成功: {llm_client.model}")
            else:
                logger.error("LLM客户端初始化失败: API Key未配置")
                logger.info("请设置环境变量: export DASHSCOPE_API_KEY=your_api_key")
                return 1
        except Exception as e:
            logger.error(f"LLM客户端初始化失败: {e}")
            return 1
    
    # 初始化生成器
    generator = SequenceGenerator(
        llm_client=llm_client,
        metadata_manager=metadata,
        dry_run=dry_run
    )
    
    # 处理每条规则（已过滤）
    all_results = []
    
    # 先处理早期过滤阶段跳过的规则（模板标识不支持、条件属性不支持等）
    for skipped in early_skipped_rules:
        result = _build_skipped_rule_result(
            rule_name=skipped['rule_name'],
            skip_reason=skipped['skip_reason'],
            output_dir=output_dir,
            rule_no=skipped['rule_no'],
            service_id=skipped['service_id']
        )
        all_results.append(result)
    
    for i, rule in enumerate(filtered_rules, 1):
        result = process_single_rule(
            rule=rule,
            rule_index=i,
            total_rules=len(filtered_rules),
            metadata=metadata,
            generator=generator,
            output_dir=output_dir,
            parallel=parallel,
            max_workers=max_workers,
            timeout=timeout,
            retry_times=retry_times,
            max_scenarios=max_scenarios
        )
        
        if result:
            all_results.append(result)
    
    # 写入批量结果
    if len(all_results) > 1:
        batch_path = write_batch_results(all_results, output_dir)
        logger.info(f"批量结果已写入: {batch_path}")
    
    # 生成Excel测试用例文件（回填到原始Excel中）
    excel_output_path = write_test_cases_to_excel(
        input_excel_path=excel_path,
        all_results=all_results,
        output_dir=output_dir,
        rules=filtered_rules
    )
    if excel_output_path:
        logger.info(f"Excel测试用例文件: {excel_output_path}")
    
    # 最终统计
    logger.section_header("全部完成")
    
    # 区分成功处理的规则和被跳过的规则
    success_results = [r for r in all_results if not r.get('rule_skipped', False)]
    skipped_results = [r for r in all_results if r.get('rule_skipped', False)]
    
    total_cases = sum(r['summary']['total_test_cases'] for r in success_results)
    total_events = sum(r['summary']['total_events'] for r in success_results)
    
    print(f"  - 处理规则: {len(success_results)}/{len(rules)} 条")
    print(f"  - 生成用例: {total_cases} 个")
    print(f"  - 总进件数: {total_events} 笔")
    
    # 显示跳过的规则
    if skipped_results:
        print(f"  - 跳过规则: {len(skipped_results)} 条")
        for sr in skipped_results:
            reason = sr['rule_skip_reason']
            # 截断过长的原因
            if len(reason) > 60:
                reason = reason[:57] + '...'
            print(f"    • {sr['rule_name'][:40]}: {reason}")
    
    print(f"  - 输出目录: {output_dir}")
    if excel_output_path:
        print(f"  - Excel文件: {os.path.basename(excel_output_path)}")
    
    # 写入LLM日志会话总结
    if llm_logger:
        llm_logger.write_session_end()
        llm_stats = llm_logger.get_stats()
        if llm_stats['call_count'] > 0:
            print(f"  - LLM调用: {llm_stats['call_count']} 次, Token: {llm_stats['total_tokens']}")
            print(f"  - LLM日志: {os.path.basename(llm_logger.log_file)}")
    
    logger.divider()
    
    return 0


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description='风控规则测试用例生成器',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
    python main.py generate --input 规则.xlsx --output ./output
    python main.py generate -i rules.xlsx -o ./output -v
    python main.py validate --input ./output/test_cases_xxx.json
    python main.py validate -i ./output/ --report-dir ./reports
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # generate 子命令
    gen_parser = subparsers.add_parser('generate', help='生成测试用例')
    gen_parser.add_argument(
        '-i', '--input',
        required=True,
        help='Excel规则文件路径'
    )
    gen_parser.add_argument(
        '-o', '--output',
        default='./output',
        help='输出目录（默认: ./output）'
    )
    gen_parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='输出详细日志'
    )
    gen_parser.add_argument(
        '--dry-run',
        action='store_true',
        help='模拟运行，不实际调用LLM'
    )
    gen_parser.add_argument(
        '--parallel',
        action='store_true',
        help='启用并行生成模式（多线程）'
    )
    gen_parser.add_argument(
        '--max-workers',
        type=int,
        default=5,
        help='最大并发线程数（默认: 5）'
    )
    gen_parser.add_argument(
        '--timeout',
        type=int,
        default=120,
        help='单个场景超时时间（秒，默认: 120）'
    )
    gen_parser.add_argument(
        '--retry-times',
        type=int,
        default=1,
        help='失败重试次数（默认: 1）'
    )
    gen_parser.add_argument(
        '--sheet',
        type=str,
        default=None,
        help='指定Excel中的sheet名称（默认读取第一个sheet）'
    )
    gen_parser.add_argument(
        '--base-info',
        type=str,
        default=None,
        help='指定base_info目录路径（如 base_info/RCBC），默认使用 base_info/'
    )
    gen_parser.add_argument(
        '--max-scenarios',
        type=int,
        default=32,
        help='每条规则最大场景数（0=不限制/全枚举，默认32），超过阈值时启用智能缩减'
    )
    
    # validate 子命令
    val_parser = subparsers.add_parser('validate', help='验证测试用例')
    val_parser.add_argument(
        '-i', '--input',
        required=True,
        help='测试用例JSON文件或目录路径'
    )
    val_parser.add_argument(
        '-r', '--report-dir',
        default='./validation_reports',
        help='验证报告输出目录（默认: ./validation_reports）'
    )
    val_parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='输出详细日志'
    )
    val_parser.add_argument(
        '--base-info',
        type=str,
        default=None,
        help='指定base_info目录路径（如 base_info/RCBC），默认使用 base_info/'
    )
    
    return parser.parse_args()


def validate_command(input_path: str, report_dir: str, verbose: bool = False, base_info_dir: str = None) -> int:
    """
    验证命令
    
    Args:
        input_path: 测试用例文件或目录路径
        report_dir: 报告输出目录
        verbose: 是否输出详细日志
        base_info_dir: 自定义base_info目录路径
    
    Returns:
        退出码
    """
    from validators import RuleValidator, ReportGenerator
    from config.validator_config import ValidatorConfig
    
    setup_logger(verbose=verbose)
    logger = get_logger()
    
    # 如有自定义base_info则在此设置，确保全局生效
    if base_info_dir:
        from config.settings import get_settings
        get_settings(base_info_dir=base_info_dir)
        logger.debug(f"使用自定义base_info目录: {base_info_dir}")
    
    logger.section_header("测试用例验证工具")
    
    # 加载配置
    config = ValidatorConfig.from_env()
    if report_dir:
        config.report_output_dir = report_dir
    
    logger.info(f"API基础地址: {config.api_base_url}")
    logger.info(f"报告目录: {config.report_output_dir}")
    
    # 获取测试用例文件列表
    test_case_files = []
    if os.path.isfile(input_path):
        test_case_files.append(input_path)
    elif os.path.isdir(input_path):
        for filename in os.listdir(input_path):
            if filename.startswith('test_cases_') and filename.endswith('.json'):
                test_case_files.append(os.path.join(input_path, filename))
    
    if not test_case_files:
        logger.error(f"未找到测试用例文件: {input_path}")
        return 1
    
    logger.info(f"找到 {len(test_case_files)} 个测试用例文件")
    
    # 创建验证器和报告生成器
    validator = RuleValidator(config)
    report_generator = ReportGenerator(config.report_output_dir)
    
    # 验证每个文件
    all_passed = True
    for file_path in test_case_files:
        logger.info(f"\n{'='*60}")
        result = validator.validate_file(file_path)
        
        # 生成报告
        report_path = report_generator.generate_report(result)
        
        # 打印控制台报告
        report_generator.print_console_report(result)
        
        if result.failed_cases > 0:
            all_passed = False
    
    # 最终汇总
    logger.section_header("验证完成")
    if all_passed:
        logger.success("所有测试用例验证通过！")
        return 0
    else:
        logger.error("存在验证失败的测试用例")
        return 1


if __name__ == "__main__":
    args = parse_args()
    
    if args.command == 'generate' or args.command is None:
        # 默认使用 generate 命令
        exit_code = main(
            excel_path=args.input,
            output_dir=args.output,
            verbose=args.verbose,
            dry_run=args.dry_run,
            parallel=args.parallel,
            max_workers=args.max_workers,
            timeout=args.timeout,
            retry_times=args.retry_times,
            sheet_name=getattr(args, 'sheet', None),
            base_info_dir=getattr(args, 'base_info', None),
            max_scenarios=getattr(args, 'max_scenarios', 0)
        )
    elif args.command == 'validate':
        exit_code = validate_command(
            input_path=args.input,
            report_dir=args.report_dir,
            verbose=args.verbose,
            base_info_dir=getattr(args, 'base_info', None)
        )
    else:
        print(f"未知命令: {args.command}")
        exit_code = 1
    
    sys.exit(exit_code)
