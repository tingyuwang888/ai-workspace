# Changelog

## [2026-03-17] 新增公式类(FORMULA)指标模板适配

### feat
- **templates/formula_template.py** — 新增 FORMULA 模板策略类(386行)，实现 DSL 公式解析、@metricCode/@fieldCode 引用提取、#nvl/#isNull/#sum 等内置函数识别，支持上下文解析将编码映射为可读名称，生成详细的 LLM 提示词描述
- **templates/__init__.py** — 注册 FormulaTemplateStrategy 到 TemplateRegistry，模板编码 'FORMULA'
- **generators/sequence_generator.py** — 新增 `_expand_formula_dependencies()` 方法，BFS 递归展开 FORMULA 引用的依赖指标(最大深度3层)，确保被引用的 STATISTICS/COUNT 等指标纳入提示词和验证范围；`_log_rule_inputs()` 增加 FORMULA 类型的日志展示
- **llm/prompts.py** — 提示词构建增加 FORMULA 指标信息(formulaType/formula/returnType)，调用 `set_formula_context()` 注入上下文后生成描述；selfIncluded 文档新增 FORMULA 计算规则说明
- **main.py** — 字段条件验证逻辑中扩展 FORMULA 依赖指标，确保被引用指标的 fieldCondition 所需字段也纳入可用性校验

### fix
- **loaders/metadata_loader.py** — `get_metric_fieldcondition_fields()` 和 `get_metric_required_fields()` 增加 None 安全处理，修复 FORMULA 指标 fieldCondition/sceneCondition 为 null 时的 AttributeError/TypeError
- **validators/rule_validator.py** — `_compare_metrics()` 新增未部署指标跳过逻辑：当指标不在 API 响应中时(matched_key=None 且 actual_value=None)，判定为服务未部署该指标，跳过校验而非报错

## [2026-03-16] 验证器指标解析修复

### fix
- **validators/rule_validator.py** — `_parse_metrics()` 修复指标值读取来源：优先从 `node.incomingFields` 读取（包含 salaxyzb_ 前缀的指标编码），补充从 `result.requestUseField` 兜底
- **validators/rule_validator.py** — `_compare_metrics()` 新增空格归一化匹配：LLM 生成的指标名可能含多余空格（如"2 小时"vs"2小时"），通过 `re.sub(r'\s+', '', name)` 消除差异后查找编码映射
- **validators/rule_validator.py** — `_compare_metrics()` null 值处理中增加空格归一化查找元数据定义，确保 HISTORY_VALUE 类型判断不因名称空格而失败

## [2026-03-16] 新增历史取值类指标模板 + LLM客户端超时修复 + 规则解析器增强

### feat
- **templates/history_value_template.py** — 新增 HISTORY_VALUE 模板策略，支持从历史事件中取首笔(EARLIEST)/最近一笔(LATEST)的字段值，完整实现 valueTakenMethod 和 valueTakenFieldCode 逻辑
- **templates/__init__.py** — 注册 HISTORY_VALUE 模板到 TemplateRegistry

### fix
- **llm/client.py** — 修复 LLM 客户端超时配置未从 settings 读取的问题，原硬编码 120s 改为从 `LLM_TIMEOUT` 环境变量动态读取，解决长 prompt 场景下 API 超时失败
- **loaders/rule_parser.py** — 修复多行条件解析：当条件文本跨行时(如 `条件2:指标\n!= 字段`)，自动合并以运算符开头的续行；新增字段元数据 aliases 查找，解决含空格的字段名(如 "IP Address")无法识别的问题
- **loaders/excel_loader.py** — 新增读取 Excel "服务标识" 列，支持动态 service_id 构建

### config
- **.env** — 模型切换为 qwen3.5-plus；新增 `LLM_TIMEOUT=300` 配置项；API URL 改为基础地址(不含服务标识)
- **config/validator_config.py** — 新增 `get_api_url(service_id)` 方法，从基础 URL + Excel 服务标识动态拼接完整请求地址

### refactor
- **base_info/filed_metadata.json** — 为 S_S_IPADDR 字段添加 aliases 数组 `["IP Address", "ip address", "IP_Address"]`，支持多名称匹配
- **loaders/metadata_loader.py** — `get_field_by_display_name` 方法增加 aliases 遍历查找逻辑
