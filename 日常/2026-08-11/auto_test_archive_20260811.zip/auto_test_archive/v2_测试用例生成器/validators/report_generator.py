"""
验证报告生成器 - 生成JSON格式的验证报告
"""

import json
import os
from datetime import datetime
from typing import Dict, Any, Optional

from validators.rule_validator import ValidationResult
from utils.logger import get_logger


class ReportGenerator:
    """验证报告生成器"""
    
    def __init__(self, output_dir: str = "./validation_reports"):
        """
        初始化报告生成器
        
        Args:
            output_dir: 报告输出目录
        """
        self.output_dir = output_dir
        self.logger = get_logger()
        # 延迟加载的指标映射缓存
        self._metric_name_to_code: Optional[Dict[str, str]] = None
        self._metric_code_to_name: Optional[Dict[str, str]] = None
    
    def _load_metric_mappings(self):
        """延迟加载指标名称 <-> salaxy编码 的双向映射"""
        if self._metric_name_to_code is not None:
            return
        
        self._metric_name_to_code = {}
        self._metric_code_to_name = {}
        
        try:
            from config.settings import Settings
            from loaders.metadata_loader import MetadataManager
            
            settings = Settings()
            metadata = MetadataManager(settings.base_info_dir)
            
            for metric_name, metric_def in metadata.metrics_metadata.items():
                metric_code = metric_def.get('metricCode', '')
                if metric_code:
                    salaxy_code = f"salaxyzb_{metric_code}"
                    self._metric_name_to_code[metric_name] = salaxy_code
                    self._metric_code_to_name[salaxy_code] = metric_name
        except Exception as e:
            self.logger.debug(f"加载指标映射失败: {e}")
    
    def generate_report(self, result: ValidationResult) -> str:
        """
        生成验证报告
        
        Args:
            result: 验证结果
        
        Returns:
            报告文件路径
        """
        # 确保输出目录存在
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
            self.logger.debug(f"创建报告目录: {self.output_dir}")
        
        # 生成文件名
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        original_filename = os.path.basename(result.test_cases_file)
        original_name = os.path.splitext(original_filename)[0]
        filename = f"validation_report_{original_name}_{timestamp}.json"
        output_path = os.path.join(self.output_dir, filename)
        
        # 构建报告数据
        report_data = self._build_report_data(result)
        
        # 写入文件
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, ensure_ascii=False, indent=2)
            
            self.logger.success(f"验证报告已生成: {output_path}")
            return output_path
            
        except Exception as e:
            self.logger.error(f"生成验证报告失败: {e}")
            return ""
    
    def _build_report_data(self, result: ValidationResult) -> Dict[str, Any]:
        """
        构建报告数据
        
        Args:
            result: 验证结果
        
        Returns:
            报告数据字典
        """
        return {
            'report_metadata': {
                'generated_at': result.validation_time,
                'test_cases_file': result.test_cases_file,
                'report_version': '1.0.0'
            },
            'rule_info': {
                'rule_id': result.rule_id,
                'rule_name': result.rule_name
            },
            'summary': {
                'total_test_cases': result.total_cases,
                'passed_cases': result.passed_cases,
                'failed_cases': result.failed_cases,
                'pass_rate': result.pass_rate,
                **result.summary
            },
            'test_case_results': [
                self._serialize_test_case_result(tc)
                for tc in result.test_case_results
            ]
        }
    
    def _serialize_test_case_result(self, tc_result) -> Dict[str, Any]:
        """序列化测试用例结果"""
        return {
            'case_id': tc_result.case_id,
            'case_name': tc_result.case_name,
            'scenario_name': tc_result.scenario_name,
            'expected_rule_hit': tc_result.expected_rule_hit,
            'success': tc_result.success,
            'error_message': tc_result.error_message,
            'event_results': [
                self._serialize_event_result(event)
                for event in tc_result.event_results
            ]
        }
    
    def _serialize_event_result(self, event_result) -> Dict[str, Any]:
        """序列化进件结果，为指标补充可读标识方便对应"""
        self._load_metric_mappings()
        
        return {
            'sequence': event_result.sequence,
            'success': event_result.success,
            'expected_hit': event_result.expected_hit,
            'actual_hit': event_result.actual_hit,
            'hit_match': event_result.hit_match,
            'expected_metrics': self._enrich_expected_metrics(event_result.expected_metrics),
            'actual_metrics': self._enrich_actual_metrics(event_result.actual_metrics),
            'metrics_match': event_result.metrics_match,
            'metrics_diff': event_result.metrics_diff,
            'error_message': event_result.error_message,
            'response_time_ms': event_result.response_time_ms
        }
    
    def _enrich_expected_metrics(self, expected_metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        为 expected_metrics 的每个 key 追加 salaxy 编码标识
        
        原始: {"指标名称": {...}}
        转换: {"指标名称 (salaxyzb_xxx)": {...}}
        """
        if not expected_metrics or not self._metric_name_to_code:
            return expected_metrics
        
        enriched = {}
        for metric_name, value in expected_metrics.items():
            salaxy_code = self._metric_name_to_code.get(metric_name, '')
            if salaxy_code:
                enriched_key = f"{metric_name} ({salaxy_code})"
            else:
                enriched_key = metric_name
            enriched[enriched_key] = value
        return enriched
    
    def _enrich_actual_metrics(self, actual_metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        为 actual_metrics 中 salaxy 编码的 key 追加指标名称标识
        
        原始: {"salaxyzb_xxx": 1, "S_S_IPCOUNTRY": "中国"}
        转换: {"salaxyzb_xxx (指标名称)": 1, "S_S_IPCOUNTRY": "中国"}
        """
        if not actual_metrics or not self._metric_code_to_name:
            return actual_metrics
        
        enriched = {}
        for key, value in actual_metrics.items():
            if key.startswith('salaxyzb_'):
                metric_name = self._metric_code_to_name.get(key, '')
                if metric_name:
                    enriched_key = f"{key} ({metric_name})"
                else:
                    enriched_key = key
            else:
                enriched_key = key
            enriched[enriched_key] = value
        return enriched
    
    def print_console_report(self, result: ValidationResult) -> None:
        """
        打印控制台报告
        
        Args:
            result: 验证结果
        """
        self.logger.section_header("验证报告")
        
        print(f"  测试文件: {result.test_cases_file}")
        print(f"  规则ID: {result.rule_id}")
        print(f"  规则名称: {result.rule_name}")
        print(f"  验证时间: {result.validation_time}")
        
        print(f"\n  [汇总]")
        print(f"    总用例数: {result.total_cases}")
        print(f"    通过: {result.passed_cases}")
        print(f"    失败: {result.failed_cases}")
        print(f"    通过率: {result.pass_rate}%")
        
        if result.summary:
            print(f"    总进件数: {result.summary.get('total_events', 0)}")
            print(f"    失败进件: {result.summary.get('failed_events', 0)}")
        
        print(f"\n  [详细结果]")
        for tc in result.test_case_results:
            status = "✓" if tc.success else "✗"
            print(f"    {status} {tc.case_id} [{tc.scenario_name}]")
            
            if not tc.success:
                print(f"       失败原因: {tc.error_message}")
                
                # 显示失败的进件详情
                for event in tc.event_results:
                    if not event.success:
                        print(f"       进件 {event.sequence}: {event.error_message}")
                        if event.metrics_diff:
                            for diff in event.metrics_diff:
                                print(f"         - {diff}")
