"""
规则验证器 - 验证测试用例与实际系统执行效果是否一致
"""

import json
import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
import requests

from config.validator_config import ValidatorConfig
from utils.logger import get_logger


@dataclass
class EventValidationResult:
    """单笔进件验证结果"""
    sequence: int
    success: bool
    expected_hit: bool
    actual_hit: bool
    hit_match: bool
    expected_metrics: Dict[str, Any] = field(default_factory=dict)
    actual_metrics: Dict[str, Any] = field(default_factory=dict)
    metrics_match: bool = True
    metrics_diff: List[str] = field(default_factory=list)
    error_message: str = ""
    response_time_ms: int = 0


@dataclass
class TestCaseValidationResult:
    """单个测试用例验证结果"""
    case_id: str
    case_name: str
    scenario_name: str
    expected_rule_hit: bool
    success: bool
    event_results: List[EventValidationResult] = field(default_factory=list)
    error_message: str = ""


@dataclass
class ValidationResult:
    """完整验证结果"""
    test_cases_file: str
    rule_id: str
    rule_name: str
    validation_time: str
    total_cases: int
    passed_cases: int
    failed_cases: int
    pass_rate: float
    test_case_results: List[TestCaseValidationResult] = field(default_factory=list)
    summary: Dict[str, Any] = field(default_factory=dict)


class RuleValidator:
    """规则验证器"""
    
    def __init__(self, config: Optional[ValidatorConfig] = None):
        """
        初始化验证器
        
        Args:
            config: 验证器配置，默认从环境变量加载
        """
        self.config = config or ValidatorConfig.from_env()
        self.logger = get_logger()
    
    def validate_file(self, test_cases_file: str) -> ValidationResult:
        """
        验证测试用例文件
        
        Args:
            test_cases_file: 测试用例JSON文件路径
        
        Returns:
            验证结果
        """
        self.logger.info(f"开始验证测试用例文件: {test_cases_file}")
        
        # 加载测试用例
        test_cases_data = self._load_test_cases(test_cases_file)
        if not test_cases_data:
            return self._create_error_result(test_cases_file, "无法加载测试用例文件")
        
        rule_info = test_cases_data.get('rule_info', {})
        rule_id = rule_info.get('rule_id', '')
        rule_name = rule_info.get('rule_name', '')
        service_id = rule_info.get('service_id', '')
        test_cases = test_cases_data.get('test_cases', [])
        
        if not rule_id:
            return self._create_error_result(test_cases_file, "测试用例文件中未找到rule_id")
        
        # 动态拼接API地址
        api_url = self.config.get_api_url(service_id)
        
        self.logger.info(f"规则ID: {rule_id}")
        self.logger.info(f"规则名称: {rule_name}")
        if service_id:
            self.logger.info(f"服务标识: {service_id}")
        self.logger.info(f"API地址: {api_url}")
        self.logger.info(f"测试用例数: {len(test_cases)}")
        
        # 验证每个测试用例
        case_results = []
        passed_count = 0
        failed_count = 0
        
        for i, test_case in enumerate(test_cases, 1):
            self.logger.info(f"\n验证测试用例 {i}/{len(test_cases)}: {test_case.get('case_name', '')}")
            case_result = self._validate_test_case(test_case, rule_id, api_url)
            case_results.append(case_result)
            
            if case_result.success:
                passed_count += 1
                self.logger.success(f"  ✓ 通过")
            else:
                failed_count += 1
                self.logger.error(f"  ✗ 失败: {case_result.error_message}")
        
        # 计算通过率
        total_cases = len(test_cases)
        pass_rate = (passed_count / total_cases * 100) if total_cases > 0 else 0
        
        # 构建验证结果
        result = ValidationResult(
            test_cases_file=test_cases_file,
            rule_id=rule_id,
            rule_name=rule_name,
            validation_time=datetime.now().isoformat(),
            total_cases=total_cases,
            passed_cases=passed_count,
            failed_cases=failed_count,
            pass_rate=round(pass_rate, 2),
            test_case_results=case_results,
            summary=self._generate_summary(case_results)
        )
        
        self.logger.info(f"\n验证完成: 通过 {passed_count}/{total_cases} ({pass_rate:.1f}%)")
        
        return result
    
    def _load_test_cases(self, file_path: str) -> Optional[Dict[str, Any]]:
        """加载测试用例文件"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            self.logger.error(f"加载测试用例文件失败: {e}")
            return None
    
    def _validate_test_case(self, test_case: Dict[str, Any], rule_id: str, api_url: str) -> TestCaseValidationResult:
        """
        验证单个测试用例
        
        Args:
            test_case: 测试用例数据
            rule_id: 规则ID
            api_url: 完整的API地址（已拼接服务标识）
        
        Returns:
            测试用例验证结果
        """
        case_id = test_case.get('case_id', '')
        case_name = test_case.get('case_name', '')
        scenario = test_case.get('scenario', {})
        scenario_name = scenario.get('scenario_name', '')
        expected_rule_hit = scenario.get('expected_rule_hit', False)
        events = test_case.get('events', [])
        
        # 验证每笔进件
        event_results = []
        all_events_pass = True
        total_events = len(events)
        
        for idx, event in enumerate(events):
            is_last_event = (idx == total_events - 1)
            event_result = self._validate_event(
                event=event,
                rule_id=rule_id,
                expected_rule_hit=expected_rule_hit,
                is_last_event=is_last_event,
                api_url=api_url
            )
            event_results.append(event_result)
            
            if not event_result.success:
                all_events_pass = False
                self.logger.error(f"    进件 {event_result.sequence}: 失败 - {event_result.error_message}")
            else:
                self.logger.debug(f"    进件 {event_result.sequence}: 通过")
        
        # 测试用例成功条件：所有进件都通过
        success = all_events_pass and len(event_results) > 0
        
        error_message = ""
        if not success:
            failed_events = [e for e in event_results if not e.success]
            error_message = f"{len(failed_events)} 笔进件验证失败"
        
        return TestCaseValidationResult(
            case_id=case_id,
            case_name=case_name,
            scenario_name=scenario_name,
            expected_rule_hit=expected_rule_hit,
            success=success,
            event_results=event_results,
            error_message=error_message
        )
    
    def _validate_event(
        self,
        event: Dict[str, Any],
        rule_id: str,
        expected_rule_hit: bool,
        is_last_event: bool,
        api_url: str
    ) -> EventValidationResult:
        """
        验证单笔进件
        
        Args:
            event: 进件数据
            rule_id: 规则ID
            expected_rule_hit: 场景预期的规则命中状态
            is_last_event: 是否为最后一笔进件
            api_url: 完整的API地址（已拼接服务标识）
        
        Returns:
            进件验证结果
        """
        sequence = event.get('sequence', 0)
        data = event.get('data', {})
        expected_metrics = event.get('expected_metric_values', {})
        purpose = event.get('purpose', '')
        
        # 从进件中读取预期的条件命中状态
        expected_condition_hit = event.get('expected_condition_hit', False)
        
        # 打印请求关键信息（verbose模式）
        self._log_request_info(sequence, data, expected_condition_hit, purpose)
        
        # 调用API
        api_response, error = self._call_api_with_retry(data, api_url)
        
        if error:
            return EventValidationResult(
                sequence=sequence,
                success=False,
                expected_hit=expected_condition_hit,
                actual_hit=False,
                hit_match=False,
                error_message=error,
                expected_metrics=expected_metrics
            )
        
        # 检测API业务错误（如渠道不存在、策略不存在等）
        api_error = self._check_api_error(api_response)
        if api_error:
            self.logger.error(f"    API业务错误: {api_error}")
            return EventValidationResult(
                sequence=sequence,
                success=False,
                expected_hit=expected_condition_hit,
                actual_hit=False,
                hit_match=False,
                error_message=f"API错误: {api_error}",
                expected_metrics=expected_metrics
            )
        
        # 解析响应
        actual_hit, hit_rules = self._parse_hit_status(api_response, rule_id)
        actual_metrics = self._parse_metrics(api_response)
        
        # 打印响应信息（debug级别）
        self._log_response_info(sequence, actual_hit, hit_rules, actual_metrics)
        
        # 验证命中状态（使用 expected_condition_hit）
        hit_match = (actual_hit == expected_condition_hit)
        
        # 对于最后一笔进件，额外验证与场景预期一致
        scenario_match = True
        if is_last_event:
            scenario_match = (expected_condition_hit == expected_rule_hit)
            if not scenario_match:
                self.logger.error(f"    最后一笔进件的expected_condition_hit({expected_condition_hit})与场景expected_rule_hit({expected_rule_hit})不一致")
        
        # 验证指标值
        metrics_match, metrics_diff = self._compare_metrics(expected_metrics, actual_metrics)
        
        # 整体成功条件：命中状态匹配、指标值匹配、最后一笔需满足场景预期
        success = hit_match and metrics_match and scenario_match
        
        error_message = ""
        if not hit_match:
            error_message = f"命中状态不匹配: 预期{'命中' if expected_condition_hit else '未命中'}, 实际{'命中' if actual_hit else '未命中'}"
        elif not scenario_match:
            error_message = f"最后一笔进件与场景预期不一致: expected_condition_hit={expected_condition_hit}, expected_rule_hit={expected_rule_hit}"
        elif not metrics_match:
            error_message = f"指标值不匹配: {', '.join(metrics_diff)}"
        
        return EventValidationResult(
            sequence=sequence,
            success=success,
            expected_hit=expected_condition_hit,
            actual_hit=actual_hit,
            hit_match=hit_match,
            expected_metrics=expected_metrics,
            actual_metrics=actual_metrics,
            metrics_match=metrics_match,
            metrics_diff=metrics_diff,
            error_message=error_message
        )
    
    def _call_api_with_retry(self, data: Dict[str, Any], api_url: str) -> Tuple[Optional[Dict], str]:
        """
        带重试机制的API调用
        
        Args:
            data: 请求数据
            api_url: 完整的API地址（已拼接服务标识）
        
        Returns:
            (响应数据, 错误信息)
        """
        last_error = ""
        
        for attempt in range(self.config.retry_times + 1):
            try:
                start_time = time.time()
                response = requests.post(
                    api_url,
                    json=data,
                    timeout=self.config.timeout,
                    headers={'Content-Type': 'application/json'}
                )
                response_time = int((time.time() - start_time) * 1000)
                
                response.raise_for_status()
                return response.json(), ""
                
            except requests.exceptions.RequestException as e:
                last_error = f"API调用失败: {str(e)}"
                self.logger.warning(f"  第 {attempt + 1} 次尝试失败: {last_error}")
                
                if attempt < self.config.retry_times:
                    # 退避重试
                    delay = self.config.retry_delay * (2 ** attempt)
                    self.logger.info(f"  {delay}秒后重试...")
                    time.sleep(delay)
        
        return None, last_error
    
    def _check_api_error(self, response: Dict[str, Any]) -> Optional[str]:
        """
        检测API业务错误
        
        Args:
            response: API响应
        
        Returns:
            错误信息，如果没有错误返回None
        """
        # 检查顶级 success 字段
        if response.get('success') is False:
            code = response.get('code', 'UNKNOWN')
            message = response.get('message', '未知错误')
            
            # 从 data 中提取更详细的错误信息
            data = response.get('data', {}) or {}
            reason_code = data.get('reasonCode', code)
            reason_message = data.get('reasonMessage', message)
            
            error_detail = f"[{reason_code}] {reason_message}"
            self.logger.warning(f"  API响应详情: code={code}, message={message}")
            return error_detail
        
        # 检查 data 中的 status 字段
        data = response.get('data', {}) or {}
        status = data.get('status')
        if status is not None and status != 1:  # status=1 通常表示成功
            reason_code = data.get('reasonCode', 'UNKNOWN')
            reason_message = data.get('reasonMessage', '未知错误')
            return f"[{reason_code}] {reason_message}"
        
        return None
    
    def _parse_hit_status(self, response: Dict[str, Any], rule_id: str) -> Tuple[bool, List[str]]:
        """
        解析命中状态
        
        Args:
            response: API响应
            rule_id: 规则ID
        
        Returns:
            (是否命中, 命中的规则ID列表)
        """
        try:
            data = response.get('data') or {}
            node_results = data.get('nodeResults') or []
            
            # 调试日志：打印响应结构
            if not node_results:
                self.logger.debug(f"API响应无nodeResults，完整响应: {response}")
            
            hit_rules = []
            for node in node_results:
                if node.get('nodeType') == 'RuleSetServiceNode':
                    result = node.get('result') or {}
                    hit_rules_info = result.get('hitRules') or []
                    for rule in hit_rules_info:
                        hit_rules.append(rule.get('id', ''))
            
            # 检查目标规则是否在命中列表中
            is_hit = rule_id in hit_rules
            return is_hit, hit_rules
            
        except Exception as e:
            self.logger.error(f"解析命中状态失败: {e}")
            return False, []
    
    def _parse_metrics(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """
        解析指标值
        
        从 API 响应的 nodeResults 中提取指标值。
        指标值主要存储在 incomingFields 中（以 salaxyzb_ 前缀编码），
        同时从 result.requestUseField 中补充读取。
        
        Args:
            response: API响应
        
        Returns:
            指标值字典 {编码: 值}，如 {"salaxyzb_jk1b18hju1": "500.0"}
        """
        try:
            data = response.get('data') or {}
            node_results = data.get('nodeResults') or []
            
            metrics = {}
            for node in node_results:
                if node.get('nodeType') == 'RuleSetServiceNode':
                    # 优先从 incomingFields 读取指标值（包含 salaxyzb_ 前缀的指标编码）
                    incoming_fields = node.get('incomingFields') or {}
                    metrics.update(incoming_fields)
                    # 从 result.requestUseField 补充读取（兜底，覆盖同名字段）
                    result = node.get('result') or {}
                    request_use_field = result.get('requestUseField') or {}
                    for k, v in request_use_field.items():
                        if k not in metrics:
                            metrics[k] = v
            
            return metrics
            
        except Exception as e:
            self.logger.error(f"解析指标值失败: {e}")
            return {}
    
    def _compare_metrics(self, expected: Dict[str, Any], actual: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """
        比较指标值
        
        Args:
            expected: 预期指标值（结构：{指标名: {query_value: x, after_update: y}}）
            actual: 实际指标值（结构：{salaxy编码: 值}）
        
        Returns:
            (是否匹配, 差异列表)
        """
        if not expected:
            return True, []
        
        if not actual:
            # 如果API没有返回指标值，跳过校验
            return True, []
        
        # 加载指标元数据获取名称到编码的映射
        metric_name_to_code = self._get_metric_name_to_code_mapping()
        
        # 构建空格无关的映射（LLM生成的指标名可能含多余空格）
        normalized_name_to_code = {}
        for name, code in metric_name_to_code.items():
            norm = re.sub(r'\s+', '', name)
            normalized_name_to_code[norm] = code
        
        diff = []
        for metric_name, expected_info in expected.items():
            # 提取 query_value 作为预期值
            if isinstance(expected_info, dict):
                expected_value = expected_info.get('query_value')
            else:
                expected_value = expected_info
            
            if expected_value is None:
                continue
            
            # 尝试通过指标名或编码查找实际值
            actual_value = None
            matched_key = None
            
            # 1. 尝试直接用指标名查找
            if metric_name in actual:
                actual_value = actual.get(metric_name)
                matched_key = metric_name
            # 2. 尝试用映射后的编码查找（精确匹配）
            elif metric_name in metric_name_to_code:
                metric_code = metric_name_to_code[metric_name]
                actual_value = actual.get(metric_code)
                matched_key = metric_code if actual_value is not None else None
            # 3. 尝试空格无关匹配（LLM生成名称可能含多余空格）
            else:
                norm_name = re.sub(r'\s+', '', metric_name)
                if norm_name in normalized_name_to_code:
                    metric_code = normalized_name_to_code[norm_name]
                    actual_value = actual.get(metric_code)
                    matched_key = metric_code if actual_value is not None else None
                else:
                    # 4. 尝试模糊匹配（salaxy编码通常包含指标名的部分哈希）
                    for code in actual.keys():
                        if metric_name in code or code in metric_name:
                            actual_value = actual.get(code)
                            matched_key = code
                            break
            
            # 处理 matched_key 为 None 的情况：指标未部署在该服务上
            # 区分"指标已部署但值为null"和"指标根本不在响应中"
            if matched_key is None and actual_value is None:
                # 指标不在API响应中，说明该服务未部署此指标
                # 对于 FORMULA 的依赖指标或非核心指标，跳过校验
                self.logger.debug(
                    f"  指标 '{metric_name}' 未在API响应中找到（未部署），跳过校验"
                )
                continue
            
            # 处理API返回的字符串 'null'：表示指标未初始化/无数据
            # 对于数值型聚合指标（SUM/COUNT/SET），'null' 等价于 0
            # 对于历史取值类指标（HISTORY_VALUE），'null' 表示无历史值，保留为 None
            if actual_value == 'null':
                # 判断该指标是否为历史取值类（通过元数据查找）
                is_history_value = False
                try:
                    from loaders.metadata_loader import MetadataManager
                    meta = MetadataManager()
                    # 尝试精确匹配和空格归一化匹配
                    metric_def = meta.get_metric(metric_name)
                    if not metric_def:
                        norm_name = re.sub(r'\s+', '', metric_name)
                        for mname in meta.metric_metadata.keys():
                            if re.sub(r'\s+', '', mname) == norm_name:
                                metric_def = meta.get_metric(mname)
                                break
                    if metric_def and metric_def.get('templateCode') in ('HISTORY_VALUE', 'TIME_GAP', 'MOVEMENT'):
                        is_history_value = True
                except Exception:
                    pass
                
                if is_history_value:
                    actual_value = None  # 保留为 None，与预期 null 匹配
                else:
                    actual_value = 0
            
            # 如果预期和实际都是 None，视为匹配
            if expected_value is None and actual_value is None:
                continue
            # 如果其中一个为 None，视为不匹配
            # 特殊处理：MOVEMENT 指标的 expected 为 null（LLM 无法精确计算距离/速度），
            # 此时跳过指标值比较，仅依赖命中状态(hit_match)来判定
            if expected_value is None or actual_value is None:
                is_movement_metric = False
                try:
                    from loaders.metadata_loader import MetadataManager
                    _m = MetadataManager()
                    _md = _m.get_metric(metric_name)
                    if not _md:
                        _nn = re.sub(r'\s+', '', metric_name)
                        for _k in _m.metric_metadata.keys():
                            if re.sub(r'\s+', '', _k) == _nn:
                                _md = _m.get_metric(_k)
                                break
                    if _md and _md.get('templateCode') == 'MOVEMENT':
                        is_movement_metric = True
                except Exception:
                    pass
                
                if is_movement_metric and expected_value is None and actual_value is not None:
                    # MOVEMENT: 预期 null 但实际有值 → 跳过比较（LLM 无法计算精确距离）
                    continue
                diff.append(f"{metric_name}: 预期{expected_value}, 实际{actual_value}")
                continue
            
            # 数值型比较：统一为浮点数后比较，容忍整数/浮点差异（如 0 vs 0.0）
            if actual_value is not None:
                try:
                    expected_num = float(expected_value)
                    actual_num = float(actual_value)
                    # MOVEMENT 等浮点型模板使用相对容差（1%），其他模板使用绝对容差
                    is_movement = False
                    try:
                        from loaders.metadata_loader import MetadataManager
                        _meta = MetadataManager()
                        _mdef = _meta.get_metric(metric_name)
                        if not _mdef:
                            _norm = re.sub(r'\s+', '', metric_name)
                            for _mn in _meta.metric_metadata.keys():
                                if re.sub(r'\s+', '', _mn) == _norm:
                                    _mdef = _meta.get_metric(_mn)
                                    break
                        if _mdef and _mdef.get('templateCode') == 'MOVEMENT':
                            is_movement = True
                    except Exception:
                        pass
                    
                    if is_movement:
                        # MOVEMENT: 相对容差 1%，绝对下限 100 米
                        base = max(abs(expected_num), abs(actual_num), 1e-9)
                        rel_diff = abs(expected_num - actual_num) / base
                        if rel_diff > 0.01 and abs(expected_num - actual_num) > 100:
                            diff.append(f"{metric_name}: 预期{expected_value}, 实际{actual_value}")
                    else:
                        if abs(expected_num - actual_num) > 1e-6:
                            diff.append(f"{metric_name}: 预期{expected_value}, 实际{actual_value}")
                except (ValueError, TypeError):
                    # 非数值型，直接比较字符串（也做空格归一化）
                    actual_str = str(actual_value).strip()
                    expected_str = str(expected_value).strip()
                    if actual_str != expected_str:
                        diff.append(f"{metric_name}: 预期{expected_value}, 实际{actual_value}")
        
        return len(diff) == 0, diff
    
    def _get_metric_name_to_code_mapping(self) -> Dict[str, str]:
        """
        获取指标名称到编码的映射
        
        Returns:
            {指标名称: salaxy编码} 字典，如 {"注册_24小时...": "salaxyzb_i7b7ipel3f"}
        """
        # 从元数据中获取映射
        try:
            from config.settings import Settings
            from loaders.metadata_loader import MetadataManager
            
            settings = Settings()
            metadata = MetadataManager(settings.base_info_dir)
            metrics_metadata = metadata.metrics_metadata
            
            mapping = {}
            for metric_name, metric_def in metrics_metadata.items():
                # metricCode 格式如 "i7b7ipel3f"，API返回格式为 "salaxyzb_i7b7ipel3f"
                metric_code = metric_def.get('metricCode', '')
                if metric_code:
                    # 加上 salaxyzb_ 前缀
                    salaxy_code = f"salaxyzb_{metric_code}"
                    mapping[metric_name] = salaxy_code
            
            return mapping
        except Exception as e:
            self.logger.debug(f"获取指标映射失败: {e}")
            return {}
    
    def _generate_summary(self, case_results: List[TestCaseValidationResult]) -> Dict[str, Any]:
        """生成验证摘要"""
        total_events = sum(len(c.event_results) for c in case_results)
        failed_events = sum(
            len([e for e in c.event_results if not e.success])
            for c in case_results
        )
        
        return {
            'total_test_cases': len(case_results),
            'total_events': total_events,
            'failed_events': failed_events,
            'event_success_rate': round((total_events - failed_events) / total_events * 100, 2) if total_events > 0 else 0
        }
    
    def _create_error_result(self, file_path: str, error_message: str) -> ValidationResult:
        """创建错误结果"""
        return ValidationResult(
            test_cases_file=file_path,
            rule_id="",
            rule_name="",
            validation_time=datetime.now().isoformat(),
            total_cases=0,
            passed_cases=0,
            failed_cases=0,
            pass_rate=0,
            test_case_results=[],
            summary={'error': error_message}
        )
    
    def _log_request_info(
        self,
        sequence: int,
        data: Dict[str, Any],
        expected_hit: bool,
        purpose: str
    ):
        """
        打印请求信息（debug级别）
        
        Args:
            sequence: 进件序号
            data: 请求数据
            expected_hit: 预期命中状态
            purpose: 进件目的
        """
        # 提取关键字段
        key_fields = ['bizid', 'biztime', 'deviceid', 'accountlogin', 'appcode', 'policycode']
        key_data = {k: data.get(k, '-') for k in key_fields if k in data}
        
        self.logger.debug(f"    [进件{sequence}] 预期: {'命中' if expected_hit else '不命中'}")
        self.logger.debug(f"    目的: {purpose[:50]}..." if len(purpose) > 50 else f"    目的: {purpose}")
        self.logger.debug(f"    关键字段: {key_data}")
    
    def _log_response_info(
        self,
        sequence: int,
        actual_hit: bool,
        hit_rules: List[str],
        actual_metrics: Dict[str, Any]
    ):
        """
        打印响应信息（debug级别）
        
        Args:
            sequence: 进件序号
            actual_hit: 实际命中状态
            hit_rules: 命中的规则列表
            actual_metrics: 实际指标值
        """
        self.logger.debug(f"    [响应{sequence}] 命中: {actual_hit}, 命中规则: {hit_rules}")
        if actual_metrics:
            # 只显示关键指标值
            metrics_preview = {k: v for k, v in list(actual_metrics.items())[:5]}
            self.logger.debug(f"    指标值: {metrics_preview}")
