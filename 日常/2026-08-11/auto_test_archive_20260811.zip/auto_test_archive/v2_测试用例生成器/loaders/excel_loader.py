"""
Excel规则加载器 - 读取Excel规则文件

Excel 字段分类：
- 入参字段-业务：LLM 需要生成的业务字段（如设备ID、登录账号）
- 入参字段-配置：系统自动填充的配置字段（如渠道标识、策略编码）
- 非入参字段：不出现在进件 data 中的字段（如策略事件类型、计算字段）
"""

import pandas as pd
from pathlib import Path
from typing import List, Dict, Any, Optional
from utils.logger import get_logger
from exceptions import FieldMappingError


def load_rules_from_excel(file_path: str, sheet_name: str = None) -> List[Dict[str, Any]]:
    """
    从Excel文件读取规则
    
    Args:
        file_path: Excel文件路径
        sheet_name: 指定读取的sheet名称，默认读取第一个sheet
    
    Returns:
        规则列表，每条规则为一个字典
    """
    logger = get_logger()
    
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Excel文件不存在: {file_path}")
    
    logger.debug(f"读取Excel文件: {file_path}" + (f" (sheet: {sheet_name})" if sheet_name else ""))
    
    # 读取Excel（支持指定sheet）
    # sheet_name=None 在 pandas 中表示读取所有sheet返回dict，需要转为 0（第一个sheet）
    read_sheet = sheet_name if sheet_name is not None else 0
    df = pd.read_excel(file_path, sheet_name=read_sheet)
    
    logger.debug(f"Excel列名: {list(df.columns)}")
    logger.debug(f"规则数量: {len(df)}")
    
    rules = []
    for idx, row in df.iterrows():
        rule = {
            'rule_index': idx + 1,
            'policy_name': str(row.get('策略名称', '')).strip(),
            'policy_code': str(row.get('策略标识', '')).strip(),
            'ruleset_name': str(row.get('规则集名称', '')).strip(),
            'rule_no': str(row.get('规则编号', '')).strip(),
            'rule_name': str(row.get('规则名称', '')).strip(),
            'rule_description': str(row.get('规则描述', row.get('规则描述(中文)', ''))).strip(),
            'metrics_text': str(row.get('指标', '')).strip(),
            
            # 新字段分类结构
            'input_fields_business_text': str(row.get('入参字段-业务', '')).strip(),
            'input_fields_config_text': str(row.get('入参字段-配置', '')).strip(),
            'non_input_fields_text': str(row.get('非入参字段', '')).strip(),
            
            # 兼容旧结构（如果存在）
            'ruleset_params_text': str(row.get('规则集参数', row.get('入参字段-业务', ''))).strip(),
            'common_fields_text': str(row.get('公共字段', row.get('入参字段-配置', ''))).strip(),
            'event_type': str(row.get('策略事件类型', '')).strip(),
            
            # 服务标识：用于验证器动态拼接API URL
            'service_id': str(row.get('服务标识', '')).strip(),
            
            # 模板标识：当前仅支持 common/custom
            'template_code': str(row.get('模板标识', '')).strip(),
            
            # 条件属性：格式为 "条件1:property\n条件2:property\n..."
            'condition_properties_text': str(row.get('条件属性', '')).strip(),
        }
        
        # 解析指标列表
        rule['metrics'] = parse_multiline_text(rule['metrics_text'])
        
        # ========== 新字段分类 ==========
        # 入参字段-业务：LLM 需要生成的字段列表
        rule['input_fields_business'] = parse_multiline_text(rule['input_fields_business_text'])
        
        # 入参字段-配置：系统填充的键值对
        rule['input_fields_config'] = parse_key_value_text(rule['input_fields_config_text'])
        
        # 非入参字段：不出现在 data 中的字段（键值对格式）
        rule['non_input_fields'] = parse_key_value_text(rule['non_input_fields_text'])
        
        # ========== 兼容旧结构 ==========
        # ruleset_params 兼容：优先使用新结构
        if rule['input_fields_business']:
            rule['ruleset_params'] = rule['input_fields_business']
        else:
            rule['ruleset_params'] = parse_multiline_text(rule['ruleset_params_text'])
        
        # common_fields 兼容：优先使用新结构，且不混入非入参字段
        if rule['input_fields_config']:
            rule['common_fields'] = rule['input_fields_config']
        else:
            rule['common_fields'] = parse_key_value_text(rule['common_fields_text'])
            # 旧结构兼容：如果有单独的策略事件类型列，不要加入 common_fields
            # （策略事件类型应该在 non_input_fields 中）
        
        # 从非入参字段中提取策略事件类型（如果有）
        if '策略事件类型' in rule['non_input_fields']:
            rule['event_type'] = rule['non_input_fields']['策略事件类型']
        elif rule['event_type'] == 'nan' or not rule['event_type']:
            rule['event_type'] = ''
        
        # 服务标识处理
        if rule['service_id'] == 'nan' or not rule['service_id']:
            rule['service_id'] = ''
        
        # 模板标识处理
        if rule['template_code'] == 'nan' or not rule['template_code']:
            rule['template_code'] = ''
        
        # 条件属性处理：解析 "条件x:property" 格式
        rule['condition_properties'] = parse_condition_properties(rule['condition_properties_text'])
        
        rules.append(rule)
    
    return rules


def parse_multiline_text(text: str) -> List[str]:
    """
    解析多行文本为列表
    
    Args:
        text: 多行文本
    
    Returns:
        去除空行的文本列表
    """
    if not text or text == 'nan':
        return []
    
    lines = text.strip().split('\n')
    return [line.strip() for line in lines if line.strip()]


def validate_field_mappings(rules: List[Dict[str, Any]], metadata_manager) -> None:
    """
    校验规则中所有字段在元数据中是否存在映射（包括系统字段）
    
    Args:
        rules: 规则列表
        metadata_manager: 元数据管理器实例
    
    Raises:
        FieldMappingError: 当字段找不到映射时
    """
    logger = get_logger()
    
    # 定义系统字段及其对应的元数据字段名（支持多语言别名）
    # 格式: Excel中的显示名 -> 元数据中可能的显示名列表
    system_field_mappings = {
        '调用类型': ['调用类型', 'Call Type', 'API Model'],
        '策略编码': ['策略编码', 'Policy Code'],
        '渠道标识': ['渠道标识', 'Channel ID', 'App Code'],
        '合作方': ['合作方', 'Partner', 'Kratos'],
        '机构编号': ['机构编号', 'Org Code', 'Organization'],
        '策略事件类型': ['事件类型', 'Event Type'],
    }
    
    for rule in rules:
        rule_name = rule.get('rule_name', '未知规则')
        
        # 校验入参字段-业务
        business_fields = rule.get('input_fields_business', [])
        for field_name in business_fields:
            field_def = metadata_manager.get_field_by_display_name(field_name)
            if not field_def:
                logger.error(f"规则 '{rule_name}' 的入参字段-业务中，字段 '{field_name}' 在元数据中未找到映射")
                raise FieldMappingError(field_name, rule_name)
        
        # 校验入参字段-配置（包括系统字段）
        config_fields = rule.get('input_fields_config', {})
        for field_name in config_fields.keys():
            # 检查是否为系统字段
            if field_name in system_field_mappings:
                # 系统字段：尝试多个候选 displayName
                candidate_names = system_field_mappings[field_name]
                field_def = None
                for candidate in candidate_names:
                    field_def = metadata_manager.get_field_by_display_name(candidate)
                    if field_def:
                        break
                if not field_def:
                    # 系统字段允许在元数据中不存在（如调用类型、策略编码等是API层面的参数）
                    logger.debug(f"规则 '{rule_name}': 系统字段 '{field_name}' 在元数据中未找到映射，跳过校验")
            else:
                # 普通字段校验
                field_def = metadata_manager.get_field_by_display_name(field_name)
                if not field_def:
                    logger.error(f"规则 '{rule_name}' 的入参字段-配置中，字段 '{field_name}' 在元数据中未找到映射")
                    raise FieldMappingError(field_name, rule_name)
        
        # 校验非入参字段（包括系统字段）
        non_input_fields = rule.get('non_input_fields', {})
        for field_name in non_input_fields.keys():
            # 检查是否为系统字段
            if field_name in system_field_mappings:
                # 系统字段：尝试多个候选 displayName
                candidate_names = system_field_mappings[field_name]
                field_def = None
                for candidate in candidate_names:
                    field_def = metadata_manager.get_field_by_display_name(candidate)
                    if field_def:
                        break
                if not field_def:
                    logger.debug(f"规则 '{rule_name}': 系统字段 '{field_name}' 在元数据中未找到映射，跳过校验")
            else:
                # 普通字段校验
                field_def = metadata_manager.get_field_by_display_name(field_name)
                if not field_def:
                    logger.error(f"规则 '{rule_name}' 的非入参字段中，字段 '{field_name}' 在元数据中未找到映射")
                    raise FieldMappingError(field_name, rule_name)
    
    logger.info(f"所有规则的字段映射校验通过，共 {len(rules)} 条规则")


def parse_key_value_text(text: str) -> Dict[str, str]:
    """
    解析键值对文本
    
    Args:
        text: 格式为"key=value"的多行文本
    
    Returns:
        键值对字典
    """
    if not text or text == 'nan':
        return {}
    
    result = {}
    lines = text.strip().split('\n')
    
    for line in lines:
        line = line.strip()
        if '=' in line:
            key, value = line.split('=', 1)
            result[key.strip()] = value.strip()
    
    return result


def parse_condition_properties(text: str) -> Dict[str, str]:
    """
    解析条件属性文本
    
    格式为多行 "条件x:property" 或 "条件 x：property"，例如:
        条件1:common
        条件 2：common/rule_template
        条件3:custom
    
    支持半角冒号(:)和全角冒号(：)作为分隔符。
    
    Args:
        text: 条件属性多行文本
    
    Returns:
        字典，key 为条件标识（如 "条件1"），value 为属性值
    """
    if not text or text == 'nan':
        return {}
    
    result = {}
    lines = text.strip().split('\n')
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # 统一全角冒号为半角冒号后再分割
        normalized = line.replace('：', ':')
        if ':' in normalized:
            key, value = normalized.split(':', 1)
            # 去除 key 中的多余空格（如 "条件 1" -> "条件1"）
            clean_key = key.strip().replace(' ', '')
            result[clean_key] = value.strip()
    
    return result


def print_rule_info(rule: Dict[str, Any]):
    """打印规则信息"""
    logger = get_logger()
    
    logger.key_value("策略名称", rule['policy_name'])
    logger.key_value("规则名称", rule['rule_name'])
    
    logger.substep(f"规则描述:")
    for line in rule['rule_description'].split('\n'):
        if line.strip():
            print(f"      {line.strip()}")
    
    logger.substep(f"指标: {len(rule['metrics'])} 个")
    for metric in rule['metrics']:
        print(f"      - {metric}")
    
    # 新字段分类显示
    logger.substep(f"入参字段-业务: {len(rule.get('input_fields_business', []))} 个")
    for param in rule.get('input_fields_business', []):
        print(f"      - {param}")
    
    logger.substep(f"入参字段-配置: {len(rule.get('input_fields_config', {}))} 个")
    for key, value in rule.get('input_fields_config', {}).items():
        print(f"      - {key} = {value}")
    
    logger.substep(f"非入参字段: {len(rule.get('non_input_fields', {}))} 个")
    for key, value in rule.get('non_input_fields', {}).items():
        print(f"      - {key} = {value}")
    
    # 模板标识
    template_code = rule.get('template_code', '')
    if template_code:
        logger.substep(f"模板标识: {template_code}")
    
    # 条件属性
    condition_props = rule.get('condition_properties', {})
    if condition_props:
        logger.substep(f"条件属性: {len(condition_props)} 个")
        for key, value in condition_props.items():
            print(f"      - {key}: {value}")


if __name__ == "__main__":
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    
    # 测试Excel加载
    test_file = Path(__file__).parent.parent / "资产环境1测试用例.xlsx"
    
    print("=" * 60)
    print("Excel规则加载测试")
    print("=" * 60)
    
    if test_file.exists():
        rules = load_rules_from_excel(str(test_file))
        print(f"\n加载了 {len(rules)} 条规则")
        
        for rule in rules:
            print(f"\n--- 规则 {rule['rule_index']} ---")
            print_rule_info(rule)
    else:
        print(f"测试文件不存在: {test_file}")
