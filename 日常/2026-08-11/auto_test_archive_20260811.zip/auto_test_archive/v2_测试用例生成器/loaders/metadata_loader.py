"""
元数据加载器 - 加载字段、指标、映射配置
"""

import json
import re
from pathlib import Path
from typing import Dict, Optional, Any, List, Set
from config.settings import get_settings
from utils.logger import get_logger


def parse_script_dependencies(script: str) -> List[str]:
    """
    解析脚本中依赖的字段
    
    Args:
        script: Groovy脚本字符串
    
    Returns:
        依赖的字段编码列表（如 ['S_S_ACCTOPNDAT', 'S_D_BIZTIME']）
    """
    if not script:
        return []
    
    # 匹配 input.get("FIELD_CODE") 或 input.get('FIELD_CODE')
    pattern = r'input\.get\(["\']([A-Z_0-9]+)["\']\)'
    matches = re.findall(pattern, script)
    
    # 去重并保持顺序
    seen = set()
    result = []
    for field_code in matches:
        if field_code not in seen:
            seen.add(field_code)
            result.append(field_code)
    
    return result


def generate_compute_description(field_def: Dict[str, Any], field_metadata: Dict[str, Any]) -> str:
    """
    根据脚本生成人类可读的计算说明
    
    Args:
        field_def: 字段定义
        field_metadata: 完整字段元数据（用于查找依赖字段的displayName）
    
    Returns:
        计算说明字符串
    """
    script = field_def.get('script', '')
    dependencies = parse_script_dependencies(script)
    
    if not dependencies:
        return field_def.get('description', '')
    
    # 获取依赖字段的显示名称
    dep_names = []
    for dep_code in dependencies:
        dep_def = field_metadata.get(dep_code, {})
        dep_name = dep_def.get('displayName', dep_code)
        dep_names.append(f"{dep_name}({dep_code})")
    
    # 根据字段特征生成说明
    field_code = field_def.get('fieldCode', '')
    display_name = field_def.get('displayName', '')
    
    # 特殊处理已知的动态字段
    if 'ACCOUNTOPENINTERVAL' in field_code:
        return f"计算 {dep_names[0]} 到 {dep_names[1]} 的天数差"
    elif 'EVENTHOUR' in field_code:
        return f"从 {dep_names[0]} 中提取小时部分（0-23）"
    
    # 通用说明
    return f"由 {', '.join(dep_names)} 计算得出"


def load_field_metadata() -> Dict[str, Any]:
    """
    加载字段元数据
    
    Returns:
        字段元数据字典，key为字段编码
    """
    settings = get_settings()
    logger = get_logger()
    
    path = settings.field_metadata_path
    logger.debug(f"加载字段元数据: {path}")
    
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 过滤掉_metadata等非字段项
    fields = {k: v for k, v in data.items() if not k.startswith('_')}
    logger.debug(f"加载了 {len(fields)} 个字段定义")
    
    return fields


def load_metric_metadata() -> Dict[str, Any]:
    """
    加载指标元数据
    
    Returns:
        指标元数据字典，key为指标名称
    """
    settings = get_settings()
    logger = get_logger()
    
    path = settings.metric_metadata_path
    logger.debug(f"加载指标元数据: {path}")
    
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    metrics = data.get('metrics', {})
    logger.debug(f"加载了 {len(metrics)} 个指标定义")
    
    return metrics


def load_mapping_config() -> Dict[str, Any]:
    """
    加载映射配置
    
    Returns:
        映射配置字典
    """
    settings = get_settings()
    logger = get_logger()
    
    path = settings.mapping_config_path
    logger.debug(f"加载映射配置: {path}")
    
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    app_count = len(data.get('app_mapping', {}))
    org_count = len(data.get('org_mapping', {}))
    logger.debug(f"加载了 app_mapping({app_count}), org_mapping({org_count})")
    
    return data


def get_field_service_param(field_code: str, field_metadata: Optional[Dict] = None) -> str:
    """
    获取字段的serviceParam
    
    Args:
        field_code: 字段编码
        field_metadata: 字段元数据（可选，不传则自动加载）
    
    Returns:
        serviceParam值，如果不存在则返回字段编码的小写
    """
    if field_metadata is None:
        field_metadata = load_field_metadata()
    
    field_def = field_metadata.get(field_code, {})
    return field_def.get('serviceParam', field_code.lower())


def get_field_definition(field_code: str, field_metadata: Optional[Dict] = None) -> Dict[str, Any]:
    """
    获取字段的完整定义
    
    Args:
        field_code: 字段编码
        field_metadata: 字段元数据（可选）
    
    Returns:
        字段定义字典
    """
    if field_metadata is None:
        field_metadata = load_field_metadata()
    
    return field_metadata.get(field_code, {})


class MetadataManager:
    """元数据管理器 - 统一管理所有元数据的加载和访问"""
    
    def __init__(self, base_info_dir: Optional[Path] = None):
        """
        初始化元数据管理器
        
        Args:
            base_info_dir: 基础信息目录（可选，默认从settings获取）
                           若指定，会同步更新全局 Settings 的 base_info_dir
        """
        self._field_metadata: Optional[Dict] = None
        self._metric_metadata: Optional[Dict] = None
        self._mapping_config: Optional[Dict] = None
        self._metrics_metadata: Optional[Dict] = None  # 别名
        self.logger = get_logger()
        
        # 若传入自定义路径，同步更新全局 Settings
        if base_info_dir is not None:
            self.base_info_dir = Path(base_info_dir)
            settings = get_settings()
            settings.set_base_info_dir(str(self.base_info_dir))
        else:
            self.base_info_dir = None
    
    def load_all(self):
        """预加载所有元数据"""
        _ = self.field_metadata
        _ = self.metric_metadata
        _ = self.mapping_config
    
    @property
    def field_metadata(self) -> Dict[str, Any]:
        """字段元数据（懒加载）"""
        if self._field_metadata is None:
            self._field_metadata = load_field_metadata()
        return self._field_metadata
    
    @property
    def metric_metadata(self) -> Dict[str, Any]:
        """指标元数据（懒加载）"""
        if self._metric_metadata is None:
            self._metric_metadata = load_metric_metadata()
        return self._metric_metadata
    
    @property
    def metrics_metadata(self) -> Dict[str, Any]:
        """指标元数据别名"""
        return self.metric_metadata
    
    @property
    def mapping_config(self) -> Dict[str, Any]:
        """映射配置（懒加载）"""
        if self._mapping_config is None:
            self._mapping_config = load_mapping_config()
        return self._mapping_config
    
    def get_service_param(self, field_code: str) -> str:
        """获取字段的serviceParam"""
        return get_field_service_param(field_code, self.field_metadata)
    
    def get_field_def(self, field_code: str) -> Dict[str, Any]:
        """获取字段定义"""
        return get_field_definition(field_code, self.field_metadata)
    
    def get_field(self, field_code: str) -> Optional[Dict[str, Any]]:
        """获取字段定义（别名）"""
        return self.get_field_def(field_code)
    
    def get_field_by_display_name(self, display_name: str) -> Optional[Dict[str, Any]]:
        """
        通过显示名称查找字段定义
        
        Args:
            display_name: 字段显示名称（如"年龄"、"IP Address"）
        
        Returns:
            字段定义字典，如果未找到则返回None
        """
        for field_code, field_def in self.field_metadata.items():
            if field_def.get('displayName') == display_name:
                return field_def
            # 检查别名列表
            aliases = field_def.get('aliases', [])
            if display_name in aliases:
                return field_def
        return None
    
    def get_metric(self, metric_name: str) -> Optional[Dict[str, Any]]:
        """获取指标定义"""
        return self.metric_metadata.get(metric_name)
    
    def get_app_mapping(self, app_name: str) -> Optional[Dict[str, str]]:
        """获取渠道映射"""
        return self.mapping_config.get('app_mapping', {}).get(app_name)
    
    def get_org_mapping(self, org_name: str) -> Optional[Dict[str, str]]:
        """获取机构映射"""
        return self.mapping_config.get('org_mapping', {}).get(org_name)
    
    def get_eventtype_mapping(self, event_name: str) -> Optional[Dict[str, str]]:
        """
        获取事件类型映射
        
        Args:
            event_name: 事件类型名称（如"登录事件"、"Register"）
        
        Returns:
            事件类型映射字典，包含name、dName、enDName
        """
        eventtypes = self.mapping_config.get('eventtypes_mapping', [])
        
        # 支持多种匹配方式
        for et in eventtypes:
            if et.get('name') == event_name or et.get('dName') == event_name:
                return et
        
        return None
    
    def get_eventtype_by_code(self, event_code: str) -> Optional[Dict[str, str]]:
        """
        根据事件类型代码获取映射
        
        Args:
            event_code: 事件类型代码（如"Register"、"Login"）
        
        Returns:
            事件类型映射字典
        """
        eventtypes = self.mapping_config.get('eventtypes_mapping', [])
        
        for et in eventtypes:
            if et.get('name') == event_code:
                return et
        
        return None
    
    def get_metric_scene_condition(self, metric_name: str) -> Optional[Dict[str, Any]]:
        """
        获取指标的场景条件配置
        
        Args:
            metric_name: 指标名称
        
        Returns:
            sceneCondition配置字典，包含sceneFieldCode、sceneType、sceneList等
        """
        metric = self.get_metric(metric_name)
        if not metric:
            return None
        
        return metric.get('sceneCondition')
    
    def get_metric_required_fields(self, metric_name: str) -> List[str]:
        """
        获取指标所需的所有字段编码
        
        Args:
            metric_name: 指标名称
        
        Returns:
            字段编码列表
        """
        metric = self.get_metric(metric_name)
        if not metric:
            return []
        
        fields = set()
        config = metric.get('templateConfig', {})
        
        # 维度字段
        if 'dimFieldCode' in config:
            fields.add(config['dimFieldCode'])
        
        # SET模板的集合字段
        if 'setFieldCode' in config:
            fields.add(config['setFieldCode'])
        
        # SUM/AMOUNT模板的计算字段
        if 'calcField' in config:
            fields.add(config['calcField'])
        
        # 场景条件字段
        scene = metric.get('sceneCondition') or {}
        if 'sceneFieldCode' in scene:
            fields.add(scene['sceneFieldCode'])
        
        # 字段条件中的字段
        field_cond = metric.get('fieldCondition') or {}
        for cond in field_cond.get('conditions', []):
            if 'fieldCode' in cond:
                fields.add(cond['fieldCode'])
        
        return list(fields)
    
    def get_metric_fieldcondition_fields(self, metric_name: str) -> List[Dict[str, Any]]:
        """
        获取指标fieldCondition中引用的字段详情
        
        Args:
            metric_name: 指标名称
        
        Returns:
            字段详情列表，每个元素包含fieldCode、fieldName、serviceParam等
        """
        metric = self.get_metric(metric_name)
        if not metric:
            return []
        
        fields = []
        field_cond = metric.get('fieldCondition')
        if not field_cond:
            return fields
        
        for cond in field_cond.get('conditions', []):
            field_code = cond.get('fieldCode')
            if field_code:
                field_def = self.get_field_def(field_code)
                if field_def:
                    fields.append({
                        'fieldCode': field_code,
                        'fieldName': field_def.get('displayName', field_code),
                        'serviceParam': field_def.get('serviceParam', field_code),
                        'logic': cond.get('logic'),
                        'refValue': cond.get('refValue')
                    })
        
        return fields
    
    def validate_metric_fieldcondition(self, metric_name: str, available_fields: List[str]) -> List[Dict[str, Any]]:
        """
        校验指标的fieldCondition字段是否在可用字段列表中
        
        Args:
            metric_name: 指标名称
            available_fields: 可用字段列表（serviceParam或displayName）
        
        Returns:
            缺失的字段列表，每个元素包含fieldCode、fieldName、serviceParam
        """
        missing_fields = []
        fc_fields = self.get_metric_fieldcondition_fields(metric_name)
        
        # 将可用字段统一转为小写，便于比较
        available_lower = [f.lower() for f in available_fields]
        
        for field in fc_fields:
            service_param = field.get('serviceParam', '')
            field_name = field.get('fieldName', '')
            field_code = field.get('fieldCode', '')
            
            # 检查serviceParam或fieldName是否在可用字段中
            if service_param.lower() not in available_lower and field_name.lower() not in available_lower:
                # 如果是脚本计算字段，检查其依赖字段是否可用
                if self.is_computed_field(field_code):
                    computed_info = self.get_computed_field_info(field_code)
                    if computed_info:
                        deps = computed_info.get('dependencies', [])
                        all_deps_available = True
                        for dep_code in deps:
                            dep_def = self.get_field_def(dep_code)
                            if dep_def:
                                dep_sp = dep_def.get('serviceParam', '').lower()
                                dep_name = dep_def.get('displayName', '').lower()
                                if dep_sp not in available_lower and dep_name not in available_lower:
                                    all_deps_available = False
                                    break
                        if all_deps_available:
                            continue  # 依赖字段都可用，无需报缺失
                missing_fields.append(field)
        
        return missing_fields
    
    def is_computed_field(self, field_code: str) -> bool:
        """
        判断是否为脚本计算的动态字段
        
        Args:
            field_code: 字段编码
        
        Returns:
            是否为脚本计算字段
        """
        field_def = self.get_field_def(field_code)
        return bool(field_def.get('script'))
    
    def get_computed_field_info(self, field_code: str) -> Optional[Dict[str, Any]]:
        """
        获取动态字段的计算信息
        
        Args:
            field_code: 字段编码
        
        Returns:
            计算信息字典，包含：
            - dependencies: 依赖的字段编码列表
            - dependency_fields: 依赖字段的完整定义列表
            - compute_description: 计算说明
        """
        field_def = self.get_field_def(field_code)
        script = field_def.get('script')
        
        if not script:
            return None
        
        dependencies = parse_script_dependencies(script)
        
        # 获取依赖字段的完整定义
        dependency_fields = []
        for dep_code in dependencies:
            dep_def = self.get_field_def(dep_code)
            if dep_def:
                dependency_fields.append(dep_def)
        
        return {
            'dependencies': dependencies,
            'dependency_fields': dependency_fields,
            'compute_description': generate_compute_description(field_def, self.field_metadata),
            'script': script
        }
    
    def get_all_computed_fields(self) -> Dict[str, Dict[str, Any]]:
        """
        获取所有带脚本的动态字段
        
        Returns:
            动态字段字典，key为fieldCode，value为字段定义（含依赖信息）
        """
        computed_fields = {}
        
        for field_code, field_def in self.field_metadata.items():
            if field_def.get('script'):
                compute_info = self.get_computed_field_info(field_code)
                computed_fields[field_code] = {
                    **field_def,
                    '_compute_info': compute_info
                }
        
        return computed_fields
    
    def expand_field_dependencies(self, field_codes: List[str]) -> List[str]:
        """
        展开字段列表中动态字段的依赖
        
        如果字段列表中包含动态字段，自动添加其依赖的前置字段
        
        Args:
            field_codes: 原始字段编码列表
        
        Returns:
            展开后的字段编码列表（包含依赖字段，去重）
        """
        expanded = list(field_codes)
        seen = set(field_codes)
        
        for field_code in field_codes:
            compute_info = self.get_computed_field_info(field_code)
            if compute_info:
                for dep_code in compute_info['dependencies']:
                    if dep_code not in seen:
                        expanded.append(dep_code)
                        seen.add(dep_code)
        
        return expanded
    
    def print_summary(self):
        """打印元数据摘要"""
        self.logger.substep(f"字段元数据: {len(self.field_metadata)} 个字段")
        self.logger.substep(f"指标元数据: {len(self.metric_metadata)} 个指标")
        
        app_count = len(self.mapping_config.get('app_mapping', {}))
        org_count = len(self.mapping_config.get('org_mapping', {}))
        self.logger.substep(f"映射配置: app_mapping({app_count}), org_mapping({org_count})")


if __name__ == "__main__":
    # 测试元数据加载
    manager = MetadataManager()
    
    print("=" * 60)
    print("元数据加载测试")
    print("=" * 60)
    
    # 测试字段元数据
    print(f"\n字段数量: {len(manager.field_metadata)}")
    print(f"示例字段 S_S_DEVICEID: {manager.get_field_def('S_S_DEVICEID')}")
    print(f"serviceParam: {manager.get_service_param('S_S_DEVICEID')}")
    
    # 测试指标元数据
    print(f"\n指标数量: {len(manager.metric_metadata)}")
    for name in list(manager.metric_metadata.keys())[:2]:
        print(f"  - {name}")
        fields = manager.get_metric_required_fields(name)
        print(f"    必需字段: {fields}")
    
    # 测试映射配置
    print(f"\n映射配置:")
    print(f"  测试渠道 -> {manager.get_app_mapping('测试渠道')}")
    print(f"  同盾决策资产库 -> {manager.get_org_mapping('同盾决策资产库')}")
