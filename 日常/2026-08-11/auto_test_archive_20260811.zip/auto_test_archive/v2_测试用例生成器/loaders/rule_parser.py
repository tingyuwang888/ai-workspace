"""
规则解析器 - 解析规则描述，提取条件和触发逻辑
"""

import re
from typing import Dict, List, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass
from utils.logger import get_logger
from exceptions import MetricMappingError


class OperandType(Enum):
    """操作数类型 - 支持所有Salaxy指标模板"""
    # 基础指标类型
    METRIC = "聚合指标型"          # 指标（通用 fallback）
    
    # 计数类模板
    METRIC_SET = "关联类指标"       # SET模板（集合去重计数，如：同一设备关联的登录账号个数）
    METRIC_COUNT = "次数类指标"     # COUNT模板（简单计数，如：登录次数）
    
    # 统计类模板 (STATISTICS)
    METRIC_SUM = "求和类指标"       # SUM模板（金额汇总，如：累计交易金额）
    METRIC_AVG = "平均类指标"       # AVG模板（平均值）
    METRIC_MAX = "最大类指标"       # MAX模板（最大值）
    METRIC_MIN = "最小类指标"       # MIN模板（最小值）
    
    # 历史取值类模板
    METRIC_LATEST = "历史取值类指标"  # LATEST/HISTORY_VALUE模板（如：最近一笔交易金额）
    
    # 时间类模板
    METRIC_TIME_GAP = "时间差类指标"  # TIME_GAP/TIME_DIFF模板（如：两次登录间隔）
    
    # 连续类模板
    METRIC_CONSECUTIVE = "连续类指标" # CONSECUTIVE/CONTINUOUS模板（如：连续失败次数）
    
    # 趋势类模板
    METRIC_TREND = "趋势类指标"      # TREND模板（如：金额连续递增）
    
    # 公式类模板
    METRIC_FORMULA = "公式类指标"    # FORMULA模板（自定义公式计算）
    
    # 地理位置类模板
    METRIC_GEO = "地理位置类指标"    # GEO模板（如：登录位置移动距离）
    
    # 链式类模板
    METRIC_CHAIN = "链式类指标"      # CHAIN模板（多阶段行为链，如：开户→试探→大额出账）
    
    # 非指标类型
    FIELD = "字段判断型"           # 字段
    CONSTANT = "常量型"            # 常量


@dataclass
class Operand:
    """操作数"""
    operand_type: OperandType
    value: str                          # 原始值（指标名/字段名/常量值）
    metric_name: Optional[str] = None   # 指标名称（仅METRIC类型）
    field_code: Optional[str] = None    # 字段编码（仅FIELD类型）
    constant_value: Optional[Any] = None  # 常量值（仅CONSTANT类型）


@dataclass
class Condition:
    """条件"""
    condition_id: str           # 条件编号，如"条件1"
    raw_text: str               # 原始条件文本
    left_operand: Operand       # 左侧操作数
    operator: str               # 操作符
    right_operand: Operand      # 右侧操作数
    condition_type: str         # 条件类型描述
    
    @property
    def original_text(self) -> str:
        """原始文本别名"""
        return self.raw_text


def get_all_metric_names(metrics_metadata: Dict[str, Any]) -> List[str]:
    """
    从指标元数据中提取所有指标名称
    
    Args:
        metrics_metadata: 指标元数据字典
    
    Returns:
        指标名称列表
    """
    names = []
    for metric_name, metric_def in metrics_metadata.items():
        names.append(metric_name)
        # 也添加可能的别名
        if isinstance(metric_def, dict):
            # 从metrics数组中提取
            if 'metrics' in metric_def:
                for m in metric_def['metrics']:
                    if isinstance(m, dict) and 'name' in m:
                        if m['name'] not in names:
                            names.append(m['name'])
    return names


def parse_rule_description(description: str, metric_names: List[str], metrics_metadata: Optional[Dict[str, Any]] = None, rule_name: str = "", field_metadata: Optional[Any] = None) -> Dict[str, Any]:
    """
    解析规则描述，提取条件和触发逻辑
    
    Args:
        description: 规则描述文本
        metric_names: 可用的指标名称列表
        metrics_metadata: 指标元数据字典（可选），用于判断指标模板类型
        rule_name: 规则名称（用于错误信息）
        field_metadata: 字段元数据管理器（可选），用于匹配字段名称
    
    Returns:
        解析结果，包含conditions和trigger_logic
    
    Raises:
        MetricMappingError: 当条件中使用的指标在元数据中找不到映射时
    """
    logger = get_logger()
    
    logger.debug(f"解析规则描述:\n{description}")
    
    lines = description.strip().split('\n')
    
    # ---- 预处理：合并多行条件 ----
    # 有些条件在Excel中跨行书写，例如：
    #   条件2:指标名称很长
    #   != IP归属省份
    # 需要将续行合并到前一个条件行
    merged_lines = []
    operators_prefix = ('>=', '<=', '!=', '==', '>', '<', '=')
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        # 如果当前行以操作符开头，且存在前一行，说明是续行
        if merged_lines and not re.match(r'^条件\d+[：:]', stripped) and \
           not re.match(r'^规则触发条件[：:]', stripped) and \
           any(stripped.startswith(op) for op in operators_prefix):
            # 合并到前一行
            merged_lines[-1] = merged_lines[-1] + ' ' + stripped
        else:
            merged_lines.append(stripped)
    
    conditions = []
    trigger_logic = ""
    
    for line in merged_lines:
        line = line.strip()
        if not line:
            continue
        
        # 匹配条件行：条件N：xxx
        condition_match = re.match(r'^条件(\d+)[：:]\s*(.+)$', line)
        if condition_match:
            condition_id = f"条件{condition_match.group(1)}"
            condition_text = condition_match.group(2).strip()
            
            # 提取条件操作数
            operand_info = extract_condition_operands(condition_text, metric_names, metrics_metadata, field_metadata)
            
            # 检查左操作数是否为指标但找不到映射
            left_operand = operand_info['left_operand']
            if left_operand.operand_type in [OperandType.METRIC, OperandType.METRIC_SET, 
                                              OperandType.METRIC_COUNT, OperandType.METRIC_SUM,
                                              OperandType.METRIC_AVG, OperandType.METRIC_MAX,
                                              OperandType.METRIC_MIN, OperandType.METRIC_LATEST,
                                              OperandType.METRIC_TIME_GAP, OperandType.METRIC_CONSECUTIVE,
                                              OperandType.METRIC_TREND, OperandType.METRIC_FORMULA,
                                              OperandType.METRIC_GEO, OperandType.METRIC_CHAIN]:
                # 指标类型，检查是否在 metric_names 中
                metric_name = left_operand.metric_name or left_operand.value
                if metric_name and metric_name not in metric_names:
                    logger.error(f"规则 '{rule_name}' 的条件 '{condition_id}' 使用未定义的指标: '{metric_name}'")
                    raise MetricMappingError(metric_name, rule_name)
            
            condition = Condition(
                condition_id=condition_id,
                raw_text=condition_text,
                left_operand=operand_info['left_operand'],
                operator=operand_info['operator'],
                right_operand=operand_info['right_operand'],
                condition_type=operand_info['condition_type']
            )
            conditions.append(condition)
            continue
        
        # 匹配触发逻辑行
        trigger_match = re.match(r'^规则触发条件[：:]\s*(.+)$', line)
        if trigger_match:
            trigger_logic = trigger_match.group(1).strip()
            continue
    
    # 如果没有找到触发逻辑，默认所有条件AND
    if not trigger_logic and conditions:
        condition_ids = [c.condition_id for c in conditions]
        trigger_logic = " and ".join(condition_ids)
    
    result = {
        'conditions': conditions,
        'trigger_logic': trigger_logic,
        'condition_count': len(conditions)
    }
    
    logger.debug(f"解析结果: {len(conditions)} 个条件, 触发逻辑: {trigger_logic}")
    
    return result


def extract_condition_operands(condition_text: str, metric_names: List[str], metrics_metadata: Optional[Dict[str, Any]] = None, field_metadata: Optional[Any] = None) -> Dict[str, Any]:
    """
    提取条件的操作数
    
    Args:
        condition_text: 条件文本，如"注册_24小时内...>=5"
        metric_names: 可用的指标名称列表
        metrics_metadata: 指标元数据字典（可选）
        field_metadata: 字段元数据管理器（可选），用于匹配字段名称
    
    Returns:
        操作数信息
    """
    # 支持的操作符（按长度降序排列，优先匹配长的）
    operators = ['>=', '<=', '!=', '==', '>', '<', '=']
    
    operator = None
    left_text = ""
    right_text = ""
    
    # 查找操作符
    for op in operators:
        if op in condition_text:
            parts = condition_text.split(op, 1)
            if len(parts) == 2:
                left_text = parts[0].strip()
                right_text = parts[1].strip()
                operator = op
                break
    
    if not operator:
        # 没有找到操作符，整个作为左操作数
        left_text = condition_text
        operator = "=="
        right_text = "true"
    
    # 判断操作数类型
    left_operand = identify_operand(left_text, metric_names, metrics_metadata, field_metadata)
    right_operand = identify_operand(right_text, metric_names, metrics_metadata, field_metadata)
    
    # 确定条件类型
    condition_type = determine_condition_type(left_operand, right_operand)
    
    return {
        'left_operand': left_operand,
        'operator': operator,
        'right_operand': right_operand,
        'condition_type': condition_type
    }


def identify_operand(text: str, metric_names: List[str], metrics_metadata: Optional[Dict[str, Any]] = None, field_metadata: Optional[Any] = None) -> Operand:
    """
    识别操作数类型
    
    Args:
        text: 操作数文本
        metric_names: 指标名称列表
        metrics_metadata: 指标元数据字典（可选），用于判断指标模板类型
        field_metadata: 字段元数据管理器（可选），用于匹配字段名称
    
    Returns:
        Operand对象
    """
    text = text.strip()
    
    # 检查是否是指标名称
    for metric_name in metric_names:
        if metric_name in text or text in metric_name:
            # 尝试精确匹配或部分匹配
            if text == metric_name or metric_name.startswith(text) or text.startswith(metric_name):
                # 根据templateCode确定指标类型
                operand_type = OperandType.METRIC  # 默认类型
                if metrics_metadata and metric_name in metrics_metadata:
                    metric_def = metrics_metadata[metric_name]
                    template_code = metric_def.get('templateCode', '')
                    
                    # 计数类模板
                    if template_code == 'SET':
                        operand_type = OperandType.METRIC_SET
                    elif template_code == 'COUNT':
                        operand_type = OperandType.METRIC_COUNT
                    
                    # 统计类模板 (STATISTICS模板根据calcMethod进一步区分)
                    elif template_code == 'STATISTICS':
                        calc_method = metric_def.get('templateConfig', {}).get('calcMethod', 'SUM')
                        if calc_method == 'SUM':
                            operand_type = OperandType.METRIC_SUM
                        elif calc_method == 'AVG':
                            operand_type = OperandType.METRIC_AVG
                        elif calc_method == 'MAX':
                            operand_type = OperandType.METRIC_MAX
                        elif calc_method == 'MIN':
                            operand_type = OperandType.METRIC_MIN
                        else:
                            operand_type = OperandType.METRIC_SUM  # 默认求和
                    elif template_code == 'SUM':
                        operand_type = OperandType.METRIC_SUM
                    
                    # 历史取值类模板
                    elif template_code in ('LATEST', 'HISTORY_VALUE'):
                        operand_type = OperandType.METRIC_LATEST
                    
                    # 时间类模板
                    elif template_code in ('TIME_GAP', 'TIME_DIFF'):
                        operand_type = OperandType.METRIC_TIME_GAP
                    
                    # 连续类模板
                    elif template_code in ('CONSECUTIVE', 'CONTINUOUS'):
                        operand_type = OperandType.METRIC_CONSECUTIVE
                    
                    # 趋势类模板
                    elif template_code == 'TREND':
                        operand_type = OperandType.METRIC_TREND
                    
                    # 公式类模板
                    elif template_code == 'FORMULA':
                        operand_type = OperandType.METRIC_FORMULA
                    
                    # 地理位置类模板
                    elif template_code == 'GEO':
                        operand_type = OperandType.METRIC_GEO
                    
                    # 链式类模板
                    elif template_code == 'CHAIN':
                        operand_type = OperandType.METRIC_CHAIN
                
                return Operand(
                    operand_type=operand_type,
                    value=text,
                    metric_name=metric_name
                )
    
    # 检查是否是数字常量
    try:
        if '.' in text:
            constant_value = float(text)
        else:
            constant_value = int(text)
        return Operand(
            operand_type=OperandType.CONSTANT,
            value=text,
            constant_value=constant_value
        )
    except ValueError:
        pass
    
    # 检查是否是字符串常量（带引号）
    if (text.startswith('"') and text.endswith('"')) or \
       (text.startswith("'") and text.endswith("'")):
        return Operand(
            operand_type=OperandType.CONSTANT,
            value=text,
            constant_value=text[1:-1]
        )
    
    # 检查是否能通过字段元数据匹配（支持含空格的字段名如 'IP Address'）
    if field_metadata:
        try:
            field_def = field_metadata.get_field_by_display_name(text)
            if field_def:
                return Operand(
                    operand_type=OperandType.FIELD,
                    value=text,
                    field_code=field_def.get('displayName', text)
                )
        except Exception:
            pass
        # field_metadata 已加载但未匹配到字段 → 视为字符串常量
        # （如 "Accept"、"CAA" 等枚举值不应被误判为字段）
        return Operand(
            operand_type=OperandType.CONSTANT,
            value=text,
            constant_value=text
        )
    
    # field_metadata 不可用时的兜底：用正则猜测是否为字段名
    if re.match(r'^[\u4e00-\u9fa5_A-Za-z][\u4e00-\u9fa5_A-Za-z0-9]*$', text):
        return Operand(
            operand_type=OperandType.FIELD,
            value=text,
            field_code=text  # 后续需要映射到实际字段编码
        )
    
    # 默认作为常量
    return Operand(
        operand_type=OperandType.CONSTANT,
        value=text,
        constant_value=text
    )


def determine_condition_type(left: Operand, right: Operand) -> str:
    """
    确定条件类型
    
    Args:
        left: 左操作数
        right: 右操作数
    
    Returns:
        条件类型描述
    """
    # 定义所有指标类型集合
    ALL_METRIC_TYPES = (
        OperandType.METRIC, OperandType.METRIC_SET, OperandType.METRIC_COUNT,
        OperandType.METRIC_SUM, OperandType.METRIC_AVG, OperandType.METRIC_MAX, OperandType.METRIC_MIN,
        OperandType.METRIC_LATEST, OperandType.METRIC_TIME_GAP, OperandType.METRIC_CONSECUTIVE,
        OperandType.METRIC_TREND, OperandType.METRIC_FORMULA, OperandType.METRIC_GEO, OperandType.METRIC_CHAIN
    )
    
    # 检查操作数是否是指标类型
    is_left_metric = left.operand_type in ALL_METRIC_TYPES
    is_right_metric = right.operand_type in ALL_METRIC_TYPES
    
    if is_left_metric:
        if is_right_metric:
            return "双指标型"
        elif right.operand_type == OperandType.CONSTANT:
            # 根据左操作数的具体类型返回更精确的描述
            type_mapping = {
                OperandType.METRIC_SET: "关联类指标型",
                OperandType.METRIC_COUNT: "次数类指标型",
                OperandType.METRIC_SUM: "求和类指标型",
                OperandType.METRIC_AVG: "平均类指标型",
                OperandType.METRIC_MAX: "最大类指标型",
                OperandType.METRIC_MIN: "最小类指标型",
                OperandType.METRIC_LATEST: "历史取值类指标型",
                OperandType.METRIC_TIME_GAP: "时间差类指标型",
                OperandType.METRIC_CONSECUTIVE: "连续类指标型",
                OperandType.METRIC_TREND: "趋势类指标型",
                OperandType.METRIC_FORMULA: "公式类指标型",
                OperandType.METRIC_GEO: "地理位置类指标型",
                OperandType.METRIC_CHAIN: "链式类指标型",
                OperandType.METRIC: "聚合指标型",
            }
            return type_mapping.get(left.operand_type, "聚合指标型")
        else:
            return "混合型"
    elif left.operand_type == OperandType.FIELD:
        if right.operand_type == OperandType.FIELD:
            return "双字段型"
        elif right.operand_type == OperandType.CONSTANT:
            return "字段判断型"
        else:
            return "混合型"
    else:
        return "常量型"


def conditions_to_dict(conditions: List[Condition]) -> List[Dict[str, Any]]:
    """将条件对象列表转换为字典列表"""
    result = []
    for cond in conditions:
        result.append({
            'condition_id': cond.condition_id,
            'raw_text': cond.raw_text,
            'left_operand': {
                'type': cond.left_operand.operand_type.value,
                'value': cond.left_operand.value,
                'metric_name': cond.left_operand.metric_name,
                'field_code': cond.left_operand.field_code,
                'constant_value': cond.left_operand.constant_value
            },
            'operator': cond.operator,
            'right_operand': {
                'type': cond.right_operand.operand_type.value,
                'value': cond.right_operand.value,
                'metric_name': cond.right_operand.metric_name,
                'field_code': cond.right_operand.field_code,
                'constant_value': cond.right_operand.constant_value
            },
            'condition_type': cond.condition_type
        })
    return result


if __name__ == "__main__":
    # 测试规则解析
    test_description = """条件1：注册_24小时内同一设备ID关联注册成功登录账号个数>=5
条件2：注册_60分钟内同一设备ID关联注册成功登录账号个数>=3
规则触发条件：条件1 or 条件2"""

    test_metrics = [
        "注册_24小时内同一设备ID关联注册成功登录账号个数",
        "注册_60分钟内同一设备ID关联注册成功登录账号个数"
    ]
    
    # 测试用指标元数据（模拟SET模板）
    test_metrics_metadata = {
        "注册_24小时内同一设备ID关联注册成功登录账号个数": {
            "templateCode": "SET",
            "metricName": "注册_24小时内同一设备ID关联注册成功登录账号个数"
        },
        "注册_60分钟内同一设备ID关联注册成功登录账号个数": {
            "templateCode": "SET", 
            "metricName": "注册_60分钟内同一设备ID关联注册成功登录账号个数"
        }
    }
    
    print("=" * 60)
    print("规则解析测试")
    print("=" * 60)
    
    print(f"\n规则描述:\n{test_description}")
    print(f"\n可用指标: {test_metrics}")
    
    # 测试1: 不传metrics_metadata（默认行为）
    print("\n" + "-" * 60)
    print("测试1: 不传指标元数据（默认类型）")
    print("-" * 60)
    result = parse_rule_description(test_description, test_metrics)
    
    print(f"\n解析结果:")
    print(f"  条件数量: {result['condition_count']}")
    print(f"  触发逻辑: {result['trigger_logic']}")
    
    print(f"\n条件详情:")
    for cond in result['conditions']:
        print(f"  {cond.condition_id}: {cond.raw_text}")
        print(f"    左操作数: {cond.left_operand.operand_type.value} - {cond.left_operand.value}")
        print(f"    操作符: {cond.operator}")
        print(f"    右操作数: {cond.right_operand.operand_type.value} - {cond.right_operand.value}")
        print(f"    条件类型: {cond.condition_type}")
    
    # 测试2: 传入metrics_metadata（识别SET模板）
    print("\n" + "-" * 60)
    print("测试2: 传入指标元数据（识别SET模板为关联类指标）")
    print("-" * 60)
    result = parse_rule_description(test_description, test_metrics, test_metrics_metadata)
    
    print(f"\n解析结果:")
    print(f"  条件数量: {result['condition_count']}")
    print(f"  触发逻辑: {result['trigger_logic']}")
    
    print(f"\n条件详情:")
    for cond in result['conditions']:
        print(f"  {cond.condition_id}: {cond.raw_text}")
        print(f"    左操作数: {cond.left_operand.operand_type.value} - {cond.left_operand.value}")
        print(f"    操作符: {cond.operator}")
        print(f"    右操作数: {cond.right_operand.operand_type.value} - {cond.right_operand.value}")
        print(f"    条件类型: {cond.condition_type}")
