# auto_test 项目归档（整理版）

> 整理日期：2026-08-11
> 来源：`~/Downloads/归档/auto_test`、`~/Downloads/归档/auto_test_v2`

## 归档说明

本归档是"风控规则测试用例生成器"项目的代码精简版，去除了冗余副本、运行环境、缓存、日志和大批量数据产物，仅保留可直接运行的核心代码与必要元数据。

项目演进脉络：

- **v1（2026-01 ~ 03）**：规则条件拆分程序。单文件 + 模块化结构，调用 DashScope 大模型将 Excel F 列规则描述拆分为结构化条件（J 列），并枚举场景（K/L 列）、直接生成测试数据（M 列）。
- **v2（2026-03-06 ~ 03-26）**：风控规则测试用例生成器 v2.0。完全模块化重构，核心思路升级为"指标累积触发"——生成有序进件序列让指标自然累积命中，支持 Salaxy 10 种指标模板、指标依赖分析、场景条件本地预校验、fieldCondition 约束，并带验证器回验平台响应。此版本后来演进为 risk-rule-testcase 系列 skill。

## 目录结构

```
auto_test_archive/
├── README.md                      # 本说明
├── v1_规则条件拆分工具/            # v1 完整核心代码
│   ├── rule_condition_extractor.py    # 主程序（2499 行单文件入口）
│   ├── main.py                        # 模块化入口
│   ├── core/ config/ data/ file_io/ io/ llm/ utils/   # 功能模块
│   ├── 参数字典.xlsx                   # 运行必需：参数中英文映射字典
│   ├── README.md / 启动命令与参数说明.md / requirements.txt
└── v2_测试用例生成器/              # v2 最新版（2026-03-26）
    ├── main.py                        # CLI 入口
    ├── loaders/ analyzers/ llm/ generators/ validators/ templates/ utils/ config/
    ├── base_info/                     # 运行必需元数据（common 通用 + RCBC 客户两套）
    ├── .env.example                   # 环境变量模板（不含真实密钥）
    ├── .changelog/ CHANGELOG.md / CLAUDE.md / README.md
    ├── 单一测试用例.xlsx / 复合测试用例.xlsx   # 示例输入
    └── requirements.txt
```

## 已剔除内容

| 类别 | 内容 | 原因 |
|---|---|---|
| 冗余副本 | `auto_test_v2_副本`、`auto_test_v2_20260313`（auto_test 内的两份旧 v2） | 与最新 v2 同源，仅保留 3-26 最新版 |
| 空壳目录 | `~/Downloads/归档/auto_test_v2`（外层） | 仅含 1 个早期元数据文件，无代码 |
| 环境与缓存 | `.venv/`、`__pycache__/`、`*.pyc`、`.DS_Store` | 可重建 |
| 运行产物 | `logs/`、`output/`（38 个 JSON）、`validation_reports/` | 历史运行输出 |
| 数据产物 | 测试用例需求_分页系列、指标汇总、bifrost 系统字段导出、资产环境测试用例等 Excel/CSV | 按"代码精简版"范围排除 |
| 敏感文件 | `.env`（含 API 密钥）、`dashscope_config.json`（含 api_key） | 安全考虑，密钥不随归档分发 |
| 其他 | 周报文档、`.qoder/`、Office 锁文件 `.~*` | 非代码资产 |

## 恢复运行

两个子项目均按各自 README 运行，通用步骤：

1. `python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`
2. v1：准备 `dashscope_config.json`（`{"api_key": "..."}`）或设置环境变量 `DASHSCOPE_API_KEY`，然后 `python rule_condition_extractor.py -i 输入.xlsx`
3. v2：复制 `.env.example` 为 `.env` 并填入 `DASHSCOPE_API_KEY` / `LLM_MODEL` / `LLM_BASE_URL`，然后 `python main.py --input 规则文件.xlsx --output ./output`
