# -*- coding: utf-8 -*-
"""
测试数据约束处理器模块

根据K列中的"测试数据生成约束"应用各种约束规则。
每个约束函数对应K列中的一个"Python规则标识"。
"""

import re
import random
from typing import Any, Dict


class DataConstraintHandler:
    """测试数据约束处理器"""

    @staticmethod
    def apply_param_constraint(
        param_name: str, base_value: Any, constraint: Dict
    ) -> Any:
        """应用参数值约束

        Args:
            param_name: 参数名称
            base_value: 基础值（未应用约束前的值）
            constraint: 约束字典，包含"Python规则"等字段

        Returns:
            应用约束后的值
        """
        if not constraint:
            return base_value

        # 优先处理IP归属地约束：根据约束规则生成合适的值
        if "IP 归属" in param_name or "IP归属" in param_name:
            # 处理IP归属地约束
            constraint_rule = constraint.get("约束规则", "")

            # 处理"不等于"约束（如："IP归属国家不等于菲律宾"）
            if "不等于" in constraint_rule or "!=" in constraint_rule:
                # 提取排除值
                match = re.search(r'不等于\s*[「"\']?([^」"\'\s]+)[」"\']?', constraint_rule)
                if not match:
                    match = re.search(r'!=\s*[「"\']?([^」"\'\s]+)[」"\']?', constraint_rule)

                if match:
                    excluded_value = match.group(1).strip()
                    # 根据参数类型选择备选值集合
                    if "国家" in param_name:
                        candidates = [
                            "中国",
                            "美国",
                            "英国",
                            "日本",
                            "新加坡",
                            "泰国",
                            "越南",
                            "马来西亚",
                            "印度尼西亚",
                        ]
                    elif "省份" in param_name:
                        candidates = [
                            "北京市",
                            "上海市",
                            "广东省",
                            "浙江省",
                            "江苏省",
                            "四川省",
                            "湖北省",
                            "河南省",
                        ]
                    elif "城市" in param_name:
                        candidates = [
                            "北京市",
                            "上海市",
                            "深圳市",
                            "广州市",
                            "杭州市",
                            "南京市",
                            "成都市",
                            "武汉市",
                        ]
                    else:
                        candidates = ["中国", "美国", "英国", "日本", "新加坡"]

                    # 排除指定值
                    valid_candidates = [c for c in candidates if c != excluded_value]
                    if valid_candidates:
                        return random.choice(valid_candidates)

            # 处理"取值范围"约束
            if "取值范围" in constraint:
                value_range = constraint["取值范围"]
                if isinstance(value_range, list) and value_range:
                    return random.choice(value_range)

            # 如果没有特殊约束，返回默认值
            if "国家" in param_name:
                return random.choice(["中国", "美国", "英国", "日本", "新加坡"])
            elif "省份" in param_name:
                return random.choice(
                    ["北京市", "上海市", "广东省", "浙江省", "江苏省", "四川省"]
                )
            elif "城市" in param_name:
                return random.choice(
                    ["北京市", "上海市", "深圳市", "广州市", "杭州市", "南京市", "成都市"]
                )

            return base_value

        python_rule = constraint.get("Python规则", "")

        if python_rule == "exclude_lan_ip":
            return DataConstraintHandler.exclude_lan_ip(base_value)
        elif python_rule == "valid_id_card_number":
            return DataConstraintHandler.valid_id_card_number()
        elif python_rule == "exclude_whitelist_customers":
            return DataConstraintHandler.exclude_whitelist_customers(base_value)
        else:
            # 未知约束，返回原值
            return base_value

    @staticmethod
    def exclude_lan_ip(ip: str) -> str:
        """排除局域网IP地址

        生成一个非局域网的公网IP地址。
        排除的网段：10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 127.0.0.0/8
        """
        # 生成公网IP（简化版：避开常见局域网段）
        while True:
            # 生成随机IP
            first_octet = random.randint(1, 223)  # 避免224-255（组播/保留）

            # 排除局域网段
            if first_octet == 10:  # 10.0.0.0/8
                continue
            if first_octet == 127:  # 127.0.0.0/8
                continue
            if first_octet == 172:  # 172.16.0.0/12
                second_octet = random.randint(0, 255)
                if 16 <= second_octet <= 31:
                    continue
            if first_octet == 192:  # 192.168.0.0/16
                second_octet = random.randint(0, 255)
                if second_octet == 168:
                    continue

            # 生成剩余字节
            second_octet = random.randint(0, 255)
            third_octet = random.randint(0, 255)
            fourth_octet = random.randint(1, 254)

            return f"{first_octet}.{second_octet}.{third_octet}.{fourth_octet}"

    @staticmethod
    def valid_id_card_number() -> str:
        """生成合法18位身份证号码

        符合GB11643-1999标准，包含校验码计算。
        """
        # 生成前17位
        # 地区码：6位（使用常见省份代码）
        province_codes = [
            "110000",
            "310000",
            "440000",
            "500000",
            "330000",
        ]  # 北京、上海、广东、重庆、浙江
        area_code = random.choice(province_codes)

        # 出生日期：8位（1980-2005年）
        year = random.randint(1980, 2005)
        month = random.randint(1, 12)
        day = random.randint(1, 28)  # 简化处理，避免月份天数问题
        birth_date = f"{year:04d}{month:02d}{day:02d}"

        # 顺序码：3位
        sequence = f"{random.randint(0, 999):03d}"

        # 前17位
        id_17 = area_code + birth_date + sequence

        # 计算校验码（第18位）
        # 加权因子
        weight_factors = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
        # 校验码对照表
        check_codes = ["1", "0", "X", "9", "8", "7", "6", "5", "4", "3", "2"]

        # 计算加权和
        total = sum(int(id_17[i]) * weight_factors[i] for i in range(17))
        # 获取校验码
        check_code = check_codes[total % 11]

        return id_17 + check_code

    @staticmethod
    def exclude_whitelist_customers(customer_id: str) -> str:
        """排除白名单客户

        确保生成的客户编号不在白名单中。
        白名单包括：VIP客户、内部员工等。
        """
        # 简化处理：生成一个普通客户ID（非VIP、非员工）
        # 假设VIP以"VIP_"开头，员工以"EMP_"开头
        customer_id = f"CUST_{random.randint(100000, 999999)}"
        return customer_id

    @staticmethod
    def initial_value_zero_on_first_transaction() -> int:
        """首次交易时指标结果为0

        当规则配置为非事中模式且当前为用户第一笔交易时，
        指标值必须为0。
        """
        return 0

    @staticmethod
    def strange_device_id() -> str:
        """生成陌生设备ID

        陌生设备ID定义为：最近90天内未登录过的设备。
        简化处理：生成一个特殊标识的设备ID。
        """
        return f"STRANGE_DEV_{random.randint(100000, 999999)}"

    @staticmethod
    def balance_before_transaction(amount: float) -> float:
        """生成交易前账户余额

        账户余额应为交易前的余额，而非交易后。
        简化处理：返回一个大于交易金额的余额。
        """
        # 余额为交易金额的 1.2-3 倍
        return amount * random.uniform(1.2, 3.0)
