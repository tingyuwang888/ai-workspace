# -*- coding: utf-8 -*-
"""
测试用例数据生成模块

根据K列JSON生成测试用例数据。
"""

import re
import random
import string
import datetime
from typing import Any, Dict, List, Optional

from .constraint_handler import DataConstraintHandler

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.helpers import (
    generate_random_bizid,
    generate_device_id,
    generate_user_account,
    generate_timestamp,
    generate_id_card,
)


def generate_testcase_data_for_rule(
    k_json: Dict[str, Any],
    j_json: Dict[str, Any],
    param_cn_to_en: Dict[str, str],
) -> List[Dict[str, Any]]:
    """根据K列JSON生成测试用例数据（纯Python函数，不调用大模型）

    Args:
        k_json: K列的JSON对象（包含场景列表、公共字段规则、参数规则）
        j_json: J列的JSON对象（用于获取I列公共字段）
        param_cn_to_en: 参数中文名到英文名的映射

    Returns:
        测试用例数据列表，每个元素是一条测试数据（JSON）
    """
    testcase_data = []

    if not k_json:
        return testcase_data

    # 读取必要信息
    common_field_rules = k_json.get("公共字段生成规则", {})
    param_gen_rules = k_json.get("参数值生成规则", {})
    i_column_fields = j_json.get("I列公共字段", {})

    # 估算时间窗口（用于在时间范围内均匀分布测试数据）
    now = datetime.datetime.now()
    window_start: Optional[datetime.datetime] = None
    window_end: Optional[datetime.datetime] = None
    hour_range_start: Optional[int] = None
    hour_range_end: Optional[int] = None
    has_exclusion: bool = False
    rule_conditions = j_json.get("条件列表", [])

    for cond in rule_conditions:
        desc = str(cond.get("条件描述", ""))
        local_start: Optional[datetime.datetime] = None
        local_end: Optional[datetime.datetime] = None

        # 模式0："[H1,H2]"小时范围
        m_hour_range = re.search(r"\[(\d+),\s*(\d+)\]", desc)
        if m_hour_range:
            hour_range_start = int(m_hour_range.group(1))
            hour_range_end = int(m_hour_range.group(2))

        # 模式1："N天内剔除M天"
        m_day_excl = re.search(r"(\d+)\s*天内[^\n]*?剔除(\d+)\s*天", desc)
        if m_day_excl:
            total_days = int(m_day_excl.group(1))
            excl_days = int(m_day_excl.group(2))
            local_end = now - datetime.timedelta(days=excl_days)
            local_start = now - datetime.timedelta(days=total_days)
            has_exclusion = True
        else:
            # 模式2："N天内"
            m_day = re.search(r"(\d+)\s*天内", desc)
            if m_day:
                days = int(m_day.group(1))
                local_end = now
                local_start = now - datetime.timedelta(days=days)

        # 模式3："N小时内"
        m_hour = re.search(r"(\d+)\s*小时内", desc)
        if m_hour:
            hours = int(m_hour.group(1))
            local_end = now
            local_start = now - datetime.timedelta(hours=hours)

        # 模式4："N分钟内"
        m_min = re.search(r"(\d+)\s*分钟内", desc)
        if m_min:
            minutes = int(m_min.group(1))
            local_end = now
            local_start = now - datetime.timedelta(minutes=minutes)

        # 合并到全局时间窗口
        if local_start is not None and local_end is not None:
            if window_start is None or local_start < window_start:
                window_start = local_start
            if has_exclusion:
                if window_end is None or local_end < window_end:
                    window_end = local_end
            else:
                if window_end is None or local_end > window_end:
                    window_end = local_end

    # 当前记录使用的时间戳
    current_timestamp: Optional[str] = None

    # 支持场景列表
    scenes = k_json.get("场景列表", [])

    if not scenes:
        # 兼容旧格式：单个场景
        scene = k_json.get("场景", {})
        if scene:
            scenes = [scene]
        else:
            return testcase_data

    # 遍历所有场景生成数据
    for scene in scenes:
        scene_is_hit = scene.get("场景整体是否命中", False)
        conditions = scene.get("条件状态列表", [])

        if not conditions:
            continue

        # ---------------- 辅助函数 -----------------
        def _generate_param_value(param_cn_name: str) -> str:
            """根据参数中文名和生成规则，生成参数值"""
            # 时间参数
            if (
                param_cn_name in param_gen_rules.get("时间参数", [])
                or "时间" in param_cn_name
                or "Time" in param_cn_name
            ):
                if current_timestamp is not None:
                    return current_timestamp
                return generate_timestamp()

            # IP地址参数
            elif (
                "IP" in param_cn_name
                or "ipAddress" in param_cn_name
                or "IpAddr" in param_cn_name
            ):
                return f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"

            # 经纬度参数
            elif "经度" in param_cn_name or "longitude" in param_cn_name.lower():
                return f"{random.uniform(-180, 180):.6f}"
            elif "纬度" in param_cn_name or "latitude" in param_cn_name.lower():
                return f"{random.uniform(-90, 90):.6f}"

            # 邮箱参数
            elif "邮箱" in param_cn_name or "email" in param_cn_name.lower():
                domains = ["gmail.com", "outlook.com", "yahoo.com", "163.com", "qq.com"]
                username = "".join(
                    random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=8)
                )
                return f"{username}@{random.choice(domains)}"

            # 手机号参数
            elif (
                "手机" in param_cn_name
                or "mobile" in param_cn_name.lower()
                or "mobileNo" in param_cn_name
            ):
                prefixes = [
                    "130", "131", "132", "133", "134", "135", "136", "137", "138", "139",
                    "147", "150", "151", "152", "153", "155", "156", "157", "158", "159",
                    "166", "170", "171", "175", "176", "177", "178", "180", "181", "182",
                    "183", "184", "185", "186", "187", "188", "189", "198", "199",
                ]
                return f"{random.choice(prefixes)}{random.randint(10000000, 99999999)}"

            # 证件号码
            elif (
                "证件" in param_cn_name
                or "身份证" in param_cn_name
                or "idNo" in param_cn_name
                or "IdNo" in param_cn_name
            ):
                return generate_id_card()

            # ID参数
            elif (
                param_cn_name in param_gen_rules.get("ID参数", [])
                or "ID" in param_cn_name
                or "No" in param_cn_name
            ):
                if "设备" in param_cn_name or "blackBox" in param_cn_name:
                    return generate_device_id()
                elif "用户" in param_cn_name or "cust" in param_cn_name.lower():
                    return f"UID_{random.randint(100000, 999999)}"
                else:
                    return f"ID_{random.randint(100000, 999999)}"

            # 账号参数
            elif (
                param_cn_name in param_gen_rules.get("账号参数", [])
                or "账号" in param_cn_name
                or "account" in param_cn_name.lower()
            ):
                return generate_user_account()

            # 银行卡号
            elif (
                "银行卡" in param_cn_name
                or "卡号" in param_cn_name
                or "cardNo" in param_cn_name
                or "CardNo" in param_cn_name
            ):
                return f"6222{random.randint(1000000000000000, 9999999999999999)}"

            # 金额参数
            elif (
                "金额" in param_cn_name
                or "额度" in param_cn_name
                or "amount" in param_cn_name.lower()
                or "balance" in param_cn_name.lower()
            ):
                return str(random.randint(1000, 100000))

            # 年龄参数
            elif "年龄" in param_cn_name or "age" in param_cn_name.lower():
                return str(random.randint(18, 65))

            # 国家/城市/地区代码
            elif "country" in param_cn_name.lower() or "国家" in param_cn_name:
                countries = ["CN", "US", "JP", "UK", "SG", "PH", "TH", "VN"]
                return random.choice(countries)
            elif "city" in param_cn_name.lower() or "城市" in param_cn_name:
                cities = ["Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Hangzhou"]
                return random.choice(cities)

            # 货币代码
            elif "currency" in param_cn_name.lower() or "货币" in param_cn_name:
                currencies = ["CNY", "USD", "EUR", "JPY", "GBP", "SGD", "PHP"]
                return random.choice(currencies)

            # 交易状态
            elif "status" in param_cn_name.lower() or "状态" in param_cn_name:
                statuses = ["SUCCESS", "FAILED", "PENDING", "PROCESSING"]
                return random.choice(statuses)

            # 交易类型
            elif "type" in param_cn_name.lower() or "类型" in param_cn_name:
                types = ["PURCHASE", "WITHDRAWAL", "TRANSFER", "DEPOSIT"]
                return random.choice(types)

            # 姓名参数
            elif "name" in param_cn_name.lower() or "姓名" in param_cn_name:
                first_names = [
                    "John", "Mary", "David", "Lisa", "Michael", "Sarah",
                    "Wang", "Li", "Zhang",
                ]
                last_names = [
                    "Smith", "Johnson", "Williams", "Brown", "Jones",
                    "Wei", "Fang", "Chen",
                ]
                return f"{random.choice(first_names)} {random.choice(last_names)}"

            # 默认：随机字符串
            else:
                return f"VALUE_{random.randint(1000, 9999)}"

        def _generate_common_fields(scene_is_hit: bool) -> Dict[str, Any]:
            """生成公共字段"""
            result = {}

            # 遍历所有公共字段规则，根据规则类型生成字段
            for field_key, field_rule in common_field_rules.items():
                if field_key == "其他字段":
                    if field_rule.get("规则类型") == "I列固定值":
                        for key, value in i_column_fields.items():
                            if key not in result:
                                result[key] = value
                    continue

                rule_type = field_rule.get("规则类型")

                if rule_type == "场景相关":
                    if scene_is_hit:
                        result[field_key] = field_rule.get("命中值", "")
                    else:
                        result[field_key] = field_rule.get("未命中值", "")
                elif rule_type == "随机生成":
                    result[field_key] = generate_random_bizid()
                elif rule_type == "固定值":
                    result[field_key] = field_rule.get("值", "")

            return result

        # 根据条件生成数据
        max_count = 0
        for cond in conditions:
            indicator_rules = cond.get("指标值规则", {})
            indicator_type = indicator_rules.get("指标类型", "")

            if indicator_type in ["次数/条数", "次数", "条数"]:
                count_rule = indicator_rules.get("条数规则", {})
                total_count = count_rule.get("生成总条数", 0)
            elif indicator_type in ["金额", "比例", "时间"]:
                total_count = random.randint(5, 10)
            else:
                total_count = 5

            if total_count > max_count:
                max_count = total_count

        if max_count == 0:
            max_count = 3

        # 生成共享设备ID
        shared_device_id = generate_device_id()

        # 计算时间窗口
        current_now = datetime.datetime.now()

        if window_start is None or window_end is None or window_end <= window_start:
            final_window_end = current_now
            final_window_start = current_now - datetime.timedelta(minutes=60)
        else:
            final_window_start = window_start
            final_window_end = window_end

        window_delta = final_window_end - final_window_start

        # 遍历条件生成数据
        for cond in conditions:
            cond_param_list_cn = cond.get("参与统计的参数列表", [])
            if not cond_param_list_cn:
                continue

            test_constraint = cond.get("测试数据生成约束", {})
            param_constraints = test_constraint.get("参数值约束", {})

            cond_desc = cond.get("条件描述", "") or cond.get("场景命中含义", "")

            shared_values = {}

            # 识别"同一XXX"模式
            same_pattern = re.findall(
                r"同一([\u4e00-\u9fa5A-Za-z0-9]+?)(?:在|和|、|，|,|交易|登录|的|成功)",
                cond_desc,
            )
            for param_hint in same_pattern:
                param_hint = param_hint.strip()

                if param_hint == "IP" or param_hint == "IP地址":
                    if "IP Address" not in shared_values:
                        shared_values["IP Address"] = (
                            f"{random.randint(1, 223)}.{random.randint(0, 255)}."
                            f"{random.randint(0, 255)}.{random.randint(1, 254)}"
                        )
                    continue

                for param_cn in cond_param_list_cn:
                    param_hint_no_space = param_hint.replace(" ", "")
                    param_cn_no_space = param_cn.replace(" ", "")

                    if (
                        param_hint_no_space in param_cn_no_space
                        or param_cn_no_space in param_hint_no_space
                    ):
                        if param_cn not in shared_values:
                            if "客户" in param_cn or "cust" in param_cn.lower():
                                shared_values[param_cn] = f"CUST_{random.randint(100000, 999999)}"
                            elif "IP 归属城市" in param_cn or "IP归属城市" in param_cn:
                                cities = ["北京市", "上海市", "深圳市", "广州市", "杭州市", "南京市", "成都市"]
                                shared_values[param_cn] = random.choice(cities)
                            elif "IP 归属国家" in param_cn or "IP归属国家" in param_cn:
                                countries = ["中国", "美国", "英国", "日本", "新加坡"]
                                shared_values[param_cn] = random.choice(countries)
                            elif "IP 归属省份" in param_cn or "IP归属省份" in param_cn:
                                provinces = ["北京市", "上海市", "广东省", "浙江省", "江苏省", "四川省"]
                                shared_values[param_cn] = random.choice(provinces)
                            elif "设备" in param_cn or "device" in param_cn.lower():
                                shared_values[param_cn] = shared_device_id
                            elif "账户" in param_cn or "account" in param_cn.lower():
                                shared_values[param_cn] = f"ACC_{random.randint(100000, 999999)}"

            # 补充 IP Address 参数
            has_ip_location = any(
                "IP 归属国家" in p or "IP归属国家" in p
                or "IP 归属省份" in p or "IP归属省份" in p
                or "IP 归属城市" in p or "IP归属城市" in p
                for p in cond_param_list_cn
            )
            param_list_cn = list(cond_param_list_cn)
            if has_ip_location and "IP Address" not in param_list_cn:
                param_list_cn.insert(0, "IP Address")

            # 计算条件的数据条数
            indicator_rules = cond.get("指标值规则", {})
            indicator_type = indicator_rules.get("指标类型", "")

            if indicator_type in ["次数/条数", "次数", "条数"]:
                count_rule = indicator_rules.get("条数规则", {})
                cond_count = count_rule.get("生成总条数", 0)
            elif indicator_type == "金额":
                cond_count = random.randint(5, 10)
            else:
                cond_count = random.randint(2, 3)

            if cond_count == 0:
                cond_count = random.randint(2, 3)

            # 生成时间点
            if cond_count == 1:
                cond_time_points = [final_window_start + window_delta / 2]
            else:
                step = window_delta / cond_count
                cond_time_points = [
                    final_window_start + step * (i + 0.5) for i in range(cond_count)
                ]

            if hour_range_start is not None and hour_range_end is not None:
                adjusted_cond_time_points = []
                for tp in cond_time_points:
                    target_hour = random.randint(hour_range_start, hour_range_end)
                    adjusted_tp = tp.replace(hour=target_hour)
                    adjusted_cond_time_points.append(adjusted_tp)
                cond_time_points = adjusted_cond_time_points

            cond_time_points_str = [
                tp.strftime("%Y-%m-%d %H:%M:%S") for tp in cond_time_points
            ]

            # 生成数据记录
            for i in range(cond_count):
                record = {}
                current_timestamp = cond_time_points_str[i]

                # 生成公共字段
                common_fields = _generate_common_fields(scene_is_hit)
                record.update(common_fields)

                # 生成参数字段
                param_fields = {}

                for param_cn in param_list_cn:
                    param_en = param_cn_to_en.get(param_cn, "")
                    if not param_en:
                        param_en = f"UNKNOWN_{param_cn}"

                    if param_en in record:
                        continue

                    if param_cn in shared_values:
                        param_fields[param_en] = shared_values[param_cn]
                    elif (
                        (param_cn == "IP Address" or ("IP" in param_cn and "归属" not in param_cn))
                        and "IP Address" in shared_values
                    ):
                        param_fields[param_en] = shared_values["IP Address"]
                    elif "设备ID" in param_cn:
                        param_fields[param_en] = shared_device_id
                    elif "IP Address" == param_cn or ("IP" in param_cn and "归属" not in param_cn):
                        ip = (
                            f"{random.randint(1, 223)}.{random.randint(0, 255)}."
                            f"{random.randint(0, 255)}.{random.randint(1, 254)}"
                        )
                        base_value = ip
                        constraint = param_constraints.get(param_cn)
                        if constraint:
                            param_fields[param_en] = DataConstraintHandler.apply_param_constraint(
                                param_cn, base_value, constraint
                            )
                        else:
                            param_fields[param_en] = base_value
                    elif "IP 归属国家" in param_cn or "IP归属国家" in param_cn:
                        constraint = param_constraints.get(param_cn)
                        if constraint and "约束规则" in constraint:
                            location_value = DataConstraintHandler.apply_param_constraint(
                                param_cn, None, constraint
                            )
                            param_fields[param_en] = location_value
                        else:
                            countries = ["中国", "美国", "英国", "日本", "新加坡"]
                            param_fields[param_en] = random.choice(countries)
                    elif "IP 归属省份" in param_cn or "IP归属省份" in param_cn:
                        constraint = param_constraints.get(param_cn)
                        if constraint and "约束规则" in constraint:
                            location_value = DataConstraintHandler.apply_param_constraint(
                                param_cn, None, constraint
                            )
                            param_fields[param_en] = location_value
                        else:
                            provinces = ["北京市", "上海市", "广东省", "浙江省", "江苏省", "四川省"]
                            param_fields[param_en] = random.choice(provinces)
                    elif "IP 归属城市" in param_cn or "IP归属城市" in param_cn:
                        constraint = param_constraints.get(param_cn)
                        if constraint and "约束规则" in constraint:
                            location_value = DataConstraintHandler.apply_param_constraint(
                                param_cn, None, constraint
                            )
                            param_fields[param_en] = location_value
                        else:
                            cities = ["北京市", "上海市", "深圳市", "广州市", "杭州市", "南京市", "成都市"]
                            param_fields[param_en] = random.choice(cities)
                    else:
                        base_value = _generate_param_value(param_cn)
                        constraint = param_constraints.get(param_cn)
                        if constraint:
                            param_fields[param_en] = DataConstraintHandler.apply_param_constraint(
                                param_cn, base_value, constraint
                            )
                        else:
                            param_fields[param_en] = base_value

                record.update(param_fields)
                testcase_data.append(record)

    return testcase_data
