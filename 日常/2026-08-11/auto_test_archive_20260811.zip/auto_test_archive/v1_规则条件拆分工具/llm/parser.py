# -*- coding: utf-8 -*-
"""
JSON 响应解析模块

负责解析大模型返回的 JSON 响应。
"""

import re
import json
from typing import Any, Dict, Optional


def parse_json_response(text: str) -> Optional[Dict[str, Any]]:
    """解析大模型返回的文本，提取 JSON 对象

    支持直接 JSON 和 markdown 代码块中的 JSON。

    Args:
        text: 大模型返回的原始文本

    Returns:
        解析后的 JSON 对象，解析失败返回 None
    """
    if not text:
        return None

    # 尝试直接解析 JSON
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
    except json.JSONDecodeError:
        pass

    # 尝试从 markdown 代码块中提取 JSON（常见格式：```json ... ```）
    json_match = re.search(r"```(?:json)?\s*\n(.*?)\n```", text, re.DOTALL)
    if json_match:
        json_str = json_match.group(1).strip()
        try:
            data = json.loads(json_str)
            if isinstance(data, dict):
                print(f"[提示] 从 markdown 代码块中成功提取 JSON")
                return data
        except json.JSONDecodeError:
            pass

    # 尝试查找第一个 { 和最后一个 } 之间的内容
    first_brace = text.find("{")
    last_brace = text.rfind("}")
    if first_brace != -1 and last_brace != -1 and last_brace > first_brace:
        json_str = text[first_brace : last_brace + 1]
        try:
            data = json.loads(json_str)
            if isinstance(data, dict):
                print(f"[提示] 从文本中提取 JSON 成功")
                return data
        except json.JSONDecodeError:
            pass

    # 解析失败
    print(f"[警告] 大模型返回内容不是合法 JSON")
    print(f"[原始返回内容] {text[:500]}...")  # 打印前500字符用于调试
    return None


def validate_condition_json(data: Dict[str, Any]) -> bool:
    """验证条件拆分 JSON 的结构是否完整

    Args:
        data: 解析后的 JSON 对象

    Returns:
        是否有效
    """
    if not data:
        return False

    if "条件列表" not in data:
        return False

    if not isinstance(data["条件列表"], list):
        return False

    if len(data["条件列表"]) == 0:
        return False

    return True


def validate_scenario_json(data: Dict[str, Any]) -> bool:
    """验证场景生成 JSON 的结构是否完整

    Args:
        data: 解析后的 JSON 对象

    Returns:
        是否有效
    """
    if not data:
        return False

    if "场景列表" not in data:
        return False

    if not isinstance(data["场景列表"], list):
        return False

    if len(data["场景列表"]) == 0:
        return False

    return True
