# -*- coding: utf-8 -*-
"""
DashScope 客户端模块

封装与 DashScope 大模型的交互。
"""

import json
from typing import Any, Dict, List, Optional

from .prompts import build_condition_split_prompt, build_scenario_generation_prompt
from .parser import parse_json_response


class DashScopeClient:
    """DashScope 大模型客户端"""

    def __init__(self, api_key: str, model: str = "qwen-plus", timeout: int = 60):
        """初始化客户端

        Args:
            api_key: DashScope API KEY
            model: 模型名称
            timeout: 请求超时时间（秒）
        """
        self.api_key = api_key
        self.model = model
        self.timeout = timeout
        self._initialized = False

    def _init_sdk(self) -> bool:
        """初始化 DashScope SDK

        Returns:
            是否初始化成功
        """
        if self._initialized:
            return True

        try:
            import dashscope

            dashscope.api_key = self.api_key
            self._initialized = True
            return True
        except Exception as e:
            print(f"[错误] 导入 dashscope SDK 失败: {e}")
            return False

    def _call_model(self, prompt: str) -> Optional[str]:
        """调用大模型

        Args:
            prompt: Prompt 文本

        Returns:
            模型返回的文本，失败返回 None
        """
        if not self._init_sdk():
            return None

        try:
            from dashscope import Generation

            response = Generation.call(
                model=self.model,
                prompt=prompt,
                result_format="message",
                timeout=self.timeout,
            )
        except Exception as e:
            print(f"[错误] DashScope 调用失败: {e}")
            return None

        out = getattr(response, "output", None)
        if not out or not hasattr(out, "choices") or not out.choices:
            print("[错误] 大模型响应格式异常，无有效内容")
            return None

        return out.choices[0].message.content

    def call_for_condition_split(
        self,
        rule_desc: str,
        metric_codes: List[str],
        param_candidates: List[str],
    ) -> Optional[Dict[str, Any]]:
        """调用大模型进行条件拆分

        Args:
            rule_desc: F 列规则描述
            metric_codes: G 列指标标识列表
            param_candidates: H 列参数候选列表

        Returns:
            条件拆分 JSON，失败返回 None
        """
        if not rule_desc or not metric_codes:
            return None

        prompt = build_condition_split_prompt(rule_desc, metric_codes, param_candidates)
        text = self._call_model(prompt)

        if text is None:
            return None

        return parse_json_response(text)

    def call_for_scenario_generation(
        self,
        rule_json: Dict[str, Any],
        param_cn_to_en: Dict[str, str],
    ) -> Optional[Dict[str, Any]]:
        """调用大模型生成场景

        Args:
            rule_json: J 列条件拆分 JSON
            param_cn_to_en: 参数中文名到英文名的映射

        Returns:
            场景生成 JSON，失败返回 None
        """
        if not rule_json:
            return None

        rule_json_text = json.dumps(rule_json, ensure_ascii=False, indent=2)

        # 提取条件数量
        cond_list = rule_json.get("条件列表", [])
        cond_count = len(cond_list)

        # 构建参数字典预览
        if param_cn_to_en:
            items_preview = []
            for idx, (cn, en) in enumerate(param_cn_to_en.items()):
                if idx >= 30:
                    break
                en_display = en or "(D列为空，业务入参字段未配置)"
                items_preview.append(f"- {cn} -> {en_display}")
            param_dict_text = "\n".join(items_preview)
        else:
            param_dict_text = "(无参数字典)"

        prompt = build_scenario_generation_prompt(
            rule_json_text, cond_count, param_dict_text
        )
        text = self._call_model(prompt)

        if text is None:
            return None

        return parse_json_response(text)
