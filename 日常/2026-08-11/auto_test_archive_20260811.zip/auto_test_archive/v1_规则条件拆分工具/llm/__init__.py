# -*- coding: utf-8 -*-
"""LLM 模块 - DashScope 大模型调用"""
from .client import DashScopeClient
from .parser import parse_json_response

__all__ = [
    "DashScopeClient",
    "parse_json_response",
]
