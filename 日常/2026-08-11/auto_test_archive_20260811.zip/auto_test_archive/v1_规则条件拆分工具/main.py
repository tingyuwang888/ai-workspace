#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
规则条件拆分程序

功能：
- 基于现有项目的经验（DashScope 调用、Excel 行处理、参数/指标一一对应）
- 对测试用例需求 Excel 中的 F 列规则描述进行条件拆分
- 拆分结果写入 J 列（JSON 格式），帮助后续模型更好理解每条规则

核心能力：
- 读取 F 列规则描述 + G 列指标标识
- 通过大模型把 F 列拆分成若干条件，条件数量 == 指标标识数量
- 为每个条件标注：条件描述、与上一个条件的关系（且/或）、是否存在括号嵌套
- 抽取并整理"注释说明库"（名词解释、场景限定、其他说明）
"""

import os
import json
import copy
import argparse
from typing import Any, Dict, List, Optional, Tuple

from openpyxl import load_workbook

from config import get_config, load_dashscope_config
from file_io import (
    load_param_dict,
    get_merged_cell_value,
    parse_param_candidates,
    safe_save_workbook,
    merge_h_i_by_column_c,
)
from file_io.excel_reader import unmerge_and_fill_cells
from file_io.excel_writer import setup_output_headers, save_output_record
from llm import DashScopeClient
from core import (
    estimate_condition_count,
    generate_metric_identifiers,
    generate_fallback_k_json,
    generate_scene_application_name,
    compute_scene_results,
)
from data import generate_testcase_data_for_rule


def process_single_sheet(
    ws,
    wb,
    output_path: str,
    llm_client: DashScopeClient,
    param_cn_to_en: Dict[str, str],
    sheet_name: str,
) -> Tuple[int, int, List]:
    """处理单个sheet页的规则文件。

    Args:
        ws: openpyxl worksheet对象
        wb: openpyxl workbook对象（用于保存）
        output_path: 输出文件路径
        llm_client: DashScope 客户端
        param_cn_to_en: 参数中文名到英文名的映射
        sheet_name: sheet页名称（用于日志输出）

    Returns:
        tuple: (处理成功数, 跳过数, 失败行列表)
    """
    print(f"\n{'='*60}")
    print(f"正在处理 Sheet: {sheet_name}")
    print(f"{'='*60}")

    # 解除合并单元格并填充值
    unmerge_and_fill_cells(ws)

    # 设置输出列表头
    setup_output_headers(ws)

    max_row = ws.max_row

    processed = 0
    skipped = 0
    failed_rows = []

    # 缓存合并单元格的值
    merged_cache: Dict[Tuple[int, int], Optional[Dict]] = {}

    row_idx = 2
    while row_idx <= max_row:
        # 读取各列数据
        b_value, b_start, b_end = get_merged_cell_value(ws, row_idx, 2)
        d_value, d_start, d_end = get_merged_cell_value(ws, row_idx, 4)
        f_value, f_start, f_end = get_merged_cell_value(ws, row_idx, 6)
        g_value, g_start, g_end = get_merged_cell_value(ws, row_idx, 7)
        h_value, h_start, h_end = get_merged_cell_value(ws, row_idx, 8)
        i_value, i_start, i_end = get_merged_cell_value(ws, row_idx, 9)

        if not f_value:
            skipped += 1
            failed_rows.append((row_idx, "F列为空"))
            row_idx += 1
            continue

        policy_code = str(b_value).strip() if b_value else ""
        rule_number = str(d_value).strip() if d_value else ""
        rule_desc = str(f_value).strip()

        # G列自动补全逻辑
        if not g_value:
            print(f"  第{row_idx}行：G列为空，自动生成指标标识...")
            metric_codes = generate_metric_identifiers(rule_desc)

            if not metric_codes:
                skipped += 1
                failed_rows.append((row_idx, "G列为空且无法生成指标标识"))
                row_idx += 1
                continue

            g_cell_value = "\n".join(metric_codes)
            ws.cell(row=row_idx, column=7).value = g_cell_value
            print(
                f"  → 生成{len(metric_codes)}个指标标识：{', '.join(metric_codes[:3])}"
                f"{'...' if len(metric_codes) > 3 else ''}"
            )
        else:
            metric_codes = [
                line.strip() for line in str(g_value).split("\n") if line.strip()
            ]

            expected_count = estimate_condition_count(rule_desc)
            current_count = len(metric_codes)

            if current_count < expected_count:
                shortage = expected_count - current_count
                print(
                    f"  第{row_idx}行：G列指标标识数量不足"
                    f"（现有{current_count}个，应有{expected_count}个），补充{shortage}个..."
                )

                additional_ids = generate_metric_identifiers(rule_desc, count=shortage)
                metric_codes.extend(additional_ids)

                g_cell_value = "\n".join(metric_codes)
                ws.cell(row=row_idx, column=7).value = g_cell_value
                print(
                    f"  → 补充完成，共{len(metric_codes)}个指标标识："
                    f"{', '.join(metric_codes[:3])}{'...' if len(metric_codes) > 3 else ''}"
                )

        param_candidates = parse_param_candidates(h_value)

        # 解析 I 列公共字段
        i_public: Dict[str, Any] = {}
        if i_value:
            try:
                tmp = json.loads(str(i_value))
                if isinstance(tmp, dict):
                    i_public = tmp
            except Exception:
                i_public = {}

        if not rule_desc or not metric_codes:
            skipped += 1
            failed_rows.append((row_idx, "规则描述为空或指标标识列表为空"))
            row_idx += 1
            continue

        # 检查缓存
        merge_key = (f_start, f_end)
        if merge_key in merged_cache:
            cached_result = merged_cache[merge_key]
            if cached_result is None:
                skipped += 1
                failed_rows.append((row_idx, "使用缓存：大模型调用失败或返回无效JSON"))
                row_idx += 1
                continue
            result_json = copy.deepcopy(cached_result)
        else:
            # 调用大模型进行条件拆分
            result_json = llm_client.call_for_condition_split(
                rule_desc, metric_codes, param_candidates
            )
            merged_cache[merge_key] = result_json

        if result_json is None:
            skipped += 1
            failed_rows.append((row_idx, "大模型调用失败或返回无效JSON"))
            row_idx += 1
            continue

        if not result_json:
            skipped += 1
            failed_rows.append((row_idx, "大模型返回空结果"))
            row_idx += 1
            continue

        if "条件列表" not in result_json or not result_json["条件列表"]:
            skipped += 1
            failed_rows.append((row_idx, "JSON缺少条件列表或条件列表为空"))
            print(f"[警告] 第{row_idx}行：JSON缺少有效的条件列表")
            row_idx += 1
            continue

        # 写入 I 列公共字段
        result_json["I列公共字段"] = i_public
        try:
            cell_text_j = json.dumps(result_json, ensure_ascii=False)
        except Exception:
            cell_text_j = str(result_json)
        ws.cell(row=row_idx, column=10).value = cell_text_j

        # 调用大模型生成场景
        k_json: Optional[Dict[str, Any]] = llm_client.call_for_scenario_generation(
            result_json, param_cn_to_en
        )

        # 如果大模型失败，使用兜底策略
        if not k_json:
            k_json = generate_fallback_k_json(rule_number, result_json)

        if not k_json:
            processed += 1
            row_idx += 1
            continue

        # 计算场景整体命中结果
        scene_summary = compute_scene_results(k_json)
        scene_hit_map: Dict[Any, Any] = {}
        for item in scene_summary.get("场景结果列表", []):
            scene_hit_map[item.get("场景序号")] = item.get("整体是否命中")

        # 处理多场景
        scene_list = k_json.get("场景列表", []) or []
        num_scenes = len(scene_list)
        if num_scenes > 1:
            ws.insert_rows(row_idx + 1, amount=num_scenes - 1)
            max_row += num_scenes - 1

        # 为所有场景行写入数据
        for idx_scene, scene in enumerate(scene_list, start=1):
            target_row = row_idx + idx_scene - 1
            scene_idx_val = scene.get("场景序号")

            if idx_scene == 1:
                pass  # 第一个场景使用当前行
            else:
                # 复制 A-G 列
                for col in range(1, 8):
                    source_val = ws.cell(row=row_idx, column=col).value
                    ws.cell(row=target_row, column=col).value = source_val
                # 复制 J 列
                ws.cell(row=target_row, column=10).value = cell_text_j

            # H 列和 I 列
            ws.cell(row=target_row, column=8).value = h_value
            ws.cell(row=target_row, column=9).value = i_value

            # 构造 K 列 JSON
            common_field_gen_rules = {}

            for field_key in i_public.keys():
                if field_key in ["S_E_TRANSSTAT", "trxStatus"]:
                    if field_key == "S_E_TRANSSTAT":
                        common_field_gen_rules[field_key] = {
                            "规则类型": "场景相关",
                            "命中值": "0",
                            "未命中值": "1",
                        }
                    elif field_key == "trxStatus":
                        common_field_gen_rules[field_key] = {
                            "规则类型": "场景相关",
                            "命中值": "posted",
                            "未命中值": "failed",
                        }
                elif field_key in ["S_S_BIZID", "bizId"]:
                    common_field_gen_rules[field_key] = {
                        "规则类型": "随机生成",
                        "格式": "20位数字字母混合",
                    }
                elif field_key in ["S_S_POLICYCODE", "policyCode"]:
                    common_field_gen_rules[field_key] = {
                        "规则类型": "固定值",
                        "值": policy_code,
                    }

            common_field_gen_rules["其他字段"] = {"规则类型": "I列固定值"}

            scene_k_json = {
                "规则编号": rule_number,
                "注释说明库": k_json.get("注释说明库", {}),
                "公共字段生成规则": common_field_gen_rules,
                "参数值生成规则": {
                    "说明": "通用参数生成策略，根据参数类型自动生成",
                    "时间参数": ["业务发生时间", "事件发生时间"],
                    "时间生成策略": "当前时间随机偏移",
                    "ID参数": ["设备ID", "用户ID"],
                    "ID生成策略": "前缀+随机数字",
                    "账号参数": ["登录账号"],
                    "账号生成策略": "USER_+随机数字",
                },
                "场景": scene,
            }
            try:
                cell_text_k = json.dumps(scene_k_json, ensure_ascii=False)
                ws.cell(row=target_row, column=11).value = cell_text_k
            except Exception as e:
                failed_rows.append((target_row, f"序列化K列场景JSON失败: {e}"))

            # L列：当前场景整体是否命中
            hit = scene_hit_map.get(scene_idx_val)
            if hit is not None:
                ws.cell(row=target_row, column=12).value = "命中" if hit else "未命中"

            # M列：生成测试用例数据
            try:
                scene_testcase_records = generate_testcase_data_for_rule(
                    scene_k_json,
                    result_json,
                    param_cn_to_en,
                )
                if scene_testcase_records:
                    json_lines = [
                        json.dumps(record, ensure_ascii=False)
                        for record in scene_testcase_records
                    ]
                    ws.cell(row=target_row, column=13).value = "\n".join(json_lines)
            except Exception as e:
                failed_rows.append((target_row, f"生成M列测试用例数据失败: {e}"))
                import traceback

                traceback.print_exc()

            # N列：生成场景应用名称
            try:
                scene_app_name = generate_scene_application_name(d_value, scene_k_json)
                ws.cell(row=target_row, column=14).value = scene_app_name
            except Exception as e:
                failed_rows.append((target_row, f"生成N列场景应用名称失败: {e}"))

        processed += 1

        # 定期保存
        if processed and processed % 10 == 0:
            print(f"[提示] 已处理{processed}行，正在保存中间结果...")
            save_success = safe_save_workbook(wb, output_path, raise_on_failure=False)
            if save_success:
                print(f"[成功] 中间结果保存成功")
            else:
                print(f"[警告] 中间结果保存失败，程序将继续处理，最后再次尝试保存")

        row_idx += num_scenes

    # 合并 H 列和 I 列
    current_max_row = ws.max_row
    merge_h_i_by_column_c(ws, current_max_row)

    print(f"\n{'='*60}")
    print(f"Sheet [{sheet_name}] 处理完成统计：")
    print(f"  成功写入: {processed} 行")
    print(f"  跳过/失败: {skipped} 行")
    print(f"  总处理行数: {max_row - 1} 行（不含表头）")
    print(f"{'='*60}")

    if failed_rows:
        print(f"\n失败行详细信息：")
        for row_num, reason in failed_rows:
            print(f"  第 {row_num} 行: {reason}")

    return processed, skipped, failed_rows


def process_rules_file(
    input_path: str,
    output_path: str,
    api_key: str,
    param_dict_path: str,
) -> None:
    """处理规则文件（支持多sheet页）

    Args:
        input_path: 输入文件路径
        output_path: 输出文件路径
        api_key: DashScope API KEY
        param_dict_path: 参数字典文件路径
    """
    print("=" * 60)
    print("规则条件拆分程序（多Sheet支持）")
    print("=" * 60)
    print(f"输入文件: {input_path}")
    print(f"输出文件: {output_path}")
    print("=" * 60)

    # 加载工作簿
    wb = load_workbook(input_path)

    # 获取所有sheet页名称
    sheet_names = wb.sheetnames
    print(f"\n发现 {len(sheet_names)} 个Sheet页: {', '.join(sheet_names)}")

    # 加载参数字典
    try:
        param_cn_to_en = load_param_dict(param_dict_path)
    except Exception as e:
        print(f"[错误] 加载参数字典失败: {e}")
        return

    # 初始化 LLM 客户端
    llm_client = DashScopeClient(api_key)

    # 统计信息
    total_processed = 0
    total_skipped = 0
    all_failed_rows = []

    # 遍历处理每个sheet页
    for sheet_name in sheet_names:
        ws = wb[sheet_name]

        processed, skipped, failed_rows = process_single_sheet(
            ws, wb, output_path, llm_client, param_cn_to_en, sheet_name
        )

        total_processed += processed
        total_skipped += skipped

        for row_num, reason in failed_rows:
            all_failed_rows.append((sheet_name, row_num, reason))

        print(f"\n[提示] Sheet [{sheet_name}] 处理完成，正在保存...")
        save_success = safe_save_workbook(wb, output_path, raise_on_failure=False)
        if save_success:
            print(f"[OK] Sheet [{sheet_name}] 已保存")
        else:
            print(f"[警告] Sheet [{sheet_name}] 保存失败，将在最后再次尝试")

    # 最终保存
    print(f"\n{'='*60}")
    print("[提示] 正在进行最终保存...")
    final_save_success = safe_save_workbook(
        wb, output_path, max_retries=10, retry_delay=2.0, raise_on_failure=False
    )

    if not final_save_success:
        print(f"\n{'='*60}")
        print("[错误] 最终保存失败！")
        print("[原因] 输出文件可能被其他程序占用（如Excel、WPS等）")
        print("[建议] 请执行以下操作：")
        print(f"  1. 关闭所有打开 '{output_path}' 的程序")
        print("  2. 程序已在内存中完成所有处理，数据没有丢失")
        print("  3. 关闭文件后，程序将再次尝试保存...")
        print(f"{'='*60}")

        input("\n按回车键继续(请先关闭文件)...")

        print("\n[提示] 再次尝试保存...")
        final_save_success = safe_save_workbook(
            wb, output_path, max_retries=10, retry_delay=2.0, raise_on_failure=False
        )

        if not final_save_success:
            print(f"\n[错误] 仍然无法保存文件")
            print(f"[建议] 请手动将文件复制到其他位置或重命名后再试")
            return

    print(f"\n{'='*60}")
    print(f"【全部Sheet处理完成统计】")
    print(f"  处理Sheet数: {len(sheet_names)} 个")
    print(f"  总成功写入: {total_processed} 行")
    print(f"  总跳过/失败: {total_skipped} 行")
    print(f"{'='*60}")

    if all_failed_rows:
        print(f"\n失败行详细信息（按Sheet分类）：")
        current_sheet = None
        for sheet_name, row_num, reason in all_failed_rows:
            if sheet_name != current_sheet:
                print(f"\n  Sheet [{sheet_name}]:")
                current_sheet = sheet_name
            print(f"    第 {row_num} 行: {reason}")

    print(f"\n输出文件: {output_path}")


def main() -> int:
    """命令行入口。"""
    parser = argparse.ArgumentParser(description="规则条件拆分程序（多Sheet支持）")
    parser.add_argument(
        "--input",
        "-i",
        dest="input_path",
        help="输入文件路径（测试用例需求_分页.xlsx）",
    )
    parser.add_argument(
        "--output",
        "-o",
        dest="output_path",
        help="输出文件路径（例如 测试用例需求_分页_输出.xlsx）",
    )
    parser.add_argument(
        "--param-dict",
        "-p",
        dest="param_dict_path",
        help="参数字典文件路径（参数字典.xlsx）",
    )
    parser.add_argument(
        "--record-csv",
        "-r",
        dest="record_csv_path",
        help="CSV记录文件路径（记录输出文件名，默认：output_file_name.csv）",
    )
    parser.add_argument(
        "--api-key",
        dest="api_key",
        help="DashScope API KEY，优先级最高，可覆盖配置文件和环境变量",
    )
    args = parser.parse_args()

    # 获取配置
    config = get_config(
        api_key_cli=(args.api_key or "").strip() if getattr(args, "api_key", None) else "",
        input_path=args.input_path,
        output_path=args.output_path,
        param_dict_path=args.param_dict_path,
        record_csv_path=args.record_csv_path,
    )

    if not config.api_key:
        print("错误: 缺少 API KEY 配置")
        print(
            "请通过命令行参数 --api-key，或在 dashscope_config.json 中设置 api_key，"
            "或设置环境变量 DASHSCOPE_API_KEY"
        )
        return 1

    if not os.path.exists(config.input_path):
        print(f"错误: 输入文件不存在: {config.input_path}")
        return 1

    if not os.path.exists(config.param_dict_path):
        print(f"错误: 参数字典文件不存在: {config.param_dict_path}")
        return 1

    try:
        process_rules_file(
            config.input_path,
            config.output_path,
            config.api_key,
            config.param_dict_path,
        )

        # 保存输出文件名到CSV记录文件
        save_output_record(config.output_path, config.record_csv_path)

        print("=" * 60)
        print("处理完成！")
        print("=" * 60)
        return 0
    except Exception as e:
        print(f"错误: 处理过程中发生异常: {e}")
        import traceback

        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
