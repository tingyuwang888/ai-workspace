# -*- coding: utf-8 -*-
"""
场景生成逻辑模块

负责生成兜底场景和场景应用名称。
"""

from typing import Any, Dict, List, Optional, Tuple


def generate_fallback_k_json(
    rule_number: str, rule_json: Dict[str, Any]
) -> Optional[Dict[str, Any]]:
    """为高条件数规则生成兜底版 K 列 JSON。

    适用场景：
    - 大模型生成的场景 JSON 解析失败或缺少"场景列表"时
    - 条件数量较多（例如 >=5）时，至少给出一批有代表性的场景，避免整条规则为空

    Args:
        rule_number: 规则编号
        rule_json: J 列条件拆分 JSON

    Returns:
        K 列 JSON，如果条件数 <= 4 或条件列表为空则返回 None
    """
    cond_list = rule_json.get("条件列表", [])
    if not cond_list:
        return None

    cond_count = len(cond_list)
    # 仅为高条件数规则提供兜底，低条件数仍交给大模型
    if cond_count <= 4:
        return None

    scenes: List[Dict[str, Any]] = []

    # 构造若干代表性场景模式：
    patterns: List[Tuple[str, str, List[bool]]] = []

    # 场景1：全部命中
    patterns.append(
        ("全部命中", "所有条件都满足命中条件的场景", [True] * cond_count)
    )

    # 场景2~N+1：仅某一个条件命中
    if cond_count > 1:
        for idx in range(cond_count):
            flags = [False] * cond_count
            flags[idx] = True
            patterns.append(
                (
                    f"仅条件{idx + 1}命中",
                    f"仅条件{idx + 1}满足，其余条件均不满足的场景",
                    flags,
                )
            )

    # 最后一个场景：全部未命中
    patterns.append(
        ("全部未命中", "所有条件都不满足命中条件的场景", [False] * cond_count)
    )

    for scene_idx, (scene_name, scene_desc, flags) in enumerate(patterns, start=1):
        cond_states: List[Dict[str, Any]] = []
        overall: Optional[bool] = None

        for i, cond in enumerate(cond_list):
            hit = bool(flags[i])
            cond_state: Dict[str, Any] = {
                "条件序号": cond.get("条件序号", i + 1),
                "指标标识": cond.get("指标标识", ""),
                "条件是否命中": hit,
                # 兜底场景中不强行推断指标类型，统一标记为"次数"
                "参数类型": "次数",
                "原始比较符号": None,
                "原始阈值表达式": None,
                "场景比较符号": None,
                "场景命中含义": "",
                "指标值示例": None,
                "指标值规则": {},
                # 与 J 列条件模板中的参数列表保持一致
                "参与统计的参数列表": cond.get("参数列表", []),
                "备注": "",
            }
            cond_states.append(cond_state)

            # 计算场景整体是否命中
            if i == 0:
                overall = hit
            else:
                relation = cond.get("与上一个指标关系") or "且"
                if relation == "或":
                    overall = bool(overall) or hit
                else:
                    overall = bool(overall) and hit

        scenes.append(
            {
                "场景序号": scene_idx,
                "场景名称": scene_name,
                "场景描述": scene_desc,
                "条件状态列表": cond_states,
                "场景整体是否命中": bool(overall) if overall is not None else False,
            }
        )

    k_json: Dict[str, Any] = {
        "规则编号": rule_number,
        "条件模板": {
            "条件数量": cond_count,
            "条件列表": cond_list,
        },
        "注释说明库": rule_json.get("注释说明库", {}),
        "I列公共字段": rule_json.get("I列公共字段", {}),
        "场景列表": scenes,
    }

    return k_json


def generate_scene_application_name(
    d_column_value: str, k_json: Dict[str, Any]
) -> str:
    """生成场景应用名称（N列）

    读取K列JSON中的'场景名称'字段，与D列内容进行拼接。
    格式：D列内容 + "_" + 场景名称

    Args:
        d_column_value: D列（规则编号）的值
        k_json: K列的JSON对象（包含场景信息）

    Returns:
        场景应用名称字符串，例如："301401001_全部命中"
    """
    if not k_json:
        return ""

    # 获取D列值，如果为空则使用空字符串
    d_value = str(d_column_value).strip() if d_column_value else ""

    # 从K列JSON中读取场景信息
    scene = k_json.get("场景", {})
    if not scene:
        return d_value if d_value else ""

    # 获取场景名称
    scene_name = scene.get("场景名称", "")
    if not scene_name:
        scene_name = scene.get("场景序号", "")
        if scene_name:
            scene_name = f"场景{scene_name}"

    # 拼接D列值和场景名称
    if d_value and scene_name:
        return f"{d_value}_{scene_name}"
    elif d_value:
        return d_value
    elif scene_name:
        return scene_name
    else:
        return ""
