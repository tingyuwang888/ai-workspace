# -*- coding: utf-8 -*-
"""
条件拆分逻辑模块

负责估算条件数量和生成指标标识。
"""

import re
import random
import string
from typing import List, Optional


def estimate_condition_count(rule_desc: str) -> int:
    """估算F列规则描述中的条件数量

    根据条件编号、中括号、分号、"或"、"且"等特征估算条件数量。
    优先识别F列中明确的条件编号（如：条件1、条件2、条件3）。

    Args:
        rule_desc: F列规则描述

    Returns:
        估算的条件数量
    """
    if not rule_desc:
        return 0

    # 移除注释说明部分（以"注："、"说明："、"备注："开头的内容）
    desc_lines = rule_desc.split("\n")
    clean_lines = []
    for line in desc_lines:
        line_stripped = line.strip()
        if line_stripped.startswith(
            ("注：", "说明：", "备注：", "注:", "说明:", "备注:")
        ):
            continue
        clean_lines.append(line)

    clean_desc = "\n".join(clean_lines)

    # 优先级1：识别明确的条件编号，例如："条件1"、"条件2"、"条件3"
    condition_numbers = set()
    # 匹配模式：条件 + 数字，或者 [条件数字]
    condition_pattern = re.findall(r"[\[【]?条件\s*(\d+)[\]】]?", clean_desc)
    for num_str in condition_pattern:
        condition_numbers.add(int(num_str))

    if condition_numbers:
        # 如果找到明确的条件编号，返回最大编号（条件1~条件N，则有N个条件）
        return max(condition_numbers)

    # 优先级2：统计中括号对数（每对通常对应一个完整条件）
    bracket_count = min(clean_desc.count("["), clean_desc.count("]"))
    if bracket_count > 0:
        # 如果使用中括号显式列出了条件边界，则以中括号对数为准
        return bracket_count

    # 优先级3：统计分号数量（每个分号通常分隔一个条件）
    semicolon_count = clean_desc.count("；") + clean_desc.count(";")
    if semicolon_count > 0:
        return semicolon_count + 1

    # 优先级4：统计"或"的数量
    or_count = clean_desc.count("或")
    if or_count > 0:
        return or_count + 1

    # 优先级5：统计"且"的数量
    and_count = clean_desc.count("且")
    if and_count > 0:
        return and_count + 1

    # 默认至少有1个条件
    return max(1, 0)


def generate_metric_identifiers(
    rule_desc: str, count: Optional[int] = None
) -> List[str]:
    """为空G列生成指标标识

    分析F列规则描述，拆解条件数量，为每个条件生成唯一的指标标识。
    指标标识格式：AUTO_{6位随机字母数字}，如 AUTO_A1B2C3

    Args:
        rule_desc: F列规则描述
        count: 指定生成数量，如果为None则自动估算

    Returns:
        指标标识列表，如 ['AUTO_A1B2C3', 'AUTO_D4E5F6']
    """
    if not rule_desc:
        return []

    # 生成随机指标标识
    def _generate_id() -> str:
        chars = string.ascii_uppercase + string.digits
        random_part = "".join(random.choice(chars) for _ in range(6))
        return f"AUTO_{random_part}"

    # 确定条件数量
    if count is None:
        condition_count = estimate_condition_count(rule_desc)
    else:
        condition_count = count

    # 限制最大条件数（避免生成过多）
    condition_count = min(condition_count, 10)
    condition_count = max(condition_count, 1)

    # 生成指标标识列表
    metric_ids = [_generate_id() for _ in range(condition_count)]

    return metric_ids
