# -*- coding: utf-8 -*-
"""
场景结果计算模块

负责计算场景的整体命中结果。
"""

from typing import Any, Dict


def compute_scene_results(k_json: Dict[str, Any]) -> Dict[str, Any]:
    """根据 K 列 JSON 计算每个场景的整体命中结果，返回摘要结构。

    Args:
        k_json: K 列 JSON 对象

    Returns:
        包含场景结果列表的字典
    """
    result = {"场景结果列表": []}

    if not k_json or "场景列表" not in k_json or "条件模板" not in k_json:
        return result

    cond_list = k_json["条件模板"].get("条件列表", [])
    scene_list = k_json.get("场景列表", [])

    if not cond_list or not scene_list:
        return result

    for scene in scene_list:
        scene_idx = scene.get("场景序号")
        cond_states = scene.get("条件状态列表", [])
        if len(cond_states) != len(cond_list):
            continue

        overall = None
        for i, cond in enumerate(cond_list):
            state = cond_states[i]
            hit = bool(state.get("条件是否命中"))
            if i == 0:
                overall = hit
                continue
            relation = cond.get("与上一个指标关系") or "且"
            if relation == "或":
                overall = bool(overall) or hit
            else:
                overall = bool(overall) and hit

        if overall is None:
            continue

        scene["场景整体是否命中"] = bool(overall)
        result["场景结果列表"].append(
            {"场景序号": scene_idx, "整体是否命中": bool(overall)}
        )

    return result
