# -*- coding: utf-8 -*-
"""
Excel 读取模块

负责 Excel 文件的读取和合并单元格处理。
"""

import re
from typing import Any, List, Tuple


def get_merged_cell_value(ws, row_idx: int, col_idx: int) -> Tuple[Any, int, int]:
    """获取合并单元格的值和范围

    Args:
        ws: worksheet对象
        row_idx: 行索引（1-based）
        col_idx: 列索引（1-based）

    Returns:
        (单元格值, 合并起始行, 合并结束行)
    """
    cell = ws.cell(row_idx, col_idx)

    # 检查是否是合并单元格
    for merged_range in ws.merged_cells.ranges:
        if cell.coordinate in merged_range:
            # 获取合并区域的左上角单元格值
            min_row = merged_range.min_row
            min_col = merged_range.min_col
            max_row = merged_range.max_row
            value = ws.cell(min_row, min_col).value
            return value, min_row, max_row

    # 不是合并单元格
    return cell.value, row_idx, row_idx


def parse_param_candidates(text: Any) -> List[str]:
    """解析 H 列参数清单为参数候选列表。

    支持的分隔符：逗号、分号、换行等。

    Args:
        text: H 列单元格的值

    Returns:
        参数名称列表
    """
    if not text:
        return []

    raw = str(text)
    parts = re.split(r"[,，;；\n\r\t]+", raw)
    params = [p.strip() for p in parts if p.strip()]
    return params


def unmerge_and_fill_cells(ws) -> List[Tuple[int, int, int, int, Any]]:
    """解除所有合并单元格并填充值到所有单元格

    Args:
        ws: worksheet对象

    Returns:
        合并区域信息列表 [(min_row, min_col, max_row, max_col, value), ...]
    """
    merged_ranges_info = []
    
    # 先记录所有合并区域的信息
    for merged_range in list(ws.merged_cells.ranges):
        min_row = merged_range.min_row
        min_col = merged_range.min_col
        max_row = merged_range.max_row
        max_col = merged_range.max_col
        value = ws.cell(min_row, min_col).value
        merged_ranges_info.append((min_row, min_col, max_row, max_col, value))

    # 解除所有合并
    for merged_range in list(ws.merged_cells.ranges):
        ws.unmerge_cells(str(merged_range))

    # 填充值到所有原合并区域的单元格
    for min_row, min_col, max_row, max_col, value in merged_ranges_info:
        for row in range(min_row, max_row + 1):
            for col in range(min_col, max_col + 1):
                ws.cell(row, col).value = value

    return merged_ranges_info
