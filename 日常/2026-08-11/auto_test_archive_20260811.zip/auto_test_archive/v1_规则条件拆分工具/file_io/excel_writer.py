# -*- coding: utf-8 -*-
"""
Excel 写入模块

负责 Excel 文件的写入、保存和单元格合并。
"""

import time
import csv
import os
from typing import List, Tuple


def safe_save_workbook(
    wb,
    output_path: str,
    max_retries: int = 5,
    retry_delay: float = 1.0,
    raise_on_failure: bool = True,
) -> bool:
    """安全保存工作簿，带重试机制

    Args:
        wb: 工作簿对象
        output_path: 输出路径
        max_retries: 最大重试次数
        retry_delay: 重试延迟(秒)
        raise_on_failure: 失败时是否抛出异常(False时仅返回False)

    Returns:
        bool: 保存是否成功
    """
    for attempt in range(max_retries):
        try:
            wb.save(output_path)
            return True
        except PermissionError as e:
            if attempt < max_retries - 1:
                print(f"[警告] 保存文件失败(尝试 {attempt + 1}/{max_retries}): {e}")
                print(f"[提示] 等待 {retry_delay} 秒后重试...")
                time.sleep(retry_delay)
            else:
                print(f"[错误] 保存文件失败,已达到最大重试次数: {e}")
                if raise_on_failure:
                    raise
                else:
                    return False
        except Exception as e:
            print(f"[错误] 保存文件时发生未预期的错误: {e}")
            if raise_on_failure:
                raise
            else:
                return False
    return False


def merge_h_i_by_column_c(ws, max_row: int) -> None:
    """按 C 列（规则集名称）合并 H 列和 I 列。

    C 列内容相同的连续行，H 列和 I 列合并为一个单元格。

    Args:
        ws: openpyxl worksheet 对象
        max_row: 最大行号
    """
    # 收集 C 列相同内容的连续行范围
    c_ranges: List[Tuple[str, int, int]] = []
    current_c_value = None
    start_row = None

    for row in range(2, max_row + 1):
        c_val = ws.cell(row=row, column=3).value

        if c_val is None:
            # C列为空，结束当前范围
            if start_row is not None:
                c_ranges.append((current_c_value, start_row, row - 1))
                start_row = None
                current_c_value = None
            continue

        c_val_str = str(c_val).strip()

        if c_val_str != current_c_value:
            # C列值变化，结束上一个范围，开始新范围
            if start_row is not None:
                c_ranges.append((current_c_value, start_row, row - 1))
            start_row = row
            current_c_value = c_val_str
        # 否则继续当前范围

    # 处理最后一个范围
    if start_row is not None:
        c_ranges.append((current_c_value, start_row, max_row))

    # 对每个范围进行 H 列和 I 列的合并
    for c_value, start, end in c_ranges:
        if end > start:  # 只有多行时才需要合并
            try:
                ws.merge_cells(start_row=start, start_column=8, end_row=end, end_column=8)  # H列
                ws.merge_cells(start_row=start, start_column=9, end_row=end, end_column=9)  # I列
            except Exception as e:
                print(f"[警告] 合并 H/I 列失败 (C列={c_value}, Row {start}-{end}): {e}")


def save_output_record(output_path: str, record_csv_path: str) -> None:
    """保存输出文件名到CSV记录文件，每次覆盖。

    Args:
        output_path: 输出的Excel文件的完整路径
        record_csv_path: CSV记录文件的路径
    """
    # 提取文件名（不包含路径）
    filename = os.path.basename(output_path)

    # 写入CSV文件（覆盖模式，只写文件名，不写表头）
    try:
        with open(record_csv_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow([filename])  # 只写入文件名，不写表头
        print(f"\n记录文件: {record_csv_path}")
        print(f"  已记录输出文件名: {filename}")
    except Exception as e:
        print(f"[警告] 保存CSV记录文件失败: {e}")


def setup_output_headers(ws) -> None:
    """设置输出列的表头

    Args:
        ws: worksheet对象
    """
    ws.cell(row=1, column=10).value = "J_条件拆分JSON"
    ws.cell(row=1, column=11).value = "K_场景规则JSON"
    ws.cell(row=1, column=12).value = "L_场景结果摘要"
    ws.cell(row=1, column=13).value = "M_测试用例数据"
    ws.cell(row=1, column=14).value = "N_场景应用名称"
