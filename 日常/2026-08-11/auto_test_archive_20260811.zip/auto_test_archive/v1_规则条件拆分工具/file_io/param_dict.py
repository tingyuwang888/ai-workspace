# -*- coding: utf-8 -*-
"""
参数字典加载模块

负责从 Excel 文件加载参数字典，将中文参数名映射到业务入参字段。
"""

import os
from typing import Dict

from openpyxl import load_workbook


def load_param_dict(dict_path: str) -> Dict[str, str]:
    """加载参数字典，将中文参数名(B列)映射到业务入参字段(D列)。

    如果D列为空，则仍然建立映射但值为空字符串；后续在生成测试数据时
    只要能在该字典中找到中文参数名即可视为匹配成功。

    Args:
        dict_path: 参数字典文件路径

    Returns:
        中文参数名到业务入参字段的映射字典

    Raises:
        FileNotFoundError: 参数字典文件不存在
    """
    if not os.path.exists(dict_path):
        raise FileNotFoundError(f"参数字典文件不存在: {dict_path}")

    wb = load_workbook(dict_path, read_only=True, data_only=True)
    ws = wb.active

    cn_to_en: Dict[str, str] = {}

    # 从第2行开始读取（第1行是表头）
    for row in ws.iter_rows(min_row=2):
        cn_name = row[1].value if len(row) > 1 else None  # B列：参数中文名
        biz_field = row[3].value if len(row) > 3 else None  # D列：业务入参字段

        if not cn_name:
            continue

        cn_str = str(cn_name).strip()
        if not cn_str:
            continue

        value = ""
        if biz_field:
            value = str(biz_field).strip()

        cn_to_en[cn_str] = value

    wb.close()
    print(f"成功加载参数字典: {len(cn_to_en)} 个参数")

    return cn_to_en
