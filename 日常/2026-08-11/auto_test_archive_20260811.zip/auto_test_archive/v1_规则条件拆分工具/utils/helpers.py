# -*- coding: utf-8 -*-
"""
通用工具函数模块

提供各种辅助函数。
"""

import random
import string
import datetime


def generate_random_bizid(length: int = 20) -> str:
    """生成20位数字+字母随机串

    Args:
        length: 生成的字符串长度

    Returns:
        随机字符串
    """
    chars = string.ascii_uppercase + string.digits
    return "".join(random.choice(chars) for _ in range(length))


def generate_device_id() -> str:
    """生成设备ID

    Returns:
        设备ID字符串
    """
    return f"DEV_{random.randint(100000, 999999)}"


def generate_user_account() -> str:
    """生成用户账号

    Returns:
        用户账号字符串
    """
    return f"USER_{random.randint(10000, 99999)}"


def generate_timestamp(offset_minutes: int = 60) -> str:
    """生成时间戳（当前时间+随机偏移）

    Args:
        offset_minutes: 随机偏移的最大分钟数

    Returns:
        时间戳字符串
    """
    now = datetime.datetime.now()
    offset = datetime.timedelta(minutes=random.randint(-offset_minutes, offset_minutes))
    target_time = now + offset
    return target_time.strftime("%Y-%m-%d %H:%M:%S")


def generate_id_card() -> str:
    """生成合法18位身份证号码

    符合GB11643-1999标准，包含校验码计算。

    Returns:
        18位身份证号码
    """
    # 生成前17位
    # 地区码：6位（使用常见省份代码）
    province_codes = [
        "110000",  # 北京
        "310000",  # 上海
        "440000",  # 广东
        "500000",  # 重庆
        "330000",  # 浙江
    ]
    area_code = random.choice(province_codes)

    # 出生日期：8位（1980-2005年）
    year = random.randint(1980, 2005)
    month = random.randint(1, 12)
    day = random.randint(1, 28)  # 简化处理，避免月份天数问题
    birth_date = f"{year:04d}{month:02d}{day:02d}"

    # 顺序码：3位
    sequence = f"{random.randint(0, 999):03d}"

    # 前17位
    id_17 = area_code + birth_date + sequence

    # 计算校验码（第18位）
    # 加权因子
    weight_factors = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
    # 校验码对照表
    check_codes = ["1", "0", "X", "9", "8", "7", "6", "5", "4", "3", "2"]

    # 计算加权和
    total = sum(int(id_17[i]) * weight_factors[i] for i in range(17))
    # 获取校验码
    check_code = check_codes[total % 11]

    return id_17 + check_code


def format_json_for_cell(data: dict) -> str:
    """将字典格式化为单元格中的 JSON 字符串

    Args:
        data: 要格式化的字典

    Returns:
        JSON 字符串
    """
    import json

    return json.dumps(data, ensure_ascii=False)


def parse_json_from_cell(text: str) -> dict:
    """从单元格中解析 JSON

    Args:
        text: 单元格中的文本

    Returns:
        解析后的字典，解析失败返回空字典
    """
    import json

    if not text:
        return {}

    try:
        data = json.loads(str(text))
        if isinstance(data, dict):
            return data
    except Exception:
        pass

    return {}
