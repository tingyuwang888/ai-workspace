# -*- coding: utf-8 -*-
"""
配置管理模块

负责加载 API KEY、文件路径等配置信息。
"""

import os
import json
from typing import Optional
from dataclasses import dataclass


@dataclass
class Config:
    """应用配置类"""
    api_key: str = ""
    input_path: str = ""
    output_path: str = ""
    param_dict_path: str = ""
    record_csv_path: str = ""


def load_dashscope_config(config_path: Optional[str] = None) -> str:
    """从 dashscope_config.json 读取 API KEY（如果存在）。

    Args:
        config_path: 配置文件路径，默认为当前目录下的 dashscope_config.json

    Returns:
        api_key 字符串，如不存在或读取失败则返回空字符串。
    """
    if config_path is None:
        config_path = os.path.join(os.getcwd(), "dashscope_config.json")
    
    if not os.path.exists(config_path):
        return ""
    
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        return cfg.get("api_key", "") or ""
    except Exception:
        return ""


def get_config(
    api_key_cli: str = "",
    input_path: Optional[str] = None,
    output_path: Optional[str] = None,
    param_dict_path: Optional[str] = None,
    record_csv_path: Optional[str] = None,
) -> Config:
    """获取完整配置，合并命令行参数、环境变量和配置文件。

    优先级：命令行 > 环境变量 > 配置文件 > 默认值

    Args:
        api_key_cli: 命令行传入的 API KEY
        input_path: 输入文件路径
        output_path: 输出文件路径
        param_dict_path: 参数字典文件路径
        record_csv_path: CSV 记录文件路径

    Returns:
        Config 对象
    """
    # 获取脚本所在目录作为基础路径
    script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # API KEY: 命令行 > 环境变量 > 配置文件
    api_key_env = os.getenv("DASHSCOPE_API_KEY", "")
    api_key_cfg = load_dashscope_config()
    api_key = api_key_cli or api_key_env or api_key_cfg

    # 文件路径：使用默认值或传入值
    config = Config(
        api_key=api_key,
        input_path=input_path or os.path.join(script_dir, "测试用例需求_分页.xlsx"),
        output_path=output_path or os.path.join(script_dir, "测试用例需求_分页_输出.xlsx"),
        param_dict_path=param_dict_path or os.path.join(script_dir, "参数字典.xlsx"),
        record_csv_path=record_csv_path or os.path.join(script_dir, "output_file_name.csv"),
    )

    return config
