# -*- coding: utf-8 -*-
"""配置管理模块"""
from .settings import load_dashscope_config, get_config

__all__ = ["load_dashscope_config", "get_config"]
