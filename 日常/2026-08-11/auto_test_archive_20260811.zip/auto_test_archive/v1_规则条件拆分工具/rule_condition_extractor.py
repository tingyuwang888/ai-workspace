#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
规则条件拆分程序

功能：
- 基于现有项目的经验（DashScope 调用、Excel 行处理、参数/指标一一对应）
- 对测试用例需求 Excel 中的 F 列规则描述进行条件拆分
- 拆分结果写入 J 列（JSON 格式），帮助后续模型更好理解每条规则

核心能力：
- 读取 F 列规则描述 + G 列指标标识
- 通过大模型把 F 列拆分成若干条件，条件数量 == 指标标识数量
- 为每个条件标注：条件描述、与上一个条件的关系（且/或）、是否存在括号嵌套
- 抽取并整理“注释说明库”（名词解释、场景限定、其他说明）
"""

import os
import json
import re
import copy
import argparse
import datetime
import random
import string
from typing import List, Dict, Any, Optional, Tuple

from openpyxl import load_workbook
from tqdm import tqdm
from collections import defaultdict


def load_param_dict(dict_path: str) -> Dict[str, str]:
    """加载参数字典，将中文参数名(B列)映射到业务入参字段(D列)。

    如果D列为空，则仍然建立映射但值为空字符串；后续在生成测试数据时
    只要能在该字典中找到中文参数名即可视为匹配成功。
    """
    if not os.path.exists(dict_path):
        raise FileNotFoundError(f"参数字典文件不存在: {dict_path}")

    wb = load_workbook(dict_path, read_only=True, data_only=True)
    ws = wb.active

    cn_to_en: Dict[str, str] = {}

    # 从第2行开始读取（第1行是表头）
    for row in ws.iter_rows(min_row=2):
        cn_name = row[1].value if len(row) > 1 else None  # B列：参数中文名
        biz_field = row[3].value if len(row) > 3 else None  # D列：业务入参字段

        if not cn_name:
            continue

        cn_str = str(cn_name).strip()
        if not cn_str:
            continue

        value = ""
        if biz_field:
            value = str(biz_field).strip()

        cn_to_en[cn_str] = value

    wb.close()
    print(f"成功加载参数字典: {len(cn_to_en)} 个参数")

    return cn_to_en


def load_dashscope_config() -> str:
    """从 dashscope_config.json 读取 API KEY（如果存在）。

    返回：api_key 字符串，如不存在或读取失败则返回空字符串。
    """
    config_path = os.path.join(os.getcwd(), "dashscope_config.json")
    if not os.path.exists(config_path):
        return ""
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        return cfg.get("api_key", "") or ""
    except Exception:
        return ""


def parse_param_candidates(text: Any) -> List[str]:
    """解析 H 列参数清单为参数候选列表。

    支持的分隔符：逗号、分号、换行等。
    """
    if not text:
        return []

    raw = str(text)
    parts = re.split(r"[,，;；\n\r\t]+", raw)
    params = [p.strip() for p in parts if p.strip()]
    return params


def get_merged_cell_value(ws, row_idx: int, col_idx: int) -> Tuple[Any, int, int]:
    """获取合并单元格的值和范围
    
    Args:
        ws: worksheet对象
        row_idx: 行索引（1-based）
        col_idx: 列索引（1-based）
        
    Returns:
        (单元格值, 合并起始行, 合并结束行)
    """
    cell = ws.cell(row_idx, col_idx)
    
    # 检查是否是合并单元格
    for merged_range in ws.merged_cells.ranges:
        if cell.coordinate in merged_range:
            # 获取合并区域的左上角单元格值
            min_row = merged_range.min_row
            min_col = merged_range.min_col
            max_row = merged_range.max_row
            value = ws.cell(min_row, min_col).value
            return value, min_row, max_row
    
    # 不是合并单元格
    return cell.value, row_idx, row_idx



def estimate_condition_count(rule_desc: str) -> int:
    """估算F列规则描述中的条件数量
    
    根据条件编号、中括号、分号、"或"、"且"等特征估算条件数量。
    优先识别F列中明确的条件编号（如：条件1、条件2、条件3）。
    
    Args:
        rule_desc: F列规则描述
        
    Returns:
        估算的条件数量
    """
    if not rule_desc:
        return 0
    
    # 移除注释说明部分（以"注："、"说明："、"备注："开头的内容）
    desc_lines = rule_desc.split('\n')
    clean_lines = []
    for line in desc_lines:
        line_stripped = line.strip()
        if line_stripped.startswith(('注：', '说明：', '备注：', '注:', '说明:', '备注:')):
            continue
        clean_lines.append(line)
    
    clean_desc = '\n'.join(clean_lines)
    
    # 优先级1：识别明确的条件编号，例如："条件1"、"条件2"、"条件3"
    condition_numbers = set()
    # 匹配模式：条件 + 数字，或者 [条件数字]
    condition_pattern = re.findall(r'[\[【]?条件\s*(\d+)[\]】]?', clean_desc)
    for num_str in condition_pattern:
        condition_numbers.add(int(num_str))
    
    if condition_numbers:
        # 如果找到明确的条件编号，返回最大编号（条件1~条件N，则有N个条件）
        return max(condition_numbers)
    
    # 优先级2：统计中括号对数（每对通常对应一个完整条件）
    bracket_count = min(clean_desc.count('['), clean_desc.count(']'))
    if bracket_count > 0:
        # 如果使用中括号显式列出了条件边界，则以中括号对数为准
        return bracket_count
    
    # 优先级3：统计分号数量（每个分号通常分隔一个条件）
    semicolon_count = clean_desc.count('；') + clean_desc.count(';')
    if semicolon_count > 0:
        return semicolon_count + 1
    
    # 优先级4：统计"或"的数量
    or_count = clean_desc.count('或')
    if or_count > 0:
        return or_count + 1
    
    # 优先级5：统计"且"的数量
    and_count = clean_desc.count('且')
    if and_count > 0:
        return and_count + 1
    
    # 默认至少有1个条件
    return max(1, 0)


def generate_metric_identifiers(rule_desc: str, count: Optional[int] = None) -> List[str]:
    """为空G列生成指标标识
    
    分析F列规则描述，拆解条件数量，为每个条件生成唯一的指标标识。
    指标标识格式：AUTO_{6位随机字母数字}，如 AUTO_A1B2C3
    
    Args:
        rule_desc: F列规则描述
        count: 指定生成数量，如果为None则自动估算
        
    Returns:
        指标标识列表，如 ['AUTO_A1B2C3', 'AUTO_D4E5F6']
    """
    import random
    import string
    
    if not rule_desc:
        return []
    
    # 生成随机指标标识
    def _generate_id() -> str:
        chars = string.ascii_uppercase + string.digits
        random_part = ''.join(random.choice(chars) for _ in range(6))
        return f"AUTO_{random_part}"
    
    # 确定条件数量
    if count is None:
        condition_count = estimate_condition_count(rule_desc)
    else:
        condition_count = count
    
    # 限制最大条件数（避免生成过多）
    condition_count = min(condition_count, 10)
    condition_count = max(condition_count, 1)
    
    # 生成指标标识列表
    metric_ids = [_generate_id() for _ in range(condition_count)]
    
    return metric_ids


def generate_scene_application_name(d_column_value: str, k_json: Dict[str, Any]) -> str:
    """生成场景应用名称（N列）
    
    读取K列JSON中的'场景名称'字段，与D列内容进行拼接。
    格式：D列内容 + "_" + 场景名称
    
    Args:
        d_column_value: D列（规则编号）的值
        k_json: K列的JSON对象（包含场景信息）
        
    Returns:
        场景应用名称字符串，例如："301401001_全部命中"
    """
    if not k_json:
        return ""
    
    # 获取D列值，如果为空则使用空字符串
    d_value = str(d_column_value).strip() if d_column_value else ""
    
    # 从K列JSON中读取场景信息
    scene = k_json.get("场景", {})
    if not scene:
        return d_value if d_value else ""
    
    # 获取场景名称
    scene_name = scene.get("场景名称", "")
    if not scene_name:
        scene_name = scene.get("场景序号", "")
        if scene_name:
            scene_name = f"场景{scene_name}"
    
    # 拼接D列值和场景名称
    if d_value and scene_name:
        return f"{d_value}_{scene_name}"
    elif d_value:
        return d_value
    elif scene_name:
        return scene_name
    else:
        return ""


def call_dashscope_for_condition_json(
    api_key: str,
    rule_desc: str,
    metric_codes: List[str],
    param_candidates: List[str],
) -> Dict[str, Any]:
    """调用 DashScope，将 F 列规则 + G 列指标标识拆分为条件 JSON。

    返回：
        符合要求的 JSON 对象（dict）。如调用失败或解析失败，返回空 dict。
    """
    if not rule_desc or not metric_codes:
        return {}

    try:
        from dashscope import Generation
        import dashscope
    except Exception as e:
        print(f"[错误] 导入 dashscope SDK 失败: {e}")
        return {}

    dashscope.api_key = api_key

    codes_text = "\n".join(metric_codes)
    params_text = "\n".join(param_candidates) if param_candidates else "(无参数清单)"

    # 构造 Prompt：强调条件拆分三原则（语义、断句符号、括号），强调条件数量 = 指标数量
    query = f"""你是一个反洗钱/风控规则理解和拆分专家，现在要对一行规则进行条件拆分，用于后续和各个指标标识一一对应。

【输入信息】
- 规则描述（F列原文）：
{rule_desc}

- 指标标识列表（G列，顺序与规则一致，多个换行分隔）：
{codes_text}

- 规则集参数清单（H列，供识别条件中涉及到的参数）：
{params_text}

【条件拆分三原则】⭐️ 核心规则，必须严格遵守
在拆分条件时，你必须依次结合以下三个特点进行精准断句和条件划分：

1. **条件编号优先（最高优先级）**：
   - **如果F列规则描述中已经明确标注了条件编号（如：条件1、条件2、条件3），必须严格按照这些条件编号进行拆分**；
   - 每个条件编号对应一个条件，条件数量必须与G列指标标识数量一致；
   - 如果条件编号数量与指标标识数量不等，请报告错误；
   - 示例：
     * F列："【条件1】7天内，登录次数>=3；【条件2】同一IP地址登录失败次数<5"
     * G列：2个指标标识
     * 拆分结果：条件1、条件2 → 2个条件

2. **语义理解（第二优先级）**：
   - 每个条件必须是一个完整的、独立的判断单元，包含：主体对象 + 统计维度 + 阈值比较；
   - 例如："同一设备ID登录次数>=40" 是一个完整条件；
   - 不能把"登录次数>=40"和"登录失败次数>=20"合并成一个条件，它们是两个不同的统计指标；
   - 如果一句话中包含多个不同的统计维度（如"登录次数"和"登录失败次数"），必须拆分成多个条件。

3. **断句符号识别（第三优先级）** - 关键标志：
   - **分号（；）：强烈的条件分隔信号**，分号前后通常是独立条件；
   - **中括号【】或 []：条件边界的明确标志**，每个中括号通常包裹一个完整条件；
   - 换行符（\n）：通常表示条件边界，但需结合语义判断；
   - "或"、"且"：明确的逻辑连接词，连接不同条件；
   - 逗号（，）：可能是条件内部的修饰，也可能是条件之间的分隔，需结合语义判断；
   - 顿号（、）：通常是并列修饰，不是条件分隔符。

4. **括号层级分析（第四优先级）**：
   - **如果原文已经用【】或 [] 划分了条件边界，优先尊重这个划分**；
   - 括号内的"或"/"且"表示内部逻辑，可能对应一个或多个条件；
   - 例如："条件A；且【条件B或条件C】"中，分号和中括号明确提示这是两个条件的边界。

【拆分示例】
示例1（有中括号标记）：
原文："60分钟内，同一设备ID关联注册成功登录账号个数>=3\n或\n24小时内，同一设备ID关联注册成功登录账号个数>=5"
指标数：2个
正确拆分：
- 条件1："[60分钟内，同一设备ID关联注册成功登录账号个数>=3]" ← "或"前的完整语义单元
- 条件2："[24小时内，同一设备ID关联注册成功登录账号个数>=5]" ← "或"后的完整语义单元
关系：条件1 或 条件2

示例2（有分号和中括号）：
原文："60分钟内，\n同一设备ID登录次数>=40\n且登录失败次数>=20；\n且关联登录账号>=8"
指标数：3个
分析：分号前有两个统计维度（登录次数、登录失败次数），分号后有一个统计维度（关联登录账号）
正确拆分：
- 条件1："[60分钟内，同一设备ID登录次数>=40]" ← 第一个独立统计维度
- 条件2："[60分钟内，同一设备ID登录失败次数>=20]" ← 第二个独立统计维度
- 条件3："[60分钟内，同一设备ID关联登录账号>=8]" ← 分号后的统计维度
关系：条件1 且 条件2 且 条件3

示例3（嵌套中括号）：
原文："2小时内，\n同一银行卡在23点累计成功转账金额>=渠道单日限额*90%；\n且当前笔非同名陌生账户转账事件发生小时等于0点；\n且【单笔交易金额>=10000或0点累计向非同名陌生账户成功转账金额>=45000】"
指标数：2个
分析：
- 第一个分号前：一个完整条件（23点累计成功转账金额）
- 第一个分号后到第二个分号前：一个条件片段（事件发生小时等于0点）
- 第二个分号后的中括号内：嵌套逻辑（单笔金额 或 累计金额）
- 由于指标数是2个，需要将"事件发生小时等于0点"和后面的中括号嵌套部分合并为一个条件
正确拆分：
- 条件1："[2小时内，同一银行卡在23点累计成功转账金额>=渠道单日限额*90%]"
- 条件2："[2小时内，当前笔非同名陌生账户转账事件发生小时等于0点，且【单笔交易金额>=10000或0点累计向非同名陌生账户成功转账金额>=45000】]"
关系：条件1 且 条件2
嵌套：条件2标记"是否嵌套"="是"

【任务目标】
1. 你需要把 F 列规则描述拆分成若干个"条件"，并且**条件数量必须与指标标识数量完全一致**。
   - 第 1 个条件对应指标标识列表中的第 1 个指标；
   - 第 2 个条件对应第 2 个指标；
   - 依此类推。
2. **在拆分前，请先仔细阅读规则描述，运用"条件拆分三原则"逐句分析**：
   - 识别有多少个独立的统计维度（每个统计维度通常对应一个条件）；
   - 识别逻辑连接词（或/且）的位置和层级；
   - 识别括号结构，判断是否存在嵌套。
3. 如果你第一次理解时条件数量与指标标识数量不相等，必须重新审视规则描述，调整你的拆分方式，直到两者数量完全相等为止。
4. 每个条件的"条件描述"中必须同时包含：
   - 时间范围（例如"60分钟内"、"24小时内"，或者规则开头共享的时间前提）；
   - 规则内容（涉及的对象，如"同一设备ID登录次数"、"同一IP登录失败次数"等）；
   - 阈值比较（例如">=3"、"<5"、">=40"等）。
   你可以使用中括号将完整条件包裹，如：[60分钟内，同一设备ID登录次数>=3]。
   - 特别说明：对于"90天内剔除3天"、"N天内剔除M天"这类描述，必须理解为**剔除的是最近的M天数据**，即统计窗口为前N天但不包含最近M天。
. **每个条件的"参数列表"必须从 H 列参数清单中识别该条件实际用到的参数**：
   - 仔细分析该条件的描述文本，识别其中涉及的所有参数；
   - 只能从H列参数清单中选择参数，参数名称必须与H列中的名称完全一致；
   - **【极其重要】业务语义强制识别规则**：
     * **涉及"交易"的条件，参数列表必须包含"客户编号"参数**（因为交易是客户之间的行为）；
     * 关键词识别：“交易”、“交易时间”、“交易金额”、“交易成功”、“转账”、“支付”、“提现”等；
     * 示例：
       - “当前笔**交易**时间发生在[0，5]点范围内” → 必须包含"客户编号"；
       - “同一客户在[0，5]点该类**交易**成功的次数” → 必须包含"客户编号"；
       - “**转账**金额>=10000” → 必须包含"客户编号"；
   - **智能识别中英文参数映射**：
     * 如果条件中提到中文简称，需要匹配到H列中的完整英文参数名称；
     * 示例映射：
       - 条件中的"IP" → H列中的"IP Address"
       - 条件中的"IP地址" → H列中的"IP Address"
       - 条件中的"设备" → H列中的"Device ID"
       - 条件中的"设备ID" → H列中的"Device ID"
       - 条件中的"账号" → H列中的"Account ID" 或 "Account Number"
       - 条件中的"客户" → H列中的"客户编号" 或 "Customer ID"
     * 匹配原则：
       - 优先完全匹配（如"设备ID"匹配到包含"Device"和"ID"的参数）；
       - 其次进行模糊匹配（如"IP"可能匹配到"IP Address"或"IP 地址"）；
       - 如果无法匹配，使用条件中出现的原始名称。
   - 返回格式为数组：["参数1", "参数2"]；
   - 如果条件涉及时间计算（如"60分钟内"、"24小时内"），必须包含"业务发生时间"参数（如果H列中有）；
   - 不同条件可能用到不同的参数，每个条件要单独分析。
6. 条件之间的"或/且"逻辑关系必须延用 F 列原文中的关系：
   - 如果原文中是"条件1 且 条件2 或 条件3"，你需要判断每个条件与"上一个条件"的关系是"且"还是"或"；
   - 第一条条件的"与上一个指标关系"统一填写为"起始"。
7. 对于规则中的注释说明部分（包括但不限于以下形式）需要单独拆分出来总结，形成“注释说明库”：
   - 以“注：”“备注：”“说明：”开头的句子；
   - 括号中的名词解释或场景限定；
   - 其他不直接参与阈值判断、但用于解释场景/名词/适用范围的文字。
   
   **注释分类与影响判断（重要）**：
   你需要把这些注释按照以下6大类进行分类，并智能判断其是否影响测试数据生成：
   
   **1、业务约束类**：
      - 定义：说明业务规则、系统限制、初始状态等
      - 判断逻辑：**需要分析是否限制数据取值、初始状态等**
      - 示例：
        * “未勾选事中，做第一笔交易时，以上指标结果为0” → 影响（需要初始值为0）
        * “规则仅适用于企业客户” → 不影响（仅限定适用范围）
   
   **2、范围限定类**：
      - 定义：说明数据范围、排除条件、适用场景
      - 判断逻辑：**必定影响测试数据**
      - 示例：
        * “排除局域网IP地址” → 影响（需过滤IP范围）
        * “仅统计非同名转账” → 影响（需限制转账类型）
   
   **3、名词定义类**：
      - 定义：解释专业术语、业务概念
      - 判断逻辑：**判断是否涉及数据状态特征**
      - 示例：
        * “陌生设备ID定义为最近90天未登录” → 影响（需生成特殊状态数据）
        * “交易渠道包括手机银行、ATM、柜面” → 不影响（仅枚举说明）
   
   **4、计算规则类**：
      - 定义：说明指标计算方式、统计口径
      - 判断逻辑：**必定影响测试数据**
      - 示例：
        * “账户余额为当笔交易前账户余额” → 影响（需按交易前计算）
        * “成功次数包含当前笔” → 影响（需调整计数逻辑）
   
   **5、数据来源类**：
      - 定义：说明数据获取方式、解析规则
      - 判断逻辑：**需要智能判断**
        * 如果仅说明数据获取渠道/方式 → 不影响
        * 如果涉及数据格式、校验规则、取值规则 → 影响
      - 示例：
        * “通过银行卡bin解析归属省份” → 不影响（仅说明来源）
        * “证件号码需符合18位身份证校验规则” → 影响（需校验格式）
        * “手机号码必须为11位数字” → 影响（限制格式）
   
   **6、补充说明类**：
      - 定义：其他辅助性说明、配置建议
      - 判断逻辑：**需要智能判断**
        * 如果仅是配置建议、注意事项 → 不影响
        * 如果涉及白名单排除、特殊处理逻辑 → 影响
      - 示例：
        * “必要时可以加白排除” → 不影响（仅建议）
        * “客户白名单用户需排除，白名单包括VIP客户、内部员工” → 影响（需排除特定数据）
        * “剔除代发工资交易” → 影响（需过滤数据）
   
   **注释说明库输出结构**：
   对于每个注释，你需要输出：
   - 注释编号：从 1 开始递增的整数（如 1, 2, 3...）
   - 注释类型：在 {{"业务约束", "范围限定", "名词定义", "计算规则", "数据来源", "补充说明"}} 中选择最合适的一类
   - 注释内容：保留原意，适当去掉多余口语
   - 影响范围："全局" 或 "条件1" 或 "条件2" ...（分析注释作用于哪些条件）
   - 影响测试数据：true 或 false（根据上述判断逻辑确定）
   - 如果影响测试数据=true，还需输出：
     * 数据生成约束：{{
         "约束类型": "初始值约束/值过滤约束/值排除约束/名词定义约束/计算逻辑约束/格式校验约束",
         "约束描述": "详细的约束说明，Python函数可理解",
         "Python规则标识": "snake_case格式的标识符，如 exclude_lan_ip"
       }}
   - 如果影响测试数据=false，输出：
     * 说明性质：简要描述（如“数据获取方式说明”、“配置建议”等）
8. 如果规则中存在括号等形式的嵌套（例如 (条件A 且 条件B) 或 条件C），请在对应条件的"是否嵌套"中标记"是"，否则标记"否"。

【输出要求】
1. 只返回**合法 JSON**，不能包含任何多余的自然语言说明。
2. 所有 JSON 的 key 必须使用英文双引号包裹，value 也必须是合法 JSON 值。
3. 顶层 JSON 结构必须严格符合下面的模板（key 名可以直接拷贝）：

{{
  "条件数量": n,
  "条件列表": [
    {{
      "条件序号": 1,
      "指标标识": "第1个指标标识（如 METRIC001）",
      "条件描述": "...[条件1完整描述，包括时间范围 + 规则内容 + 阈值]...",
      "参数列表": ["参数1", "参数2"],
      "与上一个指标关系": "起始",
      "是否嵌套": "是" 或 "否"
    }},
    {{
      "条件序号": 2,
      "指标标识": "第2个指标标识（如 METRIC002）",
      "条件描述": "...[条件2完整描述，包括时间范围 + 规则内容 + 阈值]...",
      "参数列表": ["参数1"],
      "与上一个指标关系": "且" 或 "或",
      "是否嵌套": "是" 或 "否"
    }},
    ...
  ],
  "注释说明库": {{
    "注释数量": m,
    "作用范围": "整条规则",
    "注释列表": [
      {{
        "注释编号": 1,
        "注释类型": "业务约束" 或 "范围限定" 或 "名词定义" 或 "计算规则" 或 "数据来源" 或 "补充说明",
        "注释内容": "...",
        "影响范围": "全局" 或 "条件1" 或 "条件2" ...,
        "影响测试数据": true 或 false,
        "数据生成约束": {{  // 仅当影响测试数据=true时存在
          "约束类型": "初始值约束/值过滤约束/值排除约束/名词定义约束/计算逻辑约束/格式校验约束",
          "约束描述": "详细的约束说明，Python函数可理解",
          "Python规则标识": "snake_case格式的标识符"
        }},
        "说明性质": "..."  // 仅当影响测试数据=false时存在
      }},
      ...
    ]
  }},
  "I列公共字段": {{}}
}}

4. 其中：
   - n 必须等于指标标识的数量（即 G 列拆分出的个数）；
   - "条件列表" 中的第 1 个元素对应输入指标列表中的第 1 个指标，第 2 个元素对应第 2 个，以此类推；
   - 每个元素的 "指标标识" 字段必须与 G 列中的某个指标完全一致；
   - **每个元素的 "参数列表" 必须是从 H 列参数清单中识别出的、该条件实际用到的参数数组**；
   - 你可以在每个"条件描述"中显式写出对应的指标标识，帮助后续人工校验。

**参数识别示例**：
假设 H 列参数清单为：["设备ID", "账号", "IP地址", "业务发生时间"]
- 条件："60分钟内，同一设备ID登录次数>=3"
  → 参数列表应为：["设备ID", "业务发生时间"]
- 条件："24小时内，同一IP地址登录失败次数<5"
  → 参数列表应为：["IP地址", "业务发生时间"]
- 条件："同一账号关联设备数>=2"（无时间限定）
  → 参数列表应为：["账号", "设备ID"]

请严格按照上述要求返回 JSON。"""

    try:
        response = Generation.call(
            model="qwen-plus",
            prompt=query,
            result_format="message",
            timeout=60,  # 设置超时时间为60秒
        )
    except Exception as e:
        print(f"[错误] DashScope 调用失败: {e}")
        return None

    out = getattr(response, "output", None)
    if not out or not hasattr(out, "choices") or not out.choices:
        print("[错误] 大模型响应格式异常，无有效内容")
        return None

    text = out.choices[0].message.content

    # 尝试直接解析 JSON
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
    except json.JSONDecodeError:
        pass

    # 尝试从 markdown 代码块中提取 JSON（常见格式：```json ... ```）
    import re
    json_match = re.search(r'```(?:json)?\s*\n(.*?)\n```', text, re.DOTALL)
    if json_match:
        json_str = json_match.group(1).strip()
        try:
            data = json.loads(json_str)
            if isinstance(data, dict):
                print(f"[提示] 从 markdown 代码块中成功提取 JSON")
                return data
        except json.JSONDecodeError:
            pass

    # 解析失败时返回 None（明确表示失败）
    print(f"[警告] 大模型返回内容不是合法 JSON")
    print(f"[原始返回内容] {text[:500]}...")  # 打印前500字符用于调试
    return None


def call_dashscope_for_scenarios(
    api_key: str,
    rule_json: Dict[str, Any],
    param_cn_to_en: Dict[str, str],
) -> Optional[Dict[str, Any]]:
    """调用 DashScope 基于规则拆分 JSON 生成场景设计（K 列 JSON）。

    关键要求：
    - 场景数量 = 条件命中/未命中的笛卡尔积组合（2^N 种，N 为条件数量）
    - 每个场景必须明确每个条件的"是否命中"和对应的"指标值"
    - 根据条件是否命中，动态调整"场景比较符号"（命中保持原符号，未命中翻转）

    返回：
        符合约定结构的 JSON 对象（dict），失败时返回 None。
    """
    if not rule_json:
        return None

    try:
        from dashscope import Generation
        import dashscope
    except Exception as e:
        print(f"[错误] 导入 dashscope SDK 失败(场景生成): {e}")
        return None

    dashscope.api_key = api_key

    rule_json_text = json.dumps(rule_json, ensure_ascii=False, indent=2)

    # 提取条件数量用于场景枚举说明
    cond_list = rule_json.get("条件列表", [])
    cond_count = len(cond_list)

    # 将部分参数字典展开给大模型参考
    if param_cn_to_en:
        items_preview = []
        for idx, (cn, en) in enumerate(param_cn_to_en.items()):
            if idx >= 30:
                break
            en_display = en or "(D列为空，业务入参字段未配置)"
            items_preview.append(f"- {cn} -> {en_display}")
        param_dict_text = "\n".join(items_preview)
    else:
        param_dict_text = "(无参数字典)"

    query = f"""你是一个反洗钱/风控测试场景设计专家，现在要基于一条规则的"条件拆分 JSON"根据触发条件关系(and/or)生成所有可能的命中场景。

【规则拆分JSON（来自J列）】
{rule_json_text}

【参数字典（中文参数名 -> 业务入参字段D列，部分预览）】
{param_dict_text}

【核心任务】
你需要根据规则描述中的触发条件关系智能生成场景。

**场景生成策略（智能识别触发关系）**：

1. **分析F列规则描述中的触发条件关系**：
   - 从规则拆分JSON中读取原始F列规则描述；
   - 识别条件之间的逻辑关系：
     * "或" → OR 关系
     * "且" → AND 关系
     * 括号 ()、【】、[] → 逻辑嵌套
   - 示例分析：
     * "(条件1 or 条件2) and 条件3" → 嵌套逻辑：(1 OR 2) AND 3
     * "条件1 and 条件2" → 简单AND：1 AND 2
     * "条件1 or 条件2" → 简单OR：1 OR 2

2. **根据逻辑关系生成场景**：
   
   **情形1：全AND关系**（如：条件1 and 条件2 and 条件3）
   - 生成 2^N 个场景（N=条件数），枚举所有命中/未命中组合：
     * 场景1：所有条件都命中（场景名称："全部命中"）
     * 场景2：条件1命中，其余未命中
     * 场景3：条件2命中，其余未命中
     * ...
     * 场景N：所有条件都不命中（场景名称："全部未命中"）
   
   **情形2：全OR关系**（如：条件1 or 条件2 or 条件3）
   - 生成 N+1 个场景（N=条件数）：
     * 场景1：条件1命中（其余可以命中或不命中，但至少有条件1命中）
     * 场景2：条件2命中（其余可以命中或不命中，但至少有条件2命中）
     * ...
     * 场景N+1：所有条件都不命中（场景名称："全部未命中"）
   - **注意**：OR关系下，只要任意一个条件命中，规则就触发，因此需要为每个条件单独生成一个场景。
   
   **情形3：混合关系**（如：(条件1 or 条件2) and 条件3）
   - 首先分析嵌套结构：
     * 内层：条件1 or 条件2 → 至少一个命中即可
     * 外层：AND 条件3 → 条件3必须命中
   - 生成场景：
     * 场景1：条件1命中 + 条件3命中（条件2任意）
     * 场景2：条件2命中 + 条件3命中（条件1任意）
     * 场景3：条件1和条件2都不命中 + 条件3命中
     * 场景4：条件3不命中（无论条件1/条件2如何）
   - 需要智能递归处理嵌套逻辑，生成所有可能的有效组合。

3. **场景命名规则**：
   - 全部命中："全部命中"
   - 全部未命中："全部未命中"
   - 部分命中："条件1命中"、"条件2命中"、"条件1+条件2命中" 等
   - 使用简洁清晰的描述，让人一眼看出哪些条件命中。

**比较符号动态调整规则（关键！）**：
- 原始条件描述中的比较符号（如 ">="、"<"）代表"命中"时的符号。
- **特殊场景识别与处理（重要）**：
  对于没有明确比较符号的场景，需要识别并生成对立场景：
  
  **1. 命中类场景**（包含"命中"、"在黑名单"、"在白名单"等）：
    - 原始描述："注册设备ID命中设备ID黑名单"
    - 场景拆分：
      * 命中场景："注册设备ID命中设备ID黑名单" → 条件是否命中=true
      * 未命中场景："注册设备ID未命中设备ID黑名单" → 条件是否命中=false
    - 指标值示例：
      * 命中：1（表示在黑名单中）
      * 未命中：0（表示不在黑名单中）
  
  **2. 范围类场景**（包含"在...之间"、"在...范围"等）：
    - 原始描述："事件发生小时在[0,5]点之间"
    - 场景拆分：
      * 在范围场景："事件发生小时在[0,5]点之间" → 条件是否命中=true
      * 不在范围场景："事件发生小时不在[0,5]点之间" → 条件是否命中=false
    - 指标值示例：
      * 在范围：3（在[0,5]之间的值）
      * 不在范围：12（不在[0,5]之间的值）
  
  **3. 等于类场景**（包含"为"、"等于"等）：
    - 原始描述："登录次数为0"
    - 场景拆分：
      * 等于场景："登录次数为0" → 条件是否命中=true
      * 不等于场景："登录次数不为0" → 条件是否命中=false
    - 指标值示例：
      * 等于：0
      * 不等于：5（任意非0值）

- 对于常规比较符号场景，在每个场景中，根据"条件是否命中"调整"场景比较符号"：
  * 如果"条件是否命中"=true → "场景比较符号" = "原始比较符号"（保持不变）
  * 如果"条件是否命中"=false → "场景比较符号" = "原始比较符号的反向"：
    - ">=" → "<"
    - ">" → "<="
    - "<=" → ">"
    - "<" → ">="
    - "==" 或 "=" → "!="
    - "!=" → "=="

**指标值生成规则**：
- 每个场景的每个条件需要给出“指标值示例”（用于后续 Python 生成测试数据）：
  * 如果“条件是否命中”=true：指标值应该满足“原始比较符号 + 原始阈值”
    例如：原始条件“>=3”且命中 → 指标值可以是 3、4、5 等
  * 如果“条件是否命中”=false：指标值应该满足“场景比较符号 + 原始阈值”
    例如：原始条件“>=3”但未命中 → 场景比较符号为“<” → 指标值可以是 0、1、2 等

**指标类型识别与规则输出**：
- 需要根据条件描述理解判断指标类型，常见类型包括：
  * "次数/条数"：计数类型，如“登录次数”、“交易笔数”等
  * "金额"：货币类型，如“交易总金额”、“预付费金额”等
  * "比例/占比"：百分比类型，如“失败率”、“占总交易的比例”等
  * "时间"：时间类型，如“时间间隔”、“持续时长”等
- 一个条件只会有一种指标类型，在“指标值规则”中只输出对应类型的规则：
  * 次数/条数类型→只输出“条数规则”：{{ "生成总条数", "命中条数", "未命中条数" }}
  * 金额类型→只输出“金额规则”：{{ "阈值数值", "命中值策略", "未命中值策略" }}
  * 比例类型→只输出“比例规则”：{{ "阈值数值", "命中值策略", "未命中值策略" }}
  * 不要同时输出多种类型的规则

**注释说明的应用（重要新增）**：
- 在生成“条件状态列表”时，必须考虑注释说明库中的约束：

1. **关联注释到条件**：
   - 检查每个注释的“影响范围”
   - 如果是“全局”，应用到所有条件
   - 如果是“条件N”，只应用到对应条件

2. **生成测试数据生成约束字段**：
   为每个条件添加“测试数据生成约束”字段，包含：
   
   - 应用注释编号列表：列出所有影响该条件且“影响测试数据=true”的注释编号
   - 参数值约束：对于每个参数，如果有注释对其约束，生成如下结构：
     {{
       "参数名": {{
         "约束来源": "注释N-类型",
         "约束类型": "值过滤/值排除/特定格式/初始状态",
         "约束规则": "详细说明",
         "Python规则": "直接复用J列注释中的Python规则标识"
       }}
     }}
   - 指标值约束：如果有注释对指标值约束（如初始值、计算规则），生成：
     {{
       "约束来源": "注释N-类型",
       "约束类型": "初始值/计算方式/取值范围",
       "约束规则": "详细说明",
       "Python规则": "直接复用J列注释中的Python规则标识"
     }}
   - 数据数量约束：基于指标值规则生成，保持现有逻辑

3. **约束规则的Python化**：
   确保每个约束规则都配有：
   - 清晰的约束描述（中文）
   - Python可识别的规则标识（直接使用J列注释中的“Python规则标识”）
   - 必要时包含具体的取值范围或正则表达式

**示例：如何应用注释约束**
如果注释说明库中有范围限定类注释（如“排除局域网IP地址”），且其Python规则标识为exclude_lan_ip，
则在生成条件状态列表时，应在测试数据生成约束字段中添加该注释的约束信息，包括应用注释编号列表、参数值约束（包含约束来源、约束类型、排除规则、Python规则）、指标值约束、数据数量约束。

**输出JSON结构要求**：
{{
  "规则编号": "（可选，从输入中找不到可置为空字符串）",
  "条件模板": {{
    "条件数量": {cond_count},
    "条件列表": [ ...直接复用输入JSON中的条件列表... ]
  }},
  "注释说明库": {{ ...直接复用输入JSON... }},
  "I列公共字段": {{ ...直接复用输入JSON... }},
  "场景列表": [
    {{
      "场景序号": 1,
      "场景名称": "全部命中",
      "场景描述": "所有条件都满足命中条件的场景",
      "条件状态列表": [
        {{
          "条件序号": 1,
          "指标标识": "（从条件模板中获取该条件的指标标识）",
          "条件是否命中": true,
          "参数类型": "次数" 或 "金额" 或 "时间" 或 "比例" 或 "其他",
          "原始比较符号": ">=",
          "原始阈值表达式": "3",
          "场景比较符号": ">=" （因为命中=true，所以保持原符号）,
          "场景命中含义": "次数大于等于3表示命中",
          "指标值示例": 3 （或略大于阈值的值，如4、5）,
          "指标值规则": {{
            "指标类型": "次数/条数",
            "条数规则": {{
              "生成总条数": 3,
              "命中条数": 3,
              "未命中条数": 0,
              "条数分布说明": "生成3条满足条件的记录"
            }}
          }},
          "参与统计的参数列表": ["设备ID", "登录账号", "业务发生时间"] （***重要：必须完整复制输入JSON中该条件的"参数列表"，不能缺失***）,
          "备注": ""
        }},
        {{
          "条件序号": 2,
          "指标标识": "（从条件模板中获取）",
          "条件是否命中": true,
          "参数类型": "次数",
          "原始比较符号": ">=",
          "原始阈值表达式": "5",
          "场景比较符号": ">=" （命中=true，保持原符号）,
          "场景命中含义": "次数大于等于5表示命中",
          "指标值示例": 5,
          "指标值规则": {{
            "指标类型": "次数/条数",
            "条数规则": {{
              "生成总条数": 5,
              "命中条数": 5,
              "未命中条数": 0
            }}
          }},
          "参与统计的参数列表": ["设备ID", "登录账号", "业务发生时间"] （***必须与输入JSON中该条件的"参数列表"一致***）,
          "备注": ""
        }}
      ],
      "场景整体是否命中": true （根据条件间"且/或"关系计算）
    }},
    {{
      "场景序号": 2,
      "场景名称": "条件1命中条件2未命中",
      "场景描述": "条件1满足，条件2不满足的场景",
      "条件状态列表": [
        {{
          "条件序号": 1,
          "指标标识": "...",
          "条件是否命中": true,
          "参数类型": "次数",
          "原始比较符号": ">=",
          "原始阈值表达式": "3",
          "场景比较符号": ">=" （命中=true，保持原符号）,
          "场景命中含义": "次数大于等于3表示命中",
          "指标值示例": 3,
          "指标值规则": {{
            "指标类型": "次数/条数",
            "条数规则": {{ "生成总条数": 3, "命中条数": 3, "未命中条数": 0 }}
          }},
          "参与统计的参数列表": [...] （与J列一致）,
          "备注": ""
        }},
        {{
          "条件序号": 2,
          "指标标识": "...",
          "条件是否命中": false,
          "参数类型": "次数",
          "原始比较符号": ">=",
          "原始阈值表达式": "5",
          "场景比较符号": "<" （命中=false，符号翻转：">="→"<"）,
          "场景命中含义": "次数小于5表示未命中",
          "指标值示例": 4 （小于阈值5）,
          "指标值规则": {{
            "指标类型": "次数/条数",
            "条数规则": {{
              "生成总条数": 4,
              "命中条数": 0,
              "未命中条数": 4,
              "条数分布说明": "生成4条不满足条件的记录"
            }}
          }},
          "参与统计的参数列表": [...] （与J列一致）,
          "备注": ""
        }}
      ],
      "场景整体是否命中": true 或 false （根据"且/或"关系和条件1、2的命中状态计算）
    }},
    ...（继续枚举剩余 {2**cond_count - 2} 个场景）
  ]
}}

**重要提示**：
1. 必须枚举 **{2**cond_count} 个场景**，覆盖所有条件命中/未命中的组合。
2. 每个场景的“条件状态列表”中，“条件是否命中”和“场景比较符号”必须严格对应：
   - 命中=true → 场景比较符号 = 原始比较符号
   - 命中=false → 场景比较符号 = 原始比较符号的反向
3. “指标值示例”必须与“场景比较符号”和“原始阈值表达式”匹配。
4. 每个场景中必须包含该条件对应的“指标标识”（从条件模板的条件列表中获取）。
5. ***关键：每个条件的“参与统计的参数列表”必须完整复制输入JSON中该条件的“参数列表”，不能缺失任何参数***。
6. ***严禁在场景内部添加“公共字段生成规则”，该信息已在顶层定义***。
7. ***指标类型识别：需要根据条件描述理解判断指标类型（次数、条数、金额、比例、占比、时间等），一个条件只会有一种指标类型，只输出对应类型的规则，不要同时输出多种类型的规则***。
8. 只返回合法JSON，不要包含任何markdown标记或额外说明文字。
"""

    try:
        response = Generation.call(
            model="qwen-plus",
            prompt=query,
            result_format="message",
            timeout=60,  # 设置超时时间为60秒
        )
    except Exception as e:
        print(f"[错误] DashScope 调用失败(场景生成): {e}")
        return None

    out = getattr(response, "output", None)
    if not out or not hasattr(out, "choices") or not out.choices:
        print("[错误] 大模型响应格式异常(场景生成)，无有效内容")
        return None

    text = out.choices[0].message.content

    # 尝试直接解析 JSON
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
    except json.JSONDecodeError:
        pass

    # 尝试从 markdown 代码块中提取 JSON
    json_match = re.search(r'```(?:json)?\s*\n(.*?)\n```', text, re.DOTALL)
    if json_match:
        json_str = json_match.group(1).strip()
        try:
            data = json.loads(json_str)
            if isinstance(data, dict):
                print("[提示] 从 markdown 代码块中成功提取 场景 JSON")
                return data
        except json.JSONDecodeError:
            pass

    print("[警告] 大模型返回内容不是合法 场景 JSON")
    print(f"[原始返回内容] {text[:500]}...")
    return None


def compute_scene_results(k_json: Dict[str, Any]) -> Dict[str, Any]:
    """根据 K 列 JSON 计算每个场景的整体命中结果，返回摘要结构。"""
    result = {"场景结果列表": []}

    if not k_json or "场景列表" not in k_json or "条件模板" not in k_json:
        return result

    cond_list = k_json["条件模板"].get("条件列表", [])
    scene_list = k_json.get("场景列表", [])

    if not cond_list or not scene_list:
        return result

    for scene in scene_list:
        scene_idx = scene.get("场景序号")
        cond_states = scene.get("条件状态列表", [])
        if len(cond_states) != len(cond_list):
            continue

        overall = None
        for i, cond in enumerate(cond_list):
            state = cond_states[i]
            hit = bool(state.get("条件是否命中"))
            if i == 0:
                overall = hit
                continue
            relation = cond.get("与上一个指标关系") or "且"
            if relation == "或":
                overall = bool(overall) or hit
            else:
                overall = bool(overall) and hit

        if overall is None:
            continue

        scene["场景整体是否命中"] = bool(overall)
        result["场景结果列表"].append(
            {"场景序号": scene_idx, "整体是否命中": bool(overall)}
        )

    return result


def generate_fallback_k_json(rule_number: str, rule_json: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """为高条件数规则生成兜底版 K 列 JSON。

    适用场景：
    - 大模型生成的场景 JSON 解析失败或缺少"场景列表"时
    - 条件数量较多（例如 >=5）时，至少给出一批有代表性的场景，避免整条规则为空
    """
    cond_list = rule_json.get("条件列表", [])
    if not cond_list:
        return None

    cond_count = len(cond_list)
    # 仅为高条件数规则提供兜底，低条件数仍交给大模型
    if cond_count <= 4:
        return None

    scenes: List[Dict[str, Any]] = []

    # 构造若干代表性场景模式：
    patterns: List[Tuple[str, str, List[bool]]] = []

    # 场景1：全部命中
    patterns.append(("全部命中", "所有条件都满足命中条件的场景", [True] * cond_count))

    # 场景2~N+1：仅某一个条件命中
    if cond_count > 1:
        for idx in range(cond_count):
            flags = [False] * cond_count
            flags[idx] = True
            patterns.append((
                f"仅条件{idx + 1}命中",
                f"仅条件{idx + 1}满足，其余条件均不满足的场景",
                flags,
            ))

    # 最后一个场景：全部未命中
    patterns.append(("全部未命中", "所有条件都不满足命中条件的场景", [False] * cond_count))

    for scene_idx, (scene_name, scene_desc, flags) in enumerate(patterns, start=1):
        cond_states: List[Dict[str, Any]] = []
        overall: Optional[bool] = None

        for i, cond in enumerate(cond_list):
            hit = bool(flags[i])
            cond_state: Dict[str, Any] = {
                "条件序号": cond.get("条件序号", i + 1),
                "指标标识": cond.get("指标标识", ""),
                "条件是否命中": hit,
                # 兜底场景中不强行推断指标类型，统一标记为"次数"
                "参数类型": "次数",
                "原始比较符号": None,
                "原始阈值表达式": None,
                "场景比较符号": None,
                "场景命中含义": "",
                "指标值示例": None,
                "指标值规则": {},
                # 与 J 列条件模板中的参数列表保持一致
                "参与统计的参数列表": cond.get("参数列表", []),
                "备注": "",
            }
            cond_states.append(cond_state)

            # 计算场景整体是否命中
            if i == 0:
                overall = hit
            else:
                relation = cond.get("与上一个指标关系") or "且"
                if relation == "或":
                    overall = bool(overall) or hit
                else:
                    overall = bool(overall) and hit

        scenes.append(
            {
                "场景序号": scene_idx,
                "场景名称": scene_name,
                "场景描述": scene_desc,
                "条件状态列表": cond_states,
                "场景整体是否命中": bool(overall) if overall is not None else False,
            }
        )

    k_json: Dict[str, Any] = {
        "规则编号": rule_number,
        "条件模板": {
            "条件数量": cond_count,
            "条件列表": cond_list,
        },
        "注释说明库": rule_json.get("注释说明库", {}),
        "I列公共字段": rule_json.get("I列公共字段", {}),
        "场景列表": scenes,
    }

    return k_json



# ==================== 数据约束处理器 ====================

class DataConstraintHandler:
    """测试数据约束处理器
    
    根据K列中的“测试数据生成约束”应用各种约束规则。
    每个约束函数对应K列中的一个"Python规则标识"。
    """
    
    @staticmethod
    def apply_param_constraint(param_name: str, base_value: Any, constraint: Dict) -> Any:
        """应用参数值约束
        
        Args:
            param_name: 参数名称
            base_value: 基础值（未应用约束前的值）
            constraint: 约束字典，包含"Python规则"等字段
            
        Returns:
            应用约束后的值
        """
        if not constraint:
            return base_value
        
        # 【问题3修复】优先处理IP归属地约束：根据约束规则生成合适的值
        if "IP 归属" in param_name or "IP归属" in param_name:
            # 处理IP归属地约束
            constraint_rule = constraint.get("约束规则", "")
            
            # 处理"不等于"约束（如："IP归属国家不等于菲律宾"）
            if "不等于" in constraint_rule or "!=" in constraint_rule:
                # 提取排除值
                import re
                match = re.search(r'不等于\s*[「"‘]?([^」"’]+)[」"’]?', constraint_rule)
                if not match:
                    match = re.search(r'!=\s*[「"‘]?([^」"’]+)[」"’]?', constraint_rule)
                
                if match:
                    excluded_value = match.group(1).strip()
                    # 根据参数类型选择备选值集合
                    if "国家" in param_name:
                        candidates = ["中国", "美国", "英国", "日本", "新加坡", "泰国", "越南", "马来西亚", "印度尼西亚"]
                    elif "省份" in param_name:
                        candidates = ["北京市", "上海市", "广东省", "浙江省", "江苏省", "四川省", "湖北省", "河南省"]
                    elif "城市" in param_name:
                        candidates = ["北京市", "上海市", "深圳市", "广州市", "杭州市", "南京市", "成都市", "武汉市"]
                    else:
                        candidates = ["中国", "美国", "英国", "日本", "新加坡"]
                    
                    # 排除指定值
                    valid_candidates = [c for c in candidates if c != excluded_value]
                    if valid_candidates:
                        import random
                        return random.choice(valid_candidates)
            
            # 处理"取值范围"约束（如：取值范围: ["中国", "新加坡", "日本", "泰国", "越南"]）
            if "取值范围" in constraint:
                value_range = constraint["取值范围"]
                if isinstance(value_range, list) and value_range:
                    import random
                    return random.choice(value_range)
            
            # 如果没有特殊约束，返回默认值
            if "国家" in param_name:
                import random
                return random.choice(["中国", "美国", "英国", "日本", "新加坡"])
            elif "省份" in param_name:
                import random
                return random.choice(["北京市", "上海市", "广东省", "浙江省", "江苏省", "四川省"])
            elif "城市" in param_name:
                import random
                return random.choice(["北京市", "上海市", "深圳市", "广州市", "杭州市", "南京市", "成都市"])
            
            return base_value
            
        python_rule = constraint.get("Python规则", "")
        
        if python_rule == "exclude_lan_ip":
            return DataConstraintHandler.exclude_lan_ip(base_value)
        elif python_rule == "valid_id_card_number":
            return DataConstraintHandler.valid_id_card_number()
        elif python_rule == "exclude_whitelist_customers":
            return DataConstraintHandler.exclude_whitelist_customers(base_value)
        else:
            # 未知约束，返回原值
            return base_value
    
    @staticmethod
    def exclude_lan_ip(ip: str) -> str:
        """排除局域网IP地址
        
        生成一个非局域网的公网IP地址。
        排除的网段：10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 127.0.0.0/8
        """
        import random
        
        # 生成公网IP（简化版：避开常见局域网段）
        while True:
            # 生成随机IP
            first_octet = random.randint(1, 223)  # 避免224-255（组播/保留）
            
            # 排除局域网段
            if first_octet == 10:  # 10.0.0.0/8
                continue
            if first_octet == 127:  # 127.0.0.0/8
                continue
            if first_octet == 172:  # 172.16.0.0/12
                second_octet = random.randint(0, 255)
                if 16 <= second_octet <= 31:
                    continue
            if first_octet == 192:  # 192.168.0.0/16
                second_octet = random.randint(0, 255)
                if second_octet == 168:
                    continue
            
            # 生成剩余字节
            second_octet = random.randint(0, 255)
            third_octet = random.randint(0, 255)
            fourth_octet = random.randint(1, 254)
            
            return f"{first_octet}.{second_octet}.{third_octet}.{fourth_octet}"
    
    @staticmethod
    def valid_id_card_number() -> str:
        """生成合法18位身份证号码
        
        符合GB11643-1999标准，包含校验码计算。
        """
        import random
        
        # 生成前17位
        # 地区码：6位（使用常见省份代码）
        province_codes = ["110000", "310000", "440000", "500000", "330000"]  # 北京、上海、广东、重庆、浙江
        area_code = random.choice(province_codes)
        
        # 出生日期：8位（1980-2005年）
        year = random.randint(1980, 2005)
        month = random.randint(1, 12)
        day = random.randint(1, 28)  # 简化处理，避免月份天数问题
        birth_date = f"{year:04d}{month:02d}{day:02d}"
        
        # 顺序码：3位
        sequence = f"{random.randint(0, 999):03d}"
        
        # 前17位
        id_17 = area_code + birth_date + sequence
        
        # 计算校验码（第18位）
        # 加权因子
        weight_factors = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
        # 校验码对照表
        check_codes = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2']
        
        # 计算加权和
        total = sum(int(id_17[i]) * weight_factors[i] for i in range(17))
        # 获取校验码
        check_code = check_codes[total % 11]
        
        return id_17 + check_code
    
    @staticmethod
    def exclude_whitelist_customers(customer_id: str) -> str:
        """排除白名单客户
        
        确保生成的客户编号不在白名单中。
        白名单包括：VIP客户、内部员工等。
        """
        import random
        
        # 简化处理：生成一个普通客户ID（非VIP、非员工）
        # 假讽VIP以"VIP_"开头，员工以"EMP_"开头
        customer_id = f"CUST_{random.randint(100000, 999999)}"
        return customer_id
    
    @staticmethod
    def initial_value_zero_on_first_transaction() -> int:
        """首次交易时指标结果为0
        
        当规则配置为非事中模式且当前为用户第一笔交易时，
        指标值必须为0。
        """
        return 0
    
    @staticmethod
    def strange_device_id() -> str:
        """生成陌生设备ID
        
        陌生设备ID定义为：最近90天内未登录过的设备。
        简化处理：生成一个特殊标识的设备ID。
        """
        import random
        return f"STRANGE_DEV_{random.randint(100000, 999999)}"
    
    @staticmethod
    def balance_before_transaction(amount: float) -> float:
        """生成交易前账户余额
        
        账户余额应为交易前的余额，而非交易后。
        简化处理：返回一个大于交易金额的余额。
        """
        import random
        # 余额为交易金额的 1.2-3 倍
        return amount * random.uniform(1.2, 3.0)


def generate_testcase_data_for_rule(
    k_json: Dict[str, Any],
    j_json: Dict[str, Any],
    param_cn_to_en: Dict[str, str],
) -> List[Dict[str, Any]]:
    """根据K列JSON生成测试用例数据（纯Python函数，不调用大模型）
    
    Args:
        k_json: K列的JSON对象（包含场景列表、公共字段规则、参数规则）
        j_json: J列的JSON对象（用于获取I列公共字段）
        param_cn_to_en: 参数中文名到英文名的映射
        
    Returns:
        测试用例数据列表，每个元素是一条测试数据（JSON）
    """
    import re  # 【修复】在函数开头导入re模块，避免UnboundLocalError
    testcase_data = []
    
    if not k_json:
        return testcase_data
    
    # 读取必要信息
    common_field_rules = k_json.get("公共字段生成规则", {})
    param_gen_rules = k_json.get("参数值生成规则", {})
    i_column_fields = j_json.get("I列公共字段", {})
    
    # 估算时间窗口（用于在时间范围内均匀分布测试数据）
    now = datetime.datetime.now()
    window_start: Optional[datetime.datetime] = None
    window_end: Optional[datetime.datetime] = None
    hour_range_start: Optional[int] = None  # 小时范围开始，如 [0,5] 中的 0
    hour_range_end: Optional[int] = None    # 小时范围结束，如 [0,5] 中的 5
    has_exclusion: bool = False  # 标记是否有"剔除N天"语义
    rule_conditions = j_json.get("条件列表", [])
    for cond in rule_conditions:
        desc = str(cond.get("条件描述", ""))
        local_start: Optional[datetime.datetime] = None
        local_end: Optional[datetime.datetime] = None

        # 模式0："[H1,H2]"小时范围，例如"[0,5]"表示凌晨0点到5点
        m_hour_range = re.search(r"\[(\d+),\s*(\d+)\]", desc)
        if m_hour_range:
            hour_range_start = int(m_hour_range.group(1))
            hour_range_end = int(m_hour_range.group(2))

        # 模式1："N天内剔除M天"，例如"90天内剔除3天"，理解为从现在往前数N天，但剔除最近的M天
        m_day_excl = re.search(r"(\d+)\s*天内[^\n]*?剔除(\d+)\s*天", desc)
        if m_day_excl:
            total_days = int(m_day_excl.group(1))
            excl_days = int(m_day_excl.group(2))
            local_end = now - datetime.timedelta(days=excl_days)
            local_start = now - datetime.timedelta(days=total_days)
            has_exclusion = True  # 标记存在排除语义
        else:
            # 模式2："N天内"
            m_day = re.search(r"(\d+)\s*天内", desc)
            if m_day:
                days = int(m_day.group(1))
                local_end = now
                local_start = now - datetime.timedelta(days=days)

        # 模式3："N小时内"
        m_hour = re.search(r"(\d+)\s*小时内", desc)
        if m_hour:
            hours = int(m_hour.group(1))
            local_end = now
            local_start = now - datetime.timedelta(hours=hours)

        # 模式4："N分钟内"
        m_min = re.search(r"(\d+)\s*分钟内", desc)
        if m_min:
            minutes = int(m_min.group(1))
            local_end = now
            local_start = now - datetime.timedelta(minutes=minutes)

        # 合并到全局时间窗口
        if local_start is not None and local_end is not None:
            # 开始时间：取最早的（扩大窗口）
            if window_start is None or local_start < window_start:
                window_start = local_start
            # 结束时间：如果有"剔除N天"语义，取最早的结束时间（最严格限制）
            # 否则取最晚的结束时间（扩大窗口）
            if has_exclusion:
                # 存在排除语义时，以最严格的结束时间为准
                if window_end is None or local_end < window_end:
                    window_end = local_end
            else:
                # 无排除语义时，扩大窗口
                if window_end is None or local_end > window_end:
                    window_end = local_end
    
    # 当前记录使用的时间戳（在时间窗口内均匀分布）
    current_timestamp: Optional[str] = None    
    # 【修改】支持场景列表
    scenes = k_json.get("场景列表", [])
    
    if not scenes:
        # 兼容旧格式：单个场景
        scene = k_json.get("场景", {})
        if scene:
            scenes = [scene]
        else:
            return testcase_data
    
    # 【新增】遍历所有场景生成数据
    for scene in scenes:
        scene_is_hit = scene.get("场景整体是否命中", False)
        conditions = scene.get("条件状态列表", [])
        
        if not conditions:
            continue
            
        # ---------------- 辅助函数 -----------------
        def _generate_random_bizid(length: int = 20) -> str:
            """生戉20位数字+字母随机串"""
            chars = string.ascii_uppercase + string.digits
            return ''.join(random.choice(chars) for _ in range(length))
            
        def _generate_device_id() -> str:
            """生成设备ID"""
            return f"DEV_{random.randint(100000, 999999)}"
            
        def _generate_user_account() -> str:
            """生成用户账号"""
            return f"USER_{random.randint(10000, 99999)}"
            
        def _generate_timestamp(offset_minutes: int = 60) -> str:
            """生成时间戳（当前时间+随机偏移）"""
            now = datetime.datetime.now()
            offset = datetime.timedelta(minutes=random.randint(-offset_minutes, offset_minutes))
            target_time = now + offset
            return target_time.strftime("%Y-%m-%d %H:%M:%S")
            
        def _generate_param_value(param_cn_name: str) -> str:
            """根据参数中文名和生成规则，生成参数值"""
            # 时间参数
            if param_cn_name in param_gen_rules.get("时间参数", []) or "时间" in param_cn_name or "Time" in param_cn_name:
                # 优先使用当前记录在时间窗口内的时间戳，实现时间窗口内的大致均匀分布
                if current_timestamp is not None:
                    return current_timestamp
                return _generate_timestamp()
            
            # IP地址参数
            elif "IP" in param_cn_name or "ipAddress" in param_cn_name or "IpAddr" in param_cn_name:
                # 生成一个IP地址
                return f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"
            
            # 经纬度参数
            elif "经度" in param_cn_name or "longitude" in param_cn_name.lower():
                # 经度范围：-180 到 180
                return f"{random.uniform(-180, 180):.6f}"
            elif "纬度" in param_cn_name or "latitude" in param_cn_name.lower():
                # 纬度范围：-90 到 90
                return f"{random.uniform(-90, 90):.6f}"
            
            # 邮箱参数
            elif "邮箱" in param_cn_name or "email" in param_cn_name.lower():
                domains = ["gmail.com", "outlook.com", "yahoo.com", "163.com", "qq.com"]
                username = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=8))
                return f"{username}@{random.choice(domains)}"
            
            # 手机号参数
            elif "手机" in param_cn_name or "mobile" in param_cn_name.lower() or "mobileNo" in param_cn_name:
                # 中国大陆手机号：13x/14x/15x/16x/17x/18x/19x 开头
                prefixes = ["130", "131", "132", "133", "134", "135", "136", "137", "138", "139",
                           "147", "150", "151", "152", "153", "155", "156", "157", "158", "159",
                           "166", "170", "171", "175", "176", "177", "178", "180", "181", "182",
                           "183", "184", "185", "186", "187", "188", "189", "198", "199"]
                return f"{random.choice(prefixes)}{random.randint(10000000, 99999999)}"
            
            # 证件号码（身份证）
            elif "证件" in param_cn_name or "身份证" in param_cn_name or "idNo" in param_cn_name or "IdNo" in param_cn_name:
                return _generate_id_card()
            
            # ID参数
            elif param_cn_name in param_gen_rules.get("ID参数", []) or "ID" in param_cn_name or "No" in param_cn_name:
                if "设备" in param_cn_name or "blackBox" in param_cn_name:
                    return _generate_device_id()
                elif "用户" in param_cn_name or "cust" in param_cn_name.lower():
                    return f"UID_{random.randint(100000, 999999)}"
                else:
                    return f"ID_{random.randint(100000, 999999)}"
            
            # 账号参数
            elif param_cn_name in param_gen_rules.get("账号参数", []) or "账号" in param_cn_name or "account" in param_cn_name.lower():
                return _generate_user_account()
            
            # 银行卡号
            elif "银行卡" in param_cn_name or "卡号" in param_cn_name or "cardNo" in param_cn_name or "CardNo" in param_cn_name:
                return f"6222{random.randint(1000000000000000, 9999999999999999)}"
            
            # 金额参数
            elif "金额" in param_cn_name or "额度" in param_cn_name or "amount" in param_cn_name.lower() or "balance" in param_cn_name.lower():
                return str(random.randint(1000, 100000))
            
            # 年龄参数
            elif "年龄" in param_cn_name or "age" in param_cn_name.lower():
                return str(random.randint(18, 65))
            
            # 国家/城市/地区代码
            elif "country" in param_cn_name.lower() or "国家" in param_cn_name:
                countries = ["CN", "US", "JP", "UK", "SG", "PH", "TH", "VN"]
                return random.choice(countries)
            elif "city" in param_cn_name.lower() or "城市" in param_cn_name:
                cities = ["Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Hangzhou"]
                return random.choice(cities)
            
            # 货币代码
            elif "currency" in param_cn_name.lower() or "货币" in param_cn_name:
                currencies = ["CNY", "USD", "EUR", "JPY", "GBP", "SGD", "PHP"]
                return random.choice(currencies)
            
            # 交易状态
            elif "status" in param_cn_name.lower() or "状态" in param_cn_name:
                statuses = ["SUCCESS", "FAILED", "PENDING", "PROCESSING"]
                return random.choice(statuses)
            
            # 交易类型
            elif "type" in param_cn_name.lower() or "类型" in param_cn_name:
                types = ["PURCHASE", "WITHDRAWAL", "TRANSFER", "DEPOSIT"]
                return random.choice(types)
            
            # 姓名参数
            elif "name" in param_cn_name.lower() or "姓名" in param_cn_name:
                first_names = ["John", "Mary", "David", "Lisa", "Michael", "Sarah", "Wang", "Li", "Zhang"]
                last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Wei", "Fang", "Chen"]
                return f"{random.choice(first_names)} {random.choice(last_names)}"
            
            # 默认：随机字符串
            else:
                return f"VALUE_{random.randint(1000, 9999)}"
            
        def _generate_common_fields(scene_is_hit: bool) -> Dict[str, Any]:
            """生成公共字段
            
            【修复】只生成 common_field_rules 中实际存在的字段，不生成硬编码字段
            """
            result = {}
                
            # 遍历所有公共字段规则，根据规则类型生成字段
            for field_key, field_rule in common_field_rules.items():
                if field_key == "其他字段":
                    # 处理其他字段：从I列读取
                    if field_rule.get("规则类型") == "I列固定值":
                        for key, value in i_column_fields.items():
                            if key not in result:  # 不覆盖已生成的字段
                                result[key] = value
                    continue
                
                rule_type = field_rule.get("规则类型")
                
                # 场景相关字段：根据场景是否命中选择值
                if rule_type == "场景相关":
                    if scene_is_hit:
                        result[field_key] = field_rule.get("命中值", "")
                    else:
                        result[field_key] = field_rule.get("未命中值", "")
                
                # 随机生成字段
                elif rule_type == "随机生成":
                    result[field_key] = _generate_random_bizid()
                
                # 固定值字段
                elif rule_type == "固定值":
                    result[field_key] = field_rule.get("值", "")
                
            return result
            
        # 根据条件生成数据
        # 策略：根据指标类型确定生成的数据条数
        max_count = 0
        for cond in conditions:
            indicator_rules = cond.get("指标值规则", {})
            indicator_type = indicator_rules.get("指标类型", "")
                    
            # 根据不同指标类型获取生成条数
            if indicator_type in ["次数/条数", "次数", "条数"]:
                # 次数类型：从条数规则中获取
                count_rule = indicator_rules.get("条数规则", {})
                total_count = count_rule.get("生成总条数", 0)
            elif indicator_type in ["金额", "比例", "时间"]:
                # 金额/比例/时间类型：根据阈值推算合理的数据条数
                # 默认生成5-10条数据来模拟累计金额/比例
                total_count = random.randint(5, 10)
            else:
                # 未知类型：默认生成5条
                total_count = 5
                    
            if total_count > max_count:
                max_count = total_count
                
        # 如果所有条件都无法确定条数，至少生成3条数据
        if max_count == 0:
            max_count = 3
            
        # 生成max_count条测试数据
        # 关键：所有数据共享同一个设备ID（因为是"同一设备ID关联"的条件）
        shared_device_id = _generate_device_id()
                
        # 在时间窗口内为每条测试数据预先计算时间戳，使其在窗口内大致均匀分布
        # 使用外部解析好的 window_start/window_end，不要重新计算
        current_now = datetime.datetime.now()
                
        # 如果未能从条件描述中解析出时间窗口，则默认使用最近1小时窗口
        if window_start is None or window_end is None or window_end <= window_start:
            final_window_end = current_now
            final_window_start = current_now - datetime.timedelta(minutes=60)
        else:
            final_window_start = window_start
            final_window_end = window_end
                
        window_delta = final_window_end - final_window_start
        if max_count == 1:
            time_points = [final_window_start + window_delta / 2]
        else:
            step = window_delta / max_count
            time_points = [final_window_start + step * (i + 0.5) for i in range(max_count)]
                
        # 如果存在小时范围限制（如 [0,5]），则调整时间点的小时部分
        if hour_range_start is not None and hour_range_end is not None:
            adjusted_time_points = []
            for tp in time_points:
                # 保持日期和分秒不变，只调整小时
                target_hour = random.randint(hour_range_start, hour_range_end)
                adjusted_tp = tp.replace(hour=target_hour)
                adjusted_time_points.append(adjusted_tp)
            time_points = adjusted_time_points
                
        time_points_str = [tp.strftime("%Y-%m-%d %H:%M:%S") for tp in time_points]
        
        # 【重大调整】改变循环顺序：外层遍历条件，内层遍历时间点
        # 这样每个条件会先生成所有时间点的数据，然后再生成下一个条件
        for cond in conditions:
            cond_param_list_cn = cond.get("参与统计的参数列表", [])
            if not cond_param_list_cn:
                continue
            
            # 读取当前条件的约束
            test_constraint = cond.get("测试数据生成约束", {})
            param_constraints = test_constraint.get("参数值约束", {})
            
            # 【新增需求】解析条件描述，识别需要共享值的参数
            # 例如：“同一客户在同一IP归属城市” → 客户编号、IP归属城市需要共享
            cond_desc = cond.get("条件描述", "")
            if not cond_desc:
                # 如果没有条件描述，尝试从场景命中含义获取
                cond_desc = cond.get("场景命中含义", "")
            
            shared_values = {}  # 存储当前条件的共享值
            
            # 识别"同一XXX"模式（使用非贪婪匹配，在遇到特定分隔符时停止）
            same_pattern = re.findall(r'同一([\u4e00-\u9fa5A-Za-z0-9]+?)(?:在|和|、|，|,|交易|登录|的|成功)', cond_desc)
            for param_hint in same_pattern:
                param_hint = param_hint.strip()  # 去除前后空格
                
                # 特殊处理：“同一IP”直接识别为IP Address
                if param_hint == "IP" or param_hint == "IP地址":
                    if "IP Address" not in shared_values:
                        shared_values["IP Address"] = f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"
                    continue
                
                # 尝试匹配参数列表中的参数（去除空格后比较）
                for param_cn in cond_param_list_cn:
                    # 去除空格后比较
                    param_hint_no_space = param_hint.replace(" ", "")
                    param_cn_no_space = param_cn.replace(" ", "")
                    
                    if param_hint_no_space in param_cn_no_space or param_cn_no_space in param_hint_no_space:
                        # 找到匹配的参数，为其生成共享值
                        if param_cn not in shared_values:
                            # 根据参数类型生成共享值
                            if "客户" in param_cn or "cust" in param_cn.lower():
                                shared_values[param_cn] = f"CUST_{random.randint(100000, 999999)}"
                            elif "IP 归属城市" in param_cn or "IP归属城市" in param_cn:
                                cities = ["北京市", "上海市", "深圳市", "广州市", "杭州市", "南京市", "成都市"]
                                shared_values[param_cn] = random.choice(cities)
                            elif "IP 归属国家" in param_cn or "IP归属国家" in param_cn:
                                countries = ["中国", "美国", "英国", "日本", "新加坡"]
                                shared_values[param_cn] = random.choice(countries)
                            elif "IP 归属省份" in param_cn or "IP归属省份" in param_cn:
                                provinces = ["北京市", "上海市", "广东省", "浙江省", "江苏省", "四川省"]
                                shared_values[param_cn] = random.choice(provinces)
                            elif "设备" in param_cn or "device" in param_cn.lower():
                                shared_values[param_cn] = shared_device_id
                            elif "账户" in param_cn or "account" in param_cn.lower():
                                shared_values[param_cn] = f"ACC_{random.randint(100000, 999999)}"
                            # 可以扩展其他参数类型
            
            # 【需求2修复】当参数列表包含IP归属地字段时，自动补充"IP Address"参数
            has_ip_location = any(
                "IP 归属国家" in p or "IP归属国家" in p or 
                "IP 归属省份" in p or "IP归属省份" in p or 
                "IP 归属城市" in p or "IP归属城市" in p 
                for p in cond_param_list_cn
            )
            param_list_cn = list(cond_param_list_cn)  # 复制一份避免修改原列表
            if has_ip_location and "IP Address" not in param_list_cn:
                # 在列表开头插入IP Address，确保它先被处理
                param_list_cn.insert(0, "IP Address")
            
            # 【关键修复】为当前条件计算其应该生成的数据条数
            indicator_rules = cond.get("指标值规则", {})
            indicator_type = indicator_rules.get("指标类型", "")
            
            if indicator_type in ["次数/条数", "次数", "条数"]:
                # 次数类型：从条数规则中获取
                count_rule = indicator_rules.get("条数规则", {})
                cond_count = count_rule.get("生成总条数", 0)
            elif indicator_type == "金额":
                # 金额类型：默认5-10条（金额需要更多样本展示分布）
                cond_count = random.randint(5, 10)
            else:
                # 其他类型（比例、时间等）：默认生成2-3条
                cond_count = random.randint(2, 3)
            
            # 如果该条件没有明确条数，默认生成2-3条
            if cond_count == 0:
                cond_count = random.randint(2, 3)
            
            # 为该条件生成对应数量的时间点
            if cond_count == 1:
                cond_time_points = [final_window_start + window_delta / 2]
            else:
                step = window_delta / cond_count
                cond_time_points = [final_window_start + step * (i + 0.5) for i in range(cond_count)]
            
            # 如果存在小时范围限制，调整时间点
            if hour_range_start is not None and hour_range_end is not None:
                adjusted_cond_time_points = []
                for tp in cond_time_points:
                    target_hour = random.randint(hour_range_start, hour_range_end)
                    adjusted_tp = tp.replace(hour=target_hour)
                    adjusted_cond_time_points.append(adjusted_tp)
                cond_time_points = adjusted_cond_time_points
            
            cond_time_points_str = [tp.strftime("%Y-%m-%d %H:%M:%S") for tp in cond_time_points]
            
            # 内层循环：遍历该条件的所有时间点
            for i in range(cond_count):
                record = {}
                
                # 为当前记录设置时间戳，供时间参数统一使用
                current_timestamp = cond_time_points_str[i]
                        
                # 1. 生成公共字段（优先级最高）
                common_fields = _generate_common_fields(scene_is_hit)
                record.update(common_fields)
                
                # 2. 生成当前条件的参数字段
                param_fields = {}  # 当前条件的参数字段
                
                for param_cn in param_list_cn:
                    # 【问题2修复】获取英文字段名，确保正确映射
                    param_en = param_cn_to_en.get(param_cn, "")
                    if not param_en:
                        # 如果映射不存在，使用UNKNOWN_前缀
                        param_en = f"UNKNOWN_{param_cn}"
                            
                    # 去重检查：如果参数字段与公共字段重复，跳过该参数
                    if param_en in record:
                        continue  # 公共字段优先，跳过重复的参数字段
                            
                    # 【新增】优先检查是否有共享值
                    if param_cn in shared_values:
                        param_fields[param_en] = shared_values[param_cn]
                    # 特殊处理：IP Address 共享检查（支持“同一IP”语义）
                    elif (param_cn == "IP Address" or ("IP" in param_cn and "归属" not in param_cn)) and "IP Address" in shared_values:
                        param_fields[param_en] = shared_values["IP Address"]
                    # 特殊处理：设备ID使用共享值
                    elif "设备ID" in param_cn:
                        param_fields[param_en] = shared_device_id
                    # 【IP参数特殊处理】生成IP并根据参数列表决定是否添加归属地信息
                    elif "IP Address" == param_cn or ("IP" in param_cn and "归属" not in param_cn):
                        # 生成标准IP地址：格式 {1-223}.{0-255}.{0-255}.{1-254}
                        ip = f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"
                        base_value = ip
                        constraint = param_constraints.get(param_cn)
                        if constraint:
                            param_fields[param_en] = DataConstraintHandler.apply_param_constraint(
                                param_cn, base_value, constraint
                            )
                        else:
                            param_fields[param_en] = base_value
                    # IP归属地参数特殊处理
                    elif "IP 归属国家" in param_cn or "IP归属国家" in param_cn:
                        constraint = param_constraints.get(param_cn)
                        if constraint and "约束规则" in constraint:
                            location_value = DataConstraintHandler.apply_param_constraint(
                                param_cn, None, constraint
                            )
                            param_fields[param_en] = location_value
                        else:
                            countries = ["中国", "美国", "英国", "日本", "新加坡"]
                            param_fields[param_en] = random.choice(countries)
                    elif "IP 归属省份" in param_cn or "IP归属省份" in param_cn:
                        constraint = param_constraints.get(param_cn)
                        if constraint and "约束规则" in constraint:
                            location_value = DataConstraintHandler.apply_param_constraint(
                                param_cn, None, constraint
                            )
                            param_fields[param_en] = location_value
                        else:
                            provinces = ["北京市", "上海市", "广东省", "浙江省", "江苏省", "四川省"]
                            param_fields[param_en] = random.choice(provinces)
                    elif "IP 归属城市" in param_cn or "IP归属城市" in param_cn:
                        constraint = param_constraints.get(param_cn)
                        if constraint and "约束规则" in constraint:
                            location_value = DataConstraintHandler.apply_param_constraint(
                                param_cn, None, constraint
                            )
                            param_fields[param_en] = location_value
                        else:
                            cities = ["北京市", "上海市", "深圳市", "广州市", "杭州市", "南京市", "成都市"]
                            param_fields[param_en] = random.choice(cities)
                    else:
                        # 根据规则生成参数值（基础值）
                        base_value = _generate_param_value(param_cn)
                        constraint = param_constraints.get(param_cn)
                        if constraint:
                            param_fields[param_en] = DataConstraintHandler.apply_param_constraint(
                                param_cn, base_value, constraint
                            )
                        else:
                            param_fields[param_en] = base_value
                
                # 合并当前条件的参数字段到记录中
                record.update(param_fields)
                # 将当前时间点当前条件的记录加入结果列表
                testcase_data.append(record)
        
    return testcase_data


def merge_h_i_by_column_c(ws, max_row: int) -> None:
    """
    按 C 列（规则集名称）合并 H 列和 I 列。
    C 列内容相同的连续行，H 列和 I 列合并为一个单元格。
    
    Args:
        ws: openpyxl worksheet 对象
        max_row: 最大行号
    """
    from collections import defaultdict
    
    # 收集 C 列相同内容的连续行范围
    # key: C列值, value: [(start_row, end_row), ...]
    c_ranges = []
    current_c_value = None
    start_row = None
    
    for row in range(2, max_row + 1):
        c_val = ws.cell(row=row, column=3).value
        
        if c_val is None:
            # C列为空，结束当前范围
            if start_row is not None:
                c_ranges.append((current_c_value, start_row, row - 1))
                start_row = None
                current_c_value = None
            continue
        
        c_val_str = str(c_val).strip()
        
        if c_val_str != current_c_value:
            # C列值变化，结束上一个范围，开始新范围
            if start_row is not None:
                c_ranges.append((current_c_value, start_row, row - 1))
            start_row = row
            current_c_value = c_val_str
        # 否则继续当前范围
    
    # 处理最后一个范围
    if start_row is not None:
        c_ranges.append((current_c_value, start_row, max_row))
    
    # 对每个范围进行 H 列和 I 列的合并
    for c_value, start, end in c_ranges:
        if end > start:  # 只有多行时才需要合并
            try:
                ws.merge_cells(start_row=start, start_column=8, end_row=end, end_column=8)  # H列
                ws.merge_cells(start_row=start, start_column=9, end_row=end, end_column=9)  # I列
            except Exception as e:
                print(f"[警告] 合并 H/I 列失败 (C列={c_value}, Row {start}-{end}): {e}")


def process_single_sheet(ws, wb, output_path: str, api_key: str, param_dict_path: str, sheet_name: str) -> tuple[int, int, list]:
    """处理单个sheet页的规则文件。
    
    Args:
        ws: openpyxl worksheet对象
        wb: openpyxl workbook对象（用于保存）
        output_path: 输出文件路径
        api_key: DashScope API KEY
        param_dict_path: 参数字典文件路径
        sheet_name: sheet页名称（用于日志输出）
    
    Returns:
        tuple: (处理成功数, 跳过数, 失败行列表)
    """
    print(f"\n{'='*60}")
    print(f"正在处理 Sheet: {sheet_name}")
    print(f"{'='*60}")

    # 先解除所有现有的合并单元格（避免后续写入冲突）
    # 但在解除前，先记录合并区域的值，解除后填充到所有单元格
    merged_ranges_info = []
    for merged_range in list(ws.merged_cells.ranges):
        min_row = merged_range.min_row
        min_col = merged_range.min_col
        max_row = merged_range.max_row
        max_col = merged_range.max_col
        value = ws.cell(min_row, min_col).value
        merged_ranges_info.append((min_row, min_col, max_row, max_col, value))
    
    # 先解除所有合并
    for merged_range in list(ws.merged_cells.ranges):
        ws.unmerge_cells(str(merged_range))
    
    # 再填充值到所有原合并区域的单元格
    for min_row, min_col, max_row, max_col, value in merged_ranges_info:
        for row in range(min_row, max_row + 1):
            for col in range(min_col, max_col + 1):
                ws.cell(row, col).value = value

    # 设置 J/K/L/M/N 列表头
    ws.cell(row=1, column=10).value = "J_条件拆分JSON"
    ws.cell(row=1, column=11).value = "K_场景规则JSON"
    ws.cell(row=1, column=12).value = "L_场景结果摘要"
    ws.cell(row=1, column=13).value = "M_测试用例数据"
    ws.cell(row=1, column=14).value = "N_场景应用名称"

    max_row = ws.max_row

    # 加载参数字典（供场景生成与测试数据生成使用）
    try:
        param_cn_to_en = load_param_dict(param_dict_path)
    except Exception as e:
        print(f"[错误] 加载参数字典失败: {e}")
        return

    # 当前系统时间，用于生成业务发生时间
    now = datetime.datetime.now()

    processed = 0
    skipped = 0
    failed_rows = []  # 记录失败的行号和原因
    
    # 缓存合并单元格的值，避免同一合并区域重复调用大模型
    # key: (merge_start, merge_end), value: result_json
    merged_cache: Dict[Tuple[int, int], Optional[Dict]] = {}
    
    row_idx = 2
    while row_idx <= max_row:
        # 使用合并单元格处理逻辑读取 B/D/F/G/H/I 列
        b_value, b_start, b_end = get_merged_cell_value(ws, row_idx, 2)  # B 列：规则编号/策略码
        d_value, d_start, d_end = get_merged_cell_value(ws, row_idx, 4)  # D 列：规则编号
        f_value, f_start, f_end = get_merged_cell_value(ws, row_idx, 6)  # F 列：规则描述
        g_value, g_start, g_end = get_merged_cell_value(ws, row_idx, 7)  # G 列：指标标识
        h_value, h_start, h_end = get_merged_cell_value(ws, row_idx, 8)  # H 列：规则集参数清单
        i_value, i_start, i_end = get_merged_cell_value(ws, row_idx, 9)  # I 列：公共字段 JSON

        if not f_value:
            skipped += 1
            failed_rows.append((row_idx, "F列为空"))
            row_idx += 1
            continue

        policy_code = str(b_value).strip() if b_value else ""
        rule_number = str(d_value).strip() if d_value else ""

        rule_desc = str(f_value).strip()
        
        # 【G列自动补全逻辑】
        # 场景1：G列为空 → 自动生成全部指标标识
        # 场景2：G列已有指标标识，但数量不足 → 补充不足的指标标识
        if not g_value:
            # 场景1：G列完全为空
            print(f"  第{row_idx}行：G列为空，自动生成指标标识...")
            # 调用函数生成指标标识
            metric_codes = generate_metric_identifiers(rule_desc)
            
            if not metric_codes:
                skipped += 1
                failed_rows.append((row_idx, "G列为空且无法生成指标标识"))
                row_idx += 1
                continue
            
            # 将生成的指标标识写入G列
            g_cell_value = "\n".join(metric_codes)
            ws.cell(row=row_idx, column=7).value = g_cell_value
            print(f"  → 生成{len(metric_codes)}个指标标识：{', '.join(metric_codes[:3])}{'...' if len(metric_codes) > 3 else ''}")
        else:
            # G列不为空，检查指标标识数量是否充足
            metric_codes = [line.strip() for line in str(g_value).split("\n") if line.strip()]
            
            # 从 F 列规则描述中估算应有的条件数量
            expected_count = estimate_condition_count(rule_desc)
            current_count = len(metric_codes)
            
            # 场景2：数量不足，需要补充
            if current_count < expected_count:
                shortage = expected_count - current_count
                print(f"  第{row_idx}行：G列指标标识数量不足（现有{current_count}个，应有{expected_count}个），补充{shortage}个...")
                
                # 生成补充的指标标识
                additional_ids = generate_metric_identifiers(rule_desc, count=shortage)
                metric_codes.extend(additional_ids)
                
                # 更新G列
                g_cell_value = "\n".join(metric_codes)
                ws.cell(row=row_idx, column=7).value = g_cell_value
                print(f"  → 补充完成，共{len(metric_codes)}个指标标识：{', '.join(metric_codes[:3])}{'...' if len(metric_codes) > 3 else ''}")
        
        param_candidates = parse_param_candidates(h_value)

        # 解析 I 列公共字段为字典（如果是合法 JSON）
        i_public: Dict[str, Any] = {}
        if i_value:
            try:
                tmp = json.loads(str(i_value))
                if isinstance(tmp, dict):
                    i_public = tmp
            except Exception:
                i_public = {}

        if not rule_desc or not metric_codes:
            skipped += 1
            failed_rows.append((row_idx, "规则描述为空或指标标识列表为空"))
            row_idx += 1
            continue

        # 检查是否在合并区域缓存中（F 列合并范围作为 key）
        merge_key = (f_start, f_end)
        if merge_key in merged_cache:
            # 使用缓存的结果（深拷贝，避免后续修改影响缓存）
            cached_result = merged_cache[merge_key]
            if cached_result is None:
                skipped += 1
                failed_rows.append((row_idx, "使用缓存：大模型调用失败或返回无效JSON"))
                row_idx += 1
                continue
            result_json = copy.deepcopy(cached_result)
        else:
            # 首次处理，调用大模型
            result_json = call_dashscope_for_condition_json(api_key, rule_desc, metric_codes, param_candidates)
            # 存入缓存
            merged_cache[merge_key] = result_json
        
        # 检查结果是否有效
        if result_json is None:
            skipped += 1
            failed_rows.append((row_idx, "大模型调用失败或返回无效JSON"))
            row_idx += 1
            continue
            
        if not result_json:  # 空字典
            skipped += 1
            failed_rows.append((row_idx, "大模型返回空结果"))
            row_idx += 1
            continue
            
        # 验证关键字段是否存在
        if "条件列表" not in result_json or not result_json["条件列表"]:
            skipped += 1
            failed_rows.append((row_idx, "JSON缺少条件列表或条件列表为空"))
            print(f"[警告] 第{row_idx}行：JSON缺少有效的条件列表")
            row_idx += 1
            continue
            
        # 将 I 列公共字段直接写入顶层 "I列公共字段"，不依赖大模型生成，避免偏差
        result_json["I列公共字段"] = i_public
        try:
            cell_text_j = json.dumps(result_json, ensure_ascii=False)
        except Exception:
            # 兜底：直接使用 str
            cell_text_j = str(result_json)
        ws.cell(row=row_idx, column=10).value = cell_text_j

        # 基于 J 列结果调用大模型生成 K 列场景 JSON
        k_json: Optional[Dict[str, Any]] = call_dashscope_for_scenarios(
            api_key, result_json, param_cn_to_en
        )

        # 如果大模型生成失败，尝试使用兜底策略生成 K 列 JSON
        if not k_json:
            k_json = generate_fallback_k_json(rule_number, result_json)

        if not k_json:
            processed += 1
            row_idx += 1
            continue

        # 基于 K 列 JSON 计算各场景整体命中结果
        scene_summary = compute_scene_results(k_json)
        scene_hit_map: Dict[Any, Any] = {}
        for item in scene_summary.get("场景结果列表", []):
            scene_hit_map[item.get("场景序号")] = item.get("整体是否命中")

        # 注意：这里不再生成测试数据，因为K列结构已改为每行一个场景
        # 测试数据生成将在后面为每个场景单独进行

        # 一个规则下存在多个场景，需要在Excel中拆成多行：
        # - 第一个场景写在当前行
        # - 其余场景插入到当前行之后
        scene_list = k_json.get("场景列表", []) or []
        num_scenes = len(scene_list)
        if num_scenes > 1:
            ws.insert_rows(row_idx + 1, amount=num_scenes - 1)
            max_row += num_scenes - 1

        # 先为所有场景行写入数据（包括复制 A-J 列和 H/I 列）
        for idx_scene, scene in enumerate(scene_list, start=1):
            target_row = row_idx + idx_scene - 1
            scene_idx_val = scene.get("场景序号")

            # 只在第一个场景行（原始行）保留原有数据，其他场景行需要复制
            if idx_scene == 1:
                # 第一个场景直接使用当前行，A-J列已经有数据
                pass
            else:
                # 其他场景需要复制 A-G 列
                for col in range(1, 8):  # A-G 列（列号1-7）
                    source_val = ws.cell(row=row_idx, column=col).value
                    ws.cell(row=target_row, column=col).value = source_val

                # 复制 J 列（条件拆分JSON）
                ws.cell(row=target_row, column=10).value = cell_text_j

            # H 列（规则集参数清单）- 先写入每一行，稍后会合并
            ws.cell(row=target_row, column=8).value = h_value

            # I 列（公共字段 JSON）- 先写入每一行，稍后会合并
            ws.cell(row=target_row, column=9).value = i_value

            # 为该场景构造K列JSON（优化后的结构）
            # 【修复】动态生成公共字段规则，只包含I列中实际存在的字段
            common_field_gen_rules = {}
            
            # 根据I列实际字段动态生成规则
            for field_key in i_public.keys():
                # 场景相关字段（交易状态类）
                if field_key in ["S_E_TRANSSTAT", "trxStatus"]:
                    if field_key == "S_E_TRANSSTAT":
                        common_field_gen_rules[field_key] = {
                            "规则类型": "场景相关",
                            "命中值": "0",
                            "未命中值": "1"
                        }
                    elif field_key == "trxStatus":
                        common_field_gen_rules[field_key] = {
                            "规则类型": "场景相关",
                            "命中值": "posted",
                            "未命中值": "failed"
                        }
                # 随机生成字段（业务ID类）
                elif field_key in ["S_S_BIZID", "bizId"]:
                    common_field_gen_rules[field_key] = {
                        "规则类型": "随机生成",
                        "格式": "20位数字字母混合"
                    }
                # 固定值字段（策略码类）
                elif field_key in ["S_S_POLICYCODE", "policyCode"]:
                    common_field_gen_rules[field_key] = {
                        "规则类型": "固定值",
                        "值": policy_code
                    }
                # 其他字段：使用I列的固定值
                else:
                    # 这些字段将在"其他字段"规则中统一处理
                    pass
            
            # 添加"其他字段"规则（用于处理未特殊定义的I列字段）
            common_field_gen_rules["其他字段"] = {
                "规则类型": "I列固定值"
            }
            
            scene_k_json = {
                "规则编号": rule_number,
                "注释说明库": k_json.get("注释说明库", {}),
                "公共字段生成规则": common_field_gen_rules,
                "参数值生成规则": {
                    "说明": "通用参数生成策略，根据参数类型自动生成",
                    "时间参数": ["业务发生时间", "事件发生时间"],
                    "时间生成策略": "当前时间随机偏移",
                    "ID参数": ["设备ID", "用户ID"],
                    "ID生成策略": "前缀+随机数字",
                    "账号参数": ["登录账号"],
                    "账号生成策略": "USER_+随机数字"
                },
                "场景": scene,
            }
            try:
                cell_text_k = json.dumps(scene_k_json, ensure_ascii=False)
                ws.cell(row=target_row, column=11).value = cell_text_k
            except Exception as e:
                failed_rows.append((target_row, f"序列化K列场景JSON失败: {e}"))

            # L列：当前场景整体是否命中（命中/未命中 文本）
            hit = scene_hit_map.get(scene_idx_val)
            if hit is not None:
                ws.cell(row=target_row, column=12).value = "命中" if hit else "未命中"

            # M列：为当前场景生成测试用例数据
            # 注意：现在每个K列只包含一个场景，所以直接使用scene_k_json生成
            try:
                scene_testcase_records = generate_testcase_data_for_rule(
                    scene_k_json,
                    result_json,  # J列JSON，包含I列公共字段
                    param_cn_to_en,
                )
                if scene_testcase_records:
                    # 将每条数据格式化为单独的JSON，用换行分隔
                    json_lines = [json.dumps(record, ensure_ascii=False) for record in scene_testcase_records]
                    ws.cell(row=target_row, column=13).value = "\n".join(json_lines)
            except Exception as e:
                failed_rows.append((target_row, f"生成M列测试用例数据失败: {e}"))
                import traceback
                traceback.print_exc()
            
            # N列：生成场景应用名称（D列 + 场景名称）
            try:
                scene_app_name = generate_scene_application_name(d_value, scene_k_json)
                ws.cell(row=target_row, column=14).value = scene_app_name
            except Exception as e:
                failed_rows.append((target_row, f"生成N列场景应用名称失败: {e}"))

        # 注意：H列和I列的合并不在这里处理，而是在所有规则处理完成后，按C列规则集名称统一合并

        processed += 1

        # 可选：每处理若干规则保存一次，避免意外中断丢数据
        # 使用 raise_on_failure=False 让保存失败时不中断程序
        if processed and processed % 10 == 0:
            print(f"[提示] 已处理{processed}行，正在保存中间结果...")
            save_success = safe_save_workbook(wb, output_path, raise_on_failure=False)
            if save_success:
                print(f"[成功] 中间结果保存成功")
            else:
                print(f"[警告] 中间结果保存失败，程序将继续处理，最后再次尝试保存")

        # row_idx 跳过当前规则所占用的所有场景行
        row_idx += num_scenes

    # 所有规则处理完成后，按 C 列（规则集名称）合并 H 列和 I 列
    current_max_row = ws.max_row
    merge_h_i_by_column_c(ws, current_max_row)

    print(f"\n{'='*60}")
    print(f"Sheet [{sheet_name}] 处理完成统计：")
    print(f"  成功写入: {processed} 行")
    print(f"  跳过/失败: {skipped} 行")
    print(f"  总处理行数: {max_row - 1} 行（不含表头）")
    print(f"{'='*60}")
    
    if failed_rows:
        print(f"\n失败行详细信息：")
        for row_num, reason in failed_rows:
            print(f"  第 {row_num} 行: {reason}")
    
    return processed, skipped, failed_rows


def safe_save_workbook(wb, output_path: str, max_retries: int = 5, retry_delay: float = 1.0, raise_on_failure: bool = True) -> bool:
    """安全保存工作簿,带重试机制
    
    Args:
        wb: 工作簿对象
        output_path: 输出路径
        max_retries: 最大重试次数
        retry_delay: 重试延迟(秒)
        raise_on_failure: 失败时是否抛出异常(False时仅返回False)
    
    Returns:
        bool: 保存是否成功
    """
    import time
    for attempt in range(max_retries):
        try:
            wb.save(output_path)
            return True
        except PermissionError as e:
            if attempt < max_retries - 1:
                print(f"[警告] 保存文件失败(尝试 {attempt + 1}/{max_retries}): {e}")
                print(f"[提示] 等待 {retry_delay} 秒后重试...")
                time.sleep(retry_delay)
            else:
                print(f"[错误] 保存文件失败,已达到最大重试次数: {e}")
                if raise_on_failure:
                    raise
                else:
                    return False
        except Exception as e:
            print(f"[错误] 保存文件时发生未预期的错误: {e}")
            if raise_on_failure:
                raise
            else:
                return False
    return False


def process_rules_file(input_path: str, output_path: str, api_key: str, param_dict_path: str) -> None:
    """处理规则文件（支持多sheet页），对 F/G 列进行条件拆分，并将 JSON 写入 J 列。

    - 输入：
      - F 列：规则描述
      - G 列：指标标识（换行分隔）
    - 输出：
      - J 列：条件拆分 JSON（字符串形式写入单元格）
    """
    print("=" * 60)
    print("规则条件拆分程序（多Sheet支持）")
    print("=" * 60)
    print(f"输入文件: {input_path}")
    print(f"输出文件: {output_path}")
    print("=" * 60)

    # 加载工作簿
    wb = load_workbook(input_path)
    
    # 获取所有sheet页名称
    sheet_names = wb.sheetnames
    print(f"\n发现 {len(sheet_names)} 个Sheet页: {', '.join(sheet_names)}")
    
    # 统计信息
    total_processed = 0
    total_skipped = 0
    all_failed_rows = []
    
    # 遍历处理每个sheet页
    for sheet_name in sheet_names:
        ws = wb[sheet_name]
        
        # 处理单个sheet
        processed, skipped, failed_rows = process_single_sheet(
            ws, wb, output_path, api_key, param_dict_path, sheet_name
        )
        
        total_processed += processed
        total_skipped += skipped
        
        # 记录失败行（带sheet名称）
        for row_num, reason in failed_rows:
            all_failed_rows.append((sheet_name, row_num, reason))
        
        # 可选：每处理完一个sheet保存一次，避免意外中断丢数据
        print(f"\n[提示] Sheet [{sheet_name}] 处理完成，正在保存...")
        save_success = safe_save_workbook(wb, output_path, raise_on_failure=False)
        if save_success:
            print(f"[OK] Sheet [{sheet_name}] 已保存")
        else:
            print(f"[警告] Sheet [{sheet_name}] 保存失败，将在最后再次尝试")
    
    # 最终保存 - 增加更多重试次数和更详细的错误提示
    print(f"\n{'='*60}")
    print("[提示] 正在进行最终保存...")
    final_save_success = safe_save_workbook(wb, output_path, max_retries=10, retry_delay=2.0, raise_on_failure=False)
    
    if not final_save_success:
        print(f"\n{'='*60}")
        print("[错误] 最终保存失败！")
        print("[原因] 输出文件可能被其他程序占用（如Excel、WPS等）")
        print("[建议] 请执行以下操作：")
        print(f"  1. 关闭所有打开 '{output_path}' 的程序")
        print("  2. 程序已在内存中完成所有处理，数据没有丢失")
        print("  3. 关闭文件后，程序将再次尝试保存...")
        print(f"{'='*60}")
        
        # 等待用户关闭文件，然后再次尝试
        input("\n按回车键继续(请先关闭文件)...")
        
        print("\n[提示] 再次尝试保存...")
        final_save_success = safe_save_workbook(wb, output_path, max_retries=10, retry_delay=2.0, raise_on_failure=False)
        
        if not final_save_success:
            print(f"\n[错误] 仍然无法保存文件")
            print(f"[建议] 请手动将文件复制到其他位置或重命名后再试")
            return  # 不抛出异常，让程序正常退出

    print(f"\n{'='*60}")
    print(f"【全部Sheet处理完成统计】")
    print(f"  处理Sheet数: {len(sheet_names)} 个")
    print(f"  总成功写入: {total_processed} 行")
    print(f"  总跳过/失败: {total_skipped} 行")
    print(f"{'='*60}")
    
    if all_failed_rows:
        print(f"\n失败行详细信息（按Sheet分类）：")
        current_sheet = None
        for sheet_name, row_num, reason in all_failed_rows:
            if sheet_name != current_sheet:
                print(f"\n  Sheet [{sheet_name}]:")
                current_sheet = sheet_name
            print(f"    第 {row_num} 行: {reason}")
    
    print(f"\n输出文件: {output_path}")


def save_output_record(output_path: str, record_csv_path: str) -> None:
    """保存输出文件名到CSV记录文件，每次覆盖。
    
    Args:
        output_path: 输出的Excel文件的完整路径
        record_csv_path: CSV记录文件的路径
    """
    import csv
    
    # 提取文件名（不包含路径）
    filename = os.path.basename(output_path)
    
    # 写入CSV文件（覆盖模式，只写文件名，不写表头）
    try:
        with open(record_csv_path, 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.writer(f)
            writer.writerow([filename])  # 只写入文件名，不写表头
        print(f"\n记录文件: {record_csv_path}")
        print(f"  已记录输出文件名: {filename}")
    except Exception as e:
        print(f"[警告] 保存CSV记录文件失败: {e}")


def main() -> int:
    """命令行入口。"""
    parser = argparse.ArgumentParser(description="规则条件拆分程序（多Sheet支持）")
    parser.add_argument("--input", "-i", dest="input_path", help="输入文件路径（测试用例需求_分页.xlsx）")
    parser.add_argument("--output", "-o", dest="output_path", help="输出文件路径（例如 测试用例需求_分页_输出.xlsx）")
    parser.add_argument("--param-dict", "-p", dest="param_dict_path", help="参数字典文件路径（参数字典.xlsx）")
    parser.add_argument("--record-csv", "-r", dest="record_csv_path", help="CSV记录文件路径（记录输出文件名，默认：output_file_name.csv）")
    parser.add_argument("--api-key", dest="api_key", help="DashScope API KEY，优先级最高，可覆盖配置文件和环境变量")
    args = parser.parse_args()

    # 读取 API KEY（命令行 > 环境变量 > 配置文件）
    api_key_cli = (args.api_key or "").strip() if getattr(args, "api_key", None) else ""
    api_key_env = os.getenv("DASHSCOPE_API_KEY", "")
    api_key_cfg = load_dashscope_config()
    api_key = api_key_cli or api_key_env or api_key_cfg

    if not api_key:
        print("错误: 缺少 API KEY 配置")
        print("请通过命令行参数 --api-key，或在 dashscope_config.json 中设置 api_key，或设置环境变量 DASHSCOPE_API_KEY")
        return 1

    # 文件路径：默认基于脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
    input_path = args.input_path or os.path.join(script_dir, "测试用例需求_分页.xlsx")
    output_path = args.output_path or os.path.join(script_dir, "测试用例需求_分页_输出.xlsx")
    param_dict_path = args.param_dict_path or os.path.join(script_dir, "参数字典.xlsx")
    record_csv_path = args.record_csv_path or os.path.join(script_dir, "output_file_name.csv")

    if not os.path.exists(input_path):
        print(f"错误: 输入文件不存在: {input_path}")
        return 1
    
    if not os.path.exists(param_dict_path):
        print(f"错误: 参数字典文件不存在: {param_dict_path}")
        return 1

    try:
        process_rules_file(input_path, output_path, api_key, param_dict_path)
        
        # 保存输出文件名到CSV记录文件
        save_output_record(output_path, record_csv_path)
        
        print("=" * 60)
        print("处理完成！")
        print("=" * 60)
        return 0
    except Exception as e:
        print(f"错误: 处理过程中发生异常: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
